# Archived task entries, mb.md

The full text of each closed task's entry, as it stood when its live entry was cut to a heading. Frozen: never read, never edited.

**MB.206 — Repository: the two-tier read scope and the page pair, written once** · 3h

_Story:_ As a developer, I want the repository to say "readable in the caller's tiers" and "one page and its count" once each, so that a change to how a tier is read, or how a page is cut, is one edit and not twelve.

Minted on 2026-10-10 from the backend DRY review the owner asked for ([`design-decisions/mb.206-plan.md`](../design-decisions/mb.206-plan.md)), the first of nine (MB.206 to MB.214) and the mechanism the rest adopt. The two-tier read scope — the compendium's rows or a membership's — is written out twelve times across `ingredients.ts`, `references.ts`, `common-names.ts` and `vocabularies.ts`, the "readable parent ingredient" `existsIn` four times, the "live and under a live group" predicate six times, the text fold and the trigram match twice each, and the page-and-count pair six times beside the `findPage` that already does it, which `users.ts` could call today. `predicates.ts` gains `readableInTiers`, `readableIngredientParent`, `curated`, `fold`, `trigramMatch` and `foldedWordMatch`; `select.ts` gains `selectOne`, `selectByIds` and `trgmSettings`; `findPage` and `findPageCount` take a key order and an optional `where`, with `groupedOrder` for the sorts that join a group's name and `vocabularyArms` for the filters, `findPageInCompendium` for the compendium tier and `selectInCompendium` for its one-row reads. The soft-delete finder guard's regex and exact-text pins widen to the new names in the same PR, so the guard goes on seeing the filter through them, and `index.ts`'s pinned export list grows by what services need. `IngredientRow` replaces the inline row type. No SQL changes: the EXPLAIN-plan tests hold their row counts, and the repository and service tests are the proof. As built, where the code corrected the plan: the tier is `inTiers` and `readableInTiers` is it with the row's tombstone filter, so `readableIngredientParent` reads the tier inside `existsIn` without filtering the parent twice, and the spell hatch reads `inTiers` unfiltered; `curated` sits in `vocabularies.ts` beside `inLiveGroup`, whose `groupingOf` now files the categories too, which is what lets `vocabularyArms` take a vocabulary and its filter; `findPage` and `findPageCount` take a sort or a `ListOrder`, so the services and `tests/db/pagination.test.ts` keep passing a sort, and the compendium's sibling is `findPageInTiers` with `findPageCountInTiers`, under no proofs for the compendium alone and under one for the substitute picker, the duplicate lookup and the reference picker; `trgmSettings` is `readUnder`, the transaction both a similarity read and a keyset read set their thresholds in; `findOneById`, `findOneBySlug` and `findOneByIdInWorkspace` read through `findOne` and `findOneInWorkspace`; `selectByIds` and `selectInCompendium` were not built, since an empty-list guard is one line before reads of five different shapes, two of them joined, and the compendium's one-row reads are already two predicates each; and `TIER_SEAM` in `tests/guards/module-boundaries.test.ts` widens by name to the five builders, which it lists, so the finders reading both tiers through them stay counted.

_Acceptance criteria:_

- No exported finder spells the two-tier scope or the page-and-count pair by hand, asserted by the soft-delete finder guard
- The two EXPLAIN-plan tests hold their row counts, and the repository and service tests are unchanged and green
- The guard pins each new predicate by name, and `index.ts`'s export list is pinned as before
- `claude-docs/db/sql-fragments.md` and `workspace-ingredients.md` name the predicates

**MB.207 — Schema: the vocabulary columns, indexes and the sourced-entity registry from one place** · 2h

_Story:_ As a developer, I want a curated vocabulary's table to declare its shared columns and indexes by one builder, and the sourced entities to be listed once, so that a new vocabulary or a new sourced table cannot drift from its siblings.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`). The eight vocabulary tables each spell the uuid id column, the slug and seed-key partial uniques, the description CHECK and the trigram index by hand, and the review found the drift that invites: `categories` and `category_groups` lack the blank-description CHECK the other six carry (MB.214). `src/db/schema-parts.ts`, client-free beside `audit.ts`, gains `idColumn`, `liveUnique`, `vocabularyColumns` and `vocabularyIndexes`, producing the same names and the same DDL, which `db:generate` writing no migration proves; the builder takes a flag for the two tables without the CHECK until MB.214 adds it. `spell_ingredients.quantity` takes the precision `quantities.ts` says is "written down once". The audit column names, listed by hand in four places, derive from the factories' keys. `reference_links` lists its five sourced entities once, as a registry its FK columns, partial uniques and `num_nonnulls` CHECK are built from, and MB.208 puts the repository's finder and `citesNothing`, hard-wired to the ingredient column today, onto it, so sourcing a deity or a planet is a row in the registry and not a copy of each. The repository half is MB.208's rather than this task's because MB.206, built beside this one, rewrites the same finder.

_As built:_ `liveUnique(name, table, ...columns)` takes the table, since the predicate names its `deletedAt`, and covers the eight indexes outside the vocabularies whose only predicate is the tombstone, beside the eight vocabulary slugs; one with a predicate of its own stays written out. `seedKeyColumn` and `seedKeyUnique` sit beside it, so `references`, the ninth table with a seed key, shares MB.171's comment and index with the vocabularies. The option is `vocabularyIndexes(prefix, table, { trigram, descriptionCheck })`, `descriptionCheck` defaulting to true. The registry is `SOURCED`, mapping each `referenceLinks` property to `{ column, table }`, with `SourcedKey` its keys. `drizzle-kit export` differs from before only in the source's column order on the four item and group tables with a column of their own, which no migration reads, and `db:generate` writes nothing.

_Acceptance criteria:_

- `npm run db:generate` on the branch writes no migration: the DDL is byte-identical, index and constraint names included
- The catalogue sweeps and `tests/db/audit-columns.test.ts` are green unchanged
- One place lists the sourced entities, and `reference-links.ts`'s header says truthfully what a sixth costs
- `spell_ingredients.quantity` reads its precision from `quantities.ts`

**MB.208 — Seed: one key reader, one actor publisher, one two-tier registry** · 2h

_Story:_ As a developer, I want the seed to build each idempotent insert's key once, publish the actor the way `withAudit` does, and read the two-tier pairs from the same list the repository reads, so that a seed file is data and not a second copy of the mechanism.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`). Eight `insertMissing` call sites write the same composite key twice, once for the live rows and once for the wanted rows, and two "one caller is not worth a helper" copies return ids; `insertMissingBy` and `insertMissingReturningIds` in `idempotent.ts` take them. `withAudit` publishes four session settings and says every write does, but the seed publishes two: `publishActor` in `src/db/audit.ts` serves both, and the seed then publishes all four, a behaviour change named in the PR. The two-tier pairs are declared in about eight places across the repository and the seed, and each seed file names the item's group key twice per call; `src/db/vocabularies.ts`, tables and types only, lists `TWO_TIER` and `FLAT` once, `groupingOf` and the unions derive from it, and `reslugItems` folds into `seedTwoTierVocabulary` so `forms.ts` and `deities.ts` call once. `findReferencesOf(memberships, column, ids)` over MB.207's registry replaces `findReferencesOfIngredients`, and `citesNothing` takes the column, both on MB.206's predicates. The seed's hand-written row types become `Pick`s of the table's insert type, so a renamed column fails there as it already does for users and ingredients.

_As built:_ `insertMissingBy` takes a `where` beside `fold`, reads only the wanted values for a one-column key, and serves eleven sites, the eight named plus W's ingredients, the demo's jars and the sources seed's links, whose `linkKey` it replaces; `insertMissing` stays for the vocabularies' `presentKeys`, and `insertMissingReturningIds` takes the caller's own present map and a `keyOfRow`, since the two callers decide what present means differently. `publishActor`'s executor is any `{ execute }`, typed in `src/db/types.ts` beside `PublishedActor`, and the seed's transaction test, `tests/db/seed/idempotent.test.ts`, gives its one connection a stale session value of each setting first, so a setting left unpublished reads as that rather than as Postgres' empty placeholder. Each `TWO_TIER` entry is `{ items, groups, key, column }`, the property the seed writes and the column a finder joins by, and `ItemTable`, `GroupTable`, `FlatTable` and `PickedTable` (forms and deities, the two an ingredient picks by id) are derived beside it; `seedTwoTierVocabulary` takes the entry as `vocabulary` and `slugOf(name, groupName)`, which also runs the reslug. `findReferencesOf` and `citesNothing` take a `SourcedKey` rather than a column, since the finder needs the parent's table, which the registry maps the key to, and a key cannot name a column that is not a sourced link; a sourced row other than an ingredient is global, so its links read while it is live and only to a compendium reference, asserted in `tests/db/repository/references.test.ts`. `SourceTargetTable` derives from `SOURCED`, whose `SOURCED_KEYS` is exported for the sources seed. The one test edited is the references loader's spy, renamed with the finder. The vocabulary module's own `typeof ingredientForms | typeof deities` unions, in `modules/vocabulary/types.ts` and `services/groups.ts`, are left: they sit above the database layer.

_Acceptance criteria:_

- `tests/db/seed/**` and `seeded-template.test.ts` are green unchanged
- The seed's transaction publishes the four session settings `withAudit` publishes, asserted
- One module lists the two-tier pairs, and the seed and the repository both read it
- No seed file builds an `insertMissing` key twice

**MB.209 — Validation: one `requiredText`, one `RowId`, one link-or-name rule** · 1.5h

_Story:_ As a developer, I want the shared validation shapes — a required text, an optional text, a row id, a link-or-name entry — written once, so that a message or a rule changes in one place and no schema disagrees with its service.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`). A bug first, regression test first: `category.ts`, `deity.ts` and `ingredient-form-value.ts` take their parent id with `z.uuid()`, while every service checks `RowId`, which is `z.guid()` precisely because a hand-written fixture id fails `z.uuid()`; the three take `RowId`. `src/lib/validation.ts` gains `requiredText` and `optionalText`, written four times today, and `curatedValueInput(noun)` for the six name-and-description pairs, on `astrology-value.ts`'s factory. The substitute and deity entries' "a link or a name, exactly one, listed once" rules are one `linkOrNameRules` with one `LinkOrName` type, and the case-folded seen-set loop is one. The 17 reference fields are listed in six places: `ReferenceTextField` derives from `CitationFields`, and `REFERENCE_TEXT_FIELDS` is exported from the formatter's table for MB.212 to build the GraphQL types from. The day regex and the quotation-mark set live in `lib/citation.ts`, which validation may import, and the two date messages become one. `lib/contrast.ts` exports `HEX_COLOR` for the group validation's colour check, the two component copies of it MB.115's, and `channels` for `group-colors.ts`, which converts a hex to channels a second time.

_Acceptance criteria:_

- The regression test fails on `staging` and passes here: a fixture-shaped group id reaches the service's "no such group" refusal, not a format refusal
- `tests/modules/*/validation/**` otherwise unchanged and green
- No validation file declares its own required-text helper, day regex or hex regex
- `REFERENCE_TEXT_FIELDS` is the one list of the reference's text fields

_As built:_ the three parent ids take `requiredRowId(message)`, `RowId`'s `z.guid()` with the field's message, since a bare `RowId` would have lost "Choose a group" and "Choose a tradition"; and the regression test is the schemas', a fixture-shaped id parsing as `groupId` or `traditionId`, since the service's live-row refusal says the same "Choose a group" and so cannot tell the two apart. `optionalText(format?)` takes the reference formatter's tidying as its argument and keeps blank as `null`; `CompendiumFilter` maps `null` to `undefined` itself, so the filter's other meaning of absent stays at its call site. The reference title stays its own required field, since it is formatted before the blank check rather than trimmed. The one date message is "Give the day as YYYY-MM-DD", in `CalendarDay`, which `StockInput`'s `acquiredDate` now speaks too. Filing a citation less its leading quotation mark now strips a guillemet as well, since the set is the formatter's.

**MB.210 — Vocabulary and identity services: the curated write steps once** · 3h

_Story:_ As a developer, I want each curated vocabulary's service to say what is its own — the deity's slug under its tradition, the form's rename carried onto entries, the group's colours — and nothing else twice, so that a change to how a slug collision or a move is refused is one edit across the seven.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`), on the owner's call for shared helpers rather than a descriptor factory: each exported service keeps its own function and JSDoc, and `tests/guards/compendium-expiry.test.ts`, which reads each exported admin write for `assertSiteAdmin(` and `expireCompendium()`, keeps counting them. The seven vocabulary services repeat the slug-collision refusal seven times, the "an id that is not a uuid names nothing" lookup fifteen, the page walk four, the move-target refusal three, the held-entries refusal four, the parent check three and the list-and-count pair three. `vocabulary/services/curated-writes.ts`, internal like `group-moves.ts`, holds `refuseSlugCollision`, `liveRow`, `moveTarget` and a `deleteGroup` built on `MovedRows`, which gains the parent column and the child's slug rule; `allPages` goes to `lib/pagination.ts`; `held-entries.ts` gains `refuseWhileHeld` and is the one `describeEntry`, the compendium's quoted variant retired and one style chosen, and `redirectRefusal` serves both ending-a-redirect refusals; `parseUnderLiveParent`, `readableFilter` and `cachedFilteredList` take the rest, the cache keys kept unique for the cache guard. `plural`, `joinAnd` and `inIdOrder` go to `src/lib/`. Coven exports `readersOf` for the five "compendium only, or this coven too" copies. Identity: `liveUser` once, `assertAdminChangesOpen` for the five check-then-pause pairs, `isSiteAdmin` and `refuseBatch` for the three hand-written role checks, `adminDeclaration` for the three trimmed notes. `ingredients/types.ts` drops its `CategoryRow` for vocabulary's export.

_Acceptance criteria:_

- `tests/guards/compendium-expiry.test.ts` counts no fewer admin writes
- Every service test is unchanged and green, and the `Forbidden` count per service file is not lower (MB.187's criterion)
- No service file defines a local slug-collision refusal, move target, `describeEntry` or page walk, asserted by a guard over `src/modules/*/services`
- The admin e2e specs pass

_As built:_ `curated-writes.ts` holds `refuseSlugCollision`, `liveRow`, `parseUnderLiveParent` and `moveTarget`, and `updateGroup` beside `deleteGroup`, so the category group's plain rename shares one body with the two re-slugging ones: a `CuratedGroup` descriptor carries its `members` as `MovedRows`, which gained `nouns`, `parentColumn`, `slugOf` (absent for a category, whose slug its group is no part of) and `under`, the walk that reads them. `readableFilter` and `cachedFilteredList` are `curated-lists.ts`, each service still spelling its own two cache keys where the cache guard reads them. The slug refusal's sentence is `addressTaken` in `src/lib/text.ts`, which the compendium's and a coven's slug refusals speak too, since neither can reach the vocabulary's internal step; `group-moves.ts`' move refusal keeps its own sentence, which its tests assert. `describeEntry` names an entry unquoted, the vocabularies' style, so the compendium's identity and redirect refusals lose the quotes round the label, seven assertions in `tests/modules/ingredients/services/compendium-entries.test.ts` and two in its GraphQL twin changing with them: the only service tests the task changed, and fewer than the quoted style would have, which would have changed some twenty vocabulary assertions and `admin.spec.ts`. `inIdOrder` replaced the three one-answer-per-id shapings there are, `groupsOf`, `formChoicesOf` and `usersForAdmin`, the O(n²) one; `liveUser`, `adminDeclaration`, `isSiteAdmin` and `refuseBatch` are identity's internal `admin-changes.ts`, `assertSiteAdmin` reading the role through `isSiteAdmin` and `assertWorkshopAccess` calling `assertSiteAdmin` in its own words. `ingredients/types.ts` re-exports vocabulary's `CategoryRow`, so its importers stand. The guard is `tests/guards/curated-write-steps.test.ts`.

**MB.211 — Ingredient writes: the child sequence and the input fields once** · 2h

_Story:_ As a developer, I want a sixth child table of an ingredient to cost one writer, one loader and one input field, so that the compendium's write and the coven's cannot drift apart.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`). The compendium's and the coven's create, update and delete make the same five child calls in the same order, in two files that always change together, and their four GraphQL input types declare the same sixteen fields; the five child-loader clears after an update are written twice, and nothing would catch a sixth loader missed in one. `ingredient-rows.ts` gains `ingredientColumns` and `writeChildren`, so each write makes one call, and the tier-message choice is one function; `loaders/ingredient-children.ts` exports `clearIngredientChildren`, built from the loaders it defines; `graphql/ingredient-input.ts` exports `ingredientInputFields` for the four input types to spread, with the two switches they differ by. The SDL is unchanged, which the committed snapshot proves.

_Acceptance criteria:_

- `src/graphql/schema.graphql` is unchanged
- Each of the two services makes one child call per write, and a loader added beside the others is cleared by both mutations without either being edited, asserted
- Service and GraphQL tests unchanged and green
- `claude-docs/db/compendium-writes.md` and `workspace-ingredients.md` say what a sixth child table costs

_As built:_ the two switches are `{ tier, whole }`, since the tier also words `formId`'s description; `SubstituteInput` and `IngredientDeityInput` moved into `ingredient-input.ts` beside the fields that use them. `ingredient-rows.ts` also gained `splitChildren`, so a service passes the parse's child lists on unnamed, and `softDeleteIngredient`, the two deletes' body; the child writers it calls are no longer exported. The loaders are one record that `clearIngredientChildren` walks, and `tests/guards/ingredient-child-loaders.test.ts` asserts it covers every loader the file defines and that neither mutation clears one by hand.

**MB.212 — GraphQL transport: the resolver plumbing and the curated-vocabulary writes once** · 2.5h

_Story:_ As a developer, I want a resolver to hold only what the transport adds, so that the session narrowing, the null-to-undefined mapping and a curated vocabulary's three writes are written once and not in every file.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`), on the owner's call for a factory here beside the small helpers, the committed SDL being the proof it changed nothing. The compile-time session narrowing is written 48 times across sixteen files, the argument mapping in six filter helpers and about fourteen inline coalesces, the suggestion field six times, the loader wrapper seven; the six curated-vocabulary files repeat one object type, one input type and eighteen mutation fields, three of them the same delete-with-move. `src/graphql/context-helpers.ts` gains `sessionOf`, `definedArgs`, `suggestionConnection` and `pageStart`; `define-loader.ts` gains `defineSignedInLoader` and `definePublicLoader`; `vocabulary/graphql/curated.ts` gains `curatedVocabularyWrites`, on the astrology loop's precedent, every field description passed through so the SDL does not move; the reference object and input types build from MB.209's `REFERENCE_TEXT_FIELDS`. The guard is a lint rule: `.oxlintrc.json`'s GraphQL override refuses the inline narrowing once `sessionOf` exists. The real gate is the service, so no authorization moves.

_As built:_ oxlint 1.86 has no `no-restricted-syntax`, so the guard is a `no-restricted-imports` entry in a `src/modules/*/graphql/**` and `src/modules/*/loaders/**` override refusing a runtime import of `Forbidden`, which the inline narrowing cannot be written without, probed by `tests/guards/lint-resolver-session.test.ts`. `curatedVocabularyWrites` takes `fields` and `input` beside `parent` for a vocabulary's own columns, and `moveTo` as the loaders a move leaves stale; the astrology loop adopts it too. `pageStart` was not built: of its two copies, `src/graphql/pagination.ts`'s and `src/lib/pagination.ts`'s, the second is MB.210's file, and the helper belongs there beside `decodeCursor`, below the transport.

_Acceptance criteria:_

- `src/graphql/schema.graphql` is byte-identical, so `codegen` is a no-op
- The lint entry refuses the inline session narrowing in `src/modules/*/graphql/**`, and `npm run lint` is green
- The query-scope sweep and `tests/graphql/**` unchanged and green
- The vocabulary admin e2e specs pass, and `claude-docs/graphql/schema.md` and `loaders.md` name the helpers

**MB.213 — Auth, sign-in and mail: the provider roster once, the gates once** · 2h

_Story:_ As a developer, I want a fifth sign-in provider to be one row the compiler checks, and the verification gates and mail templates to say each thing once, so that `auth.ts` cannot silently skip a provider or reword a refusal.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`). `auth.ts` configures the four providers as four near-identical blocks under a switch with no exhaustive default, so a provider added to the roster would compile and not register, against `social-providers.ts`'s own claim that it is "one entry here"; a `PROFILE` record keyed by `ProviderId` holds what differs — the account id's field, whether the provider vouches for the address, Microsoft's tenant — and `mapProfile` builds each block. The provider-id and role casts become the checks `request-session.ts` already has, exported; the three "signed in to this account" gates, the two quiet sweeps and the two set-or-throw-in-production reads become one each; `sign-in.ts`'s three identical message lookups become one, its repeated sentences written once. The two mail templates share `defineMessage`, `actionVerb`, `BaseEmailProps` and the ignore paragraph, and the two senders share `requestOrigin`. The colour helpers are MB.209's.

As built: `PROFILE` sits in `social-providers-config.ts` beside the credentials, not in `social-providers.ts`, which a client component imports and which must carry no env var name (Microsoft's tenant reads one); `mapProfile` stays in `auth.ts`, the one importer. The checks could not be exported from `request-session.ts`, which imports `auth`: `isRosterProvider` moved beside the roster and `toUserRole` into `src/lib/session-role.ts`, reading `userRole.enumValues`. `requiredInProduction` is `src/lib/env.ts` and `requestOrigin` `src/lib/request-origin.ts`, since `primary-admin.ts` and the senders must not load `auth` at import; `linkedProviderIds` is exported from `auth.ts`, which `email-verification.ts` already imports at call time. The ignore paragraph is `IgnoreNote`. The fourth `SIGN_IN_TO_VERIFY` wording, on the email page, is a different sentence for a different reader, and stays.

_Acceptance criteria:_

- `npm run build` is green
- A fifth `ProviderId` without a `PROFILE` entry fails `typecheck`, asserted by a type test
- `tests/lib/**`, the identity services and the email stories unchanged and green
- The sign-in e2e specs pass

**MB.214 — Categories and category groups refuse a blank description** · 0.5h

_Story:_ As a site keeper, I want a category or a category group with a blank description refused at the database as a form or a deity is, so that the vocabularies hold to one rule however a row reaches them.

Minted on 2026-10-10 from the backend DRY review (`design-decisions/mb.206-plan.md`), the drift MB.207 found when it put the vocabulary indexes through one builder: six vocabulary tables carry a blank-description CHECK and `categories` and `category_groups` do not, though `description` is `notNull` on both and the zod input refuses a blank. One migration adds the two CHECKs under the siblings' naming, additive DDL with no sidecar; the builder's flag goes; a `db` test asserts each constraint by name. Its own task after MB.207 because it changes the database and MB.207 must not: a table task, then a behaviour task.

_As built:_ The migration is `0060_category-description-checks`, the two `ADD CONSTRAINT … CHECK (btrim(description) <> '')` statements alone; no live row can fail it, since the seed writes none and both keeper inputs trim and refuse a blank. The tests extend `categories-schema.test.ts`, reading each CHECK by name from `information_schema` and refusing `''` and `'   '` with `23514`. DESIGN.md §5's `categories` entry now says the description is non-empty on both tables, since `db/categories.md` had called its absence a difference in the specification.

_Acceptance criteria:_

- Both constraints exist by name in `information_schema`, asserted
- A blank description is refused at the database with the constraint named
- The vocabulary index builder takes no flag
- `npm run check:destructive-ddl` reports nothing

**MB.224 — Tests assert functional requirements: the rules, lint carries the architecture guards, harness tests go** · 3.5h

_Story:_ As a maintainer, I want the test suite to hold only tests of functional requirements, written down as rules every later task follows, so that a reworded label, a renamed helper or a CI edit breaks no test and the suite's time is spent on behaviour.

Minted on 2026-10-11 on the owner's call ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)): MB.70's title-case change broke five test files that asserted wording and no behaviour, and three surveys found about 2,700 of the suite's 5,808 cases asserting copy, class names, the harness, CI wiring, docs, scripts, column lists, past fixes or a rule another layer already proves — tests at 1.9× the source. This task writes the ten rules into `claude-docs/testing/layer-ownership.md` ("What a test may assert"), points `.claude/rules/testing.md`, `CLAUDE.md`, `testing/coverage.md`, `acting-as-fixture-users.md`, `e2e.md` and `acceptance.md` at them, moves the architecture guards lint can carry onto oxlint (`.oxlintrc.json` import bans, `import/no-cycle`, `lint/sorrel-lint.js` for `'use server'`, `server-only`, the route allowlist and the pagination helper), keeps the six Vitest sweeps that read the schema, the catalogue or the module graph, and deletes the tests of the harness, CI YAML, docs, scripts and skills tooling (`tests/guards/` 43 files → 6, `tests/support/*.test.ts` → 1, `tests/scripts/` gone, `tests/scss` and `tests/graphql` trimmed). It lands first because the six lanes beside it (MB.225–MB.230) cite its rules by section, and it is one PR because the rule and the guards it retires are one decision.

_Acceptance criteria:_

- The ten rules are in `layer-ownership.md` under "What a test may assert" and the six pointer docs name it
- `npm run lint` fails on a probe file for each rule moved onto oxlint, shown once in the PR body
- `tests/guards/` holds the six named files and nothing else; `tests/scripts/` is gone; `tests/support/` holds one test
- `vitest.config.mts`'s `unit` project runs no `globalSetup` nothing reads
- Every doc that named a deleted guard or script test is corrected
- Per-file coverage is unchanged, and the `Run vitest` step time is recorded against the plan's baseline

_As built:_ oxlint 1.86 loads `lint/sorrel-lint.js` through `jsPlugins`, so the plan's four rules are plugin rules, with a fifth, `module-boundaries`, carrying the `ALLOWED` module map, the relative deep imports, a module importing presentation and the repository's index-only surface; `import/no-cycle` is on everywhere but `src/db/repository/*.ts`, whose `select.ts` and `predicates.ts` import each other's builders. `tests/guards/` holds eight files, not six: the plan's fallback applied twice, since the destructive-DDL leg runs the scan but not `--self-test` and `scripts/assert-pulled-env.ts` has no self-test, so `destructive-ddl-check.test.ts` keeps its seven rule cases and `pulled-env-assertion.test.ts` its six no-secret cases. The codegen staleness check is a `checks / codegen` leg in `checks.yml` rather than a test. The `unit` project keeps its `globalSetup`, which three surviving guards `inject`. The soft-delete guard reads the finders off the repository's index instead of a pinned list, so a new finder is checked without being listed. `tests/support/as-user.test.ts`'s compile assertion moved to `tests/support/as-user.type-check.ts`, and `tests/support/story-naming.ts` went with its last reader. Comments naming a retired guard are rewritten to the fact they carried, and `.ladle/config.d.mts`, read only by the workshop guard, is gone.

**MB.225 — `tests/db/`: catalogue sweeps once, seed content once, harness tests gone** · 2.5h

_Story:_ As a maintainer, I want the database tests to prove each cross-table invariant once and each seed's behaviour once, so that a `db` run pays for behaviour and not for template clones spent on harness arithmetic and column lists.

Minted on 2026-10-11 with MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)). `tests/db/` holds 746 cases outside the repository tests; the survey found the audit-column sweep pinning every table twice, the scope sweep refusing each keeper write as four fixture users who differ only by coven, 54 seed-key cases repeating the partial-unique sweep or memorialising shipped backfills, four seed files of developer-only scenarios, and tests of the connection budget, the seeded template and the fixture inserters — each a file that clones the template for nothing a user depends on. The task deletes those, trims the sweeps to one pass each, keeps every behavioural rule whole, and makes the small repository trims (`compendium-search-query`'s SQL-shape cases, the import-cycle memorial, the service repeats in `invitations`).

_Acceptance criteria:_

- `tests/db/` holds no test of the harness, a developer-only scenario or a seed's doc wording
- Every admin write is refused once as a non-keeper in the scope sweep, which still asserts its field list equals the schema's
- The five production seeds each pass the three shape sweeps in `seed/index.test.ts`
- `audit-columns.test.ts` reads the catalogue once
- Per-file coverage of `src/db/**` is not below the previous run, and the `Run vitest` time is recorded

_As built:_ `tests/db/` runs 495 cases in 39 files where it ran 948 in 51. Twelve files go whole: the harness's (`connection-budget`, `seeded-template`, the two inserter tests), the developer scenarios' (`seed/demo`, `reset`, `standard`, `idempotent`), `seed-keys`, `append-only-trigger`, `bootstrap` and `repository/index`. `audit-columns.test.ts` is one case reading the catalogue once, every audited table's columns, nullability and `users.id` keys compared at once and the three adapter tables proved to carry none. The scope sweep runs each keeper write as A alone, and holds its precondition in the same case: E is admitted past the scope, and `assertSiteAdmin` refuses A in other words than the scope's default. `seed/index.test.ts` runs its three sweeps over the five seeds `migrate.yml` runs, beside `minimal` leaving no keeper and an unknown scenario refused; each per-seed file keeps what a reseed leaves of a keeper's edits, `sources` its compendium keying and a tradition's source reaching its deities, and `categories` one contrast sweep whose grounds it reads from `_variables.scss` rather than pins. Where the plan was wrong: `pagination.test.ts` keeps "passes any other database error through unchanged", the only test of `select.ts`'s rethrow, so `src/db/**` keeps its coverage; the email-change body sentence was one assertion in a case that stays; and the two compile-time finder refusals in `pagination.test.ts` sit at module level, out of any `it`. The `db/*.md` and testing docs that named a deleted test now name what holds the rule, or say review does.

**MB.226 — Module schema and validation tests: shape once, behaviour particular to the table** · 3h

_Story:_ As a maintainer, I want a table's shape asserted once and its tests to hold only the behaviour particular to it, so that a column added to a table is one test edit and not a dozen.

Minted on 2026-10-11 with MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)). The 734 module schema cases pin each column property three times — in code, from the catalogue, then by behaviour — repeat the partial-unique pair thirty times, loop every enum member in three places, keep data tests for migrations already in production's journal, and hold 18 memorials of removed columns; four vocabulary schema files are one file copied four times over a registry that exists (`src/db/vocabularies.ts`). The 339 validation cases re-test the shared builders `tests/lib/validation.test.ts` owns and run one input schema twice across two variants that share every field. The task adds one `tests/db/schema-drift.test.ts` comparing `getTableConfig` with the catalogue for every table, a registry-driven vocabulary schema file and a join-table template, and trims every schema and validation file to its exact-column test plus what is particular to it, messages asserted by `failedPaths`.

_As built:_ the drift test compares each column's type too, `format_type` against Drizzle's spelling with a bare `timestamp` and a numeric's precision normalised, which is what retires the per-file type pins; it compares index names, uniqueness and partiality but not predicates or expressions, so the trigram, unaccent and folk-name gin indexes keep one catalogue read each of their expression, and an enum's members are held by one `enum_range` equality per table that has one. It carries `PENDING_DROPS`, empty today, the declared expand/contract window: the undeclare task of a two-PR drop adds its objects, the drop task removes them, and a line outliving its drop fails the file. The vocabulary file runs 26 cases over `TWO_TIER` and `FLAT` (each table's exact columns and blank-description CHECK, the slug and display-name rules per two-tier pair, the trigram index per searched table), and `ingredients.form`'s identity rule — text, never a key — moved to `ingredients-schema.test.ts` as the table's own foreign keys held to its workspace and `form_id`, with `ingredients_form_id_has_form`'s refusal beside it. Every migration's data test went, the migrations all being in the journal and production not live: 0011, 0018, 0026–0027, 0030–0031, 0034–0035, 0037, 0032 with 0039, 0041 with 0048, 0050, 0055 with 0058 and 0057 with 0059. The two `` `@ts-expect-error` pins on generated columns went as property pins; the two `namedWrites` compile-time tests stayed. Schema files went from 734 cases in 28 files to 213 in 22 plus the drift test's 32, validation from 339 in 10 to 143 in 8.

_Acceptance criteria:_

- `schema-drift.test.ts` compares every table's columns, constraints and indexes with the catalogue and asserts the table set non-empty, leaving out only what its `PENDING_DROPS` declares, and fails a pending drop the catalogue no longer holds
- No schema file holds a catalogue read, a property pin, a "no X column" case, a partial-unique pair or a per-enum-member loop; each keeps its exact-column test and every CHECK, identity and tier behaviour
- The four vocabulary schema files are one registry-driven file; the two join tables share one template
- No data test of a shipped migration remains, each listed in the PR body with its journal entry
- Validation files assert through `failedPaths` and only what their schema adds over `src/lib/validation.ts`
- Per-file coverage of the module schema and validation directories is not below the previous run, and the `Run vitest` time is recorded

**MB.227 — Services, GraphQL, loaders and acceptance: one refusal per rule, the transport's half only** · 3.5h

_Story:_ As a maintainer, I want each authorization rule refused once with its precondition and each GraphQL file to prove only the transport, so that a refusal's sentence can change without a test and a service rule is not run five times at five layers.

Minted on 2026-10-11 with MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)). About 140 service rows refuse the same write as fixture users A, B, C and D, who differ only by coven while the check reads the site role; 162 service, GraphQL and validation assertions pin a refusal's sentence beside a check that already pins its class, code or path, against `acting-as-fixture-users.md`'s "assert the type, never the message"; the GraphQL files re-run scope refusals the field sweep owns and signed-out cases its loop owns; the loader access matrix runs three times through one `admit()`; the 51-row permission matrix is 51 cases. The task collapses each to one row with its precondition, loosens every sentence to its kind (and `stringContaining` of the entry named, where the title promises it), deletes the SQL-text and architecture-demo files, and loosens the acceptance suite's refusal messages to classes and `reason` codes without removing a test.

_Acceptance criteria:_

- For every service rule exactly one direct-id refusal with its precondition remains; the PR body lists `Forbidden` expectations per file before and after, naming the A–D rows removed
- No GraphQL file calls `run(null, …)` or asserts a non-keeper refusal on an `ADMIN_WRITES` field, and every `fieldErrors` assertion names a path and no message
- No `toThrow('<sentence>')` remains outside the sentinel and exported-constant forms
- `npm run test:stories` prints one line per story
- Per-file coverage of `src/modules/**/services/**` and `src/graphql/**` is not below the previous run, and the `Run vitest` time is recorded

_As built:_ 116 A–D rows collapse to A with its precondition (A's role is `user`, and E's same call succeeds), only where the check reads the site role alone; the 51-row permission matrix is one `toEqual`; `two-transports.test.ts` and `suggestions-query.test.ts` go, and the two plan tests keep only their EXPLAIN and row counts; every sentence becomes a class, a `reason`, a `path` or a `stringContaining` of the entry named; the GraphQL files lose their admin-scope and signed-out refusals and every message beside a code; the child loaders' access cases run as one matrix over the three; the RSC dedupe is one test. 1,394 → 1,093 cases in the lane's directories, and coverage of the services and the GraphQL layer is unchanged. The GraphQL harness is still called with a `null` session for the public reads (MB.80) — the compendium, an entry and the vocabularies — which are the public surface's own behaviour, not a signed-out refusal. Follow-up: one registry-driven GraphQL file over `curatedVocabularyWrites` (`src/modules/vocabulary/graphql/curated.ts`) in place of the per-vocabulary write cases.

**MB.228 — Component tests: the owner component once, no noun matrices, no presentation, no copy** · 4h

_Story:_ As a maintainer, I want each component behaviour tested in the component that has it, once, by the state it leaves, so that a relabelled button, a renamed class or a second vocabulary adds no test.

Minted on 2026-10-11 with MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)). Of 732 component cases the survey found 258 that run shared behaviour once per noun (`GroupedValueList` three subjects, `GroupedValueForm` three kinds, `VocabularyValueForm` and `VocabularyValueList` two vocabularies, `ListField` four variants and six lists), re-test `Pager` and the filter in every list, assert class names, CSS variables, mocked layout and animation frames in jsdom, pin bugs fixed before any PR, or re-run a lib rule through its caller — plus the copy assertions MB.70's change broke. The task runs each shared path on one row, moves each behaviour to the component that owns it, drops presentation and memorials, replaces every copy assertion by the presence of the status, alert, tooltip, row or description that the action left, and removes the fixture fields and constants nothing reads any longer.

_Acceptance criteria:_

- No component test asserts copy, a class name, a CSS variable, a mocked layout or an animation state
- No `describe.each` over a config table runs shared behaviour on more than one row; Pager and filter behaviour appear in `Pager` and `CompendiumList` only
- The dead fixture fields in `tests/support/types.ts` and the dead constants are gone
- `IngredientForm/index.test.tsx` is under 8 s in the slowest-files block
- The component docs' Testing sections describe the tests as they are
- Per-file coverage of `src/components/**` is not below the previous run except where the PR body names the file, and the `Run vitest` time is recorded

_As built:_ The component suite went from 732 cases to 460, in 34 files rather than 36: `Backdrop`'s test went whole, a decoration having no behaviour for jsdom to prove, and `UserList/layers.test.ts` with the stacking it pinned. The form's resolver rows moved to `tests/modules/ingredients/validation/ingredient-resolver.test.ts`, asserting the issue lands on `form` rather than its sentence, and the linked substitute's refused link to `list-field.test.tsx`, the block it sat in having rendered `ListField` alone. Shared rows run once: `GroupedValueForm`'s seven on the category, `GroupedValueList` on the deities, the other kinds keeping only their address and parameter, `VocabularyValueForm` and `VocabularyValueList` on the planets, the form keeping each vocabulary's three mutations, and `ListField` on a plain and a pick-only list, two payload shapes. Copy became state: a status or alert's presence, the data it carries, an accessible description present or absent, a busy caption the pre-click handle's `aria-busy`, and a note or status joining a field's description counted by its `aria-describedby` ids where the field also carries a hint. Copy that is a state's one rendering stays: `UserList`'s Yes and No and its Verified mark, `EmailForm`'s status lines, and which lock reason won. Two deleted cases were folded back where their behaviour was the component's own and their coverage otherwise lost: `CategoryPicker`'s Backspace and clear reported through `onChange`, and a press on `Combobox`'s qualifier focusing the text. `IngredientForm/index.test.tsx` ran 6.2 s against staging's 7.4 s side by side; files whose coverage fell, all presentation or memorial branches, are named in the PR body.

**MB.229 — Page, lib and email tests: no re-run of lib or e2e, no design pins, no copy** · 2.5h

_Story:_ As a maintainer, I want a page test to hold only the page's half, a lib test one row per branch and an email test the addressing and links, so that a wording, a font or a second environment adds no test.

Minted on 2026-10-11 with MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)). Nine admin page files repeat one template of a dozen tests, re-run `readableCursor` and the empty-page count that `tests/lib/pagination.test.ts` owns, assert where the Add button sits, and run the GraphQL armor under two environments its source does not branch on; the lib tests enumerate 24 seed rows one by one and re-test `safeReturnPath` through four callers; the email tests pin subjects, body sentences, fonts and positions. The task keeps the page's guard, its search params reaching the service, `?edit` NotFound against other errors and its modal close href; folds matrices into one loop; keeps of the emails the recipient, the links, the no-HTML text part, the scoped light rules and the image origin.

_Acceptance criteria:_

- No page test asserts layout or copy or re-runs a lib rule; `armor.test.ts` runs one environment
- No email test asserts a sentence, a font or a position; the preview equals the subject and both provider names are present
- Per-file coverage of `src/app/**`, `src/lib/**` and `src/emails/**` is not below the previous run, and the `Run vitest` time is recorded

_As built:_ the three directories went from 611 cases to 462: `tests/app` 222 → 168, `tests/lib` 373 → 287 (MB.210's additions included, which the plan's 366 left out) and `tests/emails` 16 → 7. `forbidden.test.tsx`, `theme.test.ts`, `tests/emails/types.ts` and `tests/support/return-paths.ts` are gone. Where the code corrected the plan, the change kept a branch's coverage or an href. `privilege-changes` keeps its InvalidCursor case, because the page's own catch retries the first page (`page.tsx:49`). `page.test.tsx` and `providers.test.tsx` keep two cases each, one per branch; the retry default was folded into the browser case. `mail` keeps one missing-variable row per transport, `account/email/page` keeps its "Your account" link, and the Add and Prev hrefs of the deleted heading-line and previous-page tests moved into a surviving test, every computed "Page n of m" kept. The entry's "re-runs a lib rule" took two cuts the plan's table did not list: the `not-a-cursor` half of seven page tests, which `tests/lib/search-params.test.ts` owns, and `account-email`'s unsafe return paths, which `safeReturnPath`'s own cases in `tests/lib/sign-in.test.ts` own. The error-message wording became "a sentence of its own, not the generic one" in one case per lookup, keeping `account_not_linked`'s no-enumeration check. Coverage rose overall, to 98.97% lines and 93.44% branches. Of the 73 files under `src/app`, `src/lib` and `src/emails`, one fell: `src/app/forbidden.tsx`, from 100% to 0%. Its only coverage now is `tests/e2e/admin.spec.ts`'s 403 cases. The full suite ran in 56.1 s locally. The docs naming a deleted case are corrected in the same PR: `email.md`, `graphql/protections.md`, `auth/{tests,admin-guard,social-providers,impersonation}.md`, `components/sign-in-panel.md` and the comment in `src/emails/theme.ts`.

**MB.230 — Playwright: duplicates of Vitest flows go, the build cache warms, the closing measurement** · 3h

_Story:_ As a maintainer, I want the Playwright suite to prove only what a real server can, and to start from a warm build cache, so that the slowest CI job spends its minutes on navigation, cookies, mail and cache rather than on flows Vitest already proves.

Minted on 2026-10-11 with MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)). The e2e step runs 113 s: 41 s of `next build` and boot, then 72 s for 79 tests on two workers, 52 s of it `admin.spec.ts`, whose filter flows, in-use alerts and second CRUD flows per template repeat `vocabulary-page.test.tsx`, the services and the component tests, and whose page titles and sentences are copy. The owner's choice is to trim only the duplicates: every admin page keeps its 403 and one flow with its axe scan. The task deletes the duplicate flows and the harness self-tests (`worker-slots`, `mail-transport`), replaces every copy assertion by presence while keeping a web-first wait before each axe scan, adds an `actions/cache` step for `.next-e2e/cache` in `playwright.yml` on `checks.yml`'s pattern, and after the seven lanes merge records the two step timings against the plan's baseline in the decision record.

_Acceptance criteria:_

- No spec re-runs a flow a component or service test proves wholesale, and every admin route keeps a 403 test and one flow with an axe scan
- No spec asserts a page title or a sentence; every axe scan is preceded by a web-first assertion that waits, listed in the PR body
- The whole e2e suite is green locally under the shared lock before the PR opens
- The cache step restores on the second CI run, shown by its log line
- The closing table of `Run vitest` and `Run Playwright e2e tests` against the baseline is written into `design-decisions/mb.224-plan.md`

_As built:_ the suite went from 79 tests to 56, and `admin.spec.ts` from 29 to 20. `admin.spec.ts` lost its filter flows, the form, planet and deity in-use alerts, the repeated unverified and primary-admin dialog checks, the deity add, edit and delete flow (its accessibility scan moved into the tradition flow) and the signed-out redirect. Elsewhere the compendium to-do filter went, as did the account rename, the invitation refusals, route-protection's email and invitation checks, the entry page's links, the greyed last-used mark, and the `worker-slots` and `mail-transport` harness specs whole. The forms add, edit and delete flow and the zodiac filter flow stay, because nothing else exercises those routes. Three tests that only ran an accessibility scan were folded into the test that loads the same page. Every page title, plain-load heading check and sentence became a role or data assertion, and each scan follows an assertion that waits. The pause notice is an `<output>`, which carries the status role itself. `playwright.yml` restores and saves `/app/.next-e2e/cache` under a key starting `nextjs-e2e`, but the cache never restores: a pull-request run cannot read another pull request's cache, and staging, which runs only the deploy workflow, saves none. The criterion "the cache step restores on the second CI run" is therefore unmet, and the owner decides between removing the step and saving the cache from the staging deploy. The closing measurement is section 8 of [`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md): the two CI test steps together went from 168 s to 116 s, −52 s, five gold stars.

**MB.231 — The repository's query helpers and predicates import one way, and the import-cycle lint rule covers `src/db/repository/`** · 1h

_Story:_ As a developer, I want every file in the repository layer to load in a fixed order, so that a helper is never undefined when another file first runs, and the lint rule that forbids import cycles covers the whole codebase.

Found by MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)), which moved the architecture guards onto oxlint and turned on `import/no-cycle`. The rule found one cycle: `src/db/repository/select.ts` imports `notSoftDeleted` from `predicates.ts`, and `predicates.ts` imports `existsIn` back from `select.ts`, for `readableIngredientParent`. It works today only because of the order the two happen to load in, and a future edit can turn that into an undefined helper at runtime with no obvious cause. MB.224 did not edit `src/`, so it exempted `src/db/repository/*.ts` in `.oxlintrc.json`. The task makes the imports one way: `existsIn` builds a query through the database client, so it belongs with `select.ts`, and the one predicate that wraps it moves beside it or into its own file, whichever reads more plainly; `predicates.ts` then imports nothing from `select.ts`. The exemption comes out, and the comment in `predicates.ts` that explains the cycle is rewritten to say where the moved predicate lives. No behaviour changes, so no new test: the existing repository tests under `tests/db/repository/` cover the moved code.

_Acceptance criteria:_

- `src/db/repository/predicates.ts` imports nothing from `select.ts`, and no other pair of files under `src/db/repository/` imports each other
- The `src/db/repository/*.ts` override that turns `import/no-cycle` off is removed from `.oxlintrc.json`, and `npm run lint` passes
- Every caller of the moved predicate imports it from its new home, and `tests/db/repository/` passes unchanged
- `claude-docs/db/repository-files.md` names where the moved predicate lives

_As built:_ `readableIngredientParent` moved into a file of its own, `src/db/repository/ingredient-parent.ts`, which imports `inTiers` from `predicates.ts` and `existsIn` from `select.ts`. It did not go into `select.ts`, which builds queries for any table and imports no table schema, while this predicate is about the `ingredients` table and its tiers. `predicates.ts` now imports nothing from the folder but types, `ingredients.ts` and `references.ts` import the predicate from its new file, and the index never exported it, so nothing outside the folder changed. The `src/db/repository/*.ts` override is gone from `.oxlintrc.json`, so `import/no-cycle` now covers every file the lint reads, the repository included, and `npm run lint` passes with it. `claude-docs/db/repository-files.md` gives the new file a row, and `modules.md` and `db/workspace-ingredients.md`, which placed the predicate in `predicates.ts`, say where it is now.

**MB.232 — The hand-written `scripts/*.d.mts` declarations go with the `tests/scripts/` files that read them** · 0.5h

_Story:_ As a developer, I want no type declaration in the tree that nothing checks against, so that a reader does not take one for a contract the code keeps.

Found by MB.224 ([`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md)), which deleted `tests/scripts/` under the rule that code only Claude agents run is not tested. The scripts under `scripts/` are plain JavaScript, and `allowJs` is off, so each had a hand-written `.d.mts` beside it describing its exports in TypeScript terms, for the tests that imported the `.mjs`. Six remain: `doc-citations`, `doc-overlap`, `repoint-doc-citations`, `split-doc`, `task-board` and `tasks-md`. With the tests gone, no TypeScript file imports those scripts, so the declarations describe shapes nothing checks, and a change to a script leaves its declaration silently wrong. The task deletes the six files and the lines that name them: the comment in each script's header if it points at its declaration, and `claude-docs/design-decisions/mb.108-plan.md`'s count of declarations, which is corrected rather than deleted since it records what MB.108 found. If `tsc` or any test still reads one of them, that file stays and the entry says why.

_Acceptance criteria:_

- No `scripts/*.d.mts` file remains, or each one that does is named in the entry with the TypeScript file that imports its script
- `npm run pre-commit` passes
- No doc or comment names a deleted declaration file as present

_As built:_ all six went: `doc-citations`, `doc-overlap`, `repoint-doc-citations`, `split-doc`, `task-board` and `tasks-md`, each `scripts/<name>.d.mts`. Before deleting them, a search of `src/`, `tests/`, `scripts/`, `lint/` and `.github/` found no TypeScript file importing any of the six scripts. The only hits were the declarations naming each other, `task-board.d.mts` importing types from `./tasks-md.mjs`, and a comment in `tests/support/unit-global-setup.ts` that names `doc-citations.mjs` without importing it. `tsconfig.json` keeps `allowJs` off, and its `include` lists `src/`, `tests/` and the Next.js type folders, never `scripts/`, so nothing but the deleted `tests/scripts/` ever read them. No script header pointed at its declaration. Two lines named a deleted file as present and are corrected: the opening comment of `.github/scripts/lib/slowest-files.d.mts`, which cited `scripts/doc-citations.d.mts` as its model, and the count in [`design-decisions/mb.108-plan.md`](../design-decisions/mb.108-plan.md), which now says 11 declarations were there then and that MB.232 removed the last six. MB.224's plan lists this task as a follow-up it found, and MB.103's criterion that `tasks-md.mjs` comes with its `.d.mts` is what that task required at the time; both are records and stay.

**MB.233 — `DROP DATABASE … WITH (FORCE)` may end an autovacuum worker: the test role joins `pg_signal_backend`** · 0.5h

_Story:_ As a developer, I want a test run's database drops to succeed whatever Postgres is doing in the background, so that a green suite is not failed by its own teardown.

PR #808's Playwright job (run 38099198158) passed all 79 tests and still failed: its global teardown, `tests/e2e/global-teardown.ts`, drops the seeded e2e template through `dropDatabase()` in `tests/support/seeded-database.ts`, and Postgres refused the drop with `permission denied to terminate process`. The drop is `DROP DATABASE IF EXISTS sorrel_e2e_template WITH (FORCE)`, and `WITH (FORCE)` ends every session still connected to the database before dropping it. One of those can be Postgres's own autovacuum worker, the background process that tidies and analyses a table a while after it is written to, and a freshly seeded template is exactly that. The worker runs as no role, and Postgres lets a role end such a process only if it is a superuser or a member of the built-in `pg_signal_backend` role. The test role, `sorrel`, is created in `Docker/postgres-init/enable-extensions.sql` as `LOGIN CREATEDB` and nothing more, so it may end only its own sessions, and the drop fails whenever it lands while the worker is busy. Every connection the tests open runs as `sorrel`, so the worker is the only session this drop can fail on; the log's `DETAIL` line names `pg_signal_backend` as the missing privilege. The same forced drop runs in three other places, each open to the same race: the per-spec re-clone of a worker's database (`recreateE2eDatabase()`, `tests/e2e/database.ts`), Vitest's re-clone before every test file (`tests/support/db-setup.ts`), and Vitest's teardown drops (`tests/support/db-global-setup.ts`). Several lanes' local runs failed the same way on 2026-10-11.

The fix is one line in the test and dev database image: `GRANT pg_signal_backend TO sorrel;`, with the privileges comment above it saying why. The grant cannot end a superuser's session, and the file builds only the image CI and the devcontainer run, never Neon. Changing `Docker/postgres-init/**` changes the image's content hash, so the PR's own CI rebuilds the image and runs Vitest and Playwright on it, and that run is the proof. No regression test is added: the harness is not tested (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 1), and a test of a role's grant would be one. A devcontainer data volume made before the change keeps its old roles until it is recreated, which `claude-docs/ci/database-image.md` says.

_Acceptance criteria:_

- `Docker/postgres-init/enable-extensions.sql` grants `pg_signal_backend` to the test role, with the comment saying why
- The PR's CI rebuilds the database image and its Vitest and Playwright jobs pass on it
- `claude-docs/ci/database-image.md`, the "Database image" section `claude-docs/ci.md` summarises, names the grant and says an existing devcontainer volume needs recreating to pick it up
- No test is added: the harness is not tested (layer-ownership.md, rule 1)

**MB.234 — The e2e build cache is saved from `staging`, so a pull request's Playwright job restores it** · 1h

_Story:_ As a maintainer, I want the e2e job's `next build` to start from a warm cache on every pull request, so that the slowest CI step spends its minutes on the tests rather than on rebuilding what staging already built.

MB.230 added a step to `.github/workflows/playwright.yml`, "Cache Next.js e2e build cache", that restores `/app/.next-e2e/cache` before the suite runs and saves it afterwards. That folder is where `next build` keeps Turbopack's on-disk cache, the record of work a later build can skip, and the e2e build writes it because `playwright.config.ts` sets the build directory to `.next-e2e`. The key is `Linux-nextjs-e2e-<lockfile hash>-<source hash>`, with a fallback to any entry for the same lockfile. The step never restored: every run since logs `Cache not found for input keys` and then `Cache saved` (run 38102191294, PR #818, is one). The build and server start before `Running 56 tests` took 24.7 s on that run, cold.

The cause is how GitHub scopes caches. A run can restore a cache saved on its own branch, on the default branch (`main`), or, for a pull request, on its base branch, but never one saved on a sibling branch, and a pull request's run saves under its merge ref (`refs/pull/<n>/merge`), so only re-runs of that same pull request can read it (GitHub Docs, "Dependency caching reference", "Restrictions for accessing a cache", https://docs.github.com/en/actions/reference/workflows-and-actions/dependency-caching). Every save so far came from a pull request, and `staging` runs only `deploy.yml`, which never builds the e2e app, so no cache exists anywhere a pull request into `staging` can look.

The fix saves the cache from `staging`. A new workflow, `.github/workflows/e2e-cache.yml`, runs on a push to `staging` that touches what the e2e build compiles or runs under (`src/**`, `public/**`, the Next, TypeScript and Playwright configs, the manifests, `Docker/Dockerfile.e2e` and the workflows involved). It calls the same three workflows `pr-gate.yml` does for its Playwright job: `build-e2e-image.yml` and `build-db-image.yml`, which find the content-addressed images the pull request already published, and `playwright.yml` itself, with a new `build-only` input. With `build-only` set, the run step adds `--grep-invert . --pass-with-no-tests` to `npm run e2e`: every test title matches `.`, so no spec runs, but Playwright starts its web servers before it loads any spec, so slot 0's server still runs `npm run build` exactly as a pull request's run does. The coverage upload is skipped, since nothing ran, and `actions/cache` saves the folder under the same key scheme, because it is the same step. Reusing `playwright.yml` rather than writing a second job makes the warm build match the pull request's by construction: the same image, the same `/app` path and build directory, the same job environment and the same `webServer` environment from `playwright.config.ts`. A Turbopack cache built under different settings would be thrown away. The job names (`e2e-image`, `db-image`, `warm`) differ from `pr-gate.yml`'s, so no check name is published twice.

The other shapes were weighed. A job in `deploy.yml` would put the e2e image, a Postgres service and Playwright beside the Vercel deploy, and a failed warm run would turn the deploy red; the deploy's runner has neither the image nor the database. Running the whole Playwright suite on every push to `staging` would spend about 1 minute of tests per push to save a cache the build-only run saves just as well.

Cost: about 2½ GitHub-hosted runner minutes per qualifying push to `staging`. Measured from run 38102191294's jobs: the two image jobs take about 16 s and 31 s when the image already exists, and the warm job about 1½ to 2 minutes (51 s to pull the e2e image and start Postgres and Mailpit, 2 s of checkout, a few seconds to restore about 160 MB, 25 to 40 s to build and boot, and 10 s to save). The repo is public, so GitHub's hosted minutes are free, and no Blacksmith minutes are used.

No test is added: a workflow is harness (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 1). This PR's own run cannot show a restore, because the warm run happens only after the merge, on `staging`. The proof is the first pull-request run after it.

_Acceptance criteria:_

- `e2e-cache.yml` runs on a push to `staging` and saves `/app/.next-e2e/cache` under the key scheme `playwright.yml`'s cache step restores
- The Playwright job on the first pull request after the merge logs `Cache restored from key`, pasted into the closing comment on the issue
- The build-and-boot time before `Running N tests` on that run is recorded in this entry against MB.230's cold 24.7 s
- `claude-docs/testing/e2e.md`, `claude-docs/ci/reusable-checks.md`, `claude-docs/ci.md` and `claude-docs/ci/runner-budget.md` describe the job and its cost
- No test is added: the harness is not tested (layer-ownership.md, rule 1)

**MB.215 — Ingredient variants: the model, the record and the re-scoped tasks** · 2h

_Story:_ As a maintainer, I want the model of an ingredient and its forms written into the spec, a decision record and every unbuilt task it changes before any table is built, so that the tables and services transcribe one agreed model and no later task is built on the old one.

Minted on 2026-10-11 on the owner's call to hold what an ingredient's forms share once ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)), the first of nine (MB.215 to MB.223). Today an ingredient's identity is its formal name plus its form (DESIGN.md §5), so Rosemary as a herb, an oil and a powder is three `ingredients` rows, each repeating the description, elements, planets, zodiac signs, colours and safety notes, and each owning its own categories, deities, folk names, substitutes and references. The owner wants what the forms share entered once: a parent ingredient carrying it, a child row per form carrying what is particular to that form, one page showing the ingredient and its forms, and a search that reaches the forms' details. The child row is a _variant_, held in a new `ingredient_variants` table. The detail page (M8.19), the compendium page (M8.18), the search UI (M8.10 to M8.14), the local-beats-compendium rule (M8.3), stock (M9.4), the spell services and `unitConvert` (M9.5) are all unbuilt and production is not live, so only the admin compendium page, `IngredientForm`, the search SQL, the vocabulary's rename-carry and their tests read today's shape. This task builds nothing: it records the model before any DDL transcribes it, under MB.28 and MB.91's rule, and MB.216 to MB.223 build it.

The decisions, settled with the owner on 2026-10-10. The child table is `ingredient_variants` and its GraphQL type `IngredientVariant`; `ingredient_forms` stays the curated vocabulary of form names, so a variant _has_ a form. An ingredient with no variant is information only: it can be read, searched and linked as a substitute, but a stock row or a spell layer names a variant, and the compendium page and the entry form prompt for at least one form. An ingredient's identity is its formal name alone, `identity_key = lower(coalesce(canonical_name, name))`, unique per tier (the compendium, or one workspace), and a variant is unique per ingredient and folded form, `(ingredient_id, lower(btrim(form)))`; the slug drops the form, and old compendium slugs retire through the existing 180-day redirects. Inheritance is a union: a variant adds to its ingredient and never removes, with no override or coalesce state, so if a form lacks a property the curator moves it off the ingredient onto the forms that have it. A variant carries `form`, `form_id` (the curated pick), `description`, `safety_notes`, the four lists (elements, planets, zodiac signs, colours), and its own references, substitutes and categories; deities and folk names stay on the ingredient. Any ingredient, or any variant of one, may substitute for a form — leaves for stems, or a different ingredient altogether — and the substitute picker ranks a matching form first, then the same form group, then the rest; the "not itself" check refuses only the same ingredient _and_ the same variant. Search reaches a variant's form and description and still returns one row per ingredient.

Why those children, from the research the record cites. References and safety notes are per form in the sources: the EMA writes one herbal monograph per plant part and preparation, and an essential oil concentrates a great deal of plant into a little liquid — about a hundred roses go into one drop of rose oil — so it is diluted before use and carries contraindications and routes the dried herb does not. Substitutes are per form but not bound to it: Cunningham's substitution lists are organised by use and property, so the substitute hangs off the form it replaces and links anything, and similarity of form is a ranking, not a constraint. Categories are mostly plant-level and sometimes form-level ("for anointing"), and the join table is cheap to widen. Deities and folk names are attributed to the plant, and the ordered, linked deities table is the costliest to split for the weakest case. The record also keeps what was rejected: a self-referential `parent_id` in one table (two kinds of row in one table, so a form row listed as an ingredient is only absent, never impossible, and `canonical_name` is duplicated and must be kept in sync); prefilling a new entry from another (it copies, it does not share); override semantics (every read coalesces, join tables need an "explicitly none" flag, and changing one element means re-entering the list); and separate variant mutations (a second tier check, a second collision mapper, per-variant cache expiry and saves in several round trips, where the form saves the whole entry in one `withAudit`).

What it edits. DESIGN.md §5: the `ingredients` entry; the identity section, retitled "— the formal name"; the five-column table's `form` row; the `ingredient_forms`, `ingredient_substitutes`, `reference_links`, `ingredient_categories`, `inventory_items` and `spell_ingredients` entries; the local-beats-compendium SQL, on `identity_key`; and the slug sentence. §7's sketch. §9: IngredientSearch, the detail page as the ingredient followed by one anchored section per form, and M8.14's line. Four §14 rows: "Is `form` part of identity?" answered "No, since MB.215", and "One row per form, or a variant table?", "Where do deities and folk names live?" and "May a substitute cross forms?". CLAUDE.md's identity invariant is rewritten. An "MB.215: …" paragraph goes into each of `db/identity-model.md`, `db/ingredient-slugs.md`, `db/compendium-read.md`, `db/compendium-writes.md` (whose sixth-child recipe gains its first adopter), `db/workspace-ingredients.md`, `db/ingredient-children.md`, `db/repository-files.md` (the `ingredient-parent.ts` row, which MB.218's `readableVariantParent` joins), `db/standard-scenario.md`, `db/demo-scenario.md`, `modules.md`, `validation.md`, `graphql/schema.md` and the component docs. The new record is `design-decisions/mb.215-ingredient-variants.md`, holding the model, the research, what was rejected and the "Merging a group" procedure MB.216's guard names; the plan is `design-decisions/mb.215-plan.md`, copied in by the mint commit this task's PR carries, whose coordination lines this task keeps current.

The tasks it re-scopes, each gaining one dated "Amended by MB.215" line, the owner syncing their issues:

- M8.3: the local-beats-compendium anti-join matches on `identity_key`, and `ingredientSuggestions` ranks a matching form first, then its form group (The hiding rule described here is retired by M12.28; see `claude-docs/design-decisions/m12.13-cupboard-names-the-compendium-plan.md`.)
- M8.3a: the key a promotion leaves unchanged is `identity_key`, not `canonicalKey`
- M8.10: the text match reaches a variant's form and description (MB.218), still one row per ingredient
- M8.11 and M8.12: a category match is the union of the ingredient's categories and its variants'
- M8.13: the form filter is an EXISTS over variants, its options the curated vocabulary plus the variant forms in use
- M8.14: the card's secondary line and its sort read the forms from the variants, not the row's `form` and `canonical_key`, which MB.223 drops
- M8.18: a card lists the entry's forms, and an entry with none is flagged on the admin to-do list
- M8.19: the page is the ingredient, then one section per variant, anchored `#form-<slug>`; the public slug carries no form
- MB.155: a form's own references are listed in its section beneath the ingredient's
- M9.4: `addIngredientToWorkspace(variantId)`; an entry with one variant picks it; the add is idempotent per workspace and variant
- M9.5: the stock and layer quantities it compares each name a variant
- M10.9: a spell's derived categories are the ingredient's pairs plus the layer's variant's
- MB.138: the substitute picker ranks a matching form first, then its group, and links a variant when the linked ingredient has them

_Acceptance criteria:_

- Every doc named above carries its MB.215 paragraph, and DESIGN.md §5, §7, §9 and §14 and CLAUDE.md's identity invariant state the model
- `design-decisions/mb.215-ingredient-variants.md` and `design-decisions/mb.215-plan.md` exist
- Every re-scoped entry carries its dated "Amended by MB.215" line
- `npm run pre-commit` green (doc-only)

**MB.216 — `ingredient_variants`, the fill, and identity on the formal name (schema)** · 4.5h

_Story:_ As a curator, I want each form of an ingredient held as a row beneath it, filled from the forms the entries already carry, and an ingredient keyed on its formal name alone, so that the forms of one plant can share one entry without any entry losing the form it has.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)), the first table task under the table-then-behaviour rule. It creates the table of forms, fills it from today's rows and adds the new identity key beside the old one; nothing reads or writes the table yet but the seeds, the test fixtures and the migration (MB.218 reads it, MB.219 writes it).

The table is MB.215's model transcribed, in `src/modules/ingredients/schema/ingredient-variants.ts`, built through `idColumn()` and `liveUnique()` from `src/db/schema-parts.ts`. Its columns: `id: idColumn()`; `ingredientId`, NOT NULL, referencing `ingredients.id`; `form`, text, NOT NULL; `formId`, nullable, referencing `ingredient_forms.id` (the curated pick); `description`; `safetyNotes`; the four lists `elements` (`ingredient_element[]`), `planets[]`, `zodiacSigns[]` and `colors[]`; and `...auditColumns`. A CHECK refuses a blank form. `liveUnique()` builds `ingredient_variants_form_unique`, one live row per ingredient and folded form, `lower(btrim(form))`. A unique index on `(id, ingredient_id)` is **not partial**: it is the target of the composite foreign keys MB.217 adds, which a partial index cannot be, and it reserves nothing the primary key does not, so it is the one named exception to "every unique index is partial". An index on `(form_id) WHERE deleted_at IS NULL` serves MB.220's in-use reads, and a GIN trigram index (the kind that serves a fuzzy text match) on `unaccent_immutable(form)` and `unaccent_immutable(description)` serves MB.218's search arm. The table takes its own `set_updated_at` trigger line and a row in `tests/support/db/table-metadata.ts` (`tableFacts`), and it is `IngredientScoped`: read through `findManyOfIngredients` under its parent's tier, never by bare id (CLAUDE.md rule 5).

Beside it, `ingredients` gains `identity_key`, a generated column, `GENERATED ALWAYS AS (lower(coalesce(canonical_name, name))) STORED`, spelt by `identityKeyOf(name, canonicalName)` beside today's `canonicalKeyOf`, and unique per tier as `ingredients_compendium_identity_key_unique` and `ingredients_workspace_identity_key_unique`. `canonical_key` stays until MB.223 drops it.

Two migrations, numbered after `0060` (MB.214's, still staging's latest) and each re-checked against `staging` before generating, since MB.173's check refuses a migration older than staging's latest. `0061` is generated, with the trigger line added by hand. Its sidecar acknowledges a false positive: the destructive-DDL check fires on a generated NOT NULL column, and this one is computed from `name`, itself NOT NULL, so no row can fail it. `0062` is a custom migration whose two `CREATE UNIQUE INDEX` statements are lifted from a scratch generate. It does three things, in order:

1. It fills one variant per `ingredients` row with a non-blank form: `btrim(form)` and `form_id`, stamped with the row's last editor, soft-deleted parents included. Correspondences are **not** copied: under the union rule the parent already holds what its single form shared.
2. A `DO` block **refuses** a database holding two live rows of one `(workspace_id, identity_key)` in a tier — two entries of one formal name, differing only by form — naming the count and the "Merging a group" procedure in MB.215's record. No seeded or live data holds such a group, and a general merge is v2's duplicate merge tooling, which could not be tested against data that does not exist, so the migration refuses rather than merges. The pre-flight query to run on staging before it, which must return no row: `select workspace_id, lower(coalesce(canonical_name, name)), count(*) from ingredients where deleted_at is null group by 1, 2 having count(*) > 1`.
3. It creates the two identity-key unique indexes, after both.

The seeds and fixtures move in the same task. `src/db/seed/standard.ts` and `src/db/seed/demo.ts` write a variant beside each row's `form` through MB.208's `insertMissingBy`, keyed `(ingredient_id, lower(form))`, and every seeded ingredient already carries a form (the demo's in lowercase: Hearth Ash is `ash`, House Chamomile `flower`), so every seeded spell layer can name a variant. `tests/support/db/insert-ingredient.ts` writes a variant from the fixture's form.

Tests are written first, to the ten rules of `claude-docs/testing/layer-ownership.md`:

- `tests/modules/ingredients/schema/ingredient-variants-schema.test.ts`, first: the exact-column test; the blank-form CHECK; a second live variant folding to the same form refused and a different form allowed (the table's identity rule)
- the fill and the guard as migration data tests, marked to retire once `0062` is in production's journal (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 7)
- `ingredients-schema.test.ts` gains `identity_key`'s fold
- `ingredients-indexes.test.ts` gains the identity rule: twice in one tier refused whatever the form, and the same formal name in two tiers coexists
- `tests/db/partial-unique-indexes.test.ts` classifies the two new indexes, the non-partial `(id, ingredient_id)` one as the named exception
- `tests/db/repository/finders.test.ts` pins `findMany(ingredientVariants)` as a type error
- the seed tests: every seeded entry has exactly one live variant

The drift, audit and trigger sweeps (`tests/db/schema-drift.test.ts`, `audit-columns.test.ts`, `updated-at-trigger.test.ts`) cover the rest once the table is in `table-metadata.ts`, so no schema test repeats them (rule 6).

The risks the plan records for this task. The identity index lands before the switch (MB.216 to MB.220): until MB.220 maps it, the old writer could try "Rosemary :: oil" beside the herb and be refused with an unmapped index name — a short window, and admin-only. The guard trips on staging if a keeper hand-entered a second form of something as its own entry; the pre-flight query finds it first. And like MB.217's, this task's sidecar says why its DDL stands in one PR (0029 and 0038's precedent): here, the check's finding loses nothing.

_Acceptance criteria:_

- After `npm run db:reset`, every seeded row with a form has exactly one live variant, and no row without a form has any
- The `0062` guard refuses a database holding two live rows of one identity key in a tier, and passes one without
- Both migrations apply on a database holding the demo scenario
- `npm run check:destructive-ddl` green with `0061`'s sidecar
- No finder, service or resolver reads or writes `ingredient_variants` yet
- Per-file coverage of the touched `src/` directories (`src/modules/ingredients/schema/**` and `src/db/seed/**`) not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.217 — A variant beneath stock, layers, categories, substitutes and references (schema)** · 5h

_Story:_ As a coven member, I want stock, spell layers, categories, substitutes and references able to name one form of an ingredient, so that a jar of rosemary oil, a layer of rosemary herb and a source on the oil each point at the form they mean.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)), the second table task under the table-then-behaviour rule. It adds a variant column to the five tables that point at an ingredient, in one migration, and no service writes it yet: MB.219 writes a variant's categories, substitutes and references, stock is written by M9.4 (Wave 11) and spell layers by the grimoire tasks of Wave 13.

Four of the five tables name the ingredient beside the variant, and each holds the pair through a composite foreign key, `(variant_id, ingredient_id) → ingredient_variants (id, ingredient_id)`, declared with Drizzle's `foreignKey` and MATCH SIMPLE, so the database itself refuses a variant of another ingredient beside this one. The target is MB.216's non-partial `(id, ingredient_id)` unique index. MATCH SIMPLE skips the check when _either_ column is null, so wherever `ingredient_id` is nullable beside the variant a CHECK closes the gap. `foreignKeyFacts` in `tests/support/db/table-metadata.ts` widens to multi-column keys, since the drift test reads it. Table by table:

- `inventory_items.variant_id` is NOT NULL, safe because the table is empty everywhere; a `liveUnique` on `(workspace_id, variant_id)` replaces the one on the ingredient pair.
- `spell_ingredients.variant_id` takes a CHECK, `(ingredient_id IS NULL) = (variant_id IS NULL)`: a linked layer names a variant, a custom layer none. A `liveUnique` on `(spell_id, variant_id)` replaces the ingredient pair, so a jar may lay Rosemary herb and Rosemary oil. `form_only_on_custom` stays.
- `ingredient_categories.variant_id` is nullable. The pair primary key becomes two unique indexes, `(ingredient_id, category_id) WHERE variant_id IS NULL` and `(variant_id, category_id) WHERE variant_id IS NOT NULL`; the table is still hard-deleted.
- `ingredient_substitutes` gains `variant_id`, the form the row is a substitute _for_, and `substitute_variant_id`, the substitute's own form, under a composite foreign key against `substitute_id`, `(substitute_variant_id, substitute_id)`. A CHECK, `substitute_variant_id IS NULL OR substitute_id IS NOT NULL`, refuses a form without its ingredient. `not_itself` narrows to refuse only `substitute_id = ingredient_id AND substitute_variant_id IS NOT DISTINCT FROM variant_id`, so a sibling form may stand in. The link and name uniqueness split by `variant_id IS NULL`, and `variant_id` takes a plain partial index.
- `reference_links` takes one entry in MB.207's `SOURCED` registry (`src/modules/ingredients/schema/reference-links.ts`), `ingredientVariantId: { column: 'ingredient_variant_id', table: ingredientVariants }`, which builds the column, its partial unique and the widened one-row CHECK; `findReferencesOf(memberships, key, ids)` reads it with no new finder.

One migration, `0063`, generated, with one sidecar. The sidecar acknowledges four DROP INDEX and three DROP CONSTRAINT — the categories' primary key, the substitutes' `not_itself`, and `reference_links_one_row`, which `db:generate` drops and re-adds from the `SOURCED` entry — each re-created in the same transaction, under 0029 and 0038's precedent (`db/expand-contract.md`'s table of destructive migrations). `0063` also fills `spell_ingredients.variant_id` from each linked layer's ingredient's single live variant before adding the CHECK, and a `DO` block refuses a linked layer whose ingredient has none or several. The pre-flight query to run on staging, which must return no row: `select si.id from spell_ingredients si where si.ingredient_id is not null and (select count(*) from ingredient_variants v where v.ingredient_id = si.ingredient_id and v.deleted_at is null) <> 1`.

A sub-hour fix rides in the PR, named in its body: `matching()` in `src/db/repository/write.ts` learns to turn `null` into `isNull`, so `write.delete(ingredientCategories, { ingredientId, variantId: null, categoryId })` names the parent's own pairs and not a form's.

Tests are written first, schema tests holding only the behaviour particular to each table (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 6):

- `tests/modules/ingredients/schema/inventory-items-schema.test.ts`: a row names a variant; another ingredient's variant beside this `ingredient_id` refused; one live row per workspace and variant
- `tests/modules/grimoire/schema/spell-ingredients-schema.test.ts`: a linked layer without a variant refused, a custom one with a variant refused; a jar may lay Rosemary herb and Rosemary oil, but not one variant twice; the fill as a migration data test (rule 7)
- `tests/modules/ingredients/schema/join-tables.test.ts` (MB.226's template) gains the variant column's rows for `ingredient_categories`: a pair twice on the parent refused; once on the parent and once on a variant is two rows; `write.delete` with `variantId: null` removes only the parent's
- `tests/modules/ingredients/schema/ingredient-substitutes-schema.test.ts`: a link to Lavender's oil beside `substitute_id` = Lavender passes, beside Mugwort refused; a variant naming its own form refused, a sibling form allowed, a different ingredient allowed
- `tests/modules/ingredients/schema/reference-links-schema.test.ts`: a variant link citing twice refused; a link naming both an ingredient and a variant refused
- `tests/db/partial-unique-indexes.test.ts` reclassified, and `table-metadata.ts`'s `foreignKeyFacts` widened

The risks the plan records for this task. Replacing indexes and constraints in one PR rests on 0029 and 0038's precedent, and the sidecar says why; read CLAUDE.md rule 10 strictly and this task becomes two. The fill's guard trips on staging if a demo layer's ingredient has no form; MB.216 gives every seeded ingredient one, and the pre-flight query finds any other first. Because the task adds constraints the e2e helpers write through, its verification runs the whole Playwright suite.

_Acceptance criteria:_

- A stock row, a linked layer, a variant's category pair and a substitute's form each refuse a variant of another ingredient beside their `ingredient_id`
- A linked layer without a variant, and a custom layer with one, are refused; a jar may lay two forms of one ingredient, never one variant twice
- A category pair may sit once on the parent and once on a variant, never twice on one; `write.delete` with `variantId: null` removes only the parent's
- A substitute naming its own form is refused, and a sibling form or another ingredient is allowed
- A reference link may cite a variant once, and never names both an ingredient and a variant
- `0063` fills every linked layer's variant, and refuses a database where a linked layer's ingredient has none or several
- `npm run check:destructive-ddl` green with the sidecar
- Nothing writes `variant_id` on stock or spell layers yet (M9.4 in Wave 11, the grimoire tasks in Wave 13)
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.218 — Variants are read and searched** · 5.5h

_Story:_ As a coven member, I want an ingredient's forms, with their own categories, substitutes and references, read with it and reached by the search, so that a word in a form's name or description finds the ingredient that has that form.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)), the first behaviour task. It reads the variants MB.216 and MB.217 built, through the repository, the services, the loaders and the GraphQL API, and widens the compendium search to reach a form's name and description. Nothing writes a variant yet; MB.219 does.

The repository. A variant's child rows need the same guard an ingredient's have: the parent ingredient must be readable in the caller's tiers, here reached through the variant. That guard is `readableVariantParent(memberships, variantColumn)`, written beside MB.206's `readableIngredientParent` in `src/db/repository/ingredient-parent.ts`, where MB.231 moved it apart from `predicates.ts` because it builds on `select.ts`'s `existsIn`; it imports one way, or MB.231's import-cycle lint rule fails it. `findManyOfVariants(memberships, table, variantIds)` is built on it, never reading by bare id. `findSubstitutesIncludingSoftDeleted` gains `of: 'ingredient' | 'variant'`, and CLAUDE.md rule 4's statement of that named finder in `.claude/rules/database.md` is amended to say so. A variant's references come through `findReferencesOf(memberships, 'ingredientVariantId', ids)`, which MB.207's `SOURCED` registry already serves. `claude-docs/db/repository-files.md` names the new finder.

The search. A third `UNION ALL` arm in `searchMatch` (`src/db/repository/ingredients.ts`) matches `unaccent_immutable(v.form)` and `unaccent_immutable(v.description)`, keyed by `v.ingredient_id`, through `foldedWordMatch`. The existing `max(score) … group by id` folds it with the other arms, so the search still returns one row per ingredient, and MB.216's trigram index serves it. The same arm reaches `findIngredientSuggestions` through `compendiumList`. `tests/db/repository/compendium-search-query.test.ts`'s plan loop gains one EXPLAIN assertion and keeps its row counts, the one home SQL text has (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 10). A bare "oil" ranks every entry with an oil form at 1.0: the search is not the precise tool for that, and the form filter (M8.13) is. The admin list's Without References filter reads the union rule too: `citesNothing` counts an entry sourced if it or one of its live variants cites a reference, so an entry whose only source is on its oil is not on the to-do list.

The services, in `src/modules/ingredients/services/ingredient-children.ts`: `variantsOf` (sorted by `lower(form)`), `categoriesOfVariants`, `substitutesOfVariants` and `referencesOfVariants`, each through `admit()`, the check that hands a child read only to a caller who may read its parent; `VariantKey = { id, ingredientId, workspaceId }` goes in `types.ts`. The loaders are keys in the record of `src/modules/ingredients/loaders/ingredient-children.ts`, built through `defineSignedInLoader` and `definePublicLoader`, so `clearIngredientChildren` clears them and `src/graphql/loaders/index.ts` registers them by name. GraphQL gains `IngredientVariant { id, form, formChoice, description, safetyNotes, elements, planets, zodiacSigns, colors, categories, substitutes, references, audit }`, `Ingredient.variants: [IngredientVariant!]!` — a nested list, which stays a bare list because the pagination guard checks fields on `Query` only (CLAUDE.md rule 8) — and `Substitute.variant`. Resolvers reach the session through `sessionOf`. The SDL snapshot and `npm run codegen` follow. `Ingredient.form` and `formChoice` stay for now; MB.222 removes them.

Tests are written first:

- `tests/db/repository/ingredients.test.ts`: a coven's variant children read under its proof only, by direct id, with the precondition asserted; an entry found by a variant's form; found by a word in a variant's description; one row for an entry with two matching variants; a deleted variant matches nothing; a coven's variant never matches another coven's picker
- `tests/modules/ingredients/loaders/ingredient-children.test.ts`: one read per batch, and the `admit()` matrix gains the variant loaders
- `tests/modules/ingredients/graphql/ingredient.test.ts`: the transport's half only — `variants` resolves in form order with each child field — with no re-test of the service or of signed-out callers (rule 6)

_Acceptance criteria:_

- `ingredient(id)` answers `variants`, in form order, with every child field
- A coven entry's variants and their children refuse a non-member by direct id, with the precondition asserted
- One query per loader batch
- Compendium reads stay under the `compendium` cache tag
- The compendium search finds an entry by a word in one of its forms, one row per entry
- The plan loop in `compendium-search-query.test.ts` holds its row counts
- An entry whose only citation is on a variant is not listed by `withoutReferences`
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.219 — Variants are written** · 4h

_Story:_ As a curator, I want to save an ingredient and its forms, each with its own description, lists, categories, substitutes and references, in one save, so that an entry and its forms are never left half-written.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)). Variants are the sixth child table in the recipe MB.211 wrote down (`claude-docs/db/compendium-writes.md`, "A sixth child table costs one writer, one loader and one input field"), and its first adopter: one add/replace pair, a line in each `writeChildren` branch, a list in `splitChildren` and `IngredientChildren`, a loader key (MB.218's) and one input field.

The input field: `ingredientInputFields` in `src/modules/ingredients/graphql/ingredient-input.ts` gains `variants: [IngredientVariantInput]`, required when the save is `whole`, so the four input types that spread it carry it unedited. `splitChildren` and `IngredientChildren` gain the list. `writeChildren` (`src/modules/ingredients/services/ingredient-rows.ts`) gains `addVariants` and `replaceVariants` in each branch; they write each variant's own categories, substitutes and references through the existing add/replace helpers, generalised over a steward `{ ingredientId, variantId }`. On replace, a variant is matched by `id` when the input carries one the ingredient holds, and otherwise by `lower(btrim(form))`, so a form can be respelt in place; a variant left out is soft-deleted, its children left; a new one is inserted. `resolvePicks` runs per variant, and on the compendium a variant's form must be a curated pick.

Validation, in `src/modules/ingredients/validation/ingredient.ts` through `requiredText`, `optionalText` and `RowId`: two variants folding to the same form are refused at `['variants', i, 'form']`; each variant's sub-lists go through the existing substitute (`linkOrNameRules`), reference and category rules, pathed under the variant; a substitute's `substituteVariantId` must belong to its `substituteId`. `refuseCollision` maps `ingredient_variants_form_unique` to `['variants', i, 'form']`.

Two transition measures keep the rest of the code working until MB.222 removes them. A shim: the top-level `form` and `formId` stay, and when `variants` is absent they become `[{ form, formId }]`, so `IngredientForm` is untouched here. And a dual write: `ingredientColumns` writes the row's `form` and `formId` from the first variant. The risk the plan records: between this task and MB.222, a two-form entry is found by `compendium(form:)` under its first form only, accepted on staging.

Tests are written first:

- validation first, through `failedPaths`, one row per rule and no messages (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 2)
- `tests/modules/ingredients/services/compendium.test.ts` and `workspace-ingredients.test.ts`: create with two variants; an update keeps a variant by id across a respelling, drops one and adds one; a typed compendium variant refused on its path; a substitute variant of the wrong ingredient refused on its path; one observer `Forbidden`, with its precondition
- the GraphQL files assert the transport's half only (rule 6)

_Acceptance criteria:_

- An entry is created with two variants, each with its categories, substitutes and references
- An update keeps a variant by id across a respelling, soft-deletes one left out and inserts a new one
- A typed compendium variant, two variants of one form and a substitute variant of the wrong ingredient are each refused, every error pathed to its variant and field
- A save that changes nothing writes nothing
- The old top-level form field still saves through the shim, so `IngredientForm` is untouched here
- No service or input type is edited by hand for the new child
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.220 — Identity is the formal name alone, and the form vocabulary reads variants** · 5.5h

_Story:_ As a curator, I want an ingredient known by its formal name alone, and a curated form's rename and delete to follow the forms that picked it, so that Rosemary's oil is added to Rosemary as a form rather than filed as a second entry.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)). This is the switch: identity moves from the formal name plus the form onto the formal name alone, on the key MB.216 built, and the form vocabulary's in-use, rename and delete rules read the variants rather than the ingredient row.

Identity. `findCompendiumEntryByIdentity({ name, canonicalName })` reads `identity_key` through `selectOne`, and `IngredientIdentity` loses `form`. `refuseCollision` maps the two identity-key indexes to `canonicalName`, or to `name` for an entry with no formal name, naming the entry already holding it through `describeEntry` and pointing at adding a form to it instead. This closes the window MB.216 opened, in which the old writer could meet the new index as an unmapped name.

The slug. Every call site passes `ingredientSlug(name, null, canonicalName)`. Existing slugs are **not** rewritten in SQL, which would be a second slug rule beside `src/lib/slugify.ts` (0025's precedent): a row keeps its form-bearing slug until its next save, when the service derives the new one and retires the old through the existing redirect path. The seed re-slugs its own entries on reseed and retires each compendium slug that moves.

The undeclare. `canonical_key` and `canonicalKeyOf` leave `src/modules/ingredients/schema/ingredients.ts`, and **`db:generate` is not run**, since it would emit the drop that is MB.223's. Instead `canonical_key` and its two indexes are listed in `PENDING_DROPS` at the top of `tests/db/schema-drift.test.ts`, MB.226's declared expand/contract window, each with `droppedBy: 'MB.223'`, so the drift test stays green over objects the code no longer names. Nobody runs `db:generate` between this task and MB.223.

The form vocabulary. `IN_USE.ingredient_forms` (`src/db/repository/vocabularies.ts`) reads `ingredient_variants.form` through the `TWO_TIER` registry's pick table (`PickedTable`, `src/db/vocabularies.ts`). `IngredientFilter.formId` becomes an EXISTS over variants, served by MB.216's pick index, so `refuseWhileHeld` (`src/modules/vocabulary/services/held-entries.ts`) counts the entries holding a variant that picked the form. `rewritesOf` becomes `findCompendiumVariantsPickingForm(formId)` on the tier seam. `refuseCollidingRewrites` checks the sibling index, `ingredient_variants_form_unique`: a rename that would give one entry two forms of one name is refused, naming that entry. `redirectRefusal` and `endRedirect` leave the form-value input, since a rename moves no slug. `write.carryFormRename` becomes one statement over the variants, with no slug and no retirement, and `FormRenameEntry` goes.

Tests are written first:

- the repository's identity finder and its `formId` arm
- `ingredients-schema.test.ts` flips the `form`-is-text identity rule MB.226 placed there, and `ingredients-indexes.test.ts` the index declarations
- service collisions and slugs: an oil beside a herb under one formal name refused on the formal-name path, the other entry named (the one place a message is asserted, through `stringContaining(<name>)`, since the entry promises the other row is named: `claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 2); a relabel moves the slug and retires the old one; an old slug stays until the next save, then redirects
- `tests/modules/vocabulary/services/ingredient-form-values.test.ts`: the rename behaviour rewritten — every compendium variant picking the form follows, no slug moves, a coven's variant does not
- the suggestions' in-use and claimant cases
- `tests/lib/slugify.test.ts`

_Acceptance criteria:_

- `grep canonical_key src/` finds only migrations
- A second entry under an existing formal name is refused on the formal-name path, naming the entry that holds it, and no raw index name reaches a client
- A form-bearing slug stays until its row's next save, then moves and redirects
- A rename of a curated form reaches every compendium variant picking it, and nothing else
- A curated form's delete is refused while a variant picks it
- No retirement row is written by a rename
- `canonical_key` and its two indexes are in `PENDING_DROPS` with `droppedBy: 'MB.223'`, and the drift test is green
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.221 — IngredientForm's Variants section** · 4h

_Story:_ As a curator, I want the compendium entry form to list an entry's forms, each with its own fields, so that I can add Rosemary's oil with its own safety note in the same modal as the herb.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)). The entry form, `IngredientForm`, gains a Variants section and sends only `variants`, never the top-level `form`, which the service has accepted since MB.219. The task is based on MB.116's branch (#824) while that pull request is open, because MB.116 trims `IngredientForm/index.tsx`, `reference-panel.tsx` and `values.ts` to read failures through `readGraphqlIssues` in `src/lib/graphql-failure.ts`; otherwise it is based on `staging`. If #824 takes a CI fix this branch rebases onto it, and its PR is retargeted to `staging` when #824 merges. MB.115 and MB.117, the other design reviews still ahead in the row, may touch `IngredientForm`'s shared pieces first, so the task re-locates them by grep before editing.

`src/components/IngredientForm/variants.tsx` holds a "Variants" section: a `useFieldArray` over `values.variants`, each variant a fieldset whose legend is its form, holding Form (the existing `FormField`, pick-only on the compendium, moved here), Description, Safety Notes, Elements, Planets, Zodiac Signs, Colours, Categories, Substitutes and References. The Substitutes picker ranks a matching form first, then its form group, and offers a variant picker when the linked ingredient has variants. The field-name unions widen to `variants.${number}.…`; drafts are kept per variant; `fieldNameOf`, `resolverFor` and `toInput` are updated; `EMPTY_VALUES.variants = []`; `src/app/(shell)/admin/compendium/entry-values.ts` fills the variants; and a variant's server issues are placed through `readGraphqlIssues` like the rest. The top-level Form field leaves the form. The component's story, its doc section and its Sass follow.

Tests are written first:

- `tests/components/IngredientForm/variants.test.tsx` first, through role and label queries, asserting state and never copy (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 2): add a variant and its fieldset is listed; pick its form and the field carries it; a typed compendium variant is marked invalid beside its Form box; remove one and it is gone; a server issue pathed to `variants.1.form` marks that field; a repeat form is refused at Add
- the resolver rows in `tests/modules/ingredients/validation/ingredient-resolver.test.ts`
- `tests/components/IngredientForm/index.test.tsx` kept under its 8-second budget, the section's own file carrying its cases
- the admin page tests, and `tests/db/admin-compendium-entry-values.test.ts` with the variants filled
- `tests/e2e/admin-compendium.spec.ts`'s one flow ("an admin adds, edits and deletes a compendium entry in the modal over the list") extended to add a second form and edit its safety note, axe clean, with no new flow (rule 9)

If the 4 hours are exceeded, the variant's sub-lists split into a follow-on task.

_Acceptance criteria:_

- A curator adds a variant, picks its form, fills its fields and removes it, and a typed compendium variant, a repeat form and a server issue on a variant's field are each marked on that field
- Usable at 375 px
- axe clean
- The form sends only `variants`, never `form`
- A variant's errors focus as a field's do
- `index.test.tsx` stays under its 8-second budget, and the e2e spec keeps one flow
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.222 — The form leaves the ingredient row: filters, list, SDL, seeds, fixtures** · 3.5h

_Story:_ As a curator, I want the compendium list, its form filter and the seeds to read an entry's forms from its variants, so that an entry with two forms shows and filters under each of them.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)), the last behaviour task. Everything still reading the form on the ingredient row moves onto the variants, MB.219's shim and dual write go, and the code stops naming `form`, `form_id` and what constrains them, which MB.223 then drops. It closes the dual-write window MB.219 opened, in which a two-form entry was found by `compendium(form:)` under its first form only.

The filter and the API. `formArm` (`src/db/repository/ingredients.ts`) becomes an EXISTS over variants, through `fold` on both sides. The SDL drops `Ingredient.form` and `formChoice`, and `form` and `formId` leave `ingredientInputFields`; the shim and the dual write go; `npm run codegen` follows. On the admin list, `CompendiumList`'s Form column lists the entry's live forms ("Herb, Oil"), the edit link names the label and the formal name, and `SubstituteLink` gains `forms`.

The seeds. `SeedIngredient` gains `variants`, and `identityOf` is keyed by `(name, canonicalName)`. **Rosemary gains an Oil variant** (the curated `Oil` exists) with its own description and safety note, listed among `db/standard-scenario.md`'s "awkward on purpose" rows. The demo's Fresh Ginger becomes W's Ginger, with an uncurated `rhizome` variant, and `ingredientIdByIdentity` is re-keyed. Both seed docs, `db/standard-scenario.md` and `db/demo-scenario.md`, are corrected.

The fixtures. `IngredientFixture` gains `variants`, with invented defaults through `makeVariant()`, and `insertIngredient` writes variant rows only.

The undeclare. `form`, `formId`, the two form CHECKs (`ingredients_form_not_blank` and `ingredients_form_id_has_form`) and the form-id index (`ingredients_compendium_form_id_idx`) leave `src/modules/ingredients/schema/ingredients.ts`, and `ingredients-schema.test.ts`'s form rules, which MB.226 placed there, go with them. **`db:generate` is not run**: `form`, `form_id`, the two CHECKs, the form foreign key and the form-id index are listed in `tests/db/schema-drift.test.ts`'s `PENDING_DROPS` with `droppedBy: 'MB.223'`.

Tests are written first:

- the repository's `form` behaviour: an entry with two forms found by either; the filter combines with search; the count agrees with the page
- the `CompendiumList` test: the forms listed, asserted as state (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 2)
- the seed tests: Rosemary has two live variants; W's Ginger has `rhizome`
- the seed idempotency sweep

_Acceptance criteria:_

- `grep -n "ingredients.form\b" src/` finds nothing outside migrations
- The SDL carries no `form` on `Ingredient` or its input types
- An entry with two forms is found by the form filter under either, alone and with a search, and the count agrees with the page
- `npm run db:reset` seeds the multi-form entry: Rosemary with two live variants, and W's Ginger with `rhizome`
- The drift test is green with the window declared in `PENDING_DROPS`
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

_As built:_ `variants` became required on all four input types here, the two creates included (`[IngredientVariantInput!]!`), where MB.219 had left it optional on every type so the old form field could save; a create stub sends `variants: []`. The zod schemas keep it optional, as every child list is, so absent is none, and `IngredientFormInput` types the form's input with the list always present. The seed's entry key is the identity itself, the formal name or the label without one, lower-cased as `identity_key` holds it (read off that column for the rows, folded in TypeScript for the literals), rather than the pair `(name, canonicalName)`: a pair keyed on the label would insert a relabelled entry again beside itself, which the identity index refuses, and a demo database seeded when W's Ginger was Fresh Ginger would fail the reseed the same way, where under the identity it finds the entry present and keeps its label. The demo's layer lookup is keyed by tier and identity, since two tiers now share an identity twice (Garden Rosemary, Ginger). `describeEntry` names an entry by its label and formal name alone, since an entry may now have several forms. The admin list reads each page's forms in one batch through `variantsOf`, the read `Ingredient.variants` resolves through. Rosemary's oil is an infused oil, the curated `Oil`'s own sense ("pressed or infused, and fatty"), so its safety note is the infused-oil one. `makeIngredient()`'s default form is the invented `Testform`, and `variantInput()` builds a write's variant input from a fixture's. Three tests still write the row's undeclared `form` raw: `partial-unique-indexes.test.ts` and `ingredients-indexes.test.ts`, because the two `canonical_key` indexes read it until MB.223 drops all three, and a row without a distinct form would be refused by those first; and `0062-ingredient-variants-fill.test.ts`, whose subject is the fill from that column, and which retires once 0062 is in production's journal (`testing/layer-ownership.md`, "What a test may assert", rule 7). While those indexes stand, every row's `form` is null, so a compendium write colliding on both the address and the identity is refused by the oldest of them, the identity's, before the address's: `compendium.ts`'s branch for an address taken by the entry's own identity twin is unreached until MB.223.

**MB.223 — Drop `canonical_key`, `form`, `form_id` and what indexed them** · 1h

_Story:_ As a maintainer, I want the columns, constraints and indexes the forms' move left behind dropped once no deploy reads them, so that the schema holds an ingredient's form in one place.

Minted on 2026-10-11 with MB.215 ([`design-decisions/mb.215-plan.md`](../design-decisions/mb.215-plan.md)), the contract half of the move (`db/expand-contract.md`; CLAUDE.md rule 10). It waits for MB.222's deploy to staging, and not for a production release, production not being live (MB.197 and MB.203's ruling).

`0064` is generated: DROP INDEX ×3 (`canonical_key`'s two identity indexes and the form-id index), DROP CONSTRAINT ×3 (the two form CHECKs and the form foreign key) and DROP COLUMN ×3 (`canonical_key`, `form` and `form_id`). Its sidecar takes 0048's shape: nothing is lost, since every form has been in `ingredient_variants` since `0062`, and MB.219's dual write kept the two level until MB.222. `ingredientSlug` loses its middle parameter, the form, which every call site has passed as `null` since MB.220. `db/expand-contract.md`'s table gains the migration's row, and `db/identity-model.md` takes its final wording. The `PENDING_DROPS` lines MB.220 and MB.222 added come out, so the drift test is the proof that the schema and the catalogue agree again.

No memorial test (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 3): nothing asserts the dropped objects' absence. The one test written first is `tests/lib/slugify.test.ts`'s, for the two-parameter `ingredientSlug`.

_Acceptance criteria:_

- The migration drops exactly the listed objects: three indexes, three constraints and three columns
- `npm run check:destructive-ddl -- --all` green with the sidecar
- The drift test green with no `PENDING_DROPS` entry for these objects
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

_As built:_ `0064` drops `canonical_key` before `form`, the reverse of the order `db:generate` wrote, since `canonical_key` is generated from `form` and Postgres refuses to drop a column a generated column reads; the file says so in a comment, and its sidecar names it. `0062-ingredient-variants-fill.test.ts` keeps its guard tests, which read only `identity_key` and still run against the migrated database, and retires its fill tests, which read the dropped `form` column and can no longer run on any migrated database (`testing/layer-ownership.md`, "What a test may assert", rule 7; production not being live, MB.197 and MB.203's ruling counts the staging deploy). `partial-unique-indexes.test.ts` and `ingredients-indexes.test.ts` stop writing the row's `form`, and the two `canonical_key` index rows leave the partial-unique sweep with nothing in their place (rule 3). With the older identity index gone, a compendium write colliding on both the address and the identity meets the address index first, so `compendium.ts`'s branch for an address taken by the entry's own identity twin is reached again.

**MB.235 — Playwright restores the e2e build cache on a pull request and saves it only from `staging`** · 1h

_Story:_ As a maintainer, I want a pull request's Playwright job to stop uploading a build cache that no other run can read, so that those seconds come off the gate's slowest job.

`actions/cache` saves at the end of the job whenever its exact key was not found. On a pull request the key's source hash changes with almost every push, so every run saves about 160 MB of `/app/.next-e2e/cache` under the pull request's merge ref, where only a re-run of that same pull request could read it (the restriction MB.234 records). Measured on run 38110758509 (PR #837): the save took 17 s, from 04:13:34 to 04:13:51, after the tests had finished. MB.234 already moved the save that matters to `staging`: `e2e-cache.yml` calls `playwright.yml` with `build-only` on every push there, and a pull request's run restores what it saved (the same run logged `Cache restored from key`, 3 s).

The fix splits the step: `actions/cache/restore@v6` runs on every run with the same key and restore-keys, and `actions/cache/save@v6` runs only when `inputs.build-only` is set, so the `staging` warm run keeps saving and a pull request's run never does.

`checks.yml`'s build leg has the same defect: it caches `/app/.next/cache` under a key nothing on `staging` ever saves, so it has never restored across pull requests and spends about 4 s saving. The agent measures `next build` there warm and cold; if a `staging`-side save is a small addition (a second build-only call beside the e2e one), it rides here, and otherwise the cache step goes and the choice is named in the PR body.

The measurements this session took ride along in [`ci/runner-budget.md`](../ci/runner-budget.md): the per-step table for the gate's jobs from six successful runs on 10–11 October (Playwright 143 s: pull 48, restore 3, build and boot 29, tests 55, save 15; vitest 68 s; the checks legs 25–49 s, of which 22–28 s is the image pull), which replaces the 17 s and 51 s figures measured at MB.96 on a 131-file suite; the gate runs about 300 times a month, not 245; a job cancelled while queued (47 vitest jobs on 28 September, no runner, no steps) bills nothing; and the Blacksmith question — moving the three image builds and Playwright there would add roughly 4,000 two-vCPU minutes a month to save about a minute, and a per-branch registry cache tag buys nothing because the content-hash tag already skips every build whose inputs are unchanged. `testing/layer-ownership.md` says CI's figures come from a GitHub-hosted runner; the vitest job has run on Blacksmith since MB.96.

No test is added: a workflow is harness (`claude-docs/testing/layer-ownership.md`, "What a test may assert", rule 1).

_Acceptance criteria:_

- The PR's own Playwright job logs `Cache restored from key` and has no save step; its job time is measured against the 143 s six-run mean and recorded in this entry
- `e2e-cache.yml`'s warm job still saves, proved on the first push to `staging` after the merge and pasted into the closing comment on the issue
- The build leg's `/app/.next/cache` is either saved from `staging` or removed, with the warm and cold `next build` times in the PR body
- `ci/runner-budget.md` carries the per-step table, the run count, the queued-job note and the Blacksmith conclusion; `testing/layer-ownership.md` names the runner correctly; `testing/e2e.md` and `ci/reusable-checks.md` describe the restore and save split
- No test is added: the harness is not tested (layer-ownership.md, rule 1)

**MB.236 — Four Playwright workers on the gate's 4-vCPU runner, kept only if measured faster** · 1h

_Story:_ As a maintainer, I want the e2e tests to use the time a worker spends waiting on the browser, so that the gate's slowest step gets shorter.

The 56 tests take 55 s on two workers (run 38110758509: `Running 56 tests using 2 workers` at 04:12:38, `56 passed` at 04:13:33), about a second each, so most of the step is per-worker serial time. `tests/e2e/slots.ts` sets the worker count to `E2E_WORKERS`, or else `floor(cpus / 2)`, which is 2 on GitHub's 4-vCPU runner. A Playwright test spends most of its second waiting on page loads, not on the runner's cores, so four workers may finish sooner even though they oversubscribe the cores. Each extra slot is one more `next start` (about 180 MB and 0.5 s to boot, `testing/e2e.md`) and one more database clone. [`design-decisions/mb.224-plan.md`](../design-decisions/mb.224-plan.md) lists this as an experiment for after its measurement.

The change is one line, `E2E_WORKERS: 4` in `playwright.yml`'s job env, and the task is the measurement: the `Run Playwright e2e tests` step and the span from `Running 56 tests` to `passed` on at least three gate runs of the PR against the six-run baseline (71 s step mean, 55 s of tests), and the retry count from the JSON report, since contention would show first as retries. If the tests are not faster, or retries rise, the task closes unmerged and this entry records the numbers. `e2e-cache.yml`'s build-only run starts the same servers and runs no spec, so it is unaffected either way.

No test is added: a workflow is harness (layer-ownership.md, rule 1).

_Acceptance criteria:_

- The step and the test span are measured on at least three gate runs of the PR and recorded in this entry against the baseline
- Merged only if the test span is shorter with no rise in retries; otherwise closed unmerged with the numbers here
- `testing/e2e.md` and `ci/reusable-checks.md` say four workers on 4 vCPU, with the reason
- No test is added: the harness is not tested (layer-ownership.md, rule 1)

**MB.237 — A Chromium-only e2e image on `node:26.6.0-bookworm-slim`** · 3h

_Story:_ As a maintainer, I want the e2e image to carry only the browser the suite uses, so that the pull at the head of every Playwright job shrinks.

`Docker/Dockerfile.e2e` builds on `mcr.microsoft.com/playwright:v1.63.0-noble`, which ships Chromium, Firefox and WebKit with the system libraries for all three, and then runs its own `npm ci`. Pulling it and starting Postgres and Mailpit is the first 48 s of every Playwright job on GitHub's runner (six successful runs, 10–11 October), the largest fixed cost on the gate's critical path. The suite runs Chromium only.

The new base is `node:26.6.0-bookworm-slim`, the Node pinned in `Dockerfile.node`'s `NODE_VERSION`, with `npx playwright install --with-deps chromium` after `npm ci` so the browser is the one `@playwright/test`'s pinned version expects. Alpine stays out: Chromium has no musl build (`Dockerfile.node`'s own comment). The `headed` stage keeps xvfb, x11vnc, noVNC, websockify and openbox working for the devcontainer's headed browser. The content hash already covers the Dockerfile, so the new image publishes on the PR's first gate run, and that run is the measurement: `Initialize containers` against 48 s, and the image's compressed size from the build log or GHCR against the old tag's.

A doc fix rides along: [`ci/composite-actions.md`](../ci/composite-actions.md), MB.99's entry in this file and [`design-decisions/mb.96-plan.md`](../design-decisions/mb.96-plan.md) all say the e2e image reuses `development`'s `npm ci` layer through the registry cache. It is a separate Dockerfile on a different base and never did.

No test is added: a Dockerfile is harness (layer-ownership.md, rule 1). The devcontainer's e2e runs use the remote `playwright-server`, not this image, so the local proof is the build and the CI run.

_Acceptance criteria:_

- `Dockerfile.e2e` builds from `node:26.6.0-bookworm-slim` with Chromium only, and the `headed` stage still builds
- The PR's Playwright job passes on the new image, with `Initialize containers` and the compressed image size recorded in this entry against 48 s and the old size
- The three docs no longer claim the e2e image shares `development`'s layer; `testing/e2e.md` names the base
- No test is added: the harness is not tested (layer-ownership.md, rule 1)

**MB.238 — The `db` project's files that register no mock run without isolation, measured** · 4h

_Story:_ As a developer, I want the database tests to stop re-evaluating the same module graph for every file, so that the suite runs faster locally and on CI.

`Run vitest` is 47 s of wall on CI's seven workers, and the run's own breakdown puts 30 % of it in imports (run 38110758509: tests 38 %, import 30 %, transform 13 %, setup 10 %, environment 8 %). Its import hint for the `db` project reads "387 modules were evaluated 16,386 times · 69.31s total": 134 files, each evaluating the same hundred-odd modules again because every file gets a fresh module registry. With `isolate: false` a worker keeps its registry from one file to the next, and the import cost is paid once per worker.

The known issue, from [`design-decisions/mb.96-plan.md`](../design-decisions/mb.96-plan.md): `--no-isolate` on the `unit` project halved it locally but broke `tests/app/providers.test.tsx`, because a `vi.stubGlobal` leaked through the shared graph, and a mock one file registers stays registered for the next. Today 38 of the `db` project's 134 files call `vi.mock`, `vi.doMock`, `vi.stubGlobal`, `vi.stubEnv` or `vi.resetModules`. So it is not a blanket switch. The shape: the config scans each `db` file's source for those calls when it loads, as it already globs the file list, and puts the files that register a mock in a `db-mocking` project with the same harness and `isolate: true`, and the rest in `db` with `isolate: false`. A scan rather than a maintained list, so a file that starts mocking moves on its own and never runs unisolated by mistake. The database harness already gives each file a fresh clone, so what remains is JavaScript module state: the `src` files holding a module-level `Map` or `Set`, React `cache()` or `unstable_cache` (18 at the time of writing) are each shown to be per-request or reset by the harness, or their test files join the isolated project.

The proof is three local runs of the full coverage suite under `--sequence.shuffle`, serialised on the shared lock, and the PR's CI run: the gain is the `Run vitest` wall and the import share. If the wall is under 5 s better on CI, the task closes unmerged and this entry records why. `unit` and `dom` stay isolated; `unit` is a follow-up only if `db` pays. `test:stories` has its own config and is unaffected.

_Acceptance criteria:_

- The `db` files that register no mock run with `isolate: false` and the ones that do keep isolation, decided by the config's scan and not by hand
- The full coverage run passes three times shuffled locally and once on CI
- `Run vitest` wall and the import share before and after are recorded in this entry; merged only if the CI wall is at least 5 s shorter
- `testing/db-harness.md` or `testing/where-tests-live.md` describes the two projects and what moves a file between them
- No test is added for the config: the harness is not tested (layer-ownership.md, rule 1)

**MB.239 — Two tests that depend on the order of the tests in their file** · 1h

_Story:_ As a developer, I want every test to pass whichever of its siblings ran before it, so that a shuffled or reordered run fails only for a real reason.

MB.238's verification ran Vitest with `--sequence.shuffle`, which shuffles the tests inside a file as well as the files, and two tests failed that pass in file order and fail the same way on the config before MB.238:

- `tests/db/seed/sources.test.ts` seeds the clone once in a `beforeAll` for its first two tests, and its "over a database a keeper has edited" block empties the clone in a `beforeEach` and seeds what each test needs. Run after that block, the first two tests read its last test's rows: the Greek source's deities then include "Adonis Renamed". The fix: the first two tests move into their own block seeded in a `beforeEach`, so each reads a fresh seed whichever block ran first.
- `tests/components/ChipColorField/index.test.tsx` presses Tab and focuses the format toggle, expecting the tooltip that opens on keyboard focus. The tooltip's keyboard listener (zag's `trackFocusVisible`) is attached a microtask after the first tooltip mounts, once per window, and it outlives the render, so every test but the file's first finds it already there. Run first, the test's key press lands before the listener exists and the tooltip never opens. The fix: the test yields a microtask after rendering, so it depends on no earlier mount.

Neither is a bug in the code under test, and CI never shuffles, so no behaviour changes. The proof is the two files under `--sequence.shuffle --sequence.seed=1791696601822`, the seed that exposed both, and in file order.

_Acceptance criteria:_

- Both files pass with seed 1791696601822 under `--sequence.shuffle`, and in file order
- No new test and no change under `src/`: each fix removes a dependence on sibling order rather than adding an assertion

**MB.240 — The compendium seed: scope, sourcing rules, the candidate list and the library** · 3h

_Story:_ As a site keeper, I want the compendium's starting entries decided and their sourcing rules written down, so that six research lanes fill one list without overlapping or inventing anything.

Minted on 2026-10-11 on the owner's call to seed the compendium with a researched, sourced list of 614 entries rather than leave a keeper to type them ([`design-decisions/mb.240-plan.md`](../design-decisions/mb.240-plan.md); the record, [`design-decisions/mb.240-compendium-seed.md`](../design-decisions/mb.240-compendium-seed.md)), the first of ten (MB.240 to MB.249). Docs and minting only, so it starts on `staging` without waiting for the variant tasks. The 3 hours are an estimate, calibrated against MB.127 (2.5h, a 216-row researched list with its sources) and MB.215 (2h, a model record).

It writes `claude-docs/db/compendium-seed/README.md`: the entry template with a worked invented example; the field names a citation's `supports` may hold; the closed lists by reference to their seed files; the formal-name rules (mineral varieties in `standard`'s form, `Quartz var. amethyst`); the sourcing rules; write-once and how a correction lands; the library, each of the owner's files identified from its own title and copyright pages, with its Chicago citation and how to cite a place in it; and the `standard` fixture's 26 names, so a lane spells them the same way. Beside it, the candidate list `claude-docs/db/compendium-seed/candidates.md`: about 614 rows of label, formal name, naming system and shard, drawn from several works, each list source a Chicago row, so the seed mirrors no single book's selection.

The library is protected in the branch's first commit: `.gitignore` gains `.library/`, and `tests/guards/no-tracked-books.test.ts` fails on a tracked or unignored `.pdf` or `.epub`. `pdfjs-dist` becomes a devDependency for `scripts/library-text.ts` and its `library:text` npm script, which writes each PDF page as a text file under `/app/.library/text/` and unpacks each EPUB there. The corrections: DESIGN.md §11's "Seed data" says the production compendium is seeded as reference data, not a scenario; §14 gains "Is the compendium seeded?"; `db/seed-module.md` names the target. The plan is copied beside its record.

Tests are written first:

- `tests/guards/no-tracked-books.test.ts`: fails on a `.pdf` or `.epub` in the repo's listing, and when `.library/` is not ignored

_Acceptance criteria:_

- No two candidate rows share an identity, every row names its shard and a naming system that satisfies the `none` rule, and every list source is a Chicago row
- DESIGN.md §11 and §14, the wave file and `db/seed-module.md` agree that the compendium is seeded
- The guard refuses a tracked or unignored `.pdf` or `.epub`, and passes without one
- `npm run library:text` extracts every PDF in the library and unpacks every EPUB; the README records each file's edition from its own pages
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.241 — `seed_key` on `ingredients`** · 1h

_Story:_ As a maintainer, I want a seeded compendium entry to carry the key the seed gave it, so that an entry a keeper renames is not seeded again beside itself.

Minted on 2026-10-11 with MB.240 ([`design-decisions/mb.240-plan.md`](../design-decisions/mb.240-plan.md)), the table task before MB.242's seed under the table-then-behaviour rule. `ingredients` and `ingredient_variants` carry no `seed_key` today (MB.171 put it on the nine tables `migrate.yml` seeds; [`design-decisions/mb.171-seed-keys.md`](../design-decisions/mb.171-seed-keys.md)), so without one a keeper's relabel or formal-name edit would make the next reseed insert the original again. Only `ingredients` needs it: the seed is write-once, so a variant is never looked up again. It follows MB.223, whose migration `0064` merged to `staging` on 2026-10-11, so it builds on `staging` directly. The hour is an estimate, calibrated against MB.171 (1.5h, nine tables) and MB.223 (1h).

`seedKey: seedKeyColumn()` and `seedKeyUnique('ingredients_seed_key_unique', table)` join `src/modules/ingredients/schema/ingredients.ts`, with the builders in `src/db/schema-parts.ts`; `db:generate` writes migration `0065`, additive, with no sidecar.

Tests are written first:

- `tests/db/partial-unique-indexes.test.ts` gains the index's row; the schema drift test picks the column up

_Acceptance criteria:_

- Exactly one column and one partial unique index are added
- The drift test is green
- Nothing reads or writes the column yet
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

_As built:_ merged to `staging` on 2026-10-11 in PR #854, built in its own lane while MB.240 minted this entry: migration `0065_ingredients-seed-key`, and the docs naming the column (DESIGN.md §5, `db/identity-model.md`, `db/seed-module.md`, `design-decisions/mb.171-seed-keys.md`).

**MB.242 — `db:seed:compendium`, the guard, CI and a 14-ingredient pilot** · 6h

_Story:_ As a site keeper, I want the compendium seeded on staging and production the way the curated vocabularies are, so that every entry arrives sourced and nothing a keeper changed is undone.

Minted on 2026-10-11 with MB.240 ([`design-decisions/mb.240-plan.md`](../design-decisions/mb.240-plan.md)), the mechanism every content shard writes through. It waits for MB.222, which leaves `identityOf` and the variant insert in `standard.ts` as the seed reuses them, and for MB.241's column. The 6 hours are an estimate, calibrated against MB.156 (6h), MB.172 (2h) and MB.129 (2h).

The types, in `src/db/seed/types.ts`: `SeedCompendiumEntry`, the ingredient's fields plus `colors`, `folkNames`, `deities`, `categories`, `substitutes` (`{ identity, form?, substituteForm? }` or a typed `{ name }`), `references` (`{ source, locator?, supports }`, `supports` naming the fields the citation backs) and `variants`, each with its own description, safety notes, the four lists, categories, substitutes and references.

The seed: `src/db/seed/compendium.ts`, `seedCompendium(db, entries = COMPENDIUM)`, and `src/db/seed/compendium/` holding `index.ts` (`COMPENDIUM = []` until the first shard), `works.ts` (the works several shards cite, declared once), `colours.ts` (a closed list of lower-case British colour names) and `guard.ts`. `insertMissingReferences` moves out of `sources.ts` into `src/db/seed/reference-rows.ts` with no change in behaviour, and both seeds key references on their rendered citation, so a work the sources seed already wrote is linked, not written twice. The seed is write-once: the run that inserts an entry writes everything beneath it, and an entry present by `seed_key` (live or deleted), by a live identity or by a live slug is skipped with nothing beneath it written and no key stamped. Forms, deities and categories are picked through the curated rows' `seed_key`, planets and signs stored as the live row's name; a soft-deleted pick is skipped and a name no seed wrote throws. Inserts are chunked at 1,000 rows, under Postgres's 65,535-parameter limit.

The guard, `checkCompendium(entries, sources)`, is a pure function run in a test and again inside `seedCompendium` before its transaction opens. It checks that identities and slugs are unique across shards; the naming system and formal name pair up, and botanical, fungal and zoological names are binomials; every form, category, deity, planet, sign and colour is on its closed list; every entry and every variant cites at least one reference of its own; every populated field is named by some citation's `supports`; every handle resolves; `book` and `chapter` citations carry a locator; citation texts are pairwise distinct; substitutes resolve to an identity in the same or an earlier shard and are never the entry itself; entry descriptions run 100 to 250 words and variant descriptions at most 120.

The wiring: `scripts/db-seed.ts`'s target, usage and error text; `package.json`'s `db:seed:compendium`; `migrate.yml`'s sixth seed line after `sources`, its input description and summary; `deploy.yml`'s reseed list gains `src/db/seed/compendium.ts`, `src/db/seed/compendium/`, `reference-rows.ts` and `idempotent.ts`. The docs: `ci/deploy.md` ("all six"), `db/references.md` (how the compendium links its sources), MB.225's "five production seeds" corrected, and the stale comments in `sources.ts` and `deities.ts` that say a test parses the docs.

The pilot: `src/db/seed/compendium/pilot.ts` and `claude-docs/db/compendium-seed/pilot.md`, 14 real entries, one of each kind (botanical, fungal, zoological with two forms, a mineral variety, a metal, a salt, a resin, a wood, a `none` water and others), researched to the README's full rule. They count toward the 614, prove the shape, the guard and the CI path on real data, and their actual time re-calibrates MB.243 to MB.248 before those are briefed.

Tests are written first:

- `tests/db/seed/compendium-literals.test.ts`, with no database: each guard rule fails once on an invented fixture, and `COMPENDIUM` is checked clean
- `tests/db/seed/compendium.test.ts`, on an invented two-entry fixture shard: it seeds whole, variants with their picks, children and links at both levels; a reference the sources seed wrote is linked, not written again; an entry present by `seed_key` (live or deleted), live identity or live slug is untouched, with nothing beneath it written and no key stamped; a soft-deleted pick is skipped; an unknown form throws; the seed runs cleanly after `standard`
- `SEED_ENTRIES` gains a sixth entry over the fixture shard, owning `ingredients`, `ingredient_variants`, the four child tables, `references` and `reference_links`

_Acceptance criteria:_

- The guard fails any entry or variant citing no reference, any field no citation supports and any value outside the closed lists, in the test and before the seed's transaction opens
- A reseed adds, moves and restores nothing, and every seeded row carries the bootstrap user's stamps
- `migrate.yml` runs the target after `sources`, and `deploy.yml` reseeds when the compendium folder changes
- The sources seed's tests are unchanged and green
- `npm run db:seed:compendium` run twice on a reset database writes nothing the second time
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.247 — The compendium seed: resins, woods and other ingredients** · 5h

_Story:_ As a reader, I want the resins, woods, incense, animal products, salts and waters in the compendium with their forms, correspondences and safety notes, each traced to a source, so that the reference I consult says nothing it cannot back.

Minted on 2026-10-11 with MB.240 ([`design-decisions/mb.240-plan.md`](../design-decisions/mb.240-plan.md)), the fifth content shard, built beside MB.243 by its own research lane after MB.242 and merged after MB.243. It writes `src/db/seed/compendium/resins-woods-and-other.ts` and `claude-docs/db/compendium-seed/resins-woods-and-other.md`, 48 entries, the rows `candidates.md` gives this shard, under MB.243's lane brief. Animal products are forms beneath the animal's binomial, and a preparation no naming system names, a moon water or a black salt, is `none`. The 5 hours are the plan's estimate for about 80 entries; the candidate list gives the shard 48, because few of the sources read name these ingredients and no row was added without one, and the pilot's measured time re-calibrates it before the lane is briefed.

No test is added: the guard and the `SEED_ENTRIES` sweeps run over the real list.

_Acceptance criteria:_

- Seeded entries plus "What is left out" rows equal the shard's candidate rows; a lane that would leave out more than a tenth of them stops and raises it with the owner before opening its pull request
- Every entry cites at least one reference of its own and every form at least one of its own, and every populated field is covered by a citation's `supports`
- The doc has its bibliography in Chicago form and one source line per entry, and records the shard's form count
- The guard is green, and `npm run db:seed:compendium` is idempotent from empty and after `standard`
- The pull request body states that every cited page or URL was read during the task
- Per-file coverage of the touched `src/` directories not below the previous run's `.reports/coverage/coverage-summary.json`, or the exception named in the PR body

**MB.251 — Call the planets Celestial Bodies wherever a person reads them** · 3h

_Story:_ As a keeper, I want the vocabulary that holds the Sun, the Moon, the asteroids and the lunar nodes called Celestial Bodies, so that its name says what it holds.

Minted on 2026-10-12 on the owner's call ([`design-decisions/mb.251-plan.md`](../design-decisions/mb.251-plan.md)), the first of four (MB.251 to MB.254). The admin tab, page, dialogs and buttons, the ingredient form's list field and its variant summaries, and the URL change: `/admin/planets` becomes `/admin/celestial-bodies`, with no redirect. Most of the admin copy is the `planet` entry in `GroupedValueList/kinds.ts`. Code, GraphQL and database names keep `planets` until MB.253 and MB.254, and a decision record, `mb.251-celestial-bodies.md`, says so, beside DESIGN.md §5, §9 and §14, CLAUDE.md's admin sentence and a Vocabulary line, so no session "fixes" the divergence early. The hours are an estimate: a copy change across about ten test files, two e2e specs and the docs that name the screen.

_Acceptance criteria:_

- `/admin/celestial-bodies` serves the vocabulary and `/admin/planets` returns 404
- The Astrology section's tab, page title, filter, empty and no-match text, and every dialog and button name the vocabulary Celestial Bodies or a Celestial Body
- The ingredient form's list field and each variant's read Celestial Bodies, with the entry box Celestial Body
- No user-visible string under `src/app` or `src/components` says planet
- DESIGN.md, CLAUDE.md and the docs naming the screen or URL are corrected, and the divergence is recorded with the tasks that end it
- The touched component tests and the `admin.spec.ts` and `admin-compendium.spec.ts` e2e specs pass under the new names

**MB.252 — The celestial bodies table and columns, beside the planet ones** · 5h

_Story:_ As a developer, I want the celestial-body table and columns in place before any code reads them, so that the switch from the planet names is a code change against objects that already exist.

Table task, the expand half of rule 10 ([`design-decisions/mb.251-plan.md`](../design-decisions/mb.251-plan.md)). The `planets` table is renamed `celestial_bodies`, and a view named `planets` over it keeps the code that is live during the rollout working. `ingredients` and `ingredient_variants` gain a nullable `celestial_bodies text[]`, and `reference_links` a `celestial_body_id` with its foreign key and partial unique index, `reference_links_celestial_body_unique`. The migration fills every new column from its old one. Scoped first, because no table has been renamed here before: whether the view serves every statement the live code sends. It does, measured on 2026-10-12 against the whole `db` test project and against statements prepared before the rename ([`design-decisions/mb.252-table-rename.md`](../design-decisions/mb.252-table-rename.md)).

**The one-row CHECK counts either column during the expand.** `reference_links_one_row`, the CHECK that a link names exactly one sourced row, today counts `planet_id` (`src/db/migrations/0063_variant-children.sql`). It is re-added counting `coalesce(celestial_body_id, planet_id)` in that place: `num_nonnulls(ingredient_id, deity_id, deity_tradition_id, coalesce(celestial_body_id, planet_id), zodiac_sign_id, ingredient_variant_id) = 1`. Two kinds of row need it. The sources seed still writes a planet link with `planet_id` alone (`add('planetId', …)` in `src/db/seed/sources.ts`), under the code before this task and under this task's own, so a CHECK counting `celestial_body_id` alone would refuse every such row and fail the sources seed test and `db:reset` on this task's own CI. And the fill leaves both columns set on every existing link, which a CHECK counting both columns would refuse. The schema file builds this CHECK from the `SOURCED` registry in `src/modules/ingredients/schema/reference-links.ts`, so the expand form is spelled out there by hand. The strict form, counting `celestial_body_id` alone, is MB.254's.

**The schema declares the renamed table, and four catalogue tests move with it.** `src/modules/vocabulary/schema/astrology.ts` declares `pgTable('celestial_bodies')` under its existing `planets` export, so this task's code reaches the table itself and only the deploy before it goes through the view. Each test below was read for this entry:

- `tests/db/schema-drift.test.ts` lists only tables (`relkind in ('r', 'p')`) and compares each table's foreign-key names and target table with the schema's. A view is out of its sight, so the renamed table must be declared under its new name. Its `PENDING_DROPS` list, the objects the schema has stopped declaring and a later task drops, has the kinds `column`, `index`, `check`, `foreignKey` and `table` and none for a view; this task adds a `view` kind, checked against the catalogue as the others are, and lists `planets` for MB.254 to drop.
- `tests/db/audit-columns.test.ts` reads `information_schema.columns`, which lists a view's columns as well as a table's, so the `planets` view would count as a stamped table beside `celestial_bodies` and the comparison with the transcribed list, held at 27 by `toHaveLength(27)`, fails. It reads base tables only, and the count stays 27.
- `tests/support/db/table-metadata.ts`'s `AUDITED_TABLES` names `planets`, and names `celestial_bodies` instead. The `set_updated_at` trigger moves with the table, since a rename keeps a table's triggers, so `tests/db/updated-at-trigger.test.ts`, which reads that list, passes with the edit.
- `tests/db/partial-unique-indexes.test.ts` fails on any partial unique index it has not classified, so `reference_links_celestial_body_unique` gets a row beside `reference_links_planet_unique`.

The scoping found more that names the table: `tests/db/seed/index.test.ts`'s astrology tables, `vocabularies.test.ts`'s trigram list, `astrology.test.ts`'s table, the three module schema tests' column lists, and `IN_USE` in `src/db/repository/vocabularies.ts`, which is keyed by table name.

**The table's foreign keys, indexes and CHECK are renamed here.** Drizzle names a foreign key from its table and the table it points at, and `vocabularyIndexes` names the indexes and CHECK from the table, and the drift test compares the names. So `planets_created_by_users_id_fk`, `planets_updated_by_users_id_fk` and `planets_deleted_by_users_id_fk` become `celestial_bodies_…`, `reference_links_planet_id_planets_id_fk` becomes `reference_links_planet_id_celestial_bodies_id_fk`, and `planets_seed_key_unique`, `planets_slug_unique`, `planets_trgm` and `planets_description_not_blank` become `celestial_bodies_…`. The astrology service's `slugIndex` names the new slug index. The deploy before maps a duplicate slug to the friendly error by the old name, so during the rollout and after a rollback to it a duplicate gets a generic error, still refused. The owner chose that on 2026-10-12 over keeping the old names until MB.253, which would have cost a two-name `slugIndex` and a second rename migration. The `RENAME`s and the CHECK's drop carry an `.ack.md` sidecar, since `scripts/check-destructive-ddl.ts` flags any `rename`.

The hours were re-estimated on review on 2026-10-12, from 2: the repo's first table rename, a view, a hand-written CHECK, four renamed foreign keys and four catalogue tests. They remain an estimate.

_Acceptance criteria:_

- `celestial_bodies` holds the rows, and the `planets` view reads and writes them, asserted from the catalogue and by a write through the view
- The three new columns exist, and every row with a value in an old column carries it in the new one, asserted against the seeded template
- `reference_links_one_row` counts `coalesce(celestial_body_id, planet_id)`: a link with `planet_id` alone saves, and so does a filled link holding both, asserted by insert
- The sources seed test and `npm run db:reset` pass with the sources seed unchanged
- The schema declares `celestial_bodies`; `AUDITED_TABLES` names it in place of `planets`; the schema-drift, audit-columns, updated-at trigger and partial-unique tests pass; and `PENDING_DROPS` holds the `planets` view under a `view` kind
- The table's three audit foreign keys and `reference_links`' planet foreign key carry `celestial_bodies` in their names, so do the table's indexes and CHECK, and a duplicate slug returns the friendly error
- The migration carries its acknowledgement sidecar, and the destructive-DDL check passes with it
- Nothing reads or writes the new columns yet

**MB.253 — Read and write celestial bodies under their own names** · 8h

_Story:_ As a developer, I want the code and the API to say celestial bodies where the screens do, so that no one has to know that "planet" in the code means a celestial body.

Switches every reader and writer to MB.252's table and columns, and renames the code and GraphQL names in the same PR, since every line it touches is one the rename touches too ([`design-decisions/mb.251-plan.md`](../design-decisions/mb.251-plan.md)). GraphQL's `Planet`, `PlanetInput`, `createPlanet`, `updatePlanet`, `deletePlanet`, `planets` and `planetSuggestions` become `CelestialBody`, `CelestialBodyInput`, `createCelestialBody`, `updateCelestialBody`, `deleteCelestialBody`, `celestialBodies` and `celestialBodySuggestions`, and the `planets` field on ingredients, variants and their inputs `celestialBodies`. The TypeScript follows: `kind: 'celestialBody'`, `CuratedField`, `FLAT`, `IN_USE`, `PLANETS`, the seed shards' `planets:` entries, the MSW mocks, codegen and the SDL snapshot. The Drizzle schema stops declaring the old columns, and the migration fills the new ones again for any row the live deploy wrote after MB.252.

**What joins `PENDING_DROPS`.** The three columns, `ingredients.planets`, `ingredient_variants.planets` and `reference_links.planet_id`, and with the last its foreign key and its partial unique index: `reference_links_planet_id_celestial_bodies_id_fk`, the name MB.252 gives `reference_links_planet_id_planets_id_fk`, and `reference_links_planet_unique`. The drift test compares both kinds, so each needs its line until MB.254 drops it.

**The seed is a larger surface than the plan counted.** A grep on 2026-10-12 finds 281 `planets:` keys and 435 `'planets'` string literals, most of the literals the field names in each reference's `supports` list. They sit in the pilot and the six compendium shards under `src/db/seed/compendium/`, and in `src/db/seed/compendium.ts`, `compendium/guard.ts`, `sources.ts`, `standard.ts` and `types.ts`. The scoping plan counted "about 260 `planets:` entries in the seed shards" and none of the literals.

**Raw-SQL test helpers name the old column too.** `tests/support/db/read-variants.ts` selects `planets`, and `tests/db/seed/sources.test.ts` selects `l.planet_id` and joins `planets` on it. Neither passes through the schema, so the type checker does not find them.

**The docs that name the table, its columns or the GraphQL names move in this task.** A grep on 2026-10-12 finds them in `claude-docs/graphql/schema.md`; `claude-docs/components/ingredient-form.md`; eleven `claude-docs/db/*.md` files (`astrology-vocabularies.md`, whose divergence note MB.252 corrected, `astrology-vocabulary-seed.md`, `compendium-cache.md`, `compendium-writes.md`, `deity-vocabulary-seed.md`, `deity-vocabulary.md`, `identity-model.md`, `member-autofill.md`, `migrations-and-scripts.md`, `references.md`, `seed-module.md`); the compendium seed's README, the pilot's doc and the six shard docs under `claude-docs/db/compendium-seed/`; `db.md`, `modules.md`, `validation.md`, `commands.md` and `ci/deploy.md`; and DESIGN.md's schema and SDL names, leaving MB.251's divergence notes for MB.254. A passage recording what an earlier task did stays as written, as do the decision records.

The hours were re-estimated on review on 2026-10-12, from 5: the seed's 716 occurrences, the index renames and their sidecar, the two raw-SQL helpers and 27 docs come on top of the calibration against MB.136 (3h) plus the rename's mechanical churn. They remain an estimate. MB.252 took the index renames on 2026-10-12, and the hours were not re-estimated for that.

_Acceptance criteria:_

- The SDL names no planet, and the snapshot and `src/gql` move with it
- Every reader and writer uses `celestial_bodies` and the new columns, and nothing declares or reads the old ones, which still exist
- A value written to an old column after MB.252's migration is in the new column after this one's
- `PENDING_DROPS` lists the three old columns, `reference_links_planet_id_celestial_bodies_id_fk` and `reference_links_planet_unique`, and the drift test passes
- A duplicate slug still returns the friendly error
- Suggestions still count a value in use once however many lists hold it, scoped to the compendium and this coven, asserted with the precondition that another coven holds the value
- No identifier, test name, comment, seed literal or raw-SQL helper under `src/` or `tests/` says planet, bar the migration history and `PENDING_DROPS`, the objects those lines still name until MB.254 (the one-row CHECK's `coalesce`, the index test's row for `reference_links_planet_unique`, and the migration data tests), and astronomy and citations that mean a planet
- The live docs listed above name the new table, columns and GraphQL names

**MB.254 — Drop the planet columns and view** · 2h

_Story:_ As a developer, I want the retired planet columns and view gone, so that nothing can write a value the app no longer reads.

The contract half of rule 10, a task of its own ([`design-decisions/mb.251-plan.md`](../design-decisions/mb.251-plan.md)). Once a release carrying MB.253 has reached production, the migration drops `ingredients.planets`, `ingredient_variants.planets`, `reference_links.planet_id` with its foreign key and unique index, and the `planets` view, with its `.ack.md` sidecar, and `PENDING_DROPS` empties, its `view` line included. Production is the gate rather than staging because the release before MB.253 still reads the old columns. The divergence notes MB.251 added to DESIGN.md and CLAUDE.md go in the same PR.

**One last fill for the links, none for the lists.** Between MB.253's migration and its code going live, the deploy before it can still write the old columns, and nothing copies those writes across. The two kinds of column are treated differently, each under its own precedent:

- **`reference_links.planet_id` is filled one last time.** Before the drop, the migration copies `planet_id` into `celestial_body_id` on every link, live or removed, that holds the first and not the second. MB.253's code never writes `planet_id`, so such a row can only be a write from the deploy before it, and the copy only adds: it never overwrites a value MB.253's code wrote. Without it, the strict CHECK below could not be added over a link whose only key was `planet_id`. MB.141's `0039_drop-substitutes-list.sql` is the precedent, a refill that only adds before the drop. The copy has one collision to handle. During MB.253's rollout the deploy before can link a body to a reference by `planet_id` while MB.253's code links the same pair by `celestial_body_id`, and copying the first over would then break `reference_links_celestial_body_unique` for two live links. Found while building MB.253 on 2026-10-12.
- **The two list columns get no last fill**, as MB.137's `0036_drop-ingredient-singles.sql` gave its single columns none. MB.253's code edits the new lists, and a cleared list is stored as NULL (`claude-docs/validation.md`), so an old list beside a NULL new one may be a member's clear rather than a missed write, and a fill would undo it.

**The strict one-row CHECK lands here.** The migration re-adds `reference_links_one_row` counting `celestial_body_id` alone, in place of MB.252's `coalesce(celestial_body_id, planet_id)`, so the schema file builds it from the `SOURCED` registry again.

**The wave stays open across a production release.** This task merges into `staging` only after a release carrying MB.253 has reached production (`claude-docs/db/expand-contract.md`, "Expand/contract and the destructive-DDL check"). Under Gitflow, a merge to `staging` before then would ride the same release as MB.253 and drop the columns under the deploy that release replaces. So Wave 9 cannot close until that release has gone out and this task has merged after it.

The hours were re-estimated on review on 2026-10-12, from 1: the links' last fill and the strict CHECK, each with its test, join the drop. They remain an estimate.

_Acceptance criteria:_

- The three columns and the view are gone, and the new columns hold every value they held
- A link that held `planet_id` alone before the migration holds the same id in `celestial_body_id` after it, live or removed, and a link that already held a `celestial_body_id` is unchanged
- A list whose old column held a value and whose new column was NULL is still NULL after the migration, and the PR body names MB.137's precedent
- `reference_links_one_row` counts `celestial_body_id` alone, and a link naming no sourced row is refused
- `PENDING_DROPS` is empty
- The migration carries its acknowledgement sidecar, and the destructive-DDL check passes with it
- DESIGN.md and CLAUDE.md no longer record a planet divergence
- Lands only after a release carrying MB.253 has reached production, and Wave 9 stays open until it has

**MB.255 — The e2e session cookie never reaches a WebKit page** · 3h

_Story:_ As a developer, I want the e2e sign-in helper to sign a WebKit browser in as it does Chromium and Firefox, so that the WebKit and phone audit (M10.25) exercises the signed-in pages rather than the sign-in page.

Found by M10.25's first audit on 2026-10-13. `tests/e2e/session.ts`'s `signInAs` and `signInAgainAs` hand the browser the session cookie as an extra request header (`page.setExtraHTTPHeaders`), since a browser never sends a `Secure` cookie to the plain-http `devcontainer:<port>` a remote browser uses, and the production build's https base URL names the cookie `__Secure-better-auth.session_token`. WebKit sends no such header. Against an echo server on the audit service, Chromium and Firefox delivered the extra `cookie` header and WebKit delivered none; a `page.route` re-adding the header on every request reached WebKit no better; and from the cookie jar (`context.addCookies`) WebKit sends a plain-named cookie over http but never a `__Secure-` one, with or without `secure`. So in the `webkit` and `phone` projects every signed-in page is the sign-in page: 24 of the audit's 276 tests failed, every one behind a session, and 132 later tests in those files never ran under `serial`; the 14 signed-out tests in each project passed, and Firefox passed all 92. The fix must make the cookie reach the server from WebKit over the plain-http origin the remote browser uses. Two shapes, for the task to choose: a plain cookie name for the e2e servers, `advanced.useSecureCookies: false` in `src/lib/auth.ts` under an e2e-only switch, so the helper sets the cookie in the jar and every engine sends it; or https in front of the slot servers, so the `__Secure-` cookie in the jar is sent as it is in production. The first is a test-only branch in the auth config, the second is more to run. Whichever lands, the helper's comment and `claude-docs/testing/e2e.md` ("A signed-in browser without a provider") change with it, and the audit runs again at the end of this task: the four Tab-walking specs M10.25 expected to fail in WebKit (`sign-in.spec.ts`, `coven.spec.ts`, `coven-create.spec.ts`, `shell.spec.ts`) could not be judged, since each sits behind the session, and each real bug the rerun finds becomes its own task. The hours are an estimate.

_Acceptance criteria:_

- `signInAs` and `signInAgainAs` sign a WebKit page in, proven by the audit's `webkit` and `phone` projects reaching a signed-in page, and `npm run e2e` is unchanged in what it proves
- The helper's comment and `claude-docs/testing/e2e.md` say how the cookie travels and why
- The audit runs again at the end, its failures are named in the PR body, and each real bug becomes its own task

**MB.256 — An unverified account loops on the email page after a link into the shell** · 3h

_Story:_ As someone whose email address is not yet confirmed, I want a link into a signed-in page to take me to the email page and stop there, so that I can confirm my address instead of watching the page reload without end.

Found on 2026-10-13 while checking M10.32 by hand, impersonating the seeded unverified user. The shell layout, `src/app/(shell)/layout.tsx`, calls `requireSession()`, which redirects an unverified account to `/account/email`. When that redirect is thrown during a client-side navigation into the shell, the browser refetches the email page about every 80 milliseconds and never settles. Reproduced in a browser driven through Playwright, by following the Continue link from `/` to `/coven`, and by a router push from `/` to `/account`: about 400 refetches in 15 seconds on `next dev`, and about 120 in 6 seconds on a production build. It happens to a plain unverified session as well as an impersonated one. A full page load of `/coven` or `/account/email` settles normally, so the existing e2e test, which loads the page directly, stays green. Each refetch is answered by the email page itself, with no redirect, and the router state header the browser sends already holds the shell from the redirected fetch. So the router appears never to recover from a `redirect()` thrown by a layout it is entering, and unverified accounts are the only case the shell layout redirects. The bug is on `main` as well as `staging`; `src/app/(shell)/layout.tsx` and `src/lib/request-session.ts` are the same in both. Two shapes, for the task to choose between: leave the unverified redirect to each page's own `requireSession()`, so the layout never throws one, or keep it and find what lets the router settle. Pointing the Continue link at the email page alone is not a fix, because every other link into the shell would still loop.

_Acceptance criteria:_

- An e2e regression test signs in an unverified account, follows a link from `/` into the shell, and asserts the page settles on `/account/email`. It fails before the fix
- An unverified account still reaches no page but `/account/email`, by full load and by client-side navigation alike, and a signed-out visitor is still sent to sign in
- `claude-docs/auth/route-protection.md` and `claude-docs/auth/admin-bootstrap.md` ("The email page") say where the unverified redirect is thrown, and why

**MB.257 — The Coven Landing Shows a Blank Page Before Redirecting** · 3h

_Story:_ As a coven member, I want sign-in to take me straight to my coven's page, so that I don't see a blank page on the way.

Found on 2026-10-15, on the local dev server. `src/app/(shell)/coven/page.tsx` reads the viewer and calls `redirect()` to the first coven the switcher lists. On a member's sign-in the browser lands on `/coven`, shows a blank page for a moment, and only then reaches `/coven/[slug]`. It happens every time and is cosmetic. The cause is not yet established: it may be a loading state, the dev server compiling the route on first request, or the sign-in return path ending on `/coven` rather than on the coven. The task names the cause and says whether a production build shows it too. If it is the dev server alone, the task records that and lands the cheapest change that removes the extra hop.

Steps to reproduce:

1. Run the dev server locally.
2. Sign in as a coven member. This takes you to `/coven`, which redirects to `/coven/[slug]`.

Actual: `/coven` shows a blank page for a moment before `/coven/[slug]` loads.
Expected: the member goes directly to `/coven/[slug]`.

_Acceptance criteria:_

- A regression test that fails before the fix: a signed-in member with a coven who goes to `/coven` ends on `/coven/[slug]` with no page body shown in between. It is a Playwright spec, since it is a navigation behaviour
- A member with no coven still sees the landing's three states (M2.8, MB.57) and is not redirected
- A signed-in account outside the coven still gets a 404 from `/coven/[slug]` by direct id, asserted with a coven the account could otherwise have reached
- The PR body names the cause and says whether a production build shows it too
- The docs that describe the post-sign-in landing are corrected if the fix changes where sign-in sends a member
- The story suite's landing check is reassessed with the fix: `landingRedirect` in `tests/e2e/stories/01-invitations.spec.ts` (Story 6) reads the 307 from `/coven` and ignores Next's prefetch of it, which the shell's brand link fires from every page. If the fix changes where a member is sent or how `/coven` answers, that helper and the Story 6 step change with it, in this task's PR

**MB.258 — The Edit Source Form Leaves Blank Space and Has No Close Button** · 2h

_Story:_ As a site keeper, I want the edit source form to open without extra blank space and to have a close button at the top, so that I can edit a source cleanly and leave the form without hunting for another way out.

Found on 2026-10-15. When a site keeper edits a source (a reference row) from the admin Compendium, the form expands inside the ingredient modal. It opened once with extra blank space below the form, and it has no close button at the top. It looks like the modal's height does not settle to its content when the form expands, but the cause is not confirmed. The blank space was seen once, so the first job is to find what makes it appear.

Steps to reproduce:

1. Sign in as a site keeper.
2. Open the admin Compendium and find a source (reference) row.
3. Choose to edit that source. The form expands inside the ingredient modal.

Actual: Extra blank space appears at the bottom of the modal when the form opens (seen once, not every time). The form has no close button at the top.
Expected: The modal fits its content with no extra blank space, and the form has a close button at the top.

_Acceptance criteria:_

- A regression test that fails before the fix: the edit source form has a close button, and using it closes the form and leaves the source unchanged
- Opening the edit source form leaves no extra blank space below it in the modal, and the PR body names the cause of the intermittent space
- The close button sits at the top of the form, can be reached by keyboard and has an accessible name, and `@axe-core/playwright` is clean on the open form
- Closing the form saves nothing, and the form keeps the form save rules (Cancel stays quiet)
- The component's doc and story are corrected if the fix changes them

**MB.259 — ~~Category Chips Sometimes Show a UUID Instead of the Name~~** · **RETIRED 2026-10-16, not done**

> **Retired without being done.** The ID is kept because task IDs are immutable
> and the analysis below is the record of why the glitch is tolerated.
>
> **Why.** The cause was found and reproduced on a production build. The
> Categories picker names a chip only from the `categories` list, which
> `listCategories` serves from the compendium data cache for up to an hour
> (`COMPENDIUM_REVALIDATE_SECONDS`), while the ingredient's picked categories
> are read live. A category written outside the app, as `db:reset` does by
> minting new ids, is missing from the cached list, so its chip shows its id
> until the cache refreshes or a keeper edit expires the `compendium` tag.
> In production that needs a deploy whose reference seed adds a new category
> and files an entry under it, then a keeper opening that entry's form within
> the hour. The seed only inserts missing rows, so existing categories keep
> their ids, and the category vocabulary rarely changes. The chip holds a real,
> live id, so saving is unaffected; the glitch is cosmetic and clears itself.
> The owner judged it not worth a fix (2026-10-16). The cause is
> local-development resets, which a `db:reset` that clears the dev data cache
> would cure if it ever becomes a nuisance.

_Story:_ As a site keeper, I want the categories input on an ingredient's edit form to always show category names, so that I can tell which categories an ingredient has and edit them.

Found on 2026-10-15, on the local dev server. In the admin Compendium, the Categories input under the Relations section of an ingredient's edit form sometimes shows each chosen category as its UUID (its unique id) instead of its name. It is intermittent, and the cause is not yet known. It may be that the chip's name is looked up from a list that has not loaded when the chip draws, or that the names are cached and missing. The task finds the cause and says whether staging and production show it too.

Steps to reproduce:

1. Run the dev server locally.
2. Sign in as a site keeper.
3. Go to `/admin/compendium` and click edit on an ingredient.
4. Expand the Relations section.
5. Look at the Categories input.

Actual: Sometimes the chips in the Categories input show the categories' UUIDs instead of their names.
Expected: Every chip always shows its category's name.

_Acceptance criteria:_

- A regression test that fails before the fix: an ingredient that has categories shows each chip with its category's name and never its id, including when the category options have not finished loading, proven by role and label queries
- The test sets up the condition that produces the UUID chip, and fails without the fix
- The categories saved on the ingredient are unchanged by opening the form, expanding Relations or closing it
- The PR body names the cause and says whether a production build shows it too
- The docs for the categories input and the ingredient form are corrected if the fix changes them

**MB.260 — Admin Curated Lists Show No Updated Column** · 5h

_Story:_ As a site keeper, I want every curated list in the admin area to show who last edited each row and when, so that I can see how current an entry is and who to ask about it, as I can on the Coven members table.

Found on 2026-10-15, on the local dev server. The Coven members table has an Updated column. None of the admin curated lists have one (the Compendium, categories, the ingredient form vocabulary, the group vocabularies, the celestial body and zodiac vocabularies, and the deity and tradition vocabularies). So a keeper can't see who last changed a row or when. Every audited table already records who changed a row and when (`...auditColumns`, with a trigger that sets `updated_at`), so the data should already exist. The task lists the lists that need the column, reuses the Coven members table's Updated cell rather than writing a second one, and reads the editor's name through the service layer.

Steps to reproduce:

1. Run the dev server locally.
2. Sign in as a site keeper (assumed).
3. Open a keeper curated list, such as categories or ingredient forms under `/admin` (assumed).
4. Look at the table's columns.
5. Compare with the Coven members table, which has an Updated column.

Actual: The admin curated lists have no Updated column, so they don't show who last edited a row or when.
Expected: Each admin curated list has an Updated column, like the Coven members table, showing who last edited the row and when.

_Acceptance criteria:_

- A regression test that fails before the fix: each keeper curated list renders an Updated column, and a row shows the name of the keeper who last edited it and when, proven by role and label queries on the state
- A row that has been edited shows the editor who made the latest edit, not the one who created it; the test edits a row as a second keeper and asserts the first would be shown without the fix
- A row whose editor has since been removed still shows a sensible value, not a UUID or a crash
- The editor's name reaches the page through a service that checks the viewer is a site keeper; a signed-in non-keeper is refused by direct id, and a coven steward who could otherwise reach the page is asserted to be refused, so the check is shown to matter
- Every list paginates through the cursor helper and loads editors in one batched lookup, so the column adds no per-row query
- The components' docs and stories are corrected for the new column

**MB.261 — The No Refs Switch Cannot Be Toggled With Enter** · 2h

_Story:_ As a site keeper using only the keyboard, I want Enter to flip a focused switch such as No Refs, so that I can use the Compendium filter without a mouse.

Found on 2026-10-15, on the local dev server, signed in as a site keeper. On `/admin/compendium` the No Refs filter is a switch (`SwitchField`, a native checkbox, used in `src/components/CompendiumList/filter.tsx`). With it focused, pressing Enter does nothing. A native checkbox flips on Space, and Enter only submits the surrounding form, so a keyboard user who presses Enter gets no change. The fix belongs in the shared switch, so every `SwitchField` behaves the same, not in this one filter.

Steps to reproduce:

1. Run the dev server (`npm run dev`, port 8000) (assumed).
2. Sign in as a site keeper.
3. Open the Compendium page, `/admin/compendium`.
4. Use the keyboard to move focus to the No Refs switch.
5. Press Enter.

Actual: The switch's state does not change, so it cannot be operated from the keyboard.
Expected: Pressing Enter with the switch focused changes its state (assumed to happen every time).

_Acceptance criteria:_

- A regression test that fails before the fix: with a switch focused, pressing Enter flips its checked state
- Enter on the No Refs switch changes the filter and updates the list, as a click does
- Space still flips the switch, and Enter does not also submit a surrounding form a second time
- Every `SwitchField` switch behaves the same, not only No Refs
- A Playwright spec walks the keyboard path on `/admin/compendium`, with `@axe-core/playwright` clean
- Docs corrected if the switch's keyboard behaviour is described in `claude-docs/` or in the component's doc

**MB.262 — Mail Shows Its Light Colours in Zoho Mail's Dark Mode** · 3h

_Story:_ As someone reading the site's mail in the Zoho Mail app with dark mode on, I want the mail to show its dark theme, so that I read light text on a dark background instead of a bright white page.

Found on 2026-10-15 on production. The three mails the site sends (verification, admin invitation, coven invitation) share the frame in `src/emails/parts/layout.tsx`. It writes the dark theme inline and overrides it with the light theme inside a `prefers-color-scheme: light` media query. It also declares `color-scheme` in two meta tags. In the Zoho Mail app with dark mode on, the mails show black text on a white background, so the light theme is winning. Zoho probably reports a light colour scheme to the mail, or ignores the media query and the meta tags; that is a guess to confirm during the fix. The fix may go beyond the frame: test in Zoho's real dark mode, then choose between changing which theme is the default and adding markup Zoho honours. Whatever is chosen must not break the clients that already show the dark theme correctly.

Found during the fix (2026-10-16, by reading the DOM Zoho builds from probe mails): Zoho reads no `<style>` at all in its dark mode and drops every `@media` block in its light mode, and in dark mode it inverts every inline colour it can see — except on an anchor whose background is an image, which it leaves alone. The frame now paints its backgrounds with a gradient and sets every run of text inside such an anchor, so Zoho shows the dark theme in both of its modes, as Gmail does (`email.md`, "Design").

Steps to reproduce:

1. Turn on dark mode in the Zoho Mail app (assumed: the app's own dark theme).
2. Trigger any of the site's mails on production to an address read in Zoho Mail.
3. Open the mail in the Zoho Mail app.

Actual: the mail shows black text on a white background, as the light theme does, though the app is in dark mode.
Expected: the mail shows its dark theme, as it does in clients that honour dark mode.

Seen on production. It happens every time. Severity: wrong result.

_Acceptance criteria:_

- A regression test fails before the fix and passes after it: it renders each of the three mails and checks that the markup Zoho Mail reads leaves the dark theme in effect there; the cause found decides what it checks
- Each of the three mails shows its dark theme in the Zoho Mail app with dark mode on, and stays dark with dark mode off, as it does in Gmail, since Zoho reads no light theme; the check is recorded on the issue
- Clients that already render correctly (those that honour `prefers-color-scheme`, and Gmail, which takes the inline dark) are unchanged, and the every-mail test still passes
- `email.md`, "Design", records what Zoho Mail does with dark mode and why the frame is written the way it is

**MB.263 — The Coven Links Still Stop on a Blank Page Before the Coven** · 2h

_Story:_ As a signed-in member or admin, I want Your Coven, the brand and Continue to take me straight to my coven, so that I don't see a blank page on the way.

Found on 2026-10-16, on the local dev server. MB.257 sent sign-in straight to the first coven, but four other links still point at `/coven`: the keeper's Your Coven link, the brand for a non-keeper, Continue on `/`, and Continue in the email form (the email page and the account page). `/coven` then redirects the browser to `/coven/[slug]`, leaving a blank stop on the way. It happens every time and is cosmetic.

Steps to reproduce:

1. Run the dev server locally.
2. Sign in as a site keeper who belongs to a coven.
3. On `/admin`, click Your Coven in the bar.

Actual: the browser stops on `/coven` and shows a blank page for a moment, then redirects to `/coven/[slug]`.
Expected: Your Coven goes straight to `/coven/[slug]`.

_Acceptance criteria:_

- Regression tests that fail before the fix check that the keeper's Your Coven link, a member's brand link, Continue on `/` and Continue on the email page each point at the viewer's first coven, `/coven/[slug]`
- Someone in no coven still gets `/coven` from each of these links, and still sees the landing's three states (M2.8, MB.57)
- A keeper's brand still goes to `/admin`; only Your Coven goes into the coven
- The sign-in callback and every Continue choose the landing through one helper, and the shell's links read the coven list the shell already loads, so they add no lookup
- `/coven` still redirects a member who opens it directly, from a bookmark or after leaving a coven
- `app-shell.md`, `welcome.md`, `email-form.md`, `route-protection.md`, `admin-bootstrap.md`, `auth/tests.md` and the MB.57 decision record are corrected

**MB.264 — The Admin Nav Folds Two Tabs on Refresh at Desktop Width** · 2h

_Story:_ As a site keeper, I want the admin nav to show every tab that fits from the first paint, so that a refresh does not flash a folded row before unfolding it.

Found on 2026-10-16, on the local dev server. The server cannot know the window's width, so `section-links.tsx` renders the phone's count of four tabs, marks the rest as extras behind More, and the stylesheet hides that class at every width. Wider than the phone the row is only corrected after hydration has measured it (React reconciles the band's server snapshot in a passive effect). With six admin sections, two tabs sit behind More from the first paint until then: about 40 ms on a production build, longer on the dev server. It happens every time and is cosmetic. The fix: the stylesheet shows every tab before the nav carries `data-fit`, wrapping any overflow out of sight with More hidden, and the measuring render marks itself (`data-measuring`) so More is still drawn for measurement. The corrections to `claude-docs/components/section-nav.md` are deferred to M11.22 at the owner's request.

Steps to reproduce:

1. Sign in as a site keeper on the local dev server.
2. Make the window wider than 882px (a desktop width).
3. Open `/admin` and refresh the page.

Actual: for a moment the admin nav shows four tabs and a More button holding the other two; then More vanishes and all six tabs show.
Expected: all six tabs show from the first paint, with no More button, since they fit the row.

_Acceptance criteria:_

- A Playwright regression test under `tests/e2e`, with the script chunks delayed at desktop width, fails before the fix and passes after: before hydration every keeper link is visible and no More button is present
- The server's HTML for `/admin` still carries every section's link once, the hidden tabs hidden by class only
- The fit tests at 642, 768 and 882px in `tests/e2e/shell.spec.ts` pass unchanged
- At a phone width the first four tabs and More show as before
- The measuring render is never painted: no frame shows the row overflowing

**MB.265 — Admin Pages Fail Axe's Title Check Under Load** · 3h

_Story:_ As a developer running the gate and story suites, I want axe's title check to pass every time on the admin pages, so that a red run means a real regression and not a busy machine.

Found on 2026-10-16, locally, during M11.18's measurement runs. The gate test "an admin filters the zodiac signs by part of a name" in `tests/e2e/admin.spec.ts` failed twice with an axe-core accessibility violation, rule `document-title` (the document has no title), on `/admin/zodiac-signs?query=AR` after filtering, and passed on every other run. Both sightings were under a load average of 11 to 24, with several Playwright and Vitest runs sharing twelve cores. The page declares a static `title` in its metadata (`src/app/(shell)/admin/(astrology)/zodiac-signs/page.tsx`), so a document without a title should not be possible. One hypothesis is that under load axe runs against a streamed document whose head has not yet carried the title; that is unproven. It is a flaky test, not a broken page, so it is not a hotfix.

Steps to reproduce:

1. Have the machine under heavy load: several Playwright and Vitest runs sharing the cores, load average over 10 (assumed, from the two sightings).
2. Run the gate suite, `npm run e2e`.
3. The test signs in as a site keeper, opens `/admin/zodiac-signs`, fills the Name search with "AR" and clicks Search.
4. It waits for `/admin/zodiac-signs?query=AR` and three rows, then runs axe-core on the page.

Actual: sometimes axe reports a `document-title` violation and the test fails; the next run passes.
Expected: the filtered page always carries its title, so axe passes and the test is stable.

Found again on 2026-10-16, locally, in one full `npm run test:stories` run on M8.10's branch, which changes nothing under `src/app/(shell)/admin/users`. Story 60, "the primary keeper pauses keeper changes …" in `tests/e2e/stories/08-email-and-admin.spec.ts`, failed at its axe check (line 464) with the same `document-title` violation, on `/admin/users` just after the primary keeper paused keeper changes. Run alone, it passed. Two pages failing the same way makes a shared cause, in the harness or the shell's head, likelier than one in either page.

Steps to reproduce:

1. Run `npm run test:stories`, the full story suite, locally.
2. Story 60 signs in as the primary keeper and opens `/admin/users` filtered to one user.
3. It presses Pause Keeper Changes and confirms in the dialog.
4. Once the dialog closes and the paused status shows, it runs the axe check.

Actual: sometimes axe reports a `document-title` violation (the page has no non-empty `<title>`); seen once in a full run, and the story passed when run alone.
Expected: the page always has its title after pausing, and the story passes every run.

_Acceptance criteria:_

- A regression test that fails before the fix: either a reproduction of the missing title (axe run against the page before hydration or during streaming), or, if the title is proved always present, a test showing the harness ran axe too early
- The cause is established and recorded for both pages, whether in the page (the title really is absent for a moment) or in the harness (axe runs before the document is settled)
- The fix lives where the cause is: the page if the title is missing, `tests/e2e/axe.ts` if the harness ran early, never a retry or a skip
- The regression test stands in for repeated runs under load: it forces the missing-title window, so it proves the wait works without needing the flake to fire (decided by the owner; ten runs of `admin.spec.ts` and of story 60 were dropped as weak evidence against a flake that is rare)
- `claude-docs/testing/e2e.md`'s "Where a run's time goes (M11.18)" section stops calling this failure unexplained once it is explained

**MB.266 — Curators Reach the Admin Curated Lists Again** · 2h

_Story:_ As a site curator, I want the Compendium and vocabulary pages to open, so that I can curate what the role exists for.

Found on 2026-10-17, locally, during M8.16's review; the code shipped in v0.9.0 (MB.260, PR #1005), so production has it. Every admin curated-list page shows who last edited each row through `editorStamps` (`src/app/(shell)/admin/editors.ts`), which reads the names through `usersForAdmin` in the identity module. That read refuses anyone but a site keeper, since it also serves the privilege ledger, so a curator — the role M11.20 added so that someone other than a keeper can curate — gets a 500 on all nine curated pages: compendium, categories, category groups, forms, form groups, deities, traditions, celestial bodies and zodiac signs. The stamps need only a name, so they read through a curator-reachable `editorNamesForCurator`, guarded by `assertCurator` and returning id and name alone; `usersForAdmin` and the People pages stay admin-only. A hotfix, since it is live.

Steps to reproduce:

1. Sign in as a site curator (fixture F).
2. Open `/admin/compendium`, or any keeper vocabulary page, with at least one row in its list.

Actual: a 500, "Runtime Forbidden — Only a site keeper may read the privilege ledger", thrown from the last-edited stamps.
Expected: the list renders, with who last edited each row.

_Acceptance criteria:_

- A regression test on `editorStamps` as fixture F fails before the fix and passes after, with a non-empty batch of real editor ids
- A browser test seeds a row and opens `/admin/compendium` and `/admin/forms` as a curator: 200, the list and the stamp present
- The name read is guarded by `assertCurator`, returns id and name only, and refuses a coven steward (A) by direct id
- `usersForAdmin` and the People pages stay admin-only
- Docs: `claude-docs/components/data-table.md` names the curator-safe read

**MB.267 — Story 18 and the Sign-In Panel Test Pass Every CI Run** · 3h

_Story:_ As a developer opening a PR, I want story 18 and the sign-in panel's component test to pass on every run, so that a red check on my PR means my change broke something.

Found on 2026-10-18 on M12.1's PR (#1063), which changes neither. Two failures, filed as one task on the owner's call. Neither is a hotfix: no user-facing page is shown broken.

**Story 18 runs at its time limit in CI.** "An admin adds a compendium entry, edits it, and deletes it, the list following each" (`tests/e2e/stories/07-admin.spec.ts`, `@story-18`) has Playwright's default 30-second limit, since `playwright.stories.config.ts` sets none. In CI it took 29.7s on M12.4's passing run (39080852601), and 30.3s and 31.1s, then 30.3s and 30.0s, on M12.1's two failing runs (39081808999, 39092340049), each retry included. Locally it passed three runs of three. Each failure was "Test timeout of 30000ms exceeded" just after the reload: Close is pressed, and the dialog is still open when time runs out. The failure snapshot shows Close focused, Save disabled and no unsaved-changes question, so the form held nothing unsaved. Whether Close is slow after a reload, or the story simply runs out of time doing five axe checks and a reload, is unproven.

Steps to reproduce:

1. Open a PR into `staging`, so the PR gate runs the stories job.
2. Story 18 signs in as a keeper, adds an entry, edits it, saves, reloads, opens the Oil variant's Details & Care, and presses Close.

Actual: the test times out at 30s waiting for the dialog to close, on the first try and the retry.
Expected: the story passes within its time limit on every run.

**The sign-in panel test warns about an uncached snapshot.** `tests/components/SignInPanel/index.test.tsx` intermittently fails on React's console error "The result of getSnapshot should be cached to avoid an infinite loop", which the harness turns into a failure. In CI run 39092340049 it failed "marks the last-used provider in its button's accessible name…". Locally, on M12.1's branch and on M12.4's head (`158361cc`) alike, it failed "surfaces a failing signIn.social result in the same alert region". Earlier CI runs passed it. The panel reads Better Auth's `getLastUsedLoginMethod` through `useSyncExternalStore` (`src/components/SignInPanel/index.tsx`), which parses `document.cookie` on every call. A string or null compares equal across calls, so the warning implies the cookie changes between React's reads, as the test's helpers write or clear it. That is unproven. M11.25's happy-dom pin is the last change to the test environment.

Steps to reproduce:

1. Run `npx vitest run tests/components/SignInPanel` (with `env -u CLAUDECODE` to see the console).
2. Repeat until a test fails.

Actual: a test fails on the getSnapshot console error; which test varies.
Expected: every test passes on every run, with no console error.

The getSnapshot warning does not reach story 18: it appears in neither story run's log, the sign-in panel is not on the compendium page, and every external store that page uses returns a stable value.

_Acceptance criteria:_

- Story 18's slow step is named from a CI trace, and the story passes on three consecutive PR-gate runs; a longer time limit is set only for the story, with a comment saying why, if the time is proved to be the story's own work and not the app's
- If Close is slow after a reload, that is fixed in the app, with a regression test that fails before the fix
- A regression test reproduces the sign-in panel's getSnapshot warning before the fix, and the panel's test passes twenty consecutive runs with none
- Docs: `claude-docs/components/sign-in-panel.md`, "Last used", says how the read stays stable

**MB.268 — Seeded Users Are Verified** · 1h

_Story:_ As a developer checking the dev site, I want the seeded users to start with verified email addresses, so that I can browse the site signed in as one of them without being sent to the email page.

None of the seeded users has a verified email address, because the seed never sets `email_verified` and it defaults to false. That covers fixture users A–F in `src/db/seed/standard.ts`, the minimal scenario's user in `src/db/seed/minimal.ts` and the bootstrap admin in `src/db/seed/bootstrap-admin.ts`. An unverified account can reach no page but `/account/email`, because `requireSession()` sends it there from every other page. So no developer or agent can check a signed-in page as a seeded user. The e2e tests aren't affected, because `tests/e2e/session.ts` creates its own verified users.

Verifying the seeded users doesn't change which accounts get deleted. The sweep of unverified accounts only deletes ones that hold a provider sign-in, and seeded users have none.

Found on 2026-10-19, during M12.33's browser checks. Not a hotfix: no live page is affected, only the dev seed. Steps to reproduce:

1. Run `npm run db:reset` with `SEED_SCENARIO=standard`.
2. Sign in to the dev site as the seeded admin, Fixture E, using the storage-state method.
3. Open `/admin/compendium`.

Actual: every page sends you to `/account/email`.
Expected: the seeded users are verified, so the signed-in pages load.

_Acceptance criteria:_

- A regression test in `tests/db/seed/` that fails before the fix: after seeding, every seeded user has `email_verified` set to true
- The standard scenario's fixture users A–F, the minimal scenario's user and the bootstrap admin are seeded as verified
- Seeding twice in a row leaves the users verified, and the seed still makes no other change on the second run
- Any database test that relied on a seeded user being unverified creates its own unverified user instead
- Docs: `claude-docs/db/standard-scenario.md`, and any seed doc that describes the users, says they are seeded verified

**MB.269 — A Repeat Invitation Replaces the Pending One** · 3h

_Story:_ As a coven steward, I want inviting an address again to replace the invitation already waiting for it, so that only one invitation is pending per address and the old link stops working.

Inviting an address that already has a pending invitation of the same kind creates a second invitation, and both stay live. "The same kind" means the same coven, or the site's keeper and curator invitations. Neither `createInvitation` in `src/modules/coven/services/invitations.ts` nor `createAdminInvitation` in `src/modules/identity/services/admin-invitations.ts` looks for one already waiting. So the Members page and the invited account's Invitations section list both, and either link can be accepted. The new invitation should withdraw the waiting one, in the same write that creates it.

Found on 2026-10-19. Steps to reproduce:

1. Sign in as a coven steward.
2. Open the coven's Members page.
3. Invite an address as a member.
4. Invite the same address to the same coven again.
5. Look at the pending invitations, on the Members page and on that address's account page.

- **Actual:** two pending invitations exist for the same address and coven, and both links work.
- **Expected:** the second replaces the first. The first is withdrawn and its link stops working, leaving one pending invitation.

The same happens when a keeper invites the same address to the site tier twice.

_Acceptance criteria:_

- A regression test that fails before the fix: inviting the same address to the same coven twice leaves one pending invitation, the newest.
- The withdrawal and the new invitation happen in one `withAudit` write. The withdrawn row is stamped as revoked by the inviter, the same as a manual withdrawal.
- The old link is refused once replaced. A test tries to accept the first invitation, both by its link and by its id on the account page, and is refused.
- The new invitation's role is the one that applies, even when it differs from the old one's.
- Only a pending invitation to the same coven is replaced. A pending invitation to another coven, an accepted one and a lapsed one are left alone, and tests prove each.
- The same rules hold for admin invitations: a second site-tier invitation to the same address replaces the pending one. Coven invitations and site-tier invitations never replace each other.
- The address is matched case-insensitively, the same way acceptance already matches it.
- `claude-docs/` docs on invitations say that a repeat invitation replaces the pending one.

**MB.270 — The Search Sentence Types a Changed Term** · 1.5h

_Story:_ As anyone searching the compendium or a coven's ingredients, I want the search sentence to type out my new search term, so that the sentence reads as one animation instead of half typing and half jumping.

Found on 2026-10-23, locally, every time, signed out on `/compendium` and as a member on a coven's Ingredients page; cosmetic. Steps to reproduce:

1. Open `/compendium` signed out, or a coven's Ingredients page as a member.
2. Search for "sage" and wait for the sentence to finish typing.
3. Change the search to "rose" by typing in the search box.

Actual: the sentence's lead words and clauses type out, but "rose" appears whole, with no typing.
Expected: "sage" is wiped and "rose" is typed out; a term that did not change stays put.

Cause found in the code: while a search is pending, `src/components/CompendiumList/filter.tsx` builds the sentence from the target address, and the pending-edge effect in `src/components/SearchSentence/index.tsx` rebuilds the old line from that same new term, so the old and new lines hold the same term and the term is never typed.

_Acceptance criteria:_

- A regression test fails before the fix: after the term changes from one value to another, the old term is wiped and the new one is typed character by character.
- A term that did not change between two searches stays on screen and is not retyped.
- Under reduced motion the sentence still switches straight to the new line.
- `claude-docs/components/search-sentence.md` matches the behaviour.

**MB.271 — The Back Link Returns to the Same Results and Place** · 3h

_Story:_ As anyone browsing ingredients, I want "Back to …" on an ingredient page to take me to the search, filters and page I came from, at the card I opened, so that I don't have to search again.

Found on 2026-10-23, locally, for every kind of user; wrong result. Steps to reproduce:

1. As any user, open a coven's Ingredients page or `/compendium`.
2. Search or set a filter, go to page 2 of the results, and scroll down.
3. Open an ingredient's card.
4. Press the "Back to …" link on the ingredient page.

Actual: the list opens unfiltered, on page 1, at the top.
Expected: the same search, filters and page, scrolled so the card that was opened is where it was.

Cause: the back link is the bare list address in `src/app/(public)/compendium/ingredients/[slug]/page.tsx` and `src/app/(shell)/coven/[slug]/ingredients/[id]/page.tsx`, and the cards in `src/components/CompendiumCards/index.tsx` carry no return address.

_Acceptance criteria:_

- A regression test fails before the fix: the back link from an entry opened from a filtered, paged list carries that list's search, filters and cursor.
- On return, the opened card is in view at the position it had.
- The return address only ever points at the list route the entry belongs to; a crafted address to another origin or route falls back to the bare list.
- Opened directly, with no list before it, the back link is the bare list, as today.
- A Playwright spec walks the steps above on both the compendium and a coven's Ingredients page.

**MB.272 — A Click Anywhere on an Ingredient Card Opens Its Entry** · 2.5h

_Story:_ As anyone searching ingredients, I want a click anywhere on an ingredient card to open its entry, so that I don't have to aim for the name.

Found on 2026-10-23, locally, for every kind of user, every time (assumed: it is how the cards are built); wrong result. Steps to reproduce:

1. As any user, open `/compendium` or a coven's Ingredients page.
2. Click a card's empty space or its description, not its name.

Actual: nothing happens; only the name opens the entry.
Expected: a click anywhere on the card opens the entry, the same as clicking its name. The + button, stock controls, chips and the Quick Look icon each still do their own thing. The card shows a hover and focus style saying it is clickable.

The name link is in `src/components/CompendiumCards/index.tsx` and `src/components/IngredientCard/index.tsx`. The fix is the stretched-link pattern: the name stays the one real link, its `::after` covers the card, and the other controls sit above it. Wrapping the card in one `<a>` is ruled out: HTML does not allow a button inside a link, and a screen reader would read the whole card as the link's name (Pickering, _Inclusive Components_, "Cards"; Soueidan, "Nested Links"; MDN, the `<a>` element).

_Acceptance criteria:_

- A regression test fails before the fix: on both cards, a click on the card outside the name navigates to the entry.
- The + button, stock controls, chips and the Quick Look icon still do their own action, and none of them navigates.
- The name is still the card's only link, so its accessible name is the ingredient's name, and tab order is unchanged.
- Each other control keeps a target of at least 24 × 24 px (WCAG 2.5.8).
- A Playwright spec clicks a card's body and its + on `/compendium`, and its body and its stock control on a coven's Ingredients page.
- Docs: `claude-docs/components/compendium-cards.md` and `claude-docs/components/ingredient-card.md`.

**MB.273 — Claude Design Previews Render in a Narrower, Shorter Frame Than Storybook** · 3h

_Story:_ As a designer using the Sorrel & Salt project in Claude Design, I want each component preview to look the same as its Storybook render, so that I can trust what the cards show.

Found on 2026-10-23, locally, during the M12.53 design sync (the upload of every component to Claude Design), every time; cosmetic. Steps to reproduce:

1. On a checkout of the feature branch, build the Claude Design bundle (the steps are in `.design-sync/NOTES.md`).
2. Run `compare.mjs` against the Storybook reference in `.design-sync/sb-reference` on CompendiumList, AdminNav, CovenCards, ProviderMark, ContextRow, Welcome, SectionNav, PublicFrame, IngredientEntry and EntryMarks.
3. Open each component's side-by-side sheet.

Actual: the preview frame is about 48px narrower than Storybook's and capped at 700px tall. Columns and links are cut (the CompendiumList Categories column, the AdminNav Deities link), cards and chips wrap (the third CovenCards card, the ProviderMark Facebook chip), the bottom of tall stories is cut off (ContextRow, Welcome, IngredientEntry, EntryMarks), and SectionNav moves extra links into More in four stories. In PublicFrame "Loading The Compendium", Storybook is captured before the story's link press takes effect, so its reference shows no loading state.
Expected: each preview renders at the Storybook frame's width and height and behaves the same, so every one of these stories grades "match".

The owner accepted these "close" grades for M12.53 and asked for this follow-up.

_Acceptance criteria:_

- A regression check fails before the fix: a scoped `compare.mjs` run grades at least one listed story "close", and the cause is the frame size or the capture timing.
- Every listed story grades "match" after the fix, except three that grade "close" and that the owner accepted on 2026-10-24. Welcome States: Storybook captures the whole page, 96px taller than the window, and the preview is captured at window height. IngredientEntry States: Storybook is 2011px tall against the 2000px capture cap. PublicFrame Loading The Compendium: Storybook's reference shows no skeleton while the preview shows the one the story means to show; the cause is not frame size or timing, and is open. Applied: scoped CSS that cancels the preview body's 24px padding on single-story pages for eleven components (`.design-sync/preview-host.scss`), and `viewport` overrides for CompendiumList, EntryMarks, ContextRow and IngredientEntry (`.design-sync/config.json`).
- The fix and its reason are recorded in `.design-sync/NOTES.md`, and no other component's grade drops below what it is today.
- The fixed components are re-uploaded to the Claude Design project, with `_ds_sync.json` written last.

**MB.274 — Seeded Compendium Content Stays Stale After a Deploy** · 2h

_Story:_ As a developer shipping a change to the compendium seed, I want the first page load after the deploy to show the seeded content, so that a seed change is live the moment its deployment is.

The compendium's shared reads are cached by `cachedCompendiumRead` in `src/lib/compendium-cache.ts`, under one tag with a one-hour timer (`COMPENDIUM_REVALIDATE_SECONDS`). Only a keeper's write through `/api/graphql` clears that tag. The seed (`npm run db:seed`) is a script that runs outside Next.js, so it cannot clear it. Vercel keeps this cache from one deployment to the next, so for up to an hour after a deploy that seeded, both the public compendium pages and the admin's screens show the content from before the seed. The fix adds the deployment's id to every cache key, so each new deployment reads under fresh keys and its first read of each entry goes to Postgres. Vercel's `VERCEL_DEPLOYMENT_ID` is the likely source. It has not been checked yet; if it is not set while the app runs, the build stamps in the commit hash instead.

Found on 2026-10-24, by reading the code and Vercel's docs, and seen locally, on staging and on production; wrong result. Steps to reproduce:

1. Edit a seeded compendium entry's file under `compendium/` (for example, change its description), marked for update with `seedUpdate`.
2. Push it to staging.
3. The Deploy workflow's `migrate` job runs the reference seed, then the `deploy` job ships a new deployment.
4. Within an hour of the deploy, open that entry's page at `/compendium/ingredients/<slug>` on staging, signed out.

Actual: the page shows the content from before the seed until the one-hour timer runs out or a keeper saves any compendium edit.
Expected: the first load after the deploy shows the seeded content.

Locally the same thing happens when `npm run db:seed` runs under a running server. This task does not fix that case: locally the key part stays fixed, and a restart clears the cache.

_Acceptance criteria:_

- A regression test, written first and failing before the fix, shows that a cached compendium read made under one deployment id is read from Postgres again under a different id.
- Every key `cachedCompendiumRead` builds includes the deployment id, which comes from Vercel's own deployment variable when the app runs there, or else from the commit hash stamped in at build time.
- Local and test runs with neither value use one fixed key part, and the existing cache tests still pass unchanged.
- A keeper write still clears every cached entry under the current deployment.
- Docs: `claude-docs/db/compendium-cache.md` says how the key part is built, and that reseeding locally under a running server still needs a restart.

**MB.275 — Lint Warnings Pile Up Because Nothing Fails on Them** · 6h

_Story:_ As a developer on this repo, I want lint to report only warnings still worth reading, and to fail on the kinds we have agreed are bugs, so that a real problem is not buried under 142 old ones.

Found on 2026-10-29 in CI run 40927631845 (PR #1321). The linter, oxlint, exits 0 on warnings, so `npm run lint` passes in CI and in pre-commit however many it prints, and GitHub shows only the first 10 as annotations; the rest pile up on staging unseen. On staging, oxlint 1.89.0 prints 142 warnings across 73 files and no errors: 33 unused imports and variables, 17 console calls (16 of them deliberate output in CLI scripts under `.design-sync/` and `.github/scripts/`), 59 React warnings, of which about 15 are real (handlers called during render, state set in an effect when it can be worked out during render, missing effect dependencies) and the rest flag intended patterns (dnd-kit callbacks, floating-ui callback refs, test harnesses), and 32 accessibility warnings, 3 of them real. The owner chose which rules become errors; every other rule stays a warning. The plan is `claude-docs/design-decisions/mb.275-plan.md`.

Steps to reproduce:

1. Check out staging.
2. Run `npm run lint`.

Actual: 142 warnings across 73 files, and the command exits 0.
Expected: 0 warnings, and a new hit on a promoted rule fails lint.

_Acceptance criteria:_

- Regression check: a planted unused import, and a planted missing effect dependency, each make `npm run lint` exit non-zero, and it exits 0 without them; run once and recorded in the PR body
- `npm run lint` on the branch prints 0 warnings and 0 errors
- `.oxlintrc.json` makes these `"error"`: `no-unused-vars`, `no-console` (with `.design-sync/**` and `.github/scripts/**` added to the scripts override), `no-unsafe-optional-chaining`, `react-hooks/exhaustive-deps`, `react/set-state-in-effect`, the jsx-a11y interaction rules (`click-events-have-key-events`, `no-static-element-interactions`, `no-noninteractive-element-interactions`, `interactive-supports-focus`, `no-noninteractive-tabindex`), `control-has-associated-label` and `anchor-is-valid`
- These stay warnings: `react/refs`, `react/immutability`, `prefer-tag-over-role`, and `aria-role` with `ignoreNonDOM` set; the React Compiler rules (`react/globals`, `react/preserve-manual-memoization`, `react/incompatible-library`) stay warnings in `src/` and are off under `tests/**`
- Every `oxlint-disable` added says why on the same line
- Each behaviour change (`cupboard-actions`, `card-more`, `SkeletonFade`, `StockDialog`, the SpellBuilder steps, `use-navigation`) is covered by a component test that leaves the same state as before, and `npm run test:coverage` passes
- The e2e specs covering those components pass, one run each
- `claude-docs/commands.md`, or the lint doc it points to, records which rules are errors and why

**MB.1 — Fix prefers-reduced-motion facet swap in ThemeToggle** · 2h

Merged before this file carried per-task hours; sized after the fact from the merged diff. The reduced-motion swap of the toggle's facets, and the workshop story that simulates the preference.

**MB.2 — Fix sun facet swinging in on first paint in light mode** · 1h

Merged before this file carried per-task hours; sized after the fact from the merged diff. The sun facet's pre-paint state settled in CSS rather than an effect.

**MB.3 — Fix Prettier formatting in `m1.1-neon-branch-strategy.md`** · 0.5h

Merged before this file carried per-task hours; sized after the fact from the merged diff. A one-line formatting fix.

**MB.4 — Stop destructive-ddl scanning non-migration changed files** · 1h

Merged before this file carried per-task hours; sized after the fact from the merged diff. The scan narrowed to the migration files a branch adds.

**MB.5 — Restore `users` foreign keys on `auditColumns`** · 2h

_Story:_ As a developer, I want the audit columns to actually reference `users` so that an audit id cannot point at a user who never existed.

M1.15 shipped `auditColumns` **without** the `.references(() => users.id)` FKs that §5 mandates, because `users` did not exist yet. It lands in Wave 1, between M2.3 and every other table: under the original order this would have needed roughly ten FK-adding migrations and backfills, and under the wave order it is a one-file edit whose FKs every Wave 3 table then generates natively.

Three things make this harder than it looks:

- **Circular module init.** `audit.ts` imports `users`; `schema/users.ts` spreads `auditColumns`. Drizzle's `() => users.id` thunk is lazy so this works at runtime, but TypeScript needs the explicit annotation `.references((): AnyPgColumn => users.id)` or it errors with "circularly references itself". If the ESM cycle proves fragile, the fallback is an `auditForeignKeys(t)` helper called from each table's extra-config argument — same DDL, no cycle.
- **`users` self-references.** `users.created_by → users.id` needs the same annotation.
- **The root row.** The first user has no pre-existing creator. Postgres checks FKs at statement end, so `INSERT INTO users (id, created_by, updated_by) VALUES ($1,$1,$1)` is self-satisfying.

_Acceptance criteria:_

- All three `*_by` columns reference `users.id`
- `users` self-reference compiles without a circularity error
- The bootstrap user inserts successfully as a single self-satisfying statement
- The bootstrap UUID is fixed and shared with M1.21, not generated twice
- The stale comment at `src/db/audit.ts:3-5` is corrected — it cites M2.1, and `users` lands in M2.3
- No retrofit migration is needed for any table created after this task

**MB.6 — Spell recipe view page** · 3h

_Story 56 — As a workspace member, I want to read a saved spell on its own page, so that I can follow it without opening the builder._

`/coven/[slug]/grimoire/[id]`, added to §9's route table by this audit. M10.22 and CLAUDE.md both reference "the spell recipe view" and story 56 is about _reading_ a spell, but §9 had no spell detail route — `/grimoire/new` is the builder, and you cannot print a saved spell from it. This is the page M10.22 attaches print styles to. Two ingredients sharing a display label render with their formal name alongside it, since the page has no hover affordance to disambiguate them.

The page also carries:

- `requireSession()`, called in the page, since the `(shell)` layout does not.
- The grimoire's `SpellCard` gains its link to this page, through `PendingLink` as `IngredientCard`'s name does: M10.11 left the card unlinked, since a link with no page behind it would ship broken ([`components/spell-card.md`](../components/spell-card.md), "No link yet").
- `LastEdit` under the title ([`components/last-edit.md`](../components/last-edit.md)).
- No Edit or Delete control: a control with nothing behind it would ship as a dead button. M13.10 adds the Edit control with the spell builder's modal at `?edit=<id>` (M10.12), M13.11 adds the Delete control with `deleteSpell`, and M13.20 adds the Duplicate control with `duplicateSpell` (decided in the Wave 13 review, 2026-10-23, on the review agent's finding).
- If the sections run past one screen, a jump menu on the pattern of the ingredient entry page (`PageNav`, `src/components/PageNav/`, used by `IngredientEntry`; [`components/page-nav.md`](../components/page-nav.md)).
- A `Skeleton` of shape `page`, through a `PARTS_OF_SECTION` entry in `src/lib/coven-path.ts`, so the loading shape matches.
- The steps are drawn with `StepRow`, the presentation component M13.3 adds under `src/components/` (M13.3 lands before this task). This page renders it read-only, with no editing controls.
- Picking a spell from the grimoire search's suggestions opens its recipe page, through `IngredientSearch`'s `pickHref`. Once M13.21 builds the spell's Quick Look, a pick opens that instead, under the owner's rule of 2026-10-27 that a pick opens the item's Quick Look, as an ingredient pick does (M13.21). Until this task a pick applies the title as the search (M10.11). `pick()` in `src/components/IngredientSearch/search-box.tsx` falls back to the search when a row carries no `match`, and a spell suggestion row carries none today, so this task gives spell rows a `match` holding the spell's id as well as passing `pickHref` (added 2026-10-27, from the M10.11 review).

**Amended 2026-10-16 by the spell steps and workings plan** ([`design-decisions/m13.1-plan.md`](../design-decisions/m13.1-plan.md)): the page renders the spell's numbered steps in `position` order, an ingredient step with its quantity and unit and an instruction-only step as its text. The page has no on-screen Ingredients summary: its In Coven Inventory panel lists each form once, with the amount needed, for gathering (owner, 2026-10-29). The print layout has its own summary (M10.22). It shows the spell's `note`, and it is the page M13.7's Record a Working control and M13.8's Workings section attach to. **Amended 2026-10-29 by the owner:** the print summary (M10.22) lists each form once, in the order of the step that first uses it, with the total quantity the spell needs across its steps (`needOf`, as In Coven Inventory adds it), and no stock marks, jar supply or buttons.

_Acceptance criteria:_

- Route resolves a spell by id within the workspace
- Visibility is enforced in SQL: a private spell is reachable only by its author
- A non-member receives 404, consistent with the rest of `/coven/[slug]`
- Steps render numbered in `position` order, an ingredient step with its quantity and unit
- The page draws no on-screen Ingredients summary; the In Coven Inventory panel lists each form once with the amount needed
- Two ingredients sharing a label are disambiguated by their formal name, not by hover
- A custom, one-off ingredient (MB.40) renders its own name and form in `position` order with the rest, marked as one-off, and links to no ingredient page
- The page calls `requireSession()` and shows `LastEdit` under the title
- A spell's card in the grimoire list links to this page
- Picking a spell from the grimoire search's suggestions opens this page, through `IngredientSearch`'s `pickHref` (M13.21 later moves the pick to the spell's Quick Look)
- The page has no Edit or Delete control; M13.10 and M13.11 each add their own
- The loading skeleton is shape `page`
- The page is the only view M10.22 styles for print

**MB.7 — Application nav shell** · 16h

_Story:_ As a user, I want one persistent navigation frame so that every page is reachable from every other page.

`AppShell`, added to §9's Components list by this audit. M8.16 and M8.17 require the add and edit modals to be "reachable from the main nav on any page", but no task and no route built an app-wide nav — `WorkspaceSwitcher` (M6.9) and the coven layout (M6.10) do not cover it, and both compendium and ingredient detail sit outside `/coven/` entirely. `/admin` is the other layout it wraps: M5.4's admin layout nests inside it as the coven layout does, and `AdminNav` becomes the admin area's section nav beneath the shell's own.

**Pulled forward to Wave 9, straight after M6.10** (2026-10-11, the owner's call, made during MB.115): every page built before Wave 12 would otherwise have no nav. By then the switcher and the coven layout exist; the add and edit modals do not, since they need Wave 11's ingredient services. So the shell carries one global Add Ingredient button, disabled until M8.16 builds the modal, and M8.17 builds Edit Ingredient where an ingredient is shown (amended 2026-10-12, see "Folded in").

**Folded in: MB.122, 2026-10-12.** MB.122 was minted during M5.4 so that the nav would be designed once this task built it. The owner folded it into this task on 2026-10-12: once the design is chosen before the build, the review and the build are one piece of work. The design was chosen from a rendered mock-up the same day: **Option C, the "context header"**. It is a slim global bar (brand, Add Ingredient, account menu, theme toggle); beneath it a context row that names the coven as the switcher, or "Admin" as plain text, with the section nav as icon tabs beside it; and on a phone the section nav becomes a bottom bar. The options drawn, the research and the reasons are in [`design-decisions/mb.7-navigation.md`](../design-decisions/mb.7-navigation.md); the approved plan is [`mb.7-plan.md`](../design-decisions/mb.7-plan.md). MB.122 is retired (below).

This task now also does the design review MB.122 described. It reviews and builds the primary nav, where `WorkspaceSwitcher` and the global Add Ingredient button sit, the Admin entry, the section navs beneath the shell's nav (the coven layout's and `AdminNav`) and the whole at phone width (375px). A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built, in the workshop and the running app, in both themes, at desktop and at phone width, and builds what the owner signed off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change except where this entry says so; a defect found on the way is fixed if it is sub-hour and minted if not.

_Left by MB.116:_ `/account`'s own nav is the pattern for a section nav: a `nav` holding a `ul.link-row` (`styling.md`, "Link rows and provider marks"), with `aria-current` on the entry for what is in view. The theme toggle's fixed top corner sits over a page's heading at 375px; this task moves it into the shell's bar on shell pages, and the fixed corner stays only on pages outside the shell.

_Left by MB.115:_ `AdminNav` (`components/admin-nav.md`) marks the page in view with `aria-current` and with weight and an offset underline, not hue, reading the address with `usePathname` (the workshop's stand-in is `.ladle/navigation.ts`). It was a wrapping row of links wider than a phone and a `<details>` disclosure at a phone's width. This task settles where it sits under the shell's nav and replaces both shapes with the one section nav component (icon tabs in the context row; a bottom bar on a phone), so the disclosure goes. The tabbed admin pages keep their heading and tabs still while a tab's content changes (`components/tabbed-page.md`).

_Acceptance criteria:_

- Wraps every signed-in page, inside and outside `/coven/`
- Carries the primary nav and the `WorkspaceSwitcher`, passing it `canCreate` from the user row so a rights holder sees its Create Coven choice (M9.16), which an e2e spec walks to `/coven/new` (`@story-3`)
- Carries one global Add Ingredient button, a labelled button at every width, disabled until M8.16 and absent for an unverified account. Its target follows the area: a coven page adds to that coven's ingredients, an admin page to the compendium, elsewhere the viewer's only coven or a choice. There is no Edit Ingredient in the shell: editing lives wherever an ingredient is shown, never inside a relational field, and M8.16 and M8.17 build to that (amended 2026-10-12)
- The brand link goes to `/admin` for a keeper and to the viewer's coven otherwise. The shell works that out itself (the first coven by slug, `/coven/new` for someone who holds none and may create, `/account` otherwise) until M2.8 (#270) builds the `/coven` landing, which then replaces the href with `/coven`
- No switcher on admin pages: the context row reads "Admin", and a Your Coven link takes its place in the bar. On coven pages the context row's name is the switcher
- On-screen copy says Coven ("Select Coven", "Create Coven", "Your Coven", the section nav labelled "Coven"); code, schema and docs keep saying workspace
- The coven layout nests inside it and adds only workspace-scoped chrome
- The admin layout nests inside it too and adds only `AdminNav`, the admin area's section nav
- Nav survives navigation between workspace-scoped and global pages
- Admin entry appears only for keepers
- An account menu on every signed-in page offers Your Account (`/account`) and Sign Out, the same sign-out `/account` carries, and the theme toggle on a phone (added 2026-10-10, on the owner's call)
- The owner signs off the design, in both themes and at phone width, recorded as a comment on this issue (given 2026-10-12 on the mock-up and recorded on #405)
- No page in the shell scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- axe clean with visible keyboard focus; the e2e specs and stories pass
- Each component's doc updates its Styling section, and its stories show the reviewed design
- Every nav marks the current page, with `aria-current` as well as visually
- At phone width the nav is reachable and operable by keyboard and by screen reader
- The section navs read as beneath the shell's nav, not beside it

**MB.8 — Zod schema for spells** · 1h

_Story:_ As a developer, I want one validation schema for spells so that the builder and the mutation cannot disagree about what is valid.

M4.5 covers ingredient and category only. M10.10 needs the spell equivalent. It creates `src/modules/grimoire/validation/`, following the layout of `src/modules/ingredients/validation/` (one file per schema, a `types.ts` for the inferred types); M13.2 extends it.

**Amended 2026-10-16 by the spell steps and workings plan** ([`design-decisions/m13.1-plan.md`](../design-decisions/m13.1-plan.md)): the layer list becomes one ordered `steps` list (M13.1). A step is `{ body?, ingredientId + variantId | name + form?, quantity?, unit?, note? }`: at least one of an instruction (`body`) or an identity, at most one identity, and `quantity`, `unit` and `note` only beside an identity. A linked ingredient always names its variant, as `spell_steps_variant_with_ingredient` requires (MB.215). The spell gains its free-text `note`.

**Amended 2026-10-25 by the autosave plan** ([`design-decisions/m13.14-plan.md`](../design-decisions/m13.14-plan.md)): the title is optional while `status` is `draft` and required when it is `complete`, as a `superRefine` over the pair that mirrors M13.15's CHECK (`status <> 'complete' OR title IS NOT NULL`), so the database never refuses what validation passed. The update input takes `expectedRevision: number | null`. The step schema is unchanged.

_Acceptance criteria:_

- One schema shared by client and server
- Covers title, visibility, note, steps, quantities and units
- A step carries an instruction, an identity, or both, and never neither; `quantity`, `unit` and `note` on an instruction-only step are rejected, and a blank instruction is rejected, mirroring M13.1's CHECKs
- A step that lays an ingredient is `{ ingredientId }` or `{ name, form? }` and never both or neither (MB.40); `form` beside `ingredientId` is rejected, and a blank `name` or `form` is rejected — the table's four CHECKs, mirrored so the CHECK is never what a user sees
- Unit validation imports the shared unit module rather than keeping its own list: `dimensionOf`, `Unit` and `UnitDimension` from `src/modules/ingredients/schema/units.ts`
- Rejects a visibility value outside `private` and `workspace`

**MB.9 — `ingredientsById` DataLoader** · 1h

_Story:_ As an operator, I want ingredient resolution batched so that a list query costs one round trip rather than one per row.

No task built a batched ingredient read, so this one does. M9.4's `InventoryItem.ingredient` and, later, M10's `SpellIngredient.ingredient` resolve through it. Constructed per request, never at module level.

**Amended 2026-10-13 after the Wave 11 review:** the loader is built the way the others are: with `defineSignedInLoader` (`src/graphql/loaders/define-loader.ts`), registered in `LOADERS` in `src/graphql/loaders/index.ts`. It takes a parent-row key, `{ id, workspaceId }`, with a `cacheKeyFn` on the id alone, as `src/modules/ingredients/loaders/ingredient-children.ts` does. One batch reads the compendium tier plus the keyed workspace's own ingredients under the session, in one query, and puts the rows back in the order of the ids with `inIdOrder` (`src/lib/in-id-order.ts`), as `users-by-id.ts` does, so a missing or soft-deleted id resolves to null. "One query per batch" is asserted the way the other loaders do it: a `vi.hoisted` spy on `@/db/repository` and `toHaveBeenCalledTimes(1)`. There is no `variantsById`: `DESIGN.md` says a variant is read only beneath its parent, never by a bare id, so a stock row's variant resolves through the existing `variantsByIngredient` loader, as `Substitute.variant` does. Only M9.4 assumed this loader; M8.5 did not.

_Acceptance criteria:_

- One query per batch, asserted by query count
- Constructed per request
- Soft-deleted rows are not returned
- A missing id resolves to null rather than throwing
- A row of another workspace resolves to null, not to the row

**MB.10 — `usersById` display-name DataLoader** · 1.5h

_Story:_ As a workspace member, I want the last-edited-by name resolved efficiently so that a long list does not issue one query per row.

M6.18 requires the display name to resolve "without an N+1" and no loader existed.

**It lands before M6.11 and M6.12, which consume it** (moved on the Wave 9 review, 2026-10-12): `MemberList` shows each member's display name, and the SDL's `WorkspaceMember` has no `user` field to carry one. M6.18, the first consumer it was minted for, moves to Wave 12.

**It resolves display names for co-members only**, the users who hold or have held a membership in a workspace the viewer is a live member of. The removed are included on purpose: M6.18 shows a row's last editor, who may have left the coven since, and the name was visible to the viewer when the edit was made. Any other id resolves to nothing, so the loader cannot be used to read a stranger's name. The hours were re-estimated on review on 2026-10-12, from 1: the gate joins the loader and the stable value for a deleted user. They remain an estimate.

**It sits beside `usersByIdForAdmin`, with a different null rule, rather than replacing it.** That loader (`src/modules/identity/loaders/users-by-id-for-admin.ts`) serves the privilege ledger: its service, `usersForAdmin`, refuses anyone but a site keeper, returns the whole user row, email included, and resolves to null for an id no live user holds. This one is gated to co-members, returns the display name alone, and gives a deleted user a stable display value instead of null. One loader serving both would carry two gates and two null rules behind a switch.

_Acceptance criteria:_

- One query per batch, asserted by query count
- Constructed per request
- Returns display name only, never the email address
- Resolves a co-member's name, a removed member's too, and nothing for a user who never shared a workspace with the viewer, asserted with the precondition that the user exists and has a name
- A deleted user still resolves to a stable display value: the name their row last held, the owner's call while building ([`mb.10-co-member-display-names.md`](../design-decisions/mb.10-co-member-display-names.md))
- `usersByIdForAdmin` is unchanged

**MB.11 — GraphQL field exposing the fuzzy duplicate service** · 1h

_Story 16 — As a workspace member, I want the duplicate check available from the client, so that the form can warn me as I type._

M4.7 builds the service; M5.10's debounced client lookup needs it exposed through GraphQL. Without this field M5.10 has nothing to call.

**Decided while building:** the field is `possibleDuplicates(workspaceId, name, first, after)`, a connection of `Ingredient`. M4.7's finder returned a fixed first 25 rows, so to page it through the helper it becomes a keyset page keyed `[-score, name]`. A keyset read gains `similarityMatch`, which sets the same 0.4 constant a similarity read does, so there is still one threshold. Each edge carries its `score`, 0.4 to 1, so M5.10 can tell an exact match from a near miss (claude-docs/graphql.md, "`possibleDuplicates`"). Riding along: the text argument of `compendium` and the four autocompletes, `search` on one and `term` on the rest, is renamed `query` on all five and through the code beneath them, while this field keeps `name` (claude-docs/graphql.md, "The schema").

_Acceptance criteria:_

- Field returns compendium and current-workspace matches only
- Threshold matches M4.7's, not a second constant
- Bounded by the M3.6 pagination helper
- Authorization is enforced in the service, not the resolver

**MB.12 — Finish the secrets matrix and verify real OAuth sign-in** · 1h

_Story:_ As a developer, I want the remaining M0.27 secrets set and a real sign-in confirmed, so that the auth work merged in M2.2/M2.4/M2.5/M2.6 is actually exercised end-to-end, not just verified against live provider endpoints without a completed login.

PR #71 (M2.2/M2.4/M2.5/M0.27, merged 2026-09-11) landed real Google/GitHub OAuth credentials and most of the secrets matrix, verified by fetching the live `accounts.google.com`/`github.com` authorization endpoints directly — real evidence the client id/secret pairs and `redirect_uri` are correct, but no one has completed an actual interactive sign-in through a browser and consent screen. Four rows of `claude-docs/secrets.md` are also still unset. M2.6 later re-scoped the roster to Google, Discord, Facebook and Microsoft — the GitHub credentials this paragraph describes are gone, and Discord/Facebook/Microsoft's are still unregistered.

Minted against Wave 1 and moved to **Wave 6** by MW.1: there is no page to sign in on until M2.6 builds one, so the browser criteria below cannot be met any earlier. Everything it verifies (M2.2/M2.3/M2.4/M2.5) is already merged, so it is a late verification of earlier work, not a blocker for it.

**GitHub row retired by M2.6's re-scoping.** The roster is now Google, Discord, Facebook and Microsoft; the criterion below is Google-only, and a browser round trip through the three new providers is added rather than assumed — none of their applications are registered yet (`claude-docs/secrets.md`'s walkthrough), so this task also covers registering them.

_Acceptance criteria:_

- A real browser completes Google sign-in on `http://localhost:8000`
- A real browser completes Discord, Facebook and Microsoft sign-in on `http://localhost:8000`, once each is registered
- Same for staging, once a staging deploy carries this code
- `VERCEL_SCOPE`, `NEON_API_KEY`, `NEON_PROJECT_ID` set as GitHub Actions secrets
- Admin bootstrap email set as a Vercel env var (Production + Preview) — unblocks M2.3
- `claude-docs/secrets.md` updated to reflect every row set

**MB.13 — Stop branch skills setting the base branch as upstream** · 1h

_Story:_ As a developer, I want a new branch to have no upstream, so that a bare `git push` cannot push my work straight at `staging` or `main`.

`/create-feature`'s `git checkout -b feature/<slug> origin/staging` set the new branch's upstream to `origin/staging`, so a later bare `git push` targeted the protected base branch rather than the feature branch. `/create-hotfix` had the same shape against `origin/main`, which is worse. Caught during M1.16, where the push was redirected by hand.

Fixed by adding `--no-track` to the `checkout -b` in all four branch skills — note the flag must precede `-b`, since `git checkout -b --no-track <name>` parses `--no-track` as the branch name — and by making `/create-pr` push the source branch by name instead of trusting the configured upstream. `/create-release` and `/create-main-sync` were less exposed, since each pushes with `-u` immediately, but take the same flag for consistency.

_Acceptance criteria:_

- A branch made by /create-feature or /create-hotfix has no upstream until it is first pushed
- /create-pr pushes the source branch by name, never relying on the configured upstream
- The four branch skills and /create-pr agree on the pattern
- Protected-branch push is impossible by accident, not merely unlikely

**MB.14 — Key the per-worker test database off `VITEST_POOL_ID`** · 1h

_Story:_ As a developer, I want each `db`-project worker to connect to a database `globalSetup` actually created, so that a green suite does not depend on how many test files the repo happens to have.

`src/test/db-global-setup.ts` clones `sorrel_test_1` through `sorrel_test_<maxWorkers>`, but `src/test/db-setup.ts` pointed the worker at `sorrel_test_${VITEST_WORKER_ID}`. Those index different things: `VITEST_POOL_ID` is the pool slot, which Vitest documents as "between 1-`maxWorkers`", while `VITEST_WORKER_ID` is a counter incremented once per test file across the whole run — both projects — and so passes `maxWorkers` as soon as there are more test files than workers. Latent since M1.9 and a coin flip on file count and sort order; M1.17's eleventh test file made it land, and three tests failed on PR #78 with `database "sorrel_test_4" does not exist` on the three-worker CI runner.

Both halves now share `src/test/worker-database.ts`, which owns the name and throws by name when `DATABASE_URL` or `VITEST_POOL_ID` is missing rather than connecting to `sorrel_test_undefined`. `globalSetup` `provide`s the list of databases it cloned and `test-database-isolation.test.ts` asserts membership of it — the regression this needed, since asserting the name's shape is what passed while the two halves disagreed.

_Acceptance criteria:_

- The database a `db`-project worker connects to is always one `globalSetup` created, whatever the test file count
- A missing `DATABASE_URL` or `VITEST_POOL_ID` fails as a harness error, not as a Postgres error
- The isolation spec asserts membership of the created set, not a name it recomputed
- Every doc naming `VITEST_WORKER_ID` for this purpose is corrected
- M1.9's decision — a real database per worker, never a rolled-back transaction — still stands

**MB.15 — Delete the redundant smoke-check workflows** · 1h

_Story:_ As a developer, I want one push to fire one CI run, so that no status-check context is published by two workflows at once.

Re-scoped mid-task, which is why the title no longer matches the branch name. It began as "collapse the smoke-check workflows onto `build-image.yml`": `lint-format-typecheck-check.yml` and `build-audit-check.yml` each defined their own inline `build-image` job, tagged `testing:smoke-<run id>`, unconditional and never reused across runs. Both headers said why — they were written at M0.16/M0.17, before `build-image.yml` landed at M0.24, and reaching ahead would have made M0.24 either redo the work or inherit a workflow written outside its own acceptance criteria. That rationale expired when M0.24 merged, so both became `uses: ./.github/workflows/build-image.yml`.

Doing that is what exposed the real defect. Once both consumed the same image build and the same `lint.yml`/`format.yml`/`typecheck.yml`/`build.yml`/`audit.yml` with the same inputs as `pr-gate.yml`, they were a strict subset of the gate. One push to the task's own PR fired three workflow runs and reported `lint / lint`, `typecheck / typecheck`, `format / format`, `build / build` and `audit / audit` twice each, `build-image / build-image` three times. Duplicate contexts under one `job / job` name make it ambiguous which run a branch ruleset gates on. Both workflows are deleted.

`composite-actions-check.yml` stays: it asserts `checkout-to-app` lands all five `action.yml` files in `/app`, which nothing in `pr-gate.yml` does, and it builds no image.

One thing the deleted workflows did cover that the gate did not: their path filters listed `Docker/Dockerfile.node`. `pr-gate.yml`'s `changes` job now lists it on `lint`, `typecheck` and `build` — the three checks that run inside that image — and deliberately **not** in the `*shared` anchor, which also feeds `destructive_ddl` and would hand `destructive-ddl.yml` an empty changed-files list for nothing.

`build-db-image.yml`'s standalone `pull_request` trigger is the same defect from the other direction — it is also an unconditional job in both `pr-gate.yml` and `merge-queue.yml`, so any PR touching `src/db/**` ran it twice. The trigger is dropped; `push` on `staging`/`main` stays, since moving `latest` is its real job. Folded into this task at the user's direction rather than minted as a separate `MB.*`, against CLAUDE.md's one-task-per-PR rule and with the rule shown first.

The merge queue was never affected: neither deleted workflow declared `merge_group:`, and `merge-queue.yml` builds each image once and passes it down.

`claude-docs/ci.md` had meanwhile grown a second, different rationale for the ad hoc builds: "so a regression check never runs through the thing it is testing". That is not a rule anyone adopted — already false for `composite-actions-check.yml` — and it is the doc that was corrected, not the code. Confirmed with the user first, per CLAUDE.md's rule on a documentary asymmetry.

Explicitly **not** in scope, and recorded so it is not re-litigated:

- `build-e2e-image.yml` cannot share `build-image.yml`'s work. `Docker/Dockerfile.node` is `node:alpine` (musl); `Docker/Dockerfile.e2e` is `mcr.microsoft.com/playwright:v<version>-noble` (Debian, glibc). An `npm ci` tree is not portable across libc — SWC and the other native addons are per-platform binaries — so the e2e image cannot `COPY --from` the testing image's `node_modules`, and Playwright's Chromium has no Alpine/musl build to unify the bases with. The two `npm ci` runs are structural; both already skip on an unchanged content hash.
- `.github/workflows/build-image.yml` is absent from every `changes` filter. Not a regression — the deleted workflows never listed it either, and `pr-gate.yml`'s own `build-image` job is unconditional, so it is exercised on every PR regardless.
- `ci.md` records (verified 2026-09-10) that no ruleset requires any status check yet, while `pr-gate.yml`'s header speaks of six as required. That discrepancy is real and is left alone here.

_Acceptance criteria:_

- `lint-format-typecheck-check.yml` and `build-audit-check.yml` are deleted
- One push to a PR produces exactly one workflow run, and `gh pr checks` reports every context exactly once
- `pr-gate.yml`'s `lint`/`typecheck`/`build` filters list `Docker/Dockerfile.node`; `*shared` does not
- `build-db-image.yml` has no `pull_request` trigger, and its `latest` tag still moves only on a push to `staging`/`main`
- No live doc or workflow still references either deleted workflow; `claude-docs/archive/**` is untouched

**MB.16 — Correct the Postgres version across the live docs** · 1h

_Story:_ As a developer, I want the docs to name the Postgres version the image actually builds from, so that nobody reasons about the wrong major.

Dependabot commit `43ff203` ("Bump postgres from 17 to 18 in /Docker") changed exactly one line of `Docker/Dockerfile.postgres` and nothing else. No prose followed it, so the Dockerfile says `postgres:18` while CLAUDE.md, DESIGN.md §11, this file, `TASKS.csv`, `ci.md`, `docker-compose.yaml` and three workflow header comments all still say 17. Confirmed with the user that the code is right before touching anything, per CLAUDE.md's rule on reconciling a doc against the code — a version bump argued nowhere and reversed nowhere is a bump, not a mistake.

Purely textual; `Docker/Dockerfile.postgres` is not touched.

Two deliberate non-changes, recorded so they are not re-litigated:

- `docker-compose.yaml`'s note about "a `postgres_data` volume populated by the _old_ `postgres:17` image" is about M0.19 switching that file from `image:` to `build:`, **not** about the version bump, and the literal is still historically accurate. It is clarified rather than changed, because with the base now on 18 it had started to read as though it meant the bump.
- `claude-docs/archive/**` is write-once and is left alone wherever it says 17.

This task also carries the `TASKS.md`/`TASKS.csv` entries for MB.16, MB.17 and MB.18, since all three were added to the board in one pass and CLAUDE.md requires the board and these files to move together.

_Acceptance criteria:_

- `grep -rn "postgres 17\|postgres:17" --exclude-dir=node_modules --exclude-dir=archive .` returns only the intentional `docker-compose.yaml` history line
- `Docker/Dockerfile.postgres` is unchanged
- `claude-docs/archive/**` is untouched
- `npm run pre-commit` passes

**MB.17 — Drop the dead `latest` tag from `build-db-image`** · 1h

_Story:_ As a developer, I want the reason a workflow runs on `staging` to be the reason written next to it, so that the next person to read it can act on what it says.

`build-db-image.yml`'s header and `ci.md` both say the `push` trigger on `staging`/`main` exists to move the `latest` tag. Nothing consumes `latest`: `docker-compose.yaml` builds `Dockerfile.postgres` locally (M0.19) and every CI caller pins the content-addressed hash tag. Meanwhile the trigger does do something neither doc mentions — it is the only thing that writes a GHA layer-cache entry another branch can read, because `cache-to: type=gha` entries are branch-scoped and a `pull_request` run writes only to its own merge-ref scope.

Measured on the real runs: a fully cold build step is 25s, a warm one 6–8s. Fresh feature branches that had never built the image got 6–8s, which is only possible via the cross-branch restore those push runs seed. Worth ~17s on each new branch's first CI run, on a job that gates `vitest` and `playwright`, at no dollar cost — the repo is public and the push run is post-merge, off the PR critical path.

So the trigger stays and the tag goes. (MB.99 later removed the trigger as well: M1.27 took `src/db/**` out of the hash, so a push found the PR's tag already published and skipped, and the layer cache moved to the registry, where every branch reads one copy.) MB.15's own entry above, which records "moving `latest` is its real job", is corrected in the same pass.

`src/db/**` is in the tag hash and the path filter but **not** in the build context — `Dockerfile.postgres` only `COPY`s `Docker/postgres-init/enable-extensions.sql` — so a `src/db`-only change republishes byte-identical layers under a new tag. M1.27 changes that by baking the schema in. Recorded here because it is what makes MB.18's cache argument work.

_Acceptance criteria:_

- `ghcr.io/<repo>/db:latest` is no longer pushed; only the hash tag is
- The `image` job output is unchanged, and `pr-gate.yml`/`merge-queue.yml` still consume it
- The build step on the task's own PR run is still ~6–8s, proving the cache restore is intact
- `build-db-image.yml`, `ci.md` and MB.15's entry above all state the cache-seeding reason, and no live doc still claims the trigger exists to move `latest`

**MB.18 — Give `build-db-image` the skip-if-exists check** · 1h

_Story:_ As a developer, I want a PR that changes nothing about the database image to skip rebuilding it, the same way the other two image builds already do.

`build-image.yml` and `build-e2e-image.yml` both gate their build on `docker buildx imagetools inspect` finding the content-addressed tag already published. `build-db-image.yml` is the only one that does not, and `ci.md` says that is deliberate: "its trigger paths are exactly its hash inputs, so the trigger already does it". That holds for the `push` trigger and fails for `workflow_call`, which bypasses the path filter entirely and is the path every PR takes. On that path nothing does the skipping and buildx runs every time.

The two mechanisms are alternatives, and the siblings picked the better one: skip-if-exists reuses work via GHCR tag existence, which is global, where the GHA layer cache is branch-scoped. Adding the check does **not** make MB.17's push trigger redundant — `src/db/**` is in the hash but not the build context, so through Wave 1 the tag misses constantly while the content does not change, which is exactly when a warm layer cache still pays. Both mechanisms stayed until MB.99, which moved the layer cache to the registry and removed the push trigger.

Three things differ from the siblings and are easy to get wrong: the tag step here is `id: tags` with output `hash-tag`, not `id: tag` with output `image`, so a copied expression would gate on an empty string and silently never skip; the `image` job output must keep coming from `hash-tag`, which is computed before the check and unconditionally, because `vitest.yml` and `playwright.yml` key their `services: postgres:` block off it; and after MB.17 `tags` and `hash-tag` are the same value.

No concurrency change. This entry once called the mid-push corruption hazard `build-image.yml`'s comment described guarded by the job's `cancel-in-progress: false`; MB.98 found the hazard was never real, since a tag is written only after every layer it names, and the workflow's own group cancelled the job regardless.

_Acceptance criteria:_

- On the task's own PR: `exists=false`, the build runs, `vitest`/`playwright` green — the build path still yields a correct `image` output. This PR **cannot** prove the skip path: editing the workflow changes the hash, so its own run is a guaranteed miss.
- On the next unrelated PR after merge: `exists=true`, the build step is skipped, `vitest`/`playwright` still green — the `image` output survives the skip path. The task is not done until a post-merge PR has exercised this.
- Skip-path job duration ~13–15s against ~24s before
- `ci.md` no longer claims the path filter makes the check unnecessary, and states that `workflow_call` bypasses it

**MB.19 — ~~Move `drizzle-kit`/`drizzle-orm` off the `@esbuild-kit` advisory~~** · **RETIRED 2026-09-17, not done**

> **Retired without being done.** The ID is kept because task IDs are immutable
> and the analysis below is still the record of why the advisory is tolerated.
> Removed from the Asana board; it is no longer work to do.
>
> **Why.** The task would trade a stable-but-frozen dependency for a
> prerelease one, to clear an advisory that has **no runtime exposure**:
> GHSA-67mh-4wv8-2f99 is esbuild's _dev server_ accepting cross-origin
> requests, `drizzle-kit` is a devDependency and build-time CLI that never
> ships to Vercel, and nothing here runs `esbuild serve`. Two claims in the
> analysis below are also wrong and are corrected here rather than silently:
> (1) it says to pin the newest `rc.5-<hash>` — those are per-commit CI
> publishes, not releases; the `rc` dist-tag points at the curated
> `1.0.0-rc.4`; (2) it says `audit.yml` "only fails CI on a high-severity
> advisory" — it never fails, running `npm audit --json … || true` and
> commenting only.
>
> **What replaced it.** MB.20 drops `@pothos/plugin-drizzle`, the component
> that tracked `drizzle-orm`'s version and would eventually have forced this
> upgrade. With it gone, the ORM sits behind `repository.ts` as a query
> builder rather than an architectural commitment, and staying on `0.45.2` is
> sustainable. The standing decision and its revisit triggers are recorded in
> `claude-docs/db.md`, "Why the ORM stays on 0.45.2" — **revisit at 1.0 GA**,
> when `drizzle-kit generate` cannot express DDL a task needs, or if the
> advisory gains a runtime path.

_Story (retired):_ As a developer, I want `npm audit` clean of the standing `drizzle-kit` advisory so a known vulnerability doesn't sit in the tree indefinitely just because it's moderate rather than high.

`npm audit` reports a moderate advisory (GHSA-67mh-4wv8-2f99, CVSS 5.3 — esbuild's dev server accepts cross-origin requests) reached only through `drizzle-kit@0.31.10` → `@esbuild-kit/esm-loader@2.6.5` → `@esbuild-kit/core-utils@3.3.2`, which pins its own nested `esbuild` to `~0.18.20` regardless of the `esbuild@^0.25.4` `drizzle-kit` depends on directly. `@esbuild-kit` is archived upstream — folded into `tsx`, which `drizzle-kit@0.31.10` already depends on separately but does not yet use to replace the esm-loader. `0.31.10` is the newest version on the stable dist-tag; there is no patched `0.3x` release to move to; M0.17's audit workflow does not catch this because it only fails CI on a high-severity advisory.

The only version line that drops `@esbuild-kit` is `drizzle-kit`'s `1.0.0-rc.*` prerelease, which depends directly on `esbuild@^0.25.10` via `jiti` instead. `drizzle-orm` has a matching `1.0.0-rc.*` line that must move with it — confirmed compatible with what's installed here: `@better-auth/drizzle-adapter`'s own peer range is already `^0.45.2 || >=1.0.0-rc.1 <2.0.0`, so `src/lib/auth.ts`'s `drizzleAdapter` accepts either. `drizzle-orm@1.0.0-rc.1`'s release notes carry one breaking change relevant to a Postgres/Drizzle Kit project — the `casing: "camel"` config option was replaced by `snakeCase`/`camelCase` table wrappers — which does not apply here: `drizzle.config.ts` sets no `casing` key (confirmed by grep) and no schema file uses it either.

An `overrides` entry forcing `esbuild` up inside `@esbuild-kit/core-utils` without touching `drizzle-kit`'s version was considered and rejected: `@esbuild-kit/core-utils` is unmaintained and pins `~0.18.20` deliberately, so overriding it to `^0.25` would run its code against an esbuild two majors newer than anything it was tested against, with no upstream fix if that broke — trading a documented, understood advisory for an undocumented one.

Both packages are still on release candidates, not a GA `1.0` — `npm view drizzle-kit versions` / `npm view drizzle-orm versions` should be re-checked at implementation time rather than assuming today's newest `rc.5-<hash>` is still the newest, and the PR should say plainly that it pins a prerelease so it's easy to find and revisit once `1.0` goes stable.

_Acceptance criteria (retired — not to be met):_

- `drizzle-kit` and `drizzle-orm` upgraded together to matching `1.0.0-rc.*` versions (re-verify the newest available rc, or a GA `1.0`, at implementation time)
- `npm audit` no longer reports the `@esbuild-kit/esm-loader` → `esbuild` advisory chain
- `npm run db:generate` against the current `src/db/schema` produces no diff versus the existing migrations in `src/db/migrations`
- `npm run db:migrate` (`make db-migrate`) still applies cleanly against a fresh `sorrel_template`
- `npm run db:seed` / `db:reset` still fail at the same known M1.21–M1.23 seed-scenario point, not earlier
- `src/lib/auth.ts`'s `drizzleAdapter` initializes with no peer-dependency warning
- `drizzle.config.ts` needs no changes beyond what the new major documents; any that are needed are recorded in the PR
- The PR body states this pins a `drizzle-kit`/`drizzle-orm` release candidate, not a GA release

**MB.20 — Drop `@pothos/plugin-drizzle` from the GraphQL stack** · 1h

_Story:_ As a developer, I want the GraphQL layer independent of `drizzle-orm`'s version so that a frozen ORM release does not eventually force an upgrade through the resolver layer.

`DESIGN.md` §2 and §7 specify Pothos **with the Drizzle plugin**, justified at `DESIGN.md:64` by `auditColumns` flowing into the graph without retyping. Three of that decision's premises do not hold:

1. **The plugin's primary capability is banned.** It exists so a resolver can query the database from the GraphQL selection set (`builder.drizzleObject`, `t.relation`). `DESIGN.md:359` says "No database access in a resolver, ever. Same lint rule as `db`," and M3.9 adds that rule.
2. **The graph does not mirror the tables.** The schema sketch at `DESIGN.md:417` exposes `audit: AuditInfo!` — a nested object, not six flat columns. `Ingredient.isGlobal` is derived from `workspace_id IS NULL` and is not a column; `Spell.derivedCategories` and `Spell.categoryGaps` are computed. Derivation would be overridden on essentially every type. `DESIGN.md`'s own "resolvers are thin" example (`:346`) is a plain `t.field` over a manually declared type.
3. **It couples GraphQL to the ORM's version.** `@pothos/plugin-drizzle` is `0.20.0` and tracks `drizzle-orm`; every other Pothos package is a stable `4.x` (`core` 4.15.1, `plugin-scope-auth` 4.2.1, `plugin-dataloader` 4.4.6, `plugin-relay` 4.8.1). It is the component that would have forced MB.19's upgrade.

N+1 and pagination were never the plugin's job: `DESIGN.md:362`/`:372` assign batching to per-request DataLoaders in the Yoga context, and rule 8 / M3.6 specify one shared cursor helper.

**Nothing is installed yet** — `package.json` carries no `pothos`, `graphql` or `yoga`, and `src/graphql/{schema,loaders}/` are empty. So this task is documentation and scoping, taken before M3 is written rather than retrofitted onto it, per CLAUDE.md's sweep-task rule. It lands in Wave 2 because M3.2 is the first task that would wire the plugin up.

_Acceptance criteria:_

- `DESIGN.md` §2's "Why Drizzle" no longer cites the Pothos plugin as a reason, and says so explicitly rather than deleting the bullet
- `DESIGN.md` §2's "Why Yoga + Pothos" states the plugin is deliberately unused and why
- `DESIGN.md` §7's stack line reads "Pothos (code-first schema, no ORM plugin)"
- M3.2 no longer says "with the Drizzle plugin", and its criterion "types are inferred from Drizzle tables" is replaced by one asserting hand-declared object types still fail typecheck on a changed column type
- `claude-docs/design-decisions/mb.20-pothos-without-drizzle-plugin.md` records the decision, what it rules out, and that re-adopting later is additive
- `claude-docs/db.md` carries the standing "leave the ORM on 0.45.2" decision and its revisit triggers
- MB.19 is marked retired in `TASKS.md` and `TASKS.csv` and removed from the Asana board
- No dependency change: `package.json` is untouched

**MB.21 — Drizzle Studio for local development** · 1h

_Story:_ As a developer, I want to browse the local database without dropping into `psql`, so I can inspect rows and schema while working.

There is no way to browse the local database today. `drizzle-kit` is already a devDependency (pinned to `0.31.10` by MB.20's decision) and ships a `studio` subcommand that reads the existing `drizzle.config.ts`, so this is a wiring task, not a new dependency. `package.json` already has `db:generate` / `db:migrate` / `db:seed` / `db:reset`; nothing exposed a Studio port.

Two constraints shape the wiring: `make` and `docker` do not exist in the devcontainer, so the npm script has to stand on its own, with the `make`/compose path as the host equivalent — the same split `workshop` / `docker-workshop` already has. And Studio's own UI is hosted externally at `https://local.drizzle.studio`; the browser connects from there back to `127.0.0.1:4983`, so the local process only ever serves data, never a page — port forwarding is the whole story.

`npm run db:studio` runs `drizzle-kit studio --host 0.0.0.0 --port 4983`, both flags explicit rather than relying on `0.31.10`'s (currently matching) defaults, so a future version change on this dist-tag doesn't silently rebind. `Docker/docker-compose.yaml` gets a `studio` service behind a `studio` compose profile, shaped like `workshop` but depending on `postgres`'s health check — there is nothing to browse without a connection. `make db-studio` and `make docker-studio` wrap the two paths, and `make docker-all` starts every long-running service (app, Postgres, workshop, studio) together — MB.23 later adds the Playwright browser server to that list. `.devcontainer/devcontainer.json` forwards **4983** alongside 8000/8001 — the only devcontainer change needed, since that overlay publishes no ports of its own.

_Acceptance criteria:_

- `npm run db:studio` (from the devcontainer, `DATABASE_URL` set) binds to `0.0.0.0:4983` and serves the schema from `src/db/schema` at `https://local.drizzle.studio`
- `make docker-studio` brings up the `studio` compose service; `docker compose ps` shows it healthy-dependent on `postgres`
- `make docker-down` removes the `studio` container (proves `--profile studio` was added to `docker-build`/`docker-down`/`docker-rebuild`, not just `docker-studio`); a bare `make docker-up` does **not** start it
- `make docker-all` starts app, postgres, workshop and studio together
- `make help` lists `db-studio`, `docker-studio` and `docker-all` with their doc lines
- `drizzle.config.ts` is unchanged — it already throws when `DATABASE_URL` is unset and needs no Studio-specific configuration
- `CLAUDE.md`, `claude-docs/db.md` and `claude-docs/docker.md` document the command, the port, and the compose profile
- `npm run pre-commit` and `npm run db:generate` (no migration diff) stay green

**MB.22 — Set up modern debugging tooling** · 8h (explicit exception to normal 1–2h sizing; see the minting note above)

_Story:_ As a developer, I want to set a breakpoint in a server component, a service, a repository finder, or a test, and to see the SQL a query actually emits, so I don't have to debug `withAudit`'s transaction scoping and the two-layer authorization model (rule 5) by printf.

There is no debugging story in this repo at all: no `.vscode/` directory, no Node inspector port wired anywhere in the container, no way to see what a query actually did beyond its output, and no way to replay a failed Playwright run locally — `playwright.config.ts` sets `trace: 'on-first-retry'` next to `retries: process.env.CI ? 2 : 0`, so a local failure writes no trace at all. Playwright also cannot run natively in the devcontainer: `Docker/Dockerfile.node` is Alpine/musl and Chromium has no musl build, so `e2e` is a separate Debian image today with no debugging affordances.

Five pieces, one PR:

1. **Node inspector.** `npm run dev:debug` (`next dev --inspect=0.0.0.0:9229 …`, `next dev`'s own native flag — not `NODE_OPTIONS`, which leaks into Next's internal child processes and collides with whatever port they auto-claim next) plus `make dev-debug`; port 9229 published on the `app` compose service and forwarded by the devcontainer.
2. **VS Code.** `.vscode/launch.example.json` and `.vscode/tasks.example.json` are committed (not `launch.json`/`tasks.json`, which stay per-developer and ignored) — attach-style configs, since every process here starts in a terminal inside the container: attach to the Next.js server (9229), attach to Vitest (9230), a launch config for the current test file, attach to the Playwright runner (9231). No client-side Chrome/Edge config — there is no browser in the container; client-side debugging is host DevTools against the forwarded 8000.
3. **Test debugging.** `npm run test:debug` runs Vitest single-worker under `--inspectBrk=0.0.0.0:9230` (Vitest's own native flag, plus `--maxWorkers=1` — the config's `poolOptions.threads.singleThread` dotted form the earlier draft of this task assumed isn't accepted from the CLI) — single-worker specifically, so the breakpoint is inside a known `sorrel_test_${VITEST_POOL_ID}` clone (CLAUDE.md's Testing section); `npm run test:ui` (`@vitest/ui`, pinned to the installed `vitest@^5.0.0` line). For Playwright: fix the local-trace defect (`trace: process.env.CI ? 'on-first-retry' : 'retain-on-failure'`, screenshots and video on failure off CI), add `e2e:ui` / `e2e:debug` / `e2e:trace` scripts, and — the harder piece — let `npm run e2e` run from inside the devcontainer at all. The approach: a long-lived `playwright-server` compose service (profile `e2e`, same `Docker/Dockerfile.e2e` image already built for CI) runs `playwright run-server`; `playwright.config.ts` reads `PLAYWRIGHT_WS_ENDPOINT` and takes Playwright's `connectOptions` branch only when it's set, which `.devcontainer/docker-compose.yml` sets only on the `devcontainer` service — so `make docker-e2e` and CI, which never set it, are unaffected and keep launching Chromium locally in the `e2e` container. The runner (plain Node, no native browser dependency) stays in the Alpine devcontainer; only the browser needs the Debian image. This is recorded as a decision, not just a diff — `claude-docs/design-decisions/mb.22-playwright-in-devcontainer.md` states the trade-off (headed interaction — `page.pause()`, UI mode's live picker — doesn't work well against a remote browser; trace viewer and UI mode's recorded-step view do).
4. **Database debugging.** `make db-psql` (`docker compose exec postgres psql -U sorrel sorrel`) and opt-in query logging: `src/db/connection.ts`'s `drizzle(client)` becomes `drizzle(client, { logger: process.env.DEBUG_SQL === '1' })` — off by default, so no test output or CI behaviour changes, and on, every statement the repository emits is printed, including `withAudit`'s `SET LOCAL app.current_user_id`. `src/db/connection.ts` is already the one file rule 2 allows to hold the client; nothing about the import boundary changes.
5. **Next.js DevTools MCP.** `.mcp.json` gains a `next-devtools` server (`npx -y next-devtools-mcp@latest`, the form `node_modules/next/dist/docs/01-app/02-guides/mcp.md` specifies) alongside the existing `asana` entry — while `npm run dev` is running, an agent session can read the dev server's current build/runtime errors, route metadata and logs directly.

All of it is documented in one place: `claude-docs/debugging.md`, a new subsystem summary (README.md's per-subsystem convention), with `claude-docs/transcripts/debugging.md` opened alongside it, plus a pointer and a Commands-table row in `CLAUDE.md`, and shorter cross-references from `claude-docs/testing.md` and `claude-docs/db.md`.

_Acceptance criteria:_

- `npm run dev:debug` prints a `Debugger listening on ws://0.0.0.0:9229/…` line and still serves 8000; `npm run dev` is unchanged and starts no inspector
- Copying `.vscode/launch.example.json` into `launch.json` gives a working attach session against the Next.js server, Vitest and the Playwright runner; `.gitignore` allows the two `*.example.json` files through its `.vscode/*` deny while `launch.json`/`tasks.json` stay ignored
- `npm run test:debug` halts on the first line under `--inspect-brk`, attaches on 9230, and the run uses exactly one `db`-project worker
- A locally-failing e2e spec writes `test-results/**/trace.zip`; `npm run e2e:trace` serves an observer on a forwarded port; CI's `trace`/`screenshot`/`video` behaviour is unchanged (`CI=true` still takes the `on-first-retry` branch)
- `npm run e2e` succeeds from inside the devcontainer with the browser running in `playwright-server`; `make docker-e2e` and `.github/workflows/playwright.yml` are provably untouched — neither sets `PLAYWRIGHT_WS_ENDPOINT`, so neither takes the `connectOptions` branch
- `make db-psql` opens a prompt against the compose `postgres` service; `DEBUG_SQL=1 npm run test -- src/db/repository.test.ts` prints SQL including the `SET LOCAL`, and without the flag output is unchanged
- With `npm run dev` running, the `next-devtools` MCP server connects and reports a deliberately introduced type error; `.mcp.json` stays valid JSON and the `asana` server still connects
- `npm run lint` passes (no new database-client importer — rule 2 holds) and `npm run pre-commit` / `npm run test:coverage` are green
- `claude-docs/debugging.md` is readable without opening any other file, per README.md's standard for a subsystem summary

**MB.23 — Playwright codegen for local development** · 2h

_Story:_ As a developer, I want to record an e2e interaction instead of hand-guessing role and label queries against a page I haven't inspected, so the spec I write matches CLAUDE.md's "role and label queries only" house style from the start.

MB.23 sits directly on top of MB.22 (merged), which split the Playwright runner from the browser: the runner stays in the Alpine devcontainer, and a long-lived `playwright-server` compose service (built from `Docker/Dockerfile.e2e`, behind the `e2e` profile) provides the Chromium it dials over `PLAYWRIGHT_WS_ENDPOINT`. That mechanism cannot serve codegen — `playwright codegen` always launches its own local browser and exposes no `--ws-endpoint` — and MB.22's own design record already names the reason: `page.pause()`'s inspector window has nowhere to open, because `playwright-server` has no display attached. Codegen is exactly that failure mode.

The fix is a display on the existing service, not a second one. `Docker/Dockerfile.e2e` gets a second, named stage (`e2e`, unchanged, then `FROM e2e AS headed` adding `xvfb`, `x11vnc`, `novnc`/`websockify`, and a window manager). `.github/workflows/build-e2e-image.yml` and the `e2e` compose service both pin `target: e2e` so default-stage behaviour doesn't shift under them. `playwright-server` builds `headed` instead, takes its own image tag (`sorrel-e2e-headed`, distinct from the `e2e` service's `sorrel-e2e` — both declaring the same tag today is a latent last-build-wins bug the moment one builds a different stage), and gains a `playwright-entrypoint.sh` that raises the display before handing off to whatever command it was given, so MB.22's `run-server` path is unchanged. Publishing `7900` alongside `4444` turns that display into a tab: `http://localhost:7900` streams the containerised Chromium and Inspector over noVNC. A new `make docker-codegen NAME=<spec>` target `exec`'s `playwright codegen` into the running `playwright-server` container as the caller's uid, writing `e2e/<name>.spec.ts` un-root-owned. `page.pause()` and UI mode's locator picker — the two things MB.22 wrote off — work as a side effect, so its design record gets a dated amendment rather than staying documented as a limitation the code no longer has.

Sign-in is OAuth-only, so an authenticated flow can't be recorded until seeded sessions exist (M1.21–M1.23); this task records unauthenticated pages only and does not build a hook for storage-state loading.

`make docker-all` is extended to bring `playwright-server` up alongside app/Postgres/workshop/studio — it's a long-running service like the other three, and now has a display worth having up by default. `e2e` stays deliberately out of that list: it's a one-shot suite run (`docker compose run --rm`), not a service to leave running, so `docker-all` names the services it starts explicitly rather than blanket-starting everything the `e2e` profile enables.

Recording against a real page surfaced two app-level defects that only a real browser could find, both folded into this task on request rather than split out. First, the recorded page rendered correctly and was completely inert: `next dev` 403s cross-origin requests to `/_next/*` from any host outside `localhost` unless it is listed in `allowedDevOrigins`, and while `<script src>` requests survive that check (they send no `Origin` and count as same-origin), the HMR websocket upgrade does not — and under Turbopack that connection is what boots the client runtime, so the app never hydrated and every handler was silently absent. Second, with that fixed, the first click on `ThemeToggle` did nothing visible: `globals.scss` resolves three theme states (`data-theme`, else a light system preference, else dark) but only a _stored_ choice stamps the attribute, so reading it alone reported "not light" on a light system with nothing stored and applied `light` — the theme already showing. `index.scss` had the same gap, leaving the crescent on a light page until the mount effect swapped it a paint later. Both are fixed by resolving the theme the way the stylesheet does, in the component and in its stylesheet alike.

A third finding is deliberately documented rather than fixed: while the recorder is attached, the dev overlay reports a hydration mismatch on `<body data-pw-cursor="pointer">`. That attribute is Playwright's own, set to drive the pointer styling it paints over the page, and it lands before React loads. Hydration still completes. Silencing it would mean `suppressHydrationWarning` on `<body>` — masking real body-level mismatches everywhere and permanently, to quiet a tool artifact that appears only under the recorder.

_Acceptance criteria:_

- `make docker-build` builds both the `e2e` and `headed` stages without error
- `make docker-e2e` still passes against the `e2e` stage; `sorrel-e2e` and `sorrel-e2e-headed` are distinct images, and `sorrel-e2e`'s size is unchanged from before this task
- `make playwright-server-up` then `npm run e2e` from inside the devcontainer still passes against the remote browser exactly as MB.22 left it
- `make docker-all` brings up app, Postgres, workshop, studio and `playwright-server` (`docker compose ps` shows all five); it does **not** start `e2e` itself
- `make docker-codegen NAME=scratch` opens `http://localhost:7900` to a headed, interactive Chromium beside a draggable Playwright Inspector; recording an interaction writes a caller-owned `e2e/scratch.spec.ts` using `getByRole`/`getByLabel`/`getByText`
- Adapting `e2e/scratch.spec.ts` per the debugging.md checklist (import from `./fixtures`, relative `goto`) and running `make docker-e2e` passes it alongside `smoke.spec.ts`; the scratch file is deleted before the PR
- A temporary `page.pause()` in `e2e/smoke.spec.ts`, run via `npm run e2e` from the devcontainer, opens the Inspector at `:7900`
- The page loaded at `http://sorrel-app:8000` in the recorder actually hydrates: clicking an interactive element runs its handler, and the console carries no blocked-websocket error
- On a system preferring light with no stored choice, the **first** click on `ThemeToggle` changes the theme (to dark), `aria-pressed` reads `true` at mount, and the sun facet is already at rest rather than swinging in after first paint — covered by unit tests that fail without the fix
- `make docker-down` leaves no container behind; the devcontainer's Ports panel lists `7900`
- `claude-docs/design-decisions/mb.23-codegen-needs-a-display.md` records why `run-server` can't serve codegen and why a display on the existing service beats a second one; `claude-docs/design-decisions/mb.22-playwright-in-devcontainer.md` is amended in place with a dated note that `page.pause()` and the locator picker now work; `claude-docs/debugging.md`, `testing.md`, `docker.md` and `ci.md` are updated
- `npm run pre-commit` is green

**MB.24 — Decide the RLS role split and read-path identity** · 2h · **merged, then superseded by MB.29**

> **Superseded, not wrong.** MB.24 shipped and its two findings hold. MB.29 then
> deferred the policies they were fixing to the public launch, so the tasks it
> spawned — MB.25, MB.26 — are retired along with M6.4 and M6.5, and the
> decision record is the specification for when RLS lands rather than for Wave 5. Everything below is history and is left as it was written.

_Story:_ As a developer, I want the RLS design to be enforceable before M6.4 writes policies against it, so that the second authorization layer is real rather than decorative.

Documentation and scoping only, in the shape of MB.20: no policy, no migration, no code. It exists because §8's two-layer design does not currently work, in two ways that hid each other.

**The policies would be inert.** The application connects as `sorrel` (`Docker/docker-compose.yaml`) and `drizzle-kit migrate` runs against that same `DATABASE_URL`, so `sorrel` owns every table its policies would filter. Postgres exempts a table's owner from its own policies unless `ALTER TABLE … FORCE ROW LEVEL SECURITY` is set, and that clause appears nowhere in this repo. Neon is the same shape — the integration injects the table-owning role. M6.5 would have caught this, but only after M6.4 had shipped believing otherwise.

**Fixing that alone would break every read.** `set_config('app.current_user_id', …, true)` is published inside `withAudit`, the write path (M1.19). Reads go through `findMany`/`findOne` → `selectFrom`, which uses the bare client with no transaction (M1.20), and a `LOCAL` GUC exists only inside one. A policy reading the GUC on a read would see it unset on a fresh pooled connection, or reset to `''` on one that has served a write — an error on the `::uuid` cast, or zero rows. Nothing planned catches it, because M6.5 asserts a read is _refused_.

The answer is three independent, individually cheap layers rather than one clever one: the app role stops owning the tables (MB.25), `FORCE` makes an owner-role misconfiguration fail closed instead of open, and a startup assertion makes it fail loudly. Reads get identity from `withViewer` (MB.26). `FORCE` was initially ruled out on the grounds that it breaks migrate and seed; that stops being true once the owner holds `BYPASSRLS`, which outranks it — so it costs nothing already being paid and covers the case where `DATABASE_URL` resolves to a table-owning role that is not `sorrel`, which is exactly what Neon's `neondb_owner` is.

This task also settles four things about the policies themselves, all cheaper to fix in the task text than in M6.4's PR. §8's policy shape subqueries `workspace_members`; applied to that table it is infinite policy recursion, which Postgres rejects outright — so the role hierarchy moves into a `security definer` `app.is_member()` helper, with `app.current_user_id()` beside it returning `NULL` rather than raising on an unset GUC. `ingredients.workspace_id` is nullable and `NULL` means the global compendium, so a policy without `workspace_id IS NULL OR …` deletes the compendium from every signed-in user's view. And `spell_ingredients` and `spell_categories` carry no `workspace_id`, so the guard as worded — "every table with a `workspace_id`" — silently exempts the two tables holding what a spell is made of.

_Acceptance criteria:_

- `claude-docs/design-decisions/mb.24-rls-role-split.md` records both findings and the options weighed: `FORCE` alone vs. the role split vs. both, derive vs. provision on Neon, and per-query vs. per-request read transaction
- DESIGN.md §8 is rewritten for the role split, `FORCE` and `withViewer`; its example policy's name/table mismatch is fixed (it names `ingredients_workspace_access` but attaches it to `inventory_items`)
- DESIGN.md §14 gains a decision-log row for RLS — there is currently none, which is part of why this went unexamined — and §2's recorded risks gain the Neon role-injection risk
- The DESIGN.md §8 / `repository.ts` disagreement is resolved **in the code's favour**: §8 claims every workspace-scoped _call_ passes `assertMembership` inside `withAudit()`, while `withAudit` is the write path only. The doc predates M1.20's read/write split; §8 is corrected to say reads carry identity through `withViewer`
- CLAUDE.md rules 3 and 5 name both wrappers and both roles
- M6.4, M6.5 and M10.3 are re-scoped here and in TASKS.csv, including striking M6.4's seed criterion as answered by MB.25
- No code, no migration
- `npm run pre-commit` is green

**MB.25 — ~~Split the database roles so RLS applies to the app~~** · **RETIRED 2026-09-17, not done**

> **Retired without being done (MB.29).** ID kept, per the MB.19 precedent;
> removed from the Asana board. The analysis below is correct and is kept as
> part of the specification for the public launch — the role split is still
> what would make policies real rather than declared.
>
> **Why.** It exists only to serve RLS, and MB.29 deferred RLS. Every cost in
> it is a cost with no v1 benefit: a second role on every environment, a
> credential-derivation scheme in `connection.ts`, two new variables wired
> through `docker-compose.yaml`, three CI workflows and `deploy.yml`, and a
> Neon assumption about role inheritance across branches that M1.1's record
> says must be verified in the live dashboard before anything depends on it.
> The layer it was buying is bought instead by M6.3's `Membership` proof, for
> nothing at runtime and nothing in operations.

_Story (retired):_ As a steward, I want the application to connect as a role that cannot bypass RLS, so that the database layer enforces workspace boundaries rather than merely declaring them.

`sorrel` keeps everything it is documented to be — owner of the database and of `sorrel_template`, holding `CREATEDB` for M1.9's per-worker clones — and gains `BYPASSRLS` so migrations and the seed run unimpeded. That is what answers M6.4's open question about seeding under policies, using the first of the two options it already offered, on the role that already runs the seed. A new `sorrel_app` (`LOGIN`, `NOBYPASSRLS`, owning nothing) is what the application connects as.

`ALTER DEFAULT PRIVILEGES` is the load-bearing line: without it, every future migration's table is invisible to the app until someone remembers a `GRANT`. Grants live in the database's own catalogs, so `CREATE DATABASE … TEMPLATE sorrel_template` carries them into each `sorrel_test_<n>` clone for free.

**Neon: derive, don't inject.** The integration's branch-per-preview feature mints an endpoint host at deploy time, so there is no host to pre-set a connection string for — "set `DATABASE_URL` explicitly per environment" is not available. Instead `connection.ts` takes whatever `DATABASE_URL` the platform supplies and swaps only username and password, keeping host, database and `sslmode`. Because it never names the host, it behaves identically on an ephemeral branch, on staging, in production, in Docker and in CI. This is also why there is no second connection string: `DATABASE_URL` stays the owner's, which is what `drizzle.config.ts`, `scripts/db-seed.ts` and `db-global-setup.ts` already want, so none of those call sites change. Vitest inherits it — `worker-database.ts` rewrites only the database name, so the clone URL flows through `connection.ts` and comes out as `sorrel_app` on the right clone.

The one assumption is that `sorrel_app` exists with the same password on whichever branch the host points at. Neon branches copy roles and their stored credentials from the parent, so a role created on `main` should reach every descendant — but M1.1's record says to verify Neon branch behaviour in the live dashboard rather than trust it, and that applies here. Verify it before anything depends on it.

_Acceptance criteria (retired — not to be met in v1):_

- `Docker/postgres-init/enable-extensions.sql` grants `BYPASSRLS` to `sorrel` and creates `sorrel_app` with `USAGE` on schema `public` and `ALTER DEFAULT PRIVILEGES` for tables and sequences
- `src/db/connection.ts` derives the app connection from `DATABASE_URL` plus `DATABASE_APP_ROLE` and `DATABASE_APP_PASSWORD`; both are **required** and throw when absent, so `FORCE` stays a backstop rather than a crutch
- The new variables are wired into `Docker/docker-compose.yaml`, the three CI workflows and `deploy.yml`
- A startup assertion refuses to connect as a role that is superuser, holds `rolbypassrls`, or owns a known application table — a `pg_roles`/`pg_class` query, the same introspection style as M6.4's catalogue guard — with a `db`-project test that fails if it is not enforced
- `npm run db:migrate` and `npm run db:seed` both succeed as the owner
- `sorrel_app` can read and write every application table but cannot `CREATE TABLE`
- `npm run test:coverage` is green, M1.9's clone isolation included
- Neon: `sorrel_app` created on `main` and `staging`, with role inheritance **verified on a throwaway branch cut from `main`**. If it does not hold, the fallback is `neonctl branches create` plus `neonctl connection-string --role-name sorrel_app` in `deploy.yml`, dropping the integration's auto-branching
- `claude-docs/secrets.md` documents both new variables
- `npm run pre-commit` is green

**MB.26 — ~~`withViewer`, the read-side identity wrapper~~** · **RETIRED 2026-09-17, not done**

> **Retired without being done (MB.29).** ID kept; removed from the Asana
> board. Unlike MB.24 and MB.25, this one is not held for the public launch
> either without re-deciding it: it is the mechanism whose standing cost is the
> reason RLS was deferred at all, so whoever adds policies later should price
> it again rather than assume this design.
>
> **Why.** Its only purpose was to give a read a transaction for the GUC to be
> `LOCAL` to. With no policy reading the GUC, it publishes a setting nothing
> consults and charges `BEGIN`, `set_config`, `SELECT`, `COMMIT` — four round
> trips where a read is one, roughly +10–15ms per `cache()`-deduped service
> call against Neon, plus a pooled connection held for the length of every
> render — on a meter that bills I/O wait (DESIGN.md §4). Re-entrancy reduces
> how often that is paid, not whether it is.
>
> **What replaced it.** M6.3's `Membership` proof carries identity as a
> function argument instead of a session variable, so reads open no transaction
> and CLAUDE.md rule 3 covers writes alone. DESIGN.md §14 records that this
> wrapper was never built, so a later reader does not go looking for it.

_Story (retired):_ As a developer, I want reads to carry the acting user into the database, so that an RLS policy can filter a read rather than erroring on a setting that was never published.

The mechanism half of the sweep-task rule: it lands one wave before its first caller and is adopted by each later task in that task's own PR, never retrofitted. Until M6.4 adds policies it changes no behaviour, so it lands green.

`withViewer` is `withAudit`'s read-side counterpart, in the same file, and is **re-entrant** so it can be established at whichever boundary is available. Services call it — the same boundary `assertMembership` sits at — and React `cache()` dedupes repeated calls within one server-component render, so that is one short read-only transaction per distinct service call rather than per query. The GraphQL route establishes an outer one alongside the per-request DataLoaders (rule 9), and re-entrancy collapses the services' own calls into it, so a whole operation — every loader batch included — costs one `BEGIN` and one `set_config`. Unauthenticated and cacheable reads establish nothing: the compendium and categories are not workspace-scoped, carry no policies, and are `unstable_cache`d under rule 6, where an observer transaction would not belong anyway.

`withViewer` and `withAudit` never nest. A mutation writes inside `withAudit`, then resolves its response fields inside `withViewer` — sequentially, one connection at a time. That keeps rule 3 intact and avoids re-introducing the savepoint semantics `m1.9-test-db-isolation.md` rejected, where an outer transaction's `set_config` leaks one user's identity into the next assertion.

_Acceptance criteria (retired — not to be met):_

- `withViewer(session, fn)` opens a read-only transaction, publishes `app.current_user_id`, and runs `fn` inside an `AsyncLocalStorage` scope
- It is re-entrant: an ambient viewer transaction is reused, not nested
- `selectFrom` reads from the ambient transaction when there is one and the bare client otherwise; no finder signature and no call site changes
- `withAudit` throws if an observer store is ambient, and a test proves it
- A guard test modelled on `tests/guards/soft-delete-finder-guard.test.ts`
- `DEBUG_SQL=1` on one authenticated page load shows a single `BEGIN`/`set_config` per GraphQL operation, not one per query
- `npm run test:coverage` is green and behaviour is unchanged
- `claude-docs/db.md` documents `withViewer` alongside `withAudit`

**MB.27 — `vercel pull` ignores branch-scoped variables** · 1h

_Story:_ As a developer, I want a staging deploy to use staging's own database, so that it does not silently share or lose it to a hotfix preview branch.

Found while tracing how `DATABASE_URL` resolves per branch for MB.25. `deploy.yml` runs `vercel pull --yes --environment=<env>` with no `--git-branch`, and a push to `staging` resolves to `environment=preview`. Vercel only resolves branch-scoped variables when `--git-branch` is passed, so M1.1's `vercel env add DATABASE_URL preview staging` override is not reaching the build.

That override is the entire mechanism shielding `staging` from the Neon integration's automatic branch-per-preview-deployment. The M1.1 record states the failure directly — "if that override is ever removed, `staging` silently starts sharing (or losing) its database with the next hotfix branch's ephemeral one" — and as wired it was never applied in the first place.

Note that M1.1's premise is itself unverified, and says so. `vercel.json` has since set `deploymentEnabled: { "**": false }` and deploys now come from `vercel deploy --prebuilt` in CI, so whether the Neon integration fires at all for CLI-created deployments is open. Establish the live behaviour as part of this task rather than assuming either answer — and if the integration does not fire, say so in the record instead of leaving a rule that describes a mechanism that isn't running.

_Acceptance criteria:_

- `deploy.yml` passes `--git-branch` to `vercel pull`, resolving to the branch actually being deployed
- `migrate.yml` resolves `DATABASE_URL` the same way — M1.1's "Cross-task impact" requires the two to match
- Verified against the live project: a `staging` deploy uses the `staging` Neon branch, and a hotfix preview does not use `staging`'s
- `m1.1-neon-branch-strategy.md` gains a dated amendment recording what the live behaviour actually is
- `claude-docs/ci.md` records the `--git-branch` requirement so the next reader does not drop it again
- `npm run pre-commit` is green

**MB.28 — Record the ingredient identity model in the design docs** · 1h

_Story:_ As a developer, I want the ingredient identity model fully specified in the design docs before M4.1 writes the table, so that the `CREATE TABLE` is transcription, not design.

DESIGN.md §5 currently models an ingredient's identity as `lower(name)` alone, with `folkNames text[]` beside it. That cannot express three things the domain contains: common names are regional and ambiguous — "Cat's Claw" names four unrelated species and a literal cat's claw — a safety note attached to an ambiguous name is dangerous, and global `lower(name)` uniqueness forbids the compendium holding more than one of them at all. `MB` is the namespace for a missing dependency scheduled without renumbering an immutable ID; MB.16 ("Correct the Postgres version across the live docs") is the doc-only precedent. This is its own task, ahead of M4.1, because M4.1 is transcription of §5 and the DDL must be fully specified before it is written.

_Acceptance criteria:_

- DESIGN.md §5 gains `nomenclature`, `canonicalName` and the generated `canonicalKey`; `folkNames[]` moves to its own `ingredient_folk_names` table; `form` becomes free text backed by the new `ingredient_forms` vocabulary rather than an enum, and its SQL block carries three partial unique indexes rather than two
- DESIGN.md §7, §9 and §11 are amended per the identity-model plan, including the note that the M3.4 SDL snapshot moves
- DESIGN.md §14 gains its decision-log rows, and the SQLite array-column example is corrected from `folkNames` to `deities[]`/`substitutes[]`
- DESIGN.md §15 is adjudicated — reworded to distinguish identity from correspondence — rather than silently rewritten
- Both CLAUDE.md invariants are updated: keepers curate the form vocabulary too, and a new paragraph states the identity rule
- `claude-docs/db.md` carries the identity model
- `grep -n "catalog" claude-docs/DESIGN.md` still returns nothing
- TASKS.md and TASKS.csv carry every amendment this redesign requires, in the same pass

**MB.29 — Defer RLS to the public launch; make the second layer a `Membership` proof** · 2h

_Story:_ As a steward, I want the second authorization layer to cost nothing at runtime, so that workspace isolation is enforced twice without a second database role, a transaction on every read, and a credential-derivation scheme in every environment.

Documentation and scoping only, in the shape of MB.24 — which it supersedes. The mechanism it specifies lands in M6.3, its first caller.

MB.24 asked whether RLS was worth its cost, answered yes, and then found two defects that had been concealing each other. Its fix is four mechanisms: `sorrel_app` (MB.25), credentials derived by swapping user and password out of whatever `DATABASE_URL` the platform supplies, a startup catalogue assertion, and a re-entrant `withViewer` (MB.26) so a read has a transaction to be `LOCAL` to. The first three are one-off. The fourth is permanent: `BEGIN`, `set_config`, `SELECT`, `COMMIT` is four round trips where a read is one — roughly +10–15ms per `cache()`-deduped service call against Neon, and a pooled connection held for the length of every render. §4 already counts I/O wait as billable, so this is a cost in the meter as well as the latency.

**What replaces it is a type.** `assertMembership(session, workspaceId, minRole)` returns a branded `Membership` — `{ workspaceId, userId, role }` — that only the membership service can build, and every workspace-scoped finder and `AuditWriter` method takes it first and scopes itself from it, so skipping the check does not compile: impossible rather than absent, and free at runtime. DESIGN.md §8 now specifies it.

**Where it is weaker than RLS**, which §8 states: a hand-written `where` naming another workspace's ids passes the type, and `spell_ingredients` and `spell_categories` carry no `workspace_id`, so as scoped here their services load the parent spell under the proof first. Both are left to the direct-id denial tests CLAUDE.md's Testing section requires and M6.6 schedules.

**The GUC does not move.** `withAudit` keeps publishing `app.current_user_id` on every write, so RLS at the public launch (`TO_CLAUDE.md`'s "V Public") stays a single migration (§8). That was half of MB.24's argument for landing the GUC early, and that half is untouched. MB.24's analysis of `FORCE`, the role split, the `security definer` helper, the compendium's nullable `workspace_id` and the two join tables stands as the specification for when it lands; the record gets a status line, not a rewrite.

Retires MB.25, MB.26, M6.4 and M6.5 — ids kept, per the MB.19 precedent. Re-scopes M6.3 and M10.3.

_Acceptance criteria:_

- CLAUDE.md rule 3 covers `withAudit` alone; rule 5 states the service check plus the `Membership` proof, records the deferral, and drops the role-split paragraph
- CLAUDE.md's spell-visibility invariant no longer claims an RLS backstop, and its SQLite justification no longer cites RLS
- DESIGN.md §8 states the `Membership` design in place of the two-layer section, pointing at `mb.24-rls-role-split.md` as the specification for when RLS lands
- DESIGN.md §2, §4, §5, §11 and §14 corrected; §11's stubbed-`assertMembership` test becomes a `@ts-expect-error` compile assertion
- `mb.24-rls-role-split.md` carries a superseded-by line and is otherwise untouched
- `claude-docs/db.md` and `debugging.md` no longer describe a layer that does not exist
- M6.3 carries the proof and its `@ts-expect-error` test; M10.3 keeps the column and the service rule and loses its policy criteria; M0.13's story no longer cites RLS
- `withViewer`, `sorrel_app`, `DATABASE_APP_ROLE` and `FORCE ROW LEVEL SECURITY` appear nowhere outside the superseded record and struck task text
- The board agrees, and `npm run test:coverage` is green — no code changed

**MB.30 — Spike Better Auth's organization plugin for workspaces and invitations** · 2h

> **Merged — not adopted.** The six answers, with the code that produced each,
> are in [`mb.30-organization-plugin.md`](../design-decisions/mb.30-organization-plugin.md).
> No follow-up task was minted: M6.2 stands, and M6.3, M6.7 → M6.15 and
> M7.1 → M7.7 are unchanged. DESIGN.md §2's Auth row no longer names the
> plugin as the reason Better Auth was chosen, and §14 records the rejection.

_Story:_ As a developer, I want to know whether the plugin that justified choosing Better Auth can carry workspaces and invitations, so that M6 and M7 are not hand-built beside a library that already does it.

A spike: code on a throwaway branch to answer six questions, then deleted. What merges is a decision record and, if the answer is yes, one follow-up task.

DESIGN.md §2's Auth row says Better Auth was chosen because its "Organization plugin matches the workspace model". The plugin is installed and unused — M6.2 hand-rolled `workspaces` and `workspace_members` instead — and M6.7 through M7.7 are about to build the rest of it by hand. Nobody has checked whether the stated reason holds.

From the installed package it offers `allowUserToCreateOrganization` taking a predicate over the user (which is `canCreateWorkspace` verbatim), `creatorRole`, `invitationExpiresIn`, an **optional** `sendInvitationEmail` so copy-link works with no mail transport, `beforeCreateInvitation`/`afterAcceptInvitation` hooks, `YOU_CANNOT_LEAVE_THE_ORGANIZATION_AS_THE_ONLY_OWNER`, `YOU_ARE_NOT_ALLOWED_TO_INVITE_USER_WITH_THIS_ROLE`, and endpoints for create, list, invite, accept, cancel, remove-member, update-member-role and get-full-organization.

**Runs before M4.1** because `ingredients.workspaceId` is a foreign key: if the plugin's table becomes the workspace, every later FK targets it, and learning that after nine tables reference `workspaces` is a migration rather than a decision.

_Acceptance criteria:_

- `claude-docs/design-decisions/mb.30-organization-plugin.md` answers all six from running code, not from documentation: (1) does the plugin enforce slug uniqueness and format, and does `/coven/[slug]` resolve through `getFullOrganization`; (2) does the last-owner guard hold for `removeMember` and `updateMemberRole`, not only `leave`, since that is where story 11 lives; (3) does `beforeCreateInvitation` reject `owner` cleanly; (4) do the invitation states plus expiry give story 7 its three distinct reasons or collapse them into one; (5) can `setActiveOrganization` be ignored entirely, since §9 puts the workspace in the URL and not the session; (6) does `auth.api.*` work with a synthetic session inside the `db` project, where `asUser(A)` is a service-level session and the plugin's server API takes headers
- The record states the decision and what it rules out either way
- If adopted, a follow-up task is minted covering the M6.2 revert — staging-only, so a real DROP with the M1.5 acknowledgement line — and the re-scoping of M6.3, M6.7, M6.8, M6.9, M6.11, M6.14, M6.15 and M7.1 → M7.7. The cost is stated plainly: membership and invitation rows join the Better Auth tables that carry neither the audit spread nor soft delete, and the invitation id is stored as the plugin stores it, so CLAUDE.md's hash-only invariant becomes single-use, expiring and CSPRNG
- If not adopted, DESIGN.md §2's Auth row no longer claims the plugin as the reason
- The throwaway branch is deleted; no plugin wiring merges here

**MB.31 — Retire transcripts, the MW compression passes and `TASKS.csv`** · 1h

_Story:_ As a developer, I want the documentation obligations attached to every PR to be the ones that pay for themselves, so that a two-hour task does not carry an hour of bookkeeping.

Three obligations are retired, each because something already does its job:

- **The per-task transcript.** Four of them, 419 lines, feeding an archive of 55 files that `claude-docs/README.md` says never to read. A PR body carries the same narrative, is reviewed, and is searchable.
- **The scheduled compression pass.** MW.3 → MW.14, twelve hours. A sweep weeks later is a slow way to find the two statements a wave staled, and it defers the fix past the person who knows which one went wrong. The rule survives in CLAUDE.md; the schedule does not.
- **`TASKS.csv`.** 2,317 lines and 200 KB duplicating `TASKS.md`, hand-synced on every task that touches the breakdown, beside an Asana board CLAUDE.md already names as the source of truth.

The sizing rule relaxes in the same pass, for a related reason: "sized 1–2h" produced 17 process-only MB ids out of 28, several of them sub-hour fixes that should have been a line in another PR. MB.22 was already an explicit exception at 8h.

Kept deliberately: the subsystem summaries, one doc per component, decision records for contested choices, the doc-versus-code adjudication rule, and MW.15. The archive is frozen where it stands rather than deleted — MW.15 still owns retiring it.

_Acceptance criteria:_

- CLAUDE.md: the `TASKS.csv` parenthetical gone from the header and from the Asana section; the sizing convention relaxed with the sub-hour-fix rule; the transcript dropped from document-as-you-go; the compression-pass bullet replaced by correct-it-in-the-PR-that-stales-it, keeping the out-of-date test, the stand-on-its-own test and the doc-versus-code rule
- `claude-docs/README.md`: `TASKS.csv` row gone, transcripts and archive marked frozen, the compression-pass bullet replaced
- This file: the sizing standing rule added; MW.3 → MW.14 recorded as retired-not-done with ids kept, and off their wave rows — MW.1 and MW.2 stay on theirs, because they ran and that is true history; MB.29 → MB.34 in the header paragraph, the table and their own entries, placed in Wave 3 in dependency order
- `TASKS.csv` deleted. Historical task records that mention it — MB.16, MB.19, MB.24, MB.28 — keep their text: they describe what those tasks did, and rewriting them would be falsifying history rather than correcting a stale instruction
- Folded-in corrections, all sub-hour and all named in the PR body rather than given ids — the new sizing rule's first exercise: `README.md` and `Docker/Dockerfile.postgres` say PostgreSQL 18, finishing the sweep MB.16 left (the image has been `postgres:18` since a Dependabot bump); DESIGN.md §7's caching snippet is corrected for Next.js 16, where single-argument `revalidateTag` is deprecated and a type error and `updateTag` is unreachable behind a route handler; M8.7, which specified that now-uncompilable call, is corrected with it
- DESIGN.md §14 records the two proposals this review rejected, so neither is re-argued from scratch
- `npm run pre-commit` is green

**MB.32 — Collapse the five check workflows onto one matrix** · 2h

> **Merged, with one defect found later.** The collapse also deleted
> `pr-gate.yml`'s `destructive-ddl` job — not one of the five, and not
> replaced by a leg — so that check ran on nothing from 2026-09-17 until
> MB.37 folded it into this matrix. Two migrations landed ungated in between.
> Nothing in the diff looked wrong because the `changes` job kept computing
> its filters and `destructive-ddl.yml` kept existing; only the job that
> called it went. The criterion below saying `pr-gate.yml` calls `checks.yml`
> once was met, and was not sufficient.
>
> `checks.yml` is one matrix job — `checks / lint`,
> `checks / format`, `checks / typecheck`, `checks / build`,
> `checks / audit` — and `pr-gate.yml` calls it once. The summarising steps
> moved into `.github/scripts/` byte-for-byte, proven by running the old
> inline shell and the moved scripts against the same fixture logs and
> diffing their `$GITHUB_OUTPUT`; the audit comment was proven the same way
> against a stubbed API, clean, vulnerable and unparseable. Nine files went:
> five check workflows, `merge-queue.yml`, `composite-actions-check.yml` and
> both timer actions. `duration` was already optional on
> `job-summary`/`pr-comment`, so the seven workflows that had timers needed
> only their timer steps removed.
>
> **Branch protection was not touched, and the criterion below is corrected
> rather than met.** No ruleset requires any status check — the state
> `ci.md` recorded on 2026-09-10 and still true — so there was no stale
> required name to update, and enabling protection is deliberately not part
> of this task. `ci.md` records the five renamed contexts for whenever it is
> enabled.

_Story:_ As a developer, I want one workflow to describe how a check runs, so that changing how checks report is one edit rather than five.

`lint.yml`, `format.yml`, `typecheck.yml`, `build.yml` and `audit.yml` are one workflow written five times — 133 to 154 lines each, `build.yml` leaner at 92 because its summarising step is smaller: identical `image`/`pr-number`/`merge-queue`/`should-run` inputs, identical container and root-user options, identical timer, job-summary and pr-comment scaffolding. They differ in one npm script and one summarising step. MB.15 already deleted two workflows on this reasoning; this is the same observation one level up.

Three more go with them. `merge-queue.yml` re-expresses `pr-gate.yml`'s whole job graph for a merge queue that is not enabled — M7.A.1 is explicitly trigger-based and a prerequisite for nothing — so it is deleted and restored from git history when that trigger fires. `composite-actions-check.yml` is a workflow testing the composite actions that exist to de-duplicate the workflows. `timer-start`/`timer-elapsed` are 46 lines across 12 workflows to print an elapsed time into a summary.

**The path-filter flag is passed in, not an `if:` on the calling job.** `pr-gate` passes it from the paths-filter output instead of putting an `if:` on the job, because a false `if:` on the job that calls a reusable workflow makes GitHub report one bare check name in place of `checks / lint` (verified by MB.39: [`mb.39-job-level-if-and-check-names.md`](../design-decisions/mb.39-job-level-if-and-check-names.md)). MB.39 later split the matrix into plain jobs, each with its own `if: inputs.run-<leg>`, so a filtered-off leg is skipped before its container is pulled.

_Acceptance criteria:_

- `.github/workflows/checks.yml` runs lint, format, typecheck, build and audit as one matrix job, reporting as `checks / <name>`
- Each leg's summarising step moves verbatim into `.github/scripts/`, beside `summarize-vitest.mjs` — no change to what a PR comment says
- `build`'s extras are preserved: the `.next/cache` restore, `DATABASE_URL`/`BETTER_AUTH_SECRET`, `check:stories` and `workshop:build`
- The five check workflows, `merge-queue.yml`, `composite-actions-check.yml` and both timer actions are deleted; `duration` becomes optional on `job-summary`/`pr-comment` so the remaining callers need no other edit
- `pr-gate.yml` calls `checks.yml` once, and path filtering still skips work without leaving a required check unsatisfied
- The `act-*` targets collapse to one parameterised target
- `claude-docs/ci.md` describes the new shape and records that `merge-queue.yml` is restored from git history when M7.A.1 fires
- **Any branch protection naming the old check names is updated in the same session as the merge** — the old names will never report again, and a stale required check blocks every later PR. No ruleset requires a status check today, so there is nothing to update; `ci.md` carries the new names for whenever protection is turned on
- A deliberately broken check is confirmed to comment and then minimise on fix

**MB.33 — Ban runtime `drizzle-orm` outside the repository by lint** · 1h

_Story:_ As a developer, I want the query-builder boundary enforced by the linter rather than by a regex over `git ls-files`, so that it cannot be evaded by declaration style and does not go red on every legitimate addition.

M1.20's guard reads every tracked file as text and asserts no `.select(` appears outside `repository.ts`. It is evaded by writing `const findX = () =>` instead of `function findX()`; its global regex carries `lastIndex` between files inside a `.filter()`; its brace matcher breaks on a brace in a string; and it spawns `git` with a `safe.directory` workaround because CI runs the container as root over a uid-1000 checkout.

The mechanism that makes the same thing impossible is already in the toolchain. A Drizzle query cannot be built without importing `drizzle-orm` at runtime, so a `no-restricted-imports` rule with `allowTypeImports` bans the capability rather than the spelling. It also enforces §7's "the GraphQL layer imports `drizzle-orm` for types only", which has no guard at all today, and is the same mechanism M3.9 is already scheduled to add for the repository boundary.

Kept, because the tripwires are worth more than the brittleness: the pinned export list, the every-finder-filters assertion, the single-`selectFrom` assertion, the escape hatch standing alone, the exemption-set pin, and one positive check that the rule fires. `check:theme-default` is untouched.

**Verify, do not assume, that the rule can be scoped in an `overrides` block.** `db.md` records that oxlint 1.82 _ignores_ a rule set to `"off"` inside `overrides` — which is why the existing exemptions are inline comments — and the inverse has not been tested. If enabling there is ignored too, the fallback is a top-level rule plus a file-level disable header in the `src/db/**` files that legitimately import it.

_Acceptance criteria:_

- A runtime `drizzle-orm` import from `src/services`, `src/graphql`, `src/app`, `src/components`, `src/lib` or `e2e` fails `npm run lint`; `import type` from the same places passes
- `src/db/**`, `scripts/db-seed.ts` and `drizzle.config.ts` are unaffected
- `soft-delete-finder-guard.test.ts` no longer shells out to `git` and no longer walks every tracked file; its remaining assertions over `repository.ts` are unchanged
- `lint-db-client-boundary.test.ts` spawns oxlint once rather than per case, and asserts on rule code and diagnostic count rather than message text
- `npm run test:coverage` is green and the `unit` project is faster
- `claude-docs/db.md` describes both rules and what each makes impossible

**MB.34 — Hard-delete rows in the three join tables** · 2h

_Story:_ As a developer, I want a category chip toggled off to leave no row behind, so that the highest-churn tables in the schema do not fill with tombstones nobody will ever read.

**Lands immediately before M4.4**, the first of the three tables it governs. After M4.4, M10.2 and M10.4 ship, the same change is a contract migration with an M1.5 acknowledgement line instead of a one-line schema choice.

CLAUDE.md rule 3 spreads all six audit columns into every table, join tables included. This task carves out `ingredient_categories`, `spell_categories` and `spell_ingredients`: they keep the four stamp columns and are hard-deleted, so only `deleted_at`/`deleted_by` go, and with them the partial index. The deciding cost is the `deleted_at IS NULL` a service joining _through_ such a table must remember by hand, which rule 4 cannot enforce there; the full argument, and why `workspace_members` and `ingredient_folk_names` keep all six, is DESIGN.md §5 ("Why those three and only those three") and §14's "Soft-delete the join tables too?" row. MB.110 later returned `spell_ingredients` to soft delete, so those now name two; the current shape is [`db/hard-delete-join-tables.md`](../db/hard-delete-join-tables.md).

_Acceptance criteria:_

- `src/db/audit.ts` exports `auditStampColumns`; `auditColumns` is defined as that plus the two delete columns, so the six-column spread has one definition
- `AuditWriter` gains `delete(table, where)`, typed to reject any table carrying `deletedAt` **at compile time**; `softDelete` still requires one. The escape hatch is named and narrow, in the shape of `findManyIncludingSoftDeleted`, not a flag a later edit defaults wrongly
- `findMany`/`findOne` apply `deleted_at IS NULL` where the column exists and accept tables where it does not; no finder can skip it where it applies
- `repository.test.ts` proves both directions on scratch tables, including a `@ts-expect-error` line proving `write.delete` cannot be pointed at a soft-deletable table
- M4.4, M10.2 and M10.4 name `auditStampColumns` and the composite primary key rather than the six-column spread and a partial index
- DESIGN.md §5 and CLAUDE.md rules 3 and 4 state the exception and why; §14 records it
- `npm run test:coverage` is green

**MB.35 — Make category and form groups admin-curated data** · 2h

_Story:_ As a keeper, I want to add a category group myself, so that a vocabulary that grows past the eight seeded groups does not need a migration and a deploy.

Documentation and scoping only, in the shape of MB.28 — the precedent this follows exactly: the model is recorded in the design docs before the table task writes it, so the `CREATE TABLE` is transcription rather than design. Every mechanism lands in the tasks this one re-scopes.

DESIGN.md §5 and §6 modelled a category's `group` as a closed set of eight, fixed both by §6's table and by M0.7's eight `_variables.scss` colour tokens, and M4.2 transcribed it as a `category_group` pgEnum — right for a closed set, wrong once a keeper may add a ninth, since adding an enum value is DDL a keeper mutation cannot run (§14, "A category's `group` as a pgEnum?"). The same question applies to `ingredient_forms.group`, whose three values have already grown twice; M4.2a is the adjacent task, so both are settled here or they diverge within one wave.

Three decisions, each argued in its §14 row and specified in §5 and §6:

1. **Groups become rows, in two tables** — `category_groups` and `ingredient_form_groups`, global and keeper-curated, shaped like `categories` itself. Two tables rather than one with a `kind` column, so a category pointing at a form group is a foreign-key violation rather than a blank at render time. Neither carries an order column: groups list alphabetically by `name`, for the reason [`db/categories.md`](../db/categories.md) gives.
2. **Both `groupId`s are foreign keys, where `ingredients.form` stays text** — a vocabulary a member writes is text, one only a keeper writes is a foreign key. Stated in §5 in those terms, because it reads as an inconsistency next to the sentence directly above it.
3. **A group's colour is a pair of hexes on its row, one per theme**, each held to the contrast floor on its own theme's ground when written. M0.7's eight tokens become M4.3's seed values. The alternative, a runtime port of `category-group-color()` plus a contrast solver replacing its hand-tabulated per-theme trims, was rejected as more machinery than the feature earns; the cost, that a keeper's ninth colour is legible but outside the rotation, is stated in §6.

_Acceptance criteria:_

- DESIGN.md §5 gains both group tables; `categories.group` and `ingredient_forms.group` become `groupId` foreign keys, with the note on why an FK is right here and wrong for `ingredients.form`
- DESIGN.md §6 reframes the eight groups as the seeded starting set, carries each group's slug, states that groups list alphabetically, and says where a seeded colour pair comes from and what an added one does not inherit
- DESIGN.md §14 gains a row per decision above, and the superseded half of the "Admins curate a third resource?" row points forward rather than contradicting the new one
- DESIGN.md's route table gains `/admin/category-groups` and `/admin/form-groups`; §5's admin paragraph and CLAUDE.md's curation invariant both name the two group vocabularies, which M6.6 asserts
- TASKS.md amends M0.7, M4.2, M4.2a, M4.3, M5.6 and M8.11 in the same pass, and adds M5.6b and MB.36
- `claude-docs/db.md` carries the model, and its `ingredient_forms` line matches
- No code changes — documentation only, and `npm run pre-commit` stays green

**MB.36 — Chip colour from the row, not the token** · 2h

_Story:_ As a user, I want a chip for a group a keeper added after launch to look like every other chip, so that the taxonomy growing does not look like a bug.

Added by MB.35, and the code half of its third decision. M0.7's `semantic-tokens` mixin emits one `--group-<slug>` custom property per key of `$category-groups`, and `_primitives.scss` generates one `.chip--<slug>` class per key; both run at Sass compile time, so a group created at runtime has neither. `chip()` takes the colour pair rather than a slug, the per-slug class generation goes, and a chip carries both of its group's stored colours as inline custom properties, with the theme rule selecting one — the same per-theme switch `semantic-tokens` already does, moved from build time to the element.

Lands as early as the mechanism can be written and is adopted by each consumer in that consumer's own PR — the sweep-task rule's code half, not a retrofit. The mechanical guard is what stops the old shape coming back: nothing may reference `--group-<slug>` or `.chip--<slug>` once the colour lives on the row.

_Acceptance criteria:_

- `chip()` takes a dark and a light colour; `.chip--<slug>` class generation and the per-slug custom properties are gone, and a guard fails the build if either returns
- Both chip states keep the 1px edge, the padding and the 4.5:1 contrast behaviour M0.8 tuned — a chip wearing an arbitrary colour must still clear its own label
- The workshop story renders chips from a list of colour pairs rather than the eight slugs, and still covers both themes
- `$category-groups` survives in `_variables.scss` as the seed source M4.3 reads, with a comment saying that is now its only job

**MB.37 — Restore the destructive-DDL gate as a checks leg, scope the local run to the branch** · 2h

_Story:_ As a developer, I want the destructive-DDL check to run on the PRs it exists to gate, and a local run to tell me about my own branch, so that neither its silence nor its noise means nothing.

Minted on a report that the check "fires too much". It fired on everything locally and on nothing in CI, for two unrelated reasons, and the first hid the second.

**MB.32 deleted its calling job from `pr-gate.yml` and folded nothing in to replace it.** The `changes` job kept computing `destructive_ddl` and `destructive_ddl_migrations_files`, `destructive-ddl.yml` kept existing, and `ci.md` kept describing a check that ran on nothing — so every surface still said it was there. No PR from #104 onward has a `destructive-ddl` job; #106 and #107 each landed a migration through a gate that was not running. That is the whole argument for folding it into `checks.yml` rather than restoring the job: a leg of a matrix that five other checks depend on cannot be deleted without someone noticing.

**Locally it was permanently red, and correctly so, which is the worse failure.** With no arguments the script scanned every committed migration, and `0002_solid_marauders.sql` carries two `ADD COLUMN ... NOT NULL` with no default — a true finding, merged in PR #73 with no acknowledgement line ([`db/expand-contract.md`](../db/expand-contract.md)), since no ruleset requires the check. A gate that is always red is a gate nobody reads. The script's header already said it scans "only the ones new or changed _in this PR_"; the fallback simply did not do that. It now diffs the branch against its Gitflow base, untracked migrations included, so a task that has just run `db:generate` gets an answer about its own work. `--all` keeps the old behaviour for an audit, where staying red is the point.

Two defects found while reading the rules against CLAUDE.md rule 10, both fixed here rather than deferred, because the fix is one line each in the file already being rewritten (MB.31's sub-hour rule): the rule set knew `DROP COLUMN` and `DROP TABLE` where rule 10 says "DROP", so `0002`'s `DROP CONSTRAINT users_email_unique` passed; and every rule matched raw text, so `drop` inside a comment or a string literal fired. `DROP NOT NULL` and `DROP DEFAULT` are the two exceptions — they widen. `DROP INDEX` is deliberately **not** an exception, which is the one judgement call here: Drizzle rebuilds a changed index as a drop and a create, so an edited predicate now costs an acknowledgement line. Dropping a unique index gives up a guarantee, and saying which in one line is cheap.

CI was also being handed `migrations/meta/*.json` alongside the real migration — MB.4's defect, one layer further in. Fixed in both places: the paths filter narrows to `*.sql`, and the script ignores anything that is not, so no future caller can reintroduce it.

_Acceptance criteria:_

- `checks.yml` runs a `destructive-ddl` leg reporting as `checks / destructive-ddl`, taking `run-destructive-ddl`, `destructive-ddl-files` and `pr-body`; `destructive-ddl.yml` is deleted and `pr-gate.yml` passes all three through
- `DESTRUCTIVE_DDL_FILES` is always _set_ in CI, so an empty list scans nothing rather than falling back to the branch diff
- `npm run check:destructive-ddl` scans what the branch adds against its Gitflow base, committed and untracked; `--base` overrides it, `--all` restores the full scan, and an unresolvable base exits 2 rather than scanning everything
- Every `DROP` but `DROP NOT NULL` and `DROP DEFAULT` is flagged; comments and string literals are read as prose, not DDL; only `*.sql` is ever scanned
- `src/test/destructive-ddl-check.test.ts` covers the rules, the file-list resolution and the branch diff, and **each guard is demonstrated to fail without its mechanism** — not merely to pass with it
- `ci.md`, `db.md`, `CLAUDE.md` and the `Makefile` describe what the check now does, including that `make act-check CHECK=destructive-ddl` scans nothing locally, which the old `act-destructive-ddl` comment claimed otherwise
- Every test passes. **The usual "`npm run test:coverage` is green" is corrected rather than met**: the run has failed its 80% _function_ threshold at 79.59% since MB.32, on `src/app`'s three untested files, and PRs #104–#107 each merged with a red `vitest` leg. Untouched here — it predates this task and belongs to whichever one covers `src/app` — but named so the red leg on this PR is not mistaken for MB.37's
- Three sub-hour fixes found while reading this PR's own run ride along, named in the PR body per MB.31 and not minted as tasks: `checks / audit` now writes its report to the job summary as well as the PR comment (it wrote no summary at all since MB.32, so the audit was invisible on the run page); the build leg's Next.js cache, which had never saved once because the Alpine image's busybox `tar` rejects `--posix`, works now that the `testing` stage installs GNU `tar` and `zstd`; and every `runs-on` is pinned to `ubuntu-26.04` ahead of GitHub's 2026-10-19 move of `ubuntu-latest`, which had been annotating every job with a notice.

**MB.38 — Move the two workshop guards into Vitest** · 1h

_Story:_ As a developer, I want a mechanical guard to be an ordinary test, so that there is one place to look for "what does this repo enforce".

`scripts/check-workshop-theme-default.ts` says in its own header that it is a script rather than a test only because Vitest had not landed yet (M1.7). It has, in M1.7, and the repo's precedent for a mechanical guard is now a Vitest file in `src/test/` — `lint-db-client-boundary.test.ts` and `soft-delete-finder-guard.test.ts` both landed after it. The theme-default check also runs in pre-commit **only**, so CI has never enforced it.

Both guards move to `src/test/workshop-guards.test.ts` and both scripts go. `check:stories` stops riding on the `build` leg, since the `vitest` leg now covers it; `workshop:build` stays there, because catching a story that fails to bundle is a build-time thing and not something a test can assert.

**Pre-commit becomes lint, `format:check` and typecheck** — test-free, by decision. The alternative was running `vitest --project unit` in the hook (it needs no Postgres and takes about two seconds); a hook that runs tests is a hook people start skipping, and CI is where a gate belongs.

_Acceptance criteria:_

- `src/test/workshop-guards.test.ts` asserts every `src/components/<Name>/index.tsx` has a sibling `index.stories.tsx`, and that `.ladle/config.mjs`'s `addons.theme.defaultState` is `'dark'`
- The story guard is proven to bite on a fixture directory, not only to pass against a tree that already complies
- Both scripts and both npm scripts are gone; `pre-commit` is lint, `format:check`, typecheck; the `build` leg runs `npm run build && npm run workshop:build`
- `CLAUDE.md`, `README.md`, `workshop.md` and `ci.md` no longer name either script; M0.33/M0.35/M0.36 carry a superseded-by note rather than an edit
- Every test passes. **The usual "`npm run test:coverage` is green" is corrected rather than met**, exactly as MB.37's entry says: the run has failed its 80% _function_ threshold at 79.59% since MB.32, on `src/app`'s three untested files, which this task does not touch either — named so the red `vitest` leg on this PR is not mistaken for the moved guards failing

**MB.40 — Custom one-off spell ingredients (schema)** · 2h

_Story 57 — As a workspace member, I want to add a one-off ingredient to a spell by name and form, so that a spell can call for something I will never stock._

A custom ingredient is a layer in the jar that carries a free-text `name` and `form` instead of pointing at an `ingredients` row. It belongs to exactly one spell, shares that spell's visibility, never appears on the workspace's ingredients page, never enters local-beats-compendium suppression, and contributes nothing to derived categories. It is one-off, not reusable, since a workspace-local `ingredients` row is already the reusable kind (story 29's stub).

**The shape is columns on `spell_ingredients`, not a table of its own.** `ingredient_id` becomes nullable and keeps its foreign key; `name` and `form` are added, `form` free text and not a foreign key for the reason `ingredients.form` is not (§14); a `num_nonnulls` check makes a row exactly one kind or the other, a second keeps `form` off a linked row, and both text columns are checked non-blank, as DESIGN.md §5 now specifies. The primary key moves from `(spell_id, ingredient_id)` to `(spell_id, layer_order)` — not every row has the pair, every row has a layer, and that pair was already a unique index — so the old layer index is dropped as redundant and no surrogate id is added. One ingredient per jar, what the old key gave, becomes a partial unique index `WHERE ingredient_id IS NOT NULL`; one custom name per jar is its mirror on `(spell_id, lower(name)) WHERE ingredient_id IS NULL`, the shape of `ingredients_workspace_label_unique`. Still `auditStampColumns`, still hard-deleted (MB.34): derived categories join _through_ this table to `ingredient_categories`, which is exactly the case that rule protects.

**Why not a separate table.** A `spell_custom_ingredients` table would leave `(spell_id, layer_order)` uniqueness absent rather than impossible, since no constraint spans tables, and split every jar read, the reorder and the GraphQL type in two. Argued in full in [`mb.40-custom-spell-ingredients.md`](../design-decisions/mb.40-custom-spell-ingredients.md), "Why not the alternatives".

**Why now.** The table is inert until Wave 13, where a fast-follow would cost a ~3–5h retrofit across ten to twelve files and a breaking change to the SDL (the record's "Decided"). It sits after M1.22 and before M1.23, the first writer of the table.

**Scope is the table, not the behaviour.** Schema, migration, schema test, docs — and the acceptance criteria of every Wave 13 task the change reaches, corrected in this PR so each builds its branch when it lands (table-then-behaviour; adopted, not retrofitted). No service, resolver, Zod or UI.

_Acceptance criteria:_

- `src/db/spell-ingredients-schema.test.ts` is rewritten first and watched red against 0014 alone: the key is `(spell_id, layer_order)` and there is no surrogate id; `ingredient_id`, `name` and `form` are nullable; both-null and both-set are refused by `spell_ingredients_ingredient_or_name`; `form` on a linked row is refused by `spell_ingredients_form_only_on_custom` where the same `form` on a custom row is accepted; a blank `name` or `form` is refused by name; a custom row and a linked row share a jar; two custom rows with distinct names share a jar; the same custom name in another case in one jar is refused by the custom-name index and accepted in another spell; the same ingredient twice is refused by the partial index rather than the key; a layer collision is refused by the key rather than an index — linked against linked, custom against linked, custom against custom; the FK, unit-enum, no-layer, sweep and hard-delete cases are kept, plus a custom row deleted by its layer
- Migration `0017` applies on top of `0016`, expand before contract: the two columns, two partial unique indexes and four checks first; then `DROP CONSTRAINT` on the old key, the new key, `DROP NOT NULL` on `ingredient_id`, and `DROP INDEX` on the old layer index — the key before the `DROP NOT NULL`, since a key column cannot be made nullable
- `npm run check:destructive-ddl` reports exactly the `DROP CONSTRAINT` and the `DROP INDEX`, both in `0017` and nothing for `DROP NOT NULL`, and the PR body carries the acknowledgement line naming both and noting the table is empty and unqueried until Wave 13
- `set_updated_at` is still attached to `spell_ingredients`, and `updated-at-trigger.test.ts` needs no edit — it applies every migration and so proves `0017` applies on top of `0016`
- DESIGN.md §5 rewrites the `spell_ingredients` paragraph; §7 defines `SpellIngredient` for the first time, with a nullable `ingredient` and a non-null `name`; §10 adds story 57 and the count becomes 45 stories (1–34, 47–57), also in §11 and CLAUDE.md; §14 gains the row
- `claude-docs/design-decisions/mb.40-custom-spell-ingredients.md` argues the key move, why no surrogate id, why hard delete still holds, the rejected alternatives, and the rules Wave 13 inherits; `db.md` corrects the M10.2 bullet and the layer-order section and gains a custom-ingredients subsection linking it
- This file: MB.40 in the Wave 4 row; M10.2's key criterion corrected with a superseded-in-part note; the Wave 13 criteria corrected — M10.1, M10.5, M10.7, M10.9, M10.10, M10.15, M10.16, M10.18, M10.19 (a third, one-off state, neither held nor not held), M10.21, MB.6, MB.8, M11.13 — and M1.23 seeds one custom row
- `npm run test:coverage` and `npm run pre-commit` are green

**MB.41 — Move Vitest tests into `tests/`** · 3h

_Story:_ As a developer, I want the test suite in one directory of its own so that `src/` holds the application and nothing else.

All 39 Vitest files live under `src/`, beside the code they cover. Playwright already sits in a top-level `e2e/`, and DESIGN.md §on testing and M1.28 already specify `tests/acceptance/` as a top-level directory — so a `tests/` root makes the repo _more_ consistent with the design doc, not less.

**The layout mirrors `src/`.** `tests/{app,components,lib,db}/` take the path of the code under test; `tests/guards/` takes the five mechanical guards and `tests/support/` the harness (`as-user`, `db-setup`, `db-global-setup`, `worker-database`, `msw/`). `src/test/` is removed; `vitest.setup.ts` stays at the repo root, a config file beside `playwright.config.ts`. Mirroring rather than flattening keeps both things that were already path-decided working unchanged: the project split stays a directory glob (`tests/db/**` → `db`), and `tests/guards/` and `tests/support/` sit two levels deep exactly as `src/test/` did, so the guards' repo-root computation is untouched.

**A test names what it wants rather than how far away it is.** Imports of the code under test go through the `@/` alias tsconfig already declared and nothing used — `vitest.config.mts` gains `resolve: { tsconfigPaths: true }`, Vite's own resolver, which supersedes the `vite-tsconfig-paths` plugin and costs no dependency. Reads from disk go through a new `tests/support/paths.ts` (`REPO_ROOT`, `fromRoot`, `MIGRATIONS_DIR`); 25 files were counting `../` chains out of their own directory, which is what made this a 25-file edit rather than a `git mv`, and is the thing that stops it being one again.

**Four silent breakers, each closed explicitly.** None of them errors — they stop working quietly, which is why each is proved by breaking it rather than by inspection. `tsconfig`'s `include` is `./src/**/*`, so `tests/` must be added or the suite silently leaves `typecheck` — the state `e2e/` is already in — and the `@ts-expect-error` compile assertions stop asserting. `.oxlintrc.json`'s overrides are all `src/**`-scoped, both the `env` blocks and the `src/db/**` one that permits runtime `drizzle-orm`; without a `tests/db/**` entry every db test becomes a rule 4 violation, and with too broad an entry the whole suite quietly gains the exemption. `pr-gate.yml`'s `vitest` filter lists `src/**`, so a test-only PR would skip the job that runs tests. And `lint-db-client-boundary.test.ts` pins its exempt file by path literal and writes its probes _inside_ the directories it names, so both arrays have to gain the new tree.

**Scope is the move and what the move breaks.** No test's assertions change. The one behaviour added is the guard that keeps the rule true.

_Acceptance criteria:_

- No `*.test.ts`/`*.test.tsx` outside `tests/`, and no `src/test/`; every file moved with `git mv` so `git log --follow` still reaches its history
- `tests/guards/test-location.test.ts` scans the git index and fails on a test file outside `tests/` — a test rather than an Oxlint rule, since Oxlint has no custom-rule API and "this file is in the wrong directory" is a statement about the tree; it asserts its own preconditions (the scan is non-empty and finds itself), because an empty scan reports the same pass. The index rather than the working tree because CI runs in a container that still holds every file deleted since its image was built (`checkout-to-app` copies over a baked `/app` without deleting), so an untracked scan reports those as violations — this move's own 34 predecessors, on the first run
- `tests/support/paths.ts` is the only place a test computes a path out of its own directory
- `npm run test:coverage` green, both projects, thresholds unchanged — the coverage `include` still reads `src/`, so the numbers are the same numbers
- `npm run pre-commit` green, and each breaker proved closed by deliberately breaking it: a type error in a `tests/` file fails `typecheck`; a runtime `drizzle-orm` import fails `lint` from `tests/lib` and passes from `tests/db`; a test file in `src/` fails the location guard; `@/db/connection` is refused by the client ban, which is why the alias is added to `CLIENT_SPECIFIERS` rather than assumed to be covered
- `pr-gate.yml`'s `vitest` filter matches `tests/**`
- Ride-along named in the PR body (MB.31): `.oxlintrc.json` listed `vitest.config.ts`, but the file is `vitest.config.mts`
- CLAUDE.md's component convention and Testing section, DESIGN.md's "Component — Vitest + RTL, colocated" heading and its two component-folder listings, `testing.md`, `workshop.md`, `ci.md`, `db.md`, `auth.md`, `components/theme-toggle.md` and the live decision records corrected in this PR; `archive/` and `transcripts/` untouched, and migration `0016`'s comment left alone as committed history

**MB.42 — CI container jobs run against files the repo has deleted** · 1h

_Story:_ As a developer, I want a CI job to see exactly the code on my branch so that a check cannot pass or fail on a file the repo no longer has.

Every container job — `vitest`, `playwright`, and all six of `checks.yml`'s legs — runs against a working tree holding every file deleted from the repo since its image was last built. `Docker/Dockerfile.node` and `Docker/Dockerfile.e2e` both bake the whole repo into `/app` with `COPY . .`; `.github/actions/checkout-to-app` then lays the checkout over it with `cp -a`, which overlays but never deletes. A file the checkout no longer contains survives on disk, untracked and not ignored.

**Two corrections to the entry as minted.** `gitflow` was named as a fourth consuming workflow and is not one: it runs on a bare `ubuntu-26.04` runner with a plain `actions/checkout` and never touches `/app` — three workflows consume the action, not four. And `checks.yml` has six legs, not four. Neither changes the bug or the fix.

**Found by MB.41**, whose location guard failed on its first CI run reporting 34 test files outside `tests/` — every one that move's own predecessor at its pre-move path. The count is the tell: 34, not that branch's 39, because the image predates the five test files added since it was built. MB.41 scans the index instead, which is right for that guard on its own merits and leaves this untouched.

**Why it went unnoticed, and why it still matters.** Until MB.41 the repo mostly added files, so the overlay was harmless; and the checks that enumerate files read _contents_ rather than _locations_, where a stale duplicate says the same thing and passes — `slug-rule.test.ts` is the example. But `oxlint` and `tsc` both walk `src/**`, so a file deleted precisely because it was wrong is still linted and typechecked: a leg can fail on a reason absent from the diff, or pass because the copy left behind is the one that satisfies it.

**The fix is no source layer in either image, and a guard that keeps it out.** `Dockerfile.node` and `Dockerfile.e2e` copy in the two manifests, run `npm ci`, and stop, so a file the branch deleted has nothing to survive _as_. `checkout-to-app` stays checkout + `cp -a`. `tests/guards/image-source-layer.test.ts` holds both Dockerfiles' `COPY`/`ADD` sources to an allowlist, with `Docker/playwright-entrypoint.sh` copied alone for `Dockerfile.e2e`'s `headed` stage so a bare `docker run` of that stage still works. The shape, and why an allowlist, is [`ci/composite-actions.md`](../ci/composite-actions.md).

**The clean-step approach was built first on this PR and replaced.** PR #133's first commits cleaned up after the source layer instead — `git clean -fd` after the copy, a `safe.directory` line when that met "dubious ownership", a `checks / overlay` job with `make act-overlay` to prove it, and MB.44 minted to remove the coverage excludes after a release. It was reversed because the layer was **shadowed everywhere but CI**, so removing it makes stale files _impossible_ where the clean made them _absent_, and because a Dockerfile change is **live on its own PR** where an action edit waits for a release; "rebuild the image more often" was rejected too. The reversal is argued in [`design-decisions/mb.42-no-source-layer.md`](../design-decisions/mb.42-no-source-layer.md).

**The coverage excludes go here too.** `vitest.config.mts` excluded `src/**/*.test.{ts,tsx}` and `src/test/**`, paths MB.41 emptied and the overlay kept alive — `include` enumerates the disk rather than the repo, and CI's container held every test file the repo had deleted; dropping them took CI from 92% to 78.54% with every test passing. With the image carrying no source they match nothing, and removing them in this PR is the proof: the number does not move. What this does **not** change is the record's "What still stands": the three guards that run `git -c safe.directory=*` stay as they are, and only the action stops running git in `/app`.

_Acceptance criteria:_

- `tests/guards/image-source-layer.test.ts` red against the two Dockerfiles as they stood, green once each carries only the manifest COPY (plus the entrypoint script in `headed`) — the guard was written first and watched fail
- Both images carry the manifests and `node_modules` only; `Dockerfile.node`'s stage banner and `Dockerfile.e2e`'s comments say where source comes from instead
- `checkout-to-app` is `actions/checkout` and `cp -a`, nothing else — no clean step, no `safe.directory`; the `overlay` job, `make act-overlay` and `pr-gate.yml`'s mention of it are gone
- `node_modules` survives the copy — no job reinstalls dependencies, and job times do not regress
- `src/**/*.test.{ts,tsx}` and `src/test/**` removed from `vitest.config.mts`'s coverage `exclude` in this PR, thresholds unchanged, and the PR body names the reported number against the 92.03% it was before — the point is that it does not move. If it does, the entries were not dead: stop and report what is still on disk in the container rather than restoring them
- All three consuming workflows (`checks`, `vitest`, `playwright`) green on the rebuilt image, on this PR
- `ci.md`, `docker.md` and `testing.md` corrected — including `ci.md`'s own "every action is exercised by the checks that use it" claim, which is what let this go unguarded; the reversal recorded in a decision record so the asymmetry CLAUDE.md warns of does not exist

**MB.43 — Map service errors to GraphQL errors with field-level detail** · 2h

_Story:_ As a workspace member, I want a rule the form could not check to come back beside the field it is about, so that a refusal from the server is as readable as one from my own browser.

**The gap this closes.** M8.8 promises "validation errors return field-level detail" and no task ever says what that detail looks like. §7's mutations return bare entities, `src/lib/errors.ts` deliberately carries no GraphQL code — "the transport decides" — and M3.1 through M3.3 mount Yoga, build the schema and set the armor limits without ever building that transport mapping. So every readable message the services are asked for (M5.2's colliding entry, M5.6/M5.6a's slug, M5.6b's column and ratio, M10.3's explaining refusal) has nowhere to go and no field to land beside, and M5.9's "errors appear beside the offending field" can only mean the resolver's own errors.

Three pieces, specified by §7's Errors subsection:

- **`ValidationError` in `src/lib/errors.ts`**, beside `Forbidden` and `NotFound`, carrying `issues: { path: (string | number)[]; message: string }[]`. **Zod-free** — it carries issues, it does not produce them, so `src/lib/` gains no dependency and a seed or a script can throw one. The Zod adapter that builds the issues list from a `ZodError` is M4.5's, in `src/lib/validation.ts` — not in any one module, since every module's schemas raise the same shape, and importing Zod for types only.
- **The mapping**, in M3.1's route, through Yoga's `maskedErrors.maskError`. Masking stays **on**: the three types leave with `extensions.code` — `VALIDATION` (plus `extensions.fieldErrors`), `FORBIDDEN`, `NOT_FOUND` — and anything else leaves masked, message and stack discarded. The service's message text is passed through verbatim; rewriting it at the transport is what turns M5.6b's ratio back into "Invalid input".
- **`mockGraphQLError(operationName, { code, fieldErrors?, message? })`** in `tests/support/msw/graphql.ts`, beside the two existing helpers, which can only answer `{ data }` today. Without it no component test can arrange a server-returned field error, which is the half of M5.9 and M10.12 that nothing currently tests.

**Why here in the order.** It is Wave 7's last GraphQL task because M3.1 must exist to hold the mapping — and it must precede Wave 8, since M5.9 is the first task that renders a server error and M8.8 the first that raises one. Landing it after either is a retrofit of both.

_Acceptance criteria:_

- `ValidationError` is distinguishable from `Forbidden` and `NotFound` by type, carries its issues, and imports nothing from Zod — asserted in `tests/lib/errors.test.ts` alongside the existing two
- A resolver throwing each of the three answers with that type's `extensions.code`; a `ValidationError` answers with `fieldErrors` matching its issues one for one, paths preserved, message verbatim
- A resolver throwing a plain `Error` answers masked — no message, no stack, no constraint name
- The refusal is still an error response: `data` is null and the operation did not write
- `mockGraphQLError` produces the shape the route itself produces — asserted against the mapping's own output, not against a hand-written fixture that can drift from it
- `auth.md`'s errors section documents all three types and names this mapping; `errors.ts`'s header comment keeps "neither type carries a status code or a GraphQL error code" and says where the code is attached instead

**MB.44 — ~~Release to `main`, then drop the coverage excludes MB.42 made dead~~** · **RETIRED 2026-09-19, not done**

> **Retired without being done (MB.42's rework).** ID kept; removed from the
> Asana board. It was minted on MB.42's first shape — a `git clean` step in
> `checkout-to-app`, which every caller resolves at `@main`, so the two
> coverage excludes the fix made dead could only go once a release had carried
> it there. The reworked MB.42 removes the source layer from the images
> instead, and `pr-gate.yml` builds the image content-addressed per PR, so the
> fix is live on the PR that makes it and nothing waits on a release. The
> excludes went in MB.42's own PR, with the unchanged number as the proof.
>
> **What survives it.** A release is still worth cutting on its own terms —
> everything that has accumulated on `staging` protects nothing until it is
> on `main` — via `/create-release`, as a release rather than as this task.

**MB.45 — `vercel pull --git-branch` is rejected on the production target** · 1h

_Story:_ As a maintainer, I want a push to `main` to reach production so that a merged release actually ships.

Every push to `main` fails at `vercel pull` with ``Invalid request: `target` must be "preview" when specifying a `gitBranch` ``. Branch-scoped environment variables are a Preview-only Vercel feature, and MB.27 added `--git-branch="$GIT_BRANCH"` to both workflows unconditionally while `resolve-target` emits `git_branch=main` for the production arm. v0.2.0 merged and was tagged but never deployed: `migrate` dies at the pull, and `deploy` is gated behind it, so production still serves v0.1.1 — stale rather than broken, since code and schema still agree.

MB.27's own commit recorded two acceptance criteria as open, both needing live Vercel access. This is one of them, found the only way it could be.

**Two steps, not one command with an optional flag.** Each workflow pulls through a preview arm and a production arm, selected by a YAML `if:` on the resolved environment. The condition is then data `tests/guards/vercel-pull-git-branch.test.ts` already parses, each arm spells its `--environment` literally so an invocation can be classified, and the run's step list shows which fired. `== 'preview'` rather than `!= 'production'`, so a third environment skips both arms and fails at `migrate.yml`'s existing named error rather than silently pulling the wrong one.

Two shapes were rejected. Making `git-branch` optional and gating on emptiness reintroduces exactly what MB.27 fixed — a caller that forgets it gets the environment-wide value and nothing fails. Computing a `--git-branch=…` string in `resolve-target` and interpolating it would mean the flag never appears as literal text on any line the guard's `INVOCATION` regex matches, so the sweep goes blind on the half that can only be made absent.

_Acceptance criteria:_

- The guard rewritten rather than deleted, written first and watched fail — six of its seven sweep assertions red against the workflows as they stood
- New assertion: a pull naming `--environment=production` carries no `--git-branch`, with the Vercel error quoted in the comment so nobody re-adds it
- New assertion: each arm's `if:` names the same target its command does — what makes the pairing structural rather than two `run:` lines that happen to agree
- MB.27's assertions kept, narrowed to preview; the sweep precondition becomes two pulls per workflow
- The honest limit stated in the test header: a YAML `if:` is still text to this test, so it proves the conditions are complementary and paired, not that GitHub evaluates them as written
- `ci.md`, `secrets.md` and `m1.1-neon-branch-strategy.md` corrected, the last superseded in place
- **Not done when CI is green.** MB.27 shipped green and broke production; the criterion is a live deploy on `main`

**MB.46 — CI cannot see what `vercel pull` actually returned** · 2h

_Story:_ As a maintainer, I want CI to state what the pull returned and refuse what it cannot use, so that a bad environment fails by name instead of inside someone else's stack trace.

Re-scoped mid-task. It began as "CI accepts a placeholder as a database connection string" — `migrate.yml`'s load step guarded `[ -z "$db_url" ]` and nothing else, so Vercel's `[SENSITIVE]` placeholder, a quote the `sed` failed to strip, or a `psql '…'` wrapper pasted from the Neon console all reached drizzle-kit, which died on `new URL()`. **MB.45's own PR showed the defect is wider than `DATABASE_URL`**: `migrate` passed on a hotfix preview while `deploy` failed on the same pull at `vercel build` with `BETTER_AUTH_SECRET is not set` — and the last staging deploy before MB.27 added `--git-branch` had that secret, and even warned it was low-entropy.

**The common defect is that nothing between the pull and its consumer could say what the pull returned.** `migrate.yml` masked the value before anything could print it; `deploy.yml` never read the file at all. That is why MB.27 dropping variables took a production outage to surface: one job said `ERR_INVALID_URL` with its input shown as `***`, the other said a secret was unset, and neither said which variables had survived.

So `scripts/assert-pulled-env.ts` does two things, and the second is the one worth having. It **asserts** the keys a job needs, each failing with its own named cause. It **reports** every key the pull returned — classification and length, never a value — and prints that report even when the run is about to fail.

A script rather than shell, because this repo tests scripts and cannot test a `run:` block. Its input is a **file path**, never argv and never an env var carrying the value: argv is visible to `ps` and echoed by `set -x`. Because it reads the file itself and provably never prints a value, it is safe to run **before** the mask exists — which is a stronger guarantee than the sequencing this task was originally specified with, and replaces it.

_Acceptance criteria:_

- Tests written before the script and watched fail — 38 of 40 green on the first run of the implementation, the two red ones being the workflow sweep, which the wiring then satisfied
- A case per rule, plus green cases for a Neon pooled URL, the local compose URL, and a `%`-escaped password
- **No value ever printed**, asserted rather than intended: every failure message and every report line checked against a realistic secret, including the cases where the rejected value is a real connection string wearing a wrapper
- A placeholder's message says a Sensitive Vercel variable is unreadable _by design_ and that a retry will not fix it — it is not a flake
- Every failure collected rather than stopping at the first, so one run names every unusable key
- `deploy.yml` requires `BETTER_AUTH_SECRET` as well, because `vercel build` runs `next build` with `NODE_ENV=production` and traces `/api/auth/[...all]` → `src/lib/auth.ts` → `src/db/connection.ts` — `auth.ts` throws on an unset secret and `connection.ts` calls `postgres()` at module scope, which parses eagerly
- A directory sweep ties the assertion to the pull rather than to these two workflows, so the next pull added without one fails in the diff that adds it

Stacked on MB.45. Its PR targets `main` and `staging` and carries MB.45's commit until that merges — deliberate, because a PR based on the MB.45 branch would not trigger `deploy.yml`, which only runs on PRs into `main`, and the preview deploy is the run this task exists to read.

**MB.47 — CI cannot read the Sensitive Vercel variables it needs** · 2h

_Story:_ As a maintainer, I want CI to hold the two values Vercel will not give it, so that a migration and a build can run without turning off a security setting.

`DATABASE_URL` and `BETTER_AUTH_SECRET` are marked Sensitive in Vercel. A Sensitive variable cannot be read back by `vercel pull` — that is what the setting means, not a fault to route around. The pull writes the literal string `[SENSITIVE]`, which is non-empty and so passes any check that only asks whether something is set; that is how it reached drizzle-kit and produced an `ERR_INVALID_URL` with its own input masked out of the stack trace, and how it reached `vercel build` and produced `BETTER_AUTH_SECRET is not set`.

**A diagnostic branch settled it.** Using MB.46's reporter, it pulled staging's preview environment both with and without `--git-branch` in one run: `DATABASE_URL` came back as `[SENSITIVE]` either way, and the flag changed only which _other_ keys resolved. That also answered two things the plan had wrong. `--git-branch` must stay — the two GitHub OAuth secrets exist only as `staging`-branch-scoped rows and vanish from an unscoped pull — so MB.45's two-arm split stands. And an earlier reading of this bug had blamed Sensitive, then withdrawn it because the "3 Secret values" count did not change between a passing and a failing run. That reasoning was wrong: the count describes whichever set that pull resolved, and the two modes resolve different sets.

**CI keeps its own copy of exactly the two values it cannot read.** `DATABASE_URL_PRODUCTION` and `DATABASE_URL_STAGING`, because it differs per target; `BETTER_AUTH_SECRET`, one value for both. The runtime is untouched — a deployed function reads its environment from the platform, not from the pulled file — so the Sensitive flag stays on and only CI changes.

**Named secrets rather than GitHub Environments.** The environment version was built first and reverted: it needed a new `workflow_call` input, a new `resolve-target` output and an `environment:` key on two jobs, to express what a secret's name already says. The three GitHub Environments that exist stay Vercel's.

`deploy.yml` writes the values **into the pulled dotfile** rather than exporting them, since the file is what reaches the Next build. The hotfix-preview arm has no named secret — its Neon branch is created per deployment — so it falls back to the pulled `POSTGRES_URL`, which the integration provides and which is _not_ Sensitive.

_Acceptance criteria:_

- Guard written first and watched fail, asserting the selection rather than the values: production chosen by the Vercel environment and not the branch name, staging by the branch, the fallback present, a named error when every source is empty, and the mask before the export
- The two workflows assert to select **identically** — M1.1's "Cross-task impact" in mechanical form, since choosing differently migrates one database and serves another
- The override runs after the pull and before both the build and MB.46's assertion, so the assertion checks the file the build will actually read
- `secrets.md` rewritten: its claim that "no separate GitHub Actions copy of `DATABASE_URL` is needed" is what this task disproves, and the two-places rotation cost is written in as a rule rather than hoped away
- `secrets.md`'s `BETTER_AUTH_SECRET` row corrected — it specified a separate Preview value, and one shared value is now a deliberate decision with its reasoning recorded, plus the known low-entropy value as an explicit pre-launch item
- **Not done when CI is green.** The criterion is a live `staging` push that migrates against the staging database, and a `main` push that reaches production

_Deferred, recorded so it is not re-derived:_ pulling connection strings from Neon directly (`GET /projects/{id}/connection_uri?branch_id=…`) would put the credential in exactly one place and cover ephemeral branches too, retiring both `DATABASE_URL_*` secrets. The keys exist since MB.12, but it would put the snapshot key on every deploy's path, a broader credential than one connection string, and would not replace `BETTER_AUTH_SECRET` regardless.

**MB.48 — A destructive-DDL acknowledgement does not survive the release PR** · 3h

_Story:_ As a reviewer, I want a destructive migration to carry its own acknowledgement so that the gate still works at the release, not only at the PR that wrote it.

Release 0.2.0's PR failed `checks / destructive-ddl` and was merged past it. `resolveDefaultBase()` maps `release/*` to `origin/main`, so a release PR rescans every migration since the last release — 17 files, 5 destructive statements in `0002` and `0017`. The acknowledgement lives only in a PR body. #126 acknowledged `0017`; #73 never acknowledged `0002`, having merged before MB.37 restored the gate. So "carry the acknowledgement forward from the staging PR" could not have worked: one of the two never existed.

**Not urgent, and the entry should say why.** With the release merged, both migrations are in `origin/main` and the next release will not rescan them — the instance is self-resolving. What remains is the class: the next destructive migration hits the same wall at the next release, and at every `main-sync/*` PR carrying a hotfix migration.

**The acknowledgement moves beside the migration**, as `src/db/migrations/<tag>.ack.md`. A PR body is the wrong home for a fact about a file: visible from one branch base, gone on merge. The scanner's pathspec is already `*.sql`, so sidecars are never scanned; and because `ACK_LINE_RE` anchors at line start, a Markdown sidecar matches it unchanged where an in-`.sql` comment would not. Findings group by file, so an acknowledgement covers exactly the migration it was written for — strictly stronger than today, where one line blesses every finding in the diff, which is precisely how a release carrying acknowledged `0017` and unacknowledged `0002` would have passed on `0017`'s line alone.

**The PR-body path is retired, not OR-ed.** An `OR` keeps the uncorrelated hole open, and with two migrations carrying findings there is nothing to migrate. The check then depends on GitHub not at all, so `make act-check CHECK=destructive-ddl` finally proves the scan rather than the wiring, and `--all` becomes a usable audit instead of permanently red.

_Acceptance criteria:_

- Per-file correlation cases written first and watched fail: two files with one acknowledged exits 1; sidecar absent; sidecar present with an empty reason; a sidecar for another migration does not cover this one
- Both sidecars written — `0017` ports #126's wording, `0002` is new and says it was written retroactively and why
- `npm run check:destructive-ddl -- --all` green with both, red again when one is deleted — the proof the sidecar is load-bearing rather than decorative
- CLAUDE.md rule 10 and `ci.md` updated; `db.md`'s claim that `0002` "was acknowledged when [it] landed" corrected — #73 carries no acknowledgement and never did, so the **doc** is what is wrong
- Sized at 3h rather than split for the sake of the number, per CLAUDE.md

**MB.49 — `drizzle-kit` fails silently, so a bad `DATABASE_URL` has no cause** · 1h

_Story:_ As whoever is on the end of a failed deploy, I want a failed migration to name what went wrong so that I can fix it instead of guessing at it.

Staging's migration failed after MB.45–47 and the log said this, in full:

```
Using 'postgres' driver for database querying
[⣟] applying migrations...

**MB.50 — Make code comments concise; move the arguments into `claude-docs/`** · 6h

_Story:_ As someone reading this code, I want a comment to tell me what the code is and why it is not the obvious alternative, so that I can follow a file without a board or a decision-record index open.

Comments are 28% of the lines in scope — 7,905 of 27,847 across 203 tracked files, which is two thirds the volume of `claude-docs/` itself and much of it paraphrase of the docs it already cites. Two problems, and they are not the same problem. **Verbosity:** eight paragraphs are duplicated near-verbatim across 3–16 files each, the M1.27 template boilerplate alone running ~120 lines across 16 db test files. **Task-reference clutter:** board identifiers and scheduling narrative — `The table is inert at Wave 3. Nothing queries it until M10.5's service and M10.9's queries land in Wave 13` — are threaded through nearly every schema, seed and test file, and mean nothing to a human reading the code.

**The rule is a division of labour, not a length limit**: the comment keeps the conclusion and `claude-docs/` the argument, as [`README.md`](../README.md)'s "Comments in code" now states it. It inverts nothing there: a summary still gives its reason in a clause and stands on its own. CLAUDE.md had **no rule about comments at all**, which is why the prose grew — so the convention lands first, and the sweep cites it.

**What brevity may not cost** is that section's list, kept whatever its length; in this sweep it also covers oxlint's `overrides` replacing rather than merging, a false job-level `if:` on a calling job reporting a bare check name, the Ladle `@type` JSDoc and shebangs.

**The dangling citations are the finding, and there are fourteen.** Scoping expected four; the guard found `.ladle/` citing m0.30, m0.32 and m0.34 as well, plus `tests/app/api/auth/[...all]/route.test.ts` citing `claude-docs/transcripts/auth.md`, which has never existed — so a hand-verification of the real OAuth URL shape is described as "recorded" nowhere. Thirteen of the fourteen resolve only under `claude-docs/archive/`, and were cited **without** the `archive/` prefix: the path was wrong and the destination is out of bounds, README.md having declared the archive never-read. Those comments are long precisely because the live doc was never written, so the prose moves into `styling.md`, `workshop.md` and `testing.md` and the citations are repointed.

**A guard on citation, deliberately none on density.** `tests/guards/doc-citation.test.ts` fails a `claude-docs/` path that does not resolve, points into `archive/`, wraps across two comment lines, or names a section heading that was never written. Density cannot be guarded without penalising exactly the comments the rule protects, so it stays prose enforced in review — a conscious deviation from the sweep-task rule's "mechanism plus a mechanical guard" default, recorded here rather than left to be noticed. The guard also makes MW.15's `grep -r 'claude-docs/archive'` criterion continuous instead of a one-time check at close-out.

_Acceptance criteria:_

- The guard is written first and watched fail — it finds all fourteen dangling citations and all four wrapped ones before anything is fixed
- CLAUDE.md carries the comment convention; `claude-docs/README.md` carries the code-vs-doc division of labour and says prose leaving a comment lands in a live summary, never in `archive/`
- The eight duplicated paragraphs collapse to one pointer each
- Task-reference narrative gone; a task ID survives only as provenance for a constraint that would otherwise look arbitrary
- Prose relocated per subsystem, **doc section written first and trim second in the same commit**, so no intermediate commit has lost the reasoning
- Coverage summary **counts** identical before and after — 185/201 statements, 49/52 branches, 73/83 functions, 183/199 lines. Comments are not executable, so any drift means non-comment code moved
- `make help` renders the full target list; `workshop:build`, `test:stories` and `check:destructive-ddl` green
- Out of scope, and the PR says so: `src/db/migrations/*.sql` (drizzle hashes migration file content, so editing one to fix a comment is not the harmless change it looks like), `claude-docs/archive/**`, and any non-comment code change

**MB.51 — Deduplicate the db-test harness, seed logic and image-build workflows** · 6h

_Story:_ As someone maintaining this repo, I want the scaffolding that every schema test, seed scenario and image-build workflow repeats to exist once, so that adding a table, a vocabulary or an image means writing what is new about it and nothing else.

Measured before scoping, so the work goes where the duplication actually is — the request was a repo-wide DRY pass on the impression that `src/` was bloated, and the measurement said otherwise. `src/` is 4,893 lines of which 1,799 are comments (MB.50's subject) and ~1,686 are seed reference data; the ~1,100 lines of application logic left are already factored — one `selectFrom`, one `auditColumns` definition, `slugify` as the package, no hand-rolled date, merge, chunk or case helper anywhere. Nor is the schema's declarative repetition a target: the uuid-PK block, the `deleted_at IS NULL` predicate and the FK triples repeat because drizzle-kit reads them literally, and a helper would hide the table's shape from the one reader that needs it. The repetition is in three other places. **Tests:** `tests/db/*-schema.test.ts` is 12 files and 4,839 lines, and 1,211 of its 2,546 substantive lines are shared with another schema test — `failureOf` byte-identical in 11 files, `columnNames` in 9, the `AUDIT_COLUMNS` array in 8, the connect/teardown pair in 10; `spell-categories-schema` and `ingredient-categories-schema` are one file with one word swapped. **Seeds:** `categories.ts` and `forms.ts` carry the same four functions with tables swapped, differing by one Prettier line-wrap; the insert-what-is-missing idiom is hand-written 13 times and the transaction preamble five. **CI:** the image-build step sequence appears three times and the Vercel secrets guard three times differing in one word.

**The harness lives under `tests/db/support/`, not `tests/support/`.** `tests/support/` may not import `drizzle-orm` at runtime — `tests/guards/lint-db-client-boundary.test.ts` probes exactly that — and `getTableConfig` is what the shared lookups are built on. The new directory joins the guard's `EXEMPT` probe list rather than the ban being loosened. The connection helper binds into each file's existing `let sql` from inside its own `beforeAll`, so no call site changes and no proxy object is introduced; it is per-file because `db-setup.ts` re-clones the worker database `WITH (FORCE)` before every file, which kills any longer-lived connection.

**The audit-column assertions become one sweep, not a shared helper.** Eight files repeat "spreads the shared audit columns" and ten repeat "references users.id from every audit id"; each reads Drizzle metadata only. A `describeAuditedTable(spells)` one-liner could be deleted in review without anything looking wrong, and shared functions would leave eight copies of one claim that still miss the next table. `tests/db/audit-columns.test.ts` holds the twelve audited and three join tables as transcribed object lists, asserts both the Drizzle and the catalogue side per table, and is added first, proven to fail three ways, and only then are the copies deleted — a deleted `it()` whose claim the sweep does not make is this task's failure mode.

**Seed helpers stay under `src/db/seed/`** because that directory is coverage-excluded; a helper anywhere else under `src/` would owe its own 80% and turn a tidy-up into a test-writing task. `insertMissing` takes the caller's own existence query on purpose — the call sites scope by `inArray`, by workspace, by `isNull(workspace_id)` and by a case-folded name, and each honours or ignores `deleted_at` on its own terms. The data literals do not move.

**One PR, by explicit decision.** The rule is one task per PR; this bundles three areas because the user chose it after the conflict was raised, in the shape MB.22 records. It is based on MB.50's branch rather than on `staging` because MB.50 rewrote the comments in every file it touches.

_Acceptance criteria:_

- The audit-columns sweep lands before any per-file copy is deleted, and its three deliberate-breakage runs — the spread removed from a schema file, `deleted_at` added to a join table, an unaudited table added to the audited list — are recorded red in the PR body
- Every deleted per-file `it()` has its claim traced to a sweep assertion, `deleted_by` undefined on the join tables in particular
- `AUDIT_COLUMNS` in the harness is a literal list, never derived from `src/db/audit.ts`
- `tests/db/seed/*.test.ts` pass unmodified across the seed refactor
- Each image-build workflow's buildx cache key is byte-identical before and after
- The hoisted or added checkout that lets the guard become a composite action is the one behaviour change, kept in its own commit
- `vercel pull` steps untouched; `vercel-pull-git-branch.test.ts` and `doc-citation.test.ts` green
- `testing.md`, `db.md` and `ci.md` corrected in the same PR; the job-level container and service repetition recorded in `ci.md` as inexpressible rather than left to be re-proposed
- `npm run test:coverage` green with the threshold unmoved — neither scope can move it, so a change means something else broke

**MB.52 — Admin user list page** · 2h

_Story:_ As a site keeper, I want a list of everyone who has signed in, so that I can act on a person without being sent their id.

**Nothing tasks this page and two tasks already assume it.** M5.8's "users awaiting approval are findable" is written as a criterion of the approval control rather than of a surface that exists, and MB.53 needs somewhere to pick an impersonation target. `/admin/users` joins `/admin/compendium`, `/admin/categories`, `/admin/forms`, `/admin/planets` and `/admin/zodiac-signs` in M5.4's nav, which gains a sixth entry here.

**It is a read, so M5.7's sweep does not reach it.** That task gates every keeper _mutation_ at the service and again at the Pothos layer; a list query is neither, so this page carries its own service-level admin assertion and its own non-keeper rejection test. The list is not a fifth admin capability either — CLAUDE.md's invariant says a keeper curates the compendium, the categories and the two vocabularies "and nothing else", which governs what a keeper may _change_. Reading who has an account is what the role already implies, and the page offers no control over any workspace.

**Not Better Auth's `listUsers`.** The `admin` plugin ships one, and reaching for it would put a database read outside `src/db/repository.ts` and a browser-initiated read outside `/api/graphql` — rules 2 and 1 in one call. The list is an ordinary service plus an ordinary GraphQL query, paginated through M3.6's cursor helper like every other list (rule 8). `User.email` is behind a Pothos auth scope; this page is the first consumer that legitimately passes it, so the scope is exercised here for the first time rather than worked around.

_Acceptance criteria:_

- `/admin/users` lists name, email, role, `canCreateWorkspace`, created-at, the providers linked to the account and whether the email is verified, server-rendered through a service, sorted stably. The provider and verified columns are what a keeper granting admin (MB.59) is asked to judge by
- The list paginates through the M3.6 helper — default 25, no offset in the cursor — and is not fetched unbounded
- Filter by name or email substring, and a filter for `canCreateWorkspace = false`, which is the curation to-do list M5.8 acts on
- Soft-deleted users do not appear, and the finder does not filter at the call site (rule 4)
- A non-keeper is refused at the service, by direct query and not merely by the page being unreachable; the test asserts why the read could have succeeded — the users exist, the fixture is populated, and the same call as E returns them
- `User.email` resolves through its existing auth scope rather than a second path around it
- M5.4's nav and layout list `/admin/users` beside the admin resources
- `auth.md` documents the page and states that it confers no workspace access

**MB.53 — Impersonate a user outside production** · 3h

_Story:_ As a site keeper, I want to sign in as a specific user in local, hotfix preview and staging, so that I can reproduce what they are seeing instead of guessing at it from their description.

Better Auth's `admin` plugin already carries this — `impersonateUser`, `stopImpersonating`, and a `session.impersonated_by` column to hang them on — so the work is the gate, the column, the audit question and the way back out, not the mechanism.

**`NODE_ENV` is the wrong signal, and using it would fail silently.** `next build` and `next start` always run at `NODE_ENV=production` (`auth.md`, "Config"), so every Vercel build is production by that measure — staging and the hotfix previews included. A `NODE_ENV !== 'production'` gate would therefore switch impersonation off in two of the three environments this task exists to serve, and on in none of them that matter. The gate reads the deploy target instead: `VERCEL_ENV`, which is `production` only on the `main` deploy, `preview` for staging and every `hotfix-<slug>` alias, and unset locally.

**Two conditions, both required, defaulting to off.** The plugin is registered only when `ENABLE_IMPERSONATION` is explicitly set _and_ `VERCEL_ENV !== 'production'` — the belt-and-braces shape rule 5 and M5.7 already use, for the same reason: one mis-scoped Vercel variable should not be the whole defence. Unset means the plugin is never constructed, so `/api/auth/admin/*` is absent rather than refusing — impossible over forbidden, which is the sweep-task rule's own test.

**It is not a third access path.** Impersonation swaps the session cookie, which a GraphQL mutation cannot do cleanly, and it lands under `/api/auth/*` — the one exception rule 1 already names. Worth stating because it looks like a new one: nothing else moves off GraphQL, and the user list it is driven from is MB.52's ordinary query.

**The audit stamps the impersonated user, and says so twice.** `created_by`/`updated_by` record whoever the session is acting as — stamping the admin instead would mean impersonation no longer reproduces what the user would see, which is the whole point. So that the acting keeper is not lost with the session row, `withAudit` publishes `app.impersonated_by` beside `app.current_user_id`, from the session and never a request body, through the same `set_config(..., true)`. Like that GUC, it has no reader in v1 and is published anyway, for rule 3's reason (`.claude/rules/database.md`).

**The way out cannot live in the admin nav.** Impersonating a non-keeper costs the admin `/admin` for the duration — correct, and precisely why a persistent banner naming the impersonated user and carrying Stop belongs outside it, on every page.

**Two things to answer from running code rather than from the plugin's documentation**, in MB.30's idiom: whether the plugin's `role` handling accepts the existing `user_role` pgEnum unmapped, since its default values and ours are both `user` and `admin`; and whether its ban endpoints can be left unregistered. v1 has no ban story, so the three ban columns the plugin's schema expects are not added — if they cannot be declined, they land nullable and the migration says in its own comment that nothing in v1 reads them.

**Impersonation is the only thing the plugin may expose.** Registering it also mounts `set-role`, `update-user`, `remove-user`, `create-user`, `set-user-password`, `list-users`, `get-user`, the session listing and revoking endpoints, and `has-permission`. On staging and previews, `set-role` would be a second way to grant admin: it writes through the adapter, outside `withAudit`, M2.9's ledger and the bootstrap admin's protection, and `remove-user` could hard-delete the primary keeper ([`design-decisions/m2.9-granting-admin.md`](../design-decisions/m2.9-granting-admin.md)). So only `impersonate-user` and `stop-impersonating` stay reachable. The test checks what is mounted against those two by name, rather than checking a list of blocked paths, so an upgrade that adds an endpoint fails the test instead of going through unnoticed. `allowImpersonatingAdmins` stays at its default, off, so a keeper cannot take on another keeper's session, the primary admin's included.

_Acceptance criteria:_

- Migration adds `sessions.impersonated_by uuid references users.id`, nullable and additive — no acknowledgement sidecar, since nothing is dropped or narrowed. `sessions` carries neither the audit spread nor `set_updated_at`, so `updated-at-trigger.test.ts` is unchanged, and the schema test asserts the column and its FK
- The gate is asserted in all four combinations: flag set with `VERCEL_ENV` unset and `preview` register the plugin; flag set with `VERCEL_ENV=production`, and the flag unset at any target, do not — and in the negative cases the endpoint is **absent**, not merely refusing
- A non-keeper cannot impersonate even where the plugin is registered, asserted against the endpoint itself rather than the missing UI
- A keeper impersonating B sees what B sees: B's workspaces, B's grimoire, and no `/admin`
- A write made while impersonating B stamps B in `created_by`/`updated_by`, and `app.impersonated_by` carries the admin — asserted inside the transaction, since the GUC is transaction-local
- Stop returns the admin to their own session with `impersonated_by` cleared, and is reachable from every page, `/admin` included
- The banner names the impersonated user and is present on every page while a session carries `impersonated_by`
- Ban endpoints are not reachable; if the plugin cannot decline them, the reason is recorded and the unused columns are named as unused
- Of the plugin's `/api/auth/admin/*` endpoints, only `impersonate-user` and `stop-impersonating` are reachable. The test compares the mounted set against that allowlist, so an endpoint a Better Auth upgrade adds fails it. `set-role` answering is asserted absent in particular, since it would grant admin outside `withAudit` and M2.9's ledger
- Impersonating a user who is a keeper is refused, asserted against the endpoint
- `secrets.md` gains the `ENABLE_IMPERSONATION` row for all three environments and states it must never be set on Production; `auth.md` gains an impersonation section covering the gate, the audit semantics and the way out; DESIGN.md §14 records the decision, `NODE_ENV` included as the rejected signal

**MB.54 — Set the account's email: prefilled from the provider, editable, verified before it counts** · 3h

_Stories 58 and 59 — As a new user, I want the email the site knows me by to be prefilled from my provider but mine to change, and to prove it's mine before it counts, so that a provider that shares no address, or the wrong one, is not a dead end._

Minted during M2.6 as "collect an email address when a provider returns none": Discord returns an email only for an account with a verified one, Facebook can withhold it under the permissions granted, and the callback then fails as `?error=email_not_found`, a readable but dead-end sentence in `src/lib/sign-in.ts`. **Re-scoped by M2.9 to follow MB.61's follow-ups, and by MB.61 to a page rather than an interstitial** ([`design-decisions/mb.61-email-verification-and-delivery.md`](../design-decisions/mb.61-email-verification-and-delivery.md)). An unverified account has a session and is provisional (MB.66, MB.67), so there is no pending identity to hold across a round trip: the account exists, and `/account/email`, protected, is where its address is set. It shows the provider's address if there is one and whether it is verified, lets the user change it through a `setEmail` mutation to a service under `withAudit`, and resends the verification mail through Better Auth's server API; the address counts only once MB.66's verification confirms it, from a session holding that row. A provider that returns no address no longer dead-ends: `mapProfileToUser` yields the placeholder `<providerAccountId>@pending.invalid`, which can never be mailed or matched, so the row and session exist and the page asks. The same page, reached from the account later, is how a user changes their email (story 59), which is why there is no separate change-email task: Better Auth's `changeEmail` stays pinned off (MB.60) and this page replaces it.

**Moved from Wave 6 to the end of Wave 7, after MB.43**, when starting it found the mutation had nowhere to go: `setEmail(email): User!` needs M3.1's `/api/graphql` and M3.10's `User` type, and rule 1 rules out a server action or a route of our own in their place. Building the service and the page first would have left a no-email user on a form that cannot submit, which is the dead end this task exists to remove.

Two criteria from the earlier draft go. "The bootstrap address is refused outright" is unnecessary, since typing it is harmless: verifying it is the promotion (MB.68), and only its owner's inbox can. "No partial `users` row survives an abandoned interstitial" is MB.67's sweep, which clears every provisional row the same way.

**Corrected while building, in MB.54's own PR:** the criterion that a change "marks the row unverified" would have put an established account under MB.67's sweep — unverified and older than the three-hour cap, it is hard-deleted on the next OAuth callback by anyone or, its audit foreign keys being `NO ACTION`, fails the whole sweep statement from then on. So a change writes nothing to `users.email`. The service mints Better Auth's own change token (`updateTo`, `requestType: change-email-verification`), mails the new address, and `/verify-email` swaps the address and verifies it in one write from a session holding the row — gated by a `hooks.before`, since Better Auth's change branch calls no `beforeEmailVerification` and mints a session for an opener with none. A provisional caller's window is still restarted first, so the link cannot outlive the row. Every unverified sign-in lands on `/account/email` with its address prefilled, not only one with no address, and the placeholder is `<providerId>-<providerAccountId>@pending.invalid`. The "resend through Better Auth's server API" in the description holds for the row's own unverified address only. The approved plan is [`design-decisions/mb.54-plan.md`](../design-decisions/mb.54-plan.md).

_Acceptance criteria:_

- A provider callback with no email lands on `/account/email` with an empty field instead of the dead-end error, and the `email_not_found` mapping in `src/lib/sign-in.ts` goes; one with an unverified email lands there too, prefilled and editable, and a verified one lands where it asked
- Asking for a new address writes nothing to `users.email` and leaves a verified row verified: the new address is mailed a change link, and the row carries it, verified, only once that link is followed from a session holding the row — asserted by reading `email` and `emailVerified` before and after, and by the sweep leaving an established account alone; a provisional caller's window is restarted through `withAudit` first
- An address already held by a live verified account is refused with a message, asserted with the other account present; one held by a provisional account is not, since that row will lapse
- The placeholder address is never mailed and never matches an invitation, asserted
- One verification mail a minute per account, whichever path would send it: `users.verification_sent_at` is stamped by every mail sent for the row's own account and cleared by the write that verifies it, `setEmail` refuses the next within the minute with a field error naming the wait, and Better Auth's resend endpoint sends nothing inside it; asserted through the service and through the endpoint. The form starts its countdown from the seconds the page reports and counts its own sends down too
- `/send-verification-email` answers 401 to anyone but the session holding the address, asserted from no session and from another account's
- An unverified account reaches no page but `/account/email`: `requireSession()` sends it there from any other page with that page's path as `next`, asserted in `tests/lib/request-session.test.ts`
- A followed link lands on the page's confirmed view (`?verified`): the address and Continue, no field; a verified account that comes back sees the field alone. A link opened from a signed-out browser goes to `/sign-in` with a sentence saying to sign in and open it again, and nothing from the link in the URL
- The form uses no native validation: an empty or malformed field is the server's refusal, shown beside the input like every other
- A signed-in user can reach the same page to change their email, with the same rules
- Covered by a component test with role and label queries, and stories 58 and 59's flows pass in `tests/e2e/stories/08-email-and-admin.spec.ts` (M9.1 moved it from `tests/acceptance/`)

**MB.55 — Scan both provider availability states in the e2e accessibility run** · 2h

_Story:_ As a developer, I want the e2e accessibility scan to cover a sign-in page whose providers _are_ configured, so that a brand-coloured button's contrast is checked by CI rather than by whoever happens to have credentials in `.env.local`.

`playwright.yml` sets `BETTER_AUTH_SECRET` and nothing else, so `configuredProviders()` returns empty and every provider button renders greyed — which drops the brand-colour class entirely (`SignInPanel/index.tsx`'s `className` comment). The brand-coloured state, which is the only state a real user sees, is therefore never scanned: `sign-in.spec.ts`'s two axe tests pass in CI because the colours under test are not on the page.

Found during MB.12, when registering the four OAuth applications put real client ids in a local `.env.local` and the same suite immediately failed on white-on-`#1877f2` at 4.23:1 — a genuine WCAG AA violation CI had passed three times. This task is the reason it was invisible, and it also carries the fix: #156 merged before the colour change could ride along in it.

The trap is that simply adding placeholder credentials inverts the gap rather than closing it: the greyed state has its own accessibility surface — `aria-disabled` keeping a button in the tab order, the `.sign-in-panel__note` text, and Facebook's transparent-chip wrinkle — and that is what the existing keyboard test's rationale rests on. Both states need covering, so the page has to be reachable in each within one run. Placeholder ids must also never reach a real authorization endpoint: nothing may click a provider button in the configured state.

It carries one more M2.6 leftover. The error-state test's bare `getByRole('alert')` matches two elements — the panel's own error and the empty `role="alert"` route announcer Next portals into `<body>` on every page — and fails Playwright's strict mode. #156 merged with that leg red, since no ruleset requires a status check (MB.39), and every PR since has been path-filtered out of the leg, so it is red on `staging` without showing it.

_Acceptance criteria:_

- An axe scan runs against the sign-in page with all four providers configured, and against it with none configured
- The brand-coloured resting **and** hover states are what the configured scan sees, not the greyed fallback
- No test clicks a provider button while placeholder credentials are set
- The greyed state keeps its existing keyboard and `aria-disabled` coverage
- The Facebook button is `#0866ff` (4.82:1) at rest and `#0653d4` on hover, and the error-state test's alert query is scoped to the page's own `main`
- A contrast regression on any brand button fails CI — demonstrated by reverting `#0866ff` to `#1877f2` and watching it fail
- `claude-docs/components/sign-in-panel.md` records which state each scan covers

**MB.56 — Rebuild the Asana board mechanism for the free Personal plan** · 6h

_Story:_ As someone running this board, I want task lookup and status to keep working on Asana's free Personal plan, so that the branch and PR skills do not break with the downgrade.

The workspace dropped to the free Personal plan, which puts custom fields and advanced search behind the paywall. `Status`, `Task ID` and `Type` are still present and still visible in the web UI, frozen at their last values, but the API no longer returns them at all — `opt_fields=custom_fields` comes back with neither the key nor an error — and `asana_search_tasks` returns `payment_required`. All four Asana-touching skills used that search to find a task by id and the `Status` field to record progress, so every one of them broke at once. Nothing was deleted and nothing here can delete them: the MCP server exposes no field-management tool, so the fields stay visible and stale until the plan changes back.

**Status moves into the task name.** A marker prefixes it: `▶ ` for `In Progress`, `◔ ` for `In Review`, nothing for `Not Started`, and the completed checkbox — which survived the downgrade — still carries `Completed`. Tags remain free on this plan but the MCP server exposes no tag tool, so they cannot be set programmatically; sections were rejected because the board already spends them on `Waves`, `Bugfixes` and `Pre-Wave Complete`, and the task notes were rejected because a board card does not show them, which is the whole point of an at-a-glance status.

**Lookup replaces search with the wave notes.** A wave card's notes already open with the ids it contains, so `asana_get_tasks` over the project finds the wave and one `asana_get_task` on it finds the subtask — two calls, deterministic, and more reliable than the fuzzy text search it replaces. It holds only under exact id-segment matching: thirty of the board's ids are a strict prefix of another (`M2.1` and `M2.10`, `M4.1` and `M4.1a`, `M0.1` and `M0.30`), so a `startsWith` test silently picks the wrong task. A CSV export taken before the downgrade confirmed all 266 ids already begin their task's name, with no duplicates — so the convention was already true and only needed writing down.

**`Type` is gone and is deliberately not replaced by an id rule.** All four historical `Hotfix` tasks were `MB.*`, and `MB.*` covers ordinary bugfixes too, so the prefix cannot decide it. `start-task` routes on what the task itself says and asks when that is ambiguous, rather than inferring a base branch and being wrong about it after there are commits on one.

**The fields could not be removed, so the project was replaced.** A downgraded project keeps whatever custom fields it had, and a free plan cannot shed them: `POST /projects/:gid/removeCustomFieldSetting` answers `402 custom_fields_premium_only`, `GET /projects/:gid/custom_field_settings` answers `402 Custom Field Settings are not available for free users`, and the web UI routes the same click to an upgrade page. Neither the MCP server nor a personal access token changes that — it is the plan, not the credential. So the board was rebuilt into a new project, which on a free plan starts with no fields and cannot be given any: 290 tasks with their names, notes, completion state, section and subtask nesting, plus all 395 comments. The original is archived rather than deleted, which keeps every pre-rebuild task permalink resolving — an older PR body's Asana link still lands somewhere real.

**What the rebuild costs, stated here rather than discovered later.** Task GIDs change, so `CLAUDE.md` and the four skills are repointed in this task. `created_at` and `completed_at` reset to the rebuild date on every task. A story's timestamp cannot be set through the API, so each migrated comment opens with `[YYYY-MM-DD HH:MM UTC]` and its own metadata reads as the rebuild date — on anything older than the rebuild, the bracket is the true date. Asana's own system stories (`changed Status from …`, `added to project`) are not recreated; they narrated the fields that caused this.

_Acceptance criteria:_

- No skill calls `asana_search_tasks` or writes a `custom_fields` value
- `start-task`, `create-feature`, `create-hotfix` and `create-pr` each find a task by id through the two-call lookup
- A status transition rewrites only the marker, never the id or title
- `CLAUDE.md`'s Asana section documents the markers, the lookup and the board's three sections
- The board's in-flight tasks carry the marker matching their real state
- The project carries no custom fields, and the pre-rebuild project is archived rather than deleted
- Task count, completion count, subtask nesting and comment count each match the source board exactly

**MB.57 — Build the public entry page at `/`** · 2h

_Story:_ As a visitor who is not signed in, I want `/` to tell me what Sorrel & Salt is and how to get in, so that the front door is neither a bare sign-in form nor an empty splash.

Minted during M2.7. Route protection first treated `/` as DESIGN.md §9 does — the post-sign-in landing — and redirected a signed-out visitor to `/sign-in`. It was then directed to leave `/` public as the site's general entry page, so M2.7 lists `/` in the proxy's `PUBLIC_ROUTES` (`tests/proxy.test.ts` pins it) and `/` is still the static splash it has been since M0. This task builds the page that stands there.

The design question is the one M2.7 left open: §9 also makes `/` the post-sign-in landing, where M2.8 puts its three states — into the workspace, the create form, or the invite-only explanation. Either `/` renders the entry content signed out and M2.8's states signed in, reading the session with `getSession()` (never `requireSession()`, which would make it protected again), or the post-sign-in landing moves to its own route and `/sign-in`'s default `next` moves with it. Decide which, and correct §9, M2.8's entry and story 2's acceptance test (which reads `src/app/page.tsx`) to match in this task's PR.

_Acceptance criteria:_

- `/` renders for a signed-out visitor without a redirect, says what the site is, and says plainly that it is invite-only
- It offers a clear way to `/sign-in`
- A signed-in visitor is not asked to sign in again
- `/` stays in `PUBLIC_ROUTES`, and reads the session (if at all) with `getSession()`
- Where the post-sign-in landing lives is decided and recorded: DESIGN.md §9's `/` row, M2.8's entry and story 2's test agree with it
- Component test with role and label queries only; axe scan passes

**Decided:** the landing moves to `/coven` and `/` stays the front door ([`design-decisions/mb.57-post-sign-in-landing.md`](../design-decisions/mb.57-post-sign-in-landing.md)).

**MB.58 — The admin role ledger (schema)** · 1h

_Story:_ As a site keeper, I want every change to who is a keeper recorded where a later edit cannot overwrite it, so that "who made this person an admin" still has an answer after their row has changed again.

_Superseded 2026-10-10: folded into MB.194's `user_privilege_changes`, which copied its rows and which a trigger on `users` fills (MB.195); MB.196 and MB.197 retire the table ([`design-decisions/mb.194-privilege-ledger-by-trigger.md`](../design-decisions/mb.194-privilege-ledger-by-trigger.md))._

M2.9's table half ([`design-decisions/m2.9-granting-admin.md`](../design-decisions/m2.9-granting-admin.md)). `users.updated_by` is overwritten by the next update to the row, and M5.8's approval control is the first one, so a grant's provenance would last only until then. The ledger is one table recording one privilege. It is not the v2 edit history.

`admin_role_changes`: `id`, `userId` → `users.id`, `change` (`bootstrap` | `grant` | `revoke`, a pgEnum because the set is closed), `note` (nullable text), plus the full `...auditColumns` spread like every non-join table. `created_by` is the actor and `created_at` is when. Nothing in v1 updates or deletes a row. The repository exposes no update or delete for the table, because `sorrel` owns its tables and a `REVOKE` would not bind it. The migration backfills a `bootstrap` row for every existing live keeper, stamped as that keeper, so the ledger has no gap at its start.

**Rider: the seed's bootstrap user is demoted to `role: 'user'`.** Every seed needs a creator row, since every `created_by` is `NOT NULL` and references `users.id`, so the row stays. But nothing needs it to be an admin: it has no OAuth account, it is unverified, so Better Auth refuses to link anything to it, and nobody can sign in as it. As a keeper it would be a revocable row on `/admin/users` and a backfilled ledger row for an account no one can use. `minimal` becomes one system user and one user; its test and the three docs that say "one admin" change with it.

_Acceptance criteria:_

- Migration creates the table, its enum and its `CREATE OR REPLACE TRIGGER` line for `set_updated_at`, so `updated-at-trigger.test.ts` stays green without an edit
- Every existing live keeper has exactly one `bootstrap` row after migration, asserted against the seeded template's keepers
- The schema test asserts the columns, the enum values and the foreign key
- The repository offers an insert and a read for the table and nothing that updates or deletes it, asserted at the type level
- The seed's bootstrap user has `role: 'user'` in every scenario, a test asserts no OAuth sign-in can reach it, and `minimal`'s test and docs say one system user and one user
- Additive only, so no acknowledgement sidecar

**MB.59 — Grant and revoke admin** · 3h

_Story:_ As a site keeper, I want to make another user a keeper, or stop one being one, from the user list, so that promoting a second keeper does not mean editing an environment variable and redeploying.

This is the behaviour half of M2.9. It builds on MB.58's table and MB.60's primary keeper, and adds a control to MB.52's `/admin/users` next to the one M5.8 puts on the same row. The decision, and the approaches it rejected, are in [`design-decisions/m2.9-granting-admin.md`](../design-decisions/m2.9-granting-admin.md).

A `setUserRole` service sits behind an admin-only GraphQL mutation and writes through `withAudit`, declaring `{ via: 'admin', note }`, `note` being the optional reason the confirmation offers. It writes no ledger row itself: the trigger on `users` records the change in `user_privilege_changes` in the same transaction (corrected 2026-10-10 by MB.195; [`design-decisions/mb.194-privilege-ledger-by-trigger.md`](../design-decisions/mb.194-privilege-ledger-by-trigger.md)). Any keeper may grant admin to any live user, verified or not, and confirming who they are from MB.52's list is the granting admin's job; a grant also sets `canCreateWorkspace`, as MB.177's CHECK requires of every keeper, and a revoke leaves it. A grant that turns the flag on is therefore recorded as two rows, `admin` and `create_workspace`, at one instant by one actor (amended by M5.8, [`design-decisions/m5.8-revoking-workspace-creation.md`](../design-decisions/m5.8-revoking-workspace-creation.md), and by MB.195). Any keeper may revoke any other keeper, themselves included, **except the primary keeper** — the live keeper whose email matches `ADMIN_BOOTSTRAP_EMAIL` when the check runs — whom no one can revoke. **A count guards the gap** a change of the variable opens: the service also refuses any revoke that would leave zero live keepers, counting under a `for update` lock on the live keeper rows. MB.60's sign-in promotion and MB.68's verification promotion already make the same write with the user's own session, declared `bootstrap` (MB.195), and the `standard` seed's fixture E is recorded the same way. Reading the ledger, story 61, is MB.199's and MB.200's. Why each rule is what it is: the record's "The primary keeper", "Granting" and "Revoking".

_Acceptance criteria:_

- A keeper can grant admin to a user and revoke it from `/admin/users`, with a confirmation that names the user. Granting does not require the grantee's email to be verified. When it is unverified, the confirmation says so in plain words, and that granting keeps the account rather than letting it lapse (MB.204); the keeper may still grant (amended by MB.205)
- Each change is recorded as one `user_privilege_changes` row, `via` `admin`, naming the subject, the direction, the actor (taken from the session), the time and the confirmation's optional reason as `note`; the service writes no ledger row itself, and the same write without its declaration is refused by the trigger. A request body cannot set the actor (corrected by MB.195)
- A grant to a user without `canCreateWorkspace` is recorded as two rows at one instant, `admin` and `create_workspace`, both `via` `admin`, and a grant to one who holds it as the `admin` row alone (amended by M5.8 and MB.195)
- Granting admin to someone who is already a keeper, or revoking it from someone who isn't, is refused with a message and writes no ledger row, because no column changed
- Revoking the primary keeper is refused for every caller, the primary keeper included, with an explaining `Forbidden` in plain language that names no variable. The test asserts the target is a live keeper who could otherwise have been revoked
- Revoking the last live keeper is refused with an explaining `Forbidden`, asserted with the primary keeper absent from the fixture so the count is what refuses. Two concurrent transactions revoking the only two keepers leave exactly one, asserted with real concurrent transactions
- The primary keeper's row carries a "Primary admin" label. Its revoke control stays visible but `aria-disabled`, with the same plain-language reason beside it, and activating it states the reason rather than doing nothing
- After `ADMIN_BOOTSTRAP_EMAIL` changes, the previous primary keeper is still a keeper and can now be revoked like any other
- A revoked admin's next request is refused at `/admin` and at every keeper mutation, with no new session issued. A test pins that `session.cookieCache` is off, since enabling it would reopen that window; it sits in `tests/lib/auth.test.ts`'s "session lifetimes" block beside MB.76's pins
- Granting sets `canCreateWorkspace` to `true` and is audited as such; revoking leaves it, workspace memberships, and the `created_by` of everything the admin wrote untouched
- A non-keeper cannot reach the control or the mutation. The test asserts why the call could have succeeded (the ledger read is MB.199's, corrected by MB.195)
- Story 60's acceptance test passes; story 61's is MB.200's (corrected by MB.195, which built the primary keeper's and the seed's `bootstrap` rows this criterion once asked for)
- The mutation carries M5.7's Pothos admin scope as well as the service check
- `auth.md` documents granting, revoking, the primary keeper's protection, the count fallback, how to change the primary keeper (set the variable, redeploy, then a Google or Discord sign-in, or a verification by mail, by the new address) and the ledger. It also records that any future user-deletion path must refuse the primary keeper

**MB.60 — Promote the primary admin at sign-in, from Google or Discord only** · 2h

_Story:_ As the site owner, I want only someone who has proved they own `ADMIN_BOOTSTRAP_EMAIL` to be made admin by it, so that an unverified sign-up cannot claim admin before I sign in.

M2.9 found the defect ([`design-decisions/m2.9-granting-admin.md`](../design-decisions/m2.9-granting-admin.md)). Today `src/lib/auth.ts`'s sign-up hook promotes whichever new user carries the address, whether or not the provider verified it, and it runs at account creation only, so the variable can name one keeper ever. Both are open until the owner has an account, and a database reset opens them again. They go live when MB.12 sets the variable in a deployed environment, so this task lands before MB.12.

**Only Google and Discord qualify**: Facebook never reports an address verified, and Microsoft is excluded on purpose, since its `common` tenant lets an attacker's own Entra tenant assert any email. The record's "The primary keeper" gives each provider's case. MB.61's first-party verification is what would let the other providers in.

**Promotion moves from account creation to sign-in, and writes through `withAudit`.** It runs in Better Auth's after-callback hook, at one comparison per sign-in and no query, and decides on the provider's fresh profile at the callback, never the stored `users.emailVerified`. The hook builds an ordinary `Session` for the now-authenticated user and calls the role service (a stub until MB.59) inside `withAudit`, stamped as the user, so the create-time promotion goes and rule 3 keeps two identity bootstraps. Promoting at sign-in is what makes changing the variable work: the new address is promoted at its next qualifying sign-in even if the account already exists, and the previous primary keeper keeps `role: 'admin'`, no longer protected (MB.59). A non-qualifying match signs in as an ordinary user, and the reason is logged against the user id, never the address. The record argues the hook, the fresh profile and the silent log ("The primary keeper").

_As built:_ the after hook's `newSession.user` is the stored row, so the fresh profile reaches it from `user.validateUserInfo`, the one hook Better Auth calls with it, through a per-request `defineRequestState` store — still no query ([`auth.md`](../auth.md), "Promotion at sign-in"). The write needed a ninth `AuditWriter` method, `updateById`, since a service cannot build `id = $1`. "At most one live row" is a `users_email_lower_case` check constraint (migration 0019). Wiring the service surfaced a latent bug, fixed in the same PR: `repository.ts` entered the `audit.ts` ↔ `schema/users.ts` cycle from the wrong side, so a repository-first import built `users` without its audit columns ([`db.md`](../db.md), "The seed module").

**The squat is left open until MB.61's follow-ups, deliberately.** Refusing an unverified account that holds the address, and mapping the `account_not_linked` code, were both in this task's first draft and move to those follow-ups, since first-party verification lands before launch and settles squatting for every address; MB.54's typed-address form now follows it. The hole that stays until then is the record's "What is simplified, and the hole it leaves"; pre-launch the site has no users who could open it.

_Acceptance criteria:_

- A user whose email matches `ADMIN_BOOTSTRAP_EMAIL` (case-insensitively) is promoted at a sign-in whose provider profile is Google or Discord with `emailVerified` true, whether the account is new or already existed
- The same email arriving through Microsoft or Facebook, or through Google or Discord unverified, is not promoted and signs in as an ordinary user. The test asserts the Google case promotes, so each refusal is shown to be the provider rule and not a mismatch
- The promotion is decided on the callback's provider profile: a stored row with `emailVerified` true and a non-qualifying provider is not promoted
- The promotion writes through `withAudit` with the signed-in user's own session; no new `oxlint-disable` and no third identity bootstrap
- An already-admin user is not rewritten on sign-in, and a non-matching user is never promoted
- At most one live `users` row matches the variable, asserted against a mixed-case row inserted by hand
- With `ADMIN_BOOTSTRAP_EMAIL` unset, the app refuses to start in every deployed environment: production, staging and hotfix previews. The check keys on `NODE_ENV=production`, as `BETTER_AUTH_SECRET`'s does, so it also covers CI's `build` leg, `playwright.yml` and compose's `e2e` service, and each of those sets a fixed placeholder on the reserved `.invalid` domain. `next dev` and Vitest are exempt, and an unset variable there promotes nobody. The test asserts both sides
- `user.changeEmail.enabled`, every provider's `overrideUserInfoOnSignIn`, and `accountLinking.trustedProviders` are pinned off by test, with a comment naming what each would move
- `auth.md` and `secrets.md` describe the Google-or-Discord, at-sign-in promotion, the squat left open and why, and what changing the variable does

**MB.61 — Scope first-party email verification and email invitations** · 3h

_Stories 58, 59 and 62, and story 4 — As the site owner, I want a considered plan for verifying email addresses ourselves, so that an address can be trusted whichever provider it arrived through, invitations can go by email, and the shortcuts M2.9 had to take can be undone._

_Decided:_ [`design-decisions/mb.61-email-verification-and-delivery.md`](../design-decisions/mb.61-email-verification-and-delivery.md), with the approved plan beside it as [`design-decisions/mb.61-plan.md`](../design-decisions/mb.61-plan.md). Follow-ups MB.65 through MB.70; M7.3, M7.4 and M7.5 rewritten in place; MB.54 re-scoped. One premise below did not survive the discovery: Better Auth's verification token is a signed JWT that is never stored, so it cannot be hashed and is not single-use, and the record argues why that is acceptable for this write where it would not be for an invitation's.

**Scoping task in M2.9's own shape: a decision doc and follow-up tasks, no code.** Today only Google's and Discord's word on an address can be trusted (MB.60); vouching for it ourselves, by mailing a link the user follows, would let the primary keeper sign in through any provider, let an unverified account prove its address rather than block the owner's sign-in, let a user set or change their email (MB.54), and send workspace invitations (story 4) and M2.9's option B, a keeper invitation (story 62), by email to be accepted only by the address's verified holder ([`design-decisions/m2.9-granting-admin.md`](../design-decisions/m2.9-granting-admin.md), "Email verification (MB.61)").

**It needs email delivery, which v1 has none of**, though several providers' free tiers sit well past the few mails a week this site would send. The discovery compares those free tiers against the site's real volume and against what each requires (a sending domain and its DNS records, a sandbox limited to verified recipients, or neither), and settles which one, if any, is worth the dependency. It then checks Better Auth's own `emailVerification` and `sendVerificationEmail` hooks against the rules here: the mail is sent from `/api/auth/*`, which is the one transport exception rule 1 already allows, the token must be stored hashed like an invitation's, and the verification write must be audited or argued as a third identity bootstrap, not just done. Until the follow-ups land, MB.60's rules stand as written.

_Acceptance criteria:_

- At least three delivery options compared on free-tier limits, sending-domain requirements and what happens when the limit is hit
- States what Better Auth's verification flow does out of the box, verified against the installed version and not its docs, and where it crosses rules 1 and 3
- Decides whether verification is required at sign-up, offered afterwards, or both, and what an unverified account can and cannot do meanwhile
- Covers the token's storage, expiry and single use, and what the audit trail records
- Names which of MB.60's restrictions each follow-up lifts, and which stay; decides how an unverified account holding an address is resolved when its owner signs in verified
- Re-scopes M7.3, M7.4 and M7.5 and §7's `InvitationResult` for email delivery with verified-match acceptance, and writes the admin-invitation follow-up (story 62): its table, hashed single-use expiring token, revocation, mailed link, verified-match acceptance route, and acceptance as a grant through MB.59's service with its ledger row and pause check
- Scopes MB.54's flow: the provider's address prefilled, editable, taking effect on verification, and reachable later to change it
- Ends with written follow-up tasks ready to schedule, sized like every other task here
- No implementation in this PR

**MB.62 — The admin-role-change pause ledger (schema)** · 1h

_Story:_ As the site owner, I want the primary keeper's pause on keeper changes kept in the database, one row per pause, so that flipping it needs no redeploy and each pause says who began and ended it.

M2.9's pause switch, table half ([`design-decisions/m2.9-granting-admin.md`](../design-decisions/m2.9-granting-admin.md)). Not a variable, because flipping one is a redeploy; not a column on the primary keeper's row, because the primary keeper moves with `ADMIN_BOOTSTRAP_EMAIL` and the switch must not. Written as a one-row `site_settings` table seeded by its migration, which on building could not be done: the row's audit stamps are foreign keys to `users`, and a fresh database is migrated before any user exists. The owner's call was one row per pause instead ([`design-decisions/mb.62-pause-ledger.md`](../design-decisions/mb.62-pause-ledger.md)): `admin_role_change_pauses`, `id`, a nullable `ended_at` and `ended_by`, and the full `...auditColumns` spread, so `created_by` and `created_at` say who paused and when and the ended pair who resumed and when. Paused means a live row with no `ended_at`. A unique index on a constant, partial on that, allows one open pause at most, so a second is a constraint error rather than an ambiguity about which is the pause; a CHECK keeps the ended pair together. Nothing is seeded. Inert until MB.63 reads it.

_Acceptance criteria:_

- Migration creates the table, its CHECK and its one-open index, writes no row, and adds the `CREATE OR REPLACE TRIGGER` line for `set_updated_at`, so `updated-at-trigger.test.ts` stays green
- A second open pause is refused by the index, asserted by inserting one, while ended pauses beside it are not; a half-ended row is refused by the CHECK
- The schema test asserts the columns, their nullability, the CHECK, the index and the audit spread
- The repository exposes the open pause's read and the writer's named pause and resume, each under the `SiteAdmin` proof, the ended pair stamped from the session; the generic insert, updates and deletes refuse the table, asserted at the type level
- Additive only, so no acknowledgement sidecar
- DESIGN.md §5 and M2.9's record name the ledger, and §5 states the primary keeper's exemption from the pause, as M2.9's record and MB.63 have it

**MB.63 — Pause admin role changes** · 2h

_Story 60 — As the primary keeper, I want to switch keeper grants and revokes off for every other keeper, so that a keeper account that has gone rogue cannot make more keepers or remove the good ones while I sort it out._

M2.9's pause switch, behaviour half, on MB.62's ledger and MB.59's service ([`design-decisions/m2.9-granting-admin.md`](../design-decisions/m2.9-granting-admin.md)). Only the primary keeper may pause or resume, and only the primary keeper is exempt from it: while paused, `setUserRole` refuses a grant or a revoke from any other keeper with an explaining `Forbidden` that says keeper changes are paused and names nobody, and the primary keeper can still do both, so it can clean up without first unpausing. The exemption costs nothing, because the primary keeper is the one account a rogue admin cannot become: it is set by `ADMIN_BOOTSTRAP_EMAIL` and cannot be revoked (MB.59). Revokes are paused as well as grants because a rogue admin removing the good keepers is the same attack from the other side. Approving and revoking coven creation (M5.8) are paused the same way, refused by the same guard with the primary keeper exempt, and locked on the page (amended 2026-10-10, on the owner's call). The control sits on `/admin/users`, visible to every keeper and active only for the primary keeper, with the current state stated in words beside it. Pausing and resuming go through `withAudit` and the writer's named pause and resume, so each pause records who began it and who ended it, and when; MB.62 keeps those rows as a ledger, and nothing in v1 lists them. The pause reads unchanged by MB.195: a grant or revoke it refuses changes no column, so the trigger on `users` records nothing for it (corrected 2026-10-10; [`design-decisions/mb.194-privilege-ledger-by-trigger.md`](../design-decisions/mb.194-privilege-ledger-by-trigger.md)).

_Acceptance criteria:_

- The primary keeper can pause and resume keeper changes from `/admin/users`, and the page states the current state in words
- A non-primary admin sees the control, cannot activate it, and is refused at the service with an explaining `Forbidden`; the test asserts the caller is a live keeper who can otherwise grant
- While paused, a grant or a revoke by any other keeper is refused with an explaining `Forbidden` and writes no ledger row; the test asserts the same call succeeds once resumed, so it is the pause that refuses
- While paused, the primary keeper can still grant and revoke, each recorded in the ledger as usual (by the trigger on `users`, since MB.195)
- While paused, approving and revoking coven creation by any other keeper are refused with the same `Forbidden` and write no ledger row, succeed once resumed, and stay open to the primary keeper (amended 2026-10-10, on the owner's call)
- A pause stamps `created_by` and a resume `ended_by` from the session through `withAudit`, and a request body can set neither
- The mutation carries M5.7's Pothos admin scope as well as the service check
- `auth.md` documents the switch beside granting and revoking

**MB.64 — Reduce root-folder clutter** · 2h

Housekeeping, no behaviour change. The root had grown to fifty entries, eight of them generated output sitting beside the source. `e2e/` becomes `tests/e2e/`, beside the db, acceptance and guard suites — the rest of `tests/` stays flat, because nesting it into a `tests/vitest/` would have cost about thirty code edits and two hundred and fifty doc lines for a level that groups nothing new, and every future test path would carry the extra segment. Every generated report and build goes under one gitignored `.reports/`: Vitest's coverage and json output, Playwright's report, traces and e2e coverage, and the Ladle workshop build. `vitest.setup.ts` moves to `tests/support/setup.ts`, `TO_CLAUDE.md` to [`backlog.md`](../backlog.md), `tsc`'s incremental state to `node_modules/.cache/`, and the empty `tmp/` goes. Two things fall out of the move: `tests/e2e/` is type-checked, since tsconfig already includes `tests/**` and the suite compiled clean the moment it was tried; and pr-gate's `playwright` filter gains `tests/support/**`, which the e2e database helper imports and which never triggered it before. The configs stay at the root by decision.

_Acceptance criteria:_

- `ls` at the root shows none of `e2e`, `build`, `coverage`, `coverage-e2e`, `playwright-report`, `test-results`, `tmp`, `tsconfig.tsbuildinfo`, `TO_CLAUDE.md`, `vitest.setup.ts` or `.vitest` after a full local run
- `tests/guards/test-location.test.ts` pins Playwright specs to `tests/e2e/` the way it pins Vitest files to `tests/`, with the same precondition
- `npm run typecheck` covers `tests/e2e/`
- pr-gate's `vitest` filter skips a change confined to `tests/e2e/`, and its `playwright` filter runs on one confined to `tests/support/`
- CI's coverage and report uploads and the two summarize scripts read from `.reports/`
- Every live doc naming a moved path is corrected in the same PR

**MB.65 — Mail transport: Resend, the Mailtrap Sandbox and Mailpit over HTTP** · 2h

_Story:_ As the site owner, I want the site to send mail in production and nowhere else, so that a verification or an invitation reaches its address and a staging test never reaches a stranger.

The first of MB.61's follow-ups ([`design-decisions/mb.61-email-verification-and-delivery.md`](../design-decisions/mb.61-email-verification-and-delivery.md), "Delivery"). One module, `src/lib/mail.ts`, one function, `send({ to, subject, text, html })`, and three transports over HTTP, selected by `MAIL_TRANSPORT`: `resend` posts to Resend's API, `mailtrap-sandbox` to the Mailtrap Email Sandbox's send API, which captures and never delivers, and `mailpit` to Mailpit's `POST /api/v1/send` in compose. Unset, the message is logged and nothing is sent. No SMTP anywhere: SMTP from a Vercel function is unreliable, and every target here speaks HTTP. **The guard fails closed:** at `VERCEL_ENV=production` the module refuses any value but `resend`, at `preview` any but `mailtrap-sandbox`, and a refused transport logs and sends nothing. A send failure is logged, never thrown. Keys are read at send time — `RESEND_API_KEY` in Production, `MAILTRAP_SANDBOX_TOKEN` and `MAILTRAP_SANDBOX_ID` in Preview, all Sensitive — so neither the pulled-environment assertion nor CI holds them. The record's "Delivery" argues each. Compose gains a `mailpit` service with its UI on `:8025`; `app`, the `e2e` service, the devcontainer and `playwright.yml` set `MAIL_TRANSPORT=mailpit` and `MAILPIT_URL`; `checks.yml`'s build leg sets neither, since nothing reads them at build. A Playwright helper reads the latest message for an address from Mailpit's API, which is how stories 58, 59, 4 and 62 will follow a mailed link.

_Acceptance criteria:_

- `send` reaches each of the three transports through a mocked `fetch`, asserted per transport with the request body checked
- The environment guard is asserted both ways: production with `mailpit` and preview with `resend` both log and send nothing, and each with its permitted value sends
- Unset `MAIL_TRANSPORT` logs the message and sends nothing, and a transport error is logged and not thrown
- Compose runs Mailpit, and a Playwright helper returns the latest message to a given address from its API, exercised by one e2e spec that sends through the transport
- `secrets.md` gains the rows for `MAIL_TRANSPORT`, `MAIL_FROM`, `RESEND_API_KEY`, `MAILTRAP_SANDBOX_TOKEN` and `MAILTRAP_SANDBOX_ID`, each scoped to the one environment that reads it, and numbered steps for the Resend account with its sending-domain DNS records and for creating the sandbox
- `tests/guards/pulled-env-assertion.test.ts` is untouched, since nothing here is read at build; `docker.md` and `ci.md` name the service and the variables

**MB.66 — Turn on Better Auth email verification, audited and session-bound** · 3h

_Story 58 — As a user, I want to prove I own my email address, whichever provider I signed in with, so the site can trust it._

Bigger than the norm: configuration, three hooks, a session check and two test files. Configures `emailVerification` in `src/lib/auth.ts` with `sendVerificationEmail` sending through MB.65's transport, `expiresIn` at 3600, `autoSignInAfterVerification` off and `sendOnSignUp` on, each pinned by test. The token is Better Auth's signed JWT, never stored and not single-use; the record argues why that is acceptable for a write that flips one boolean. Verification is offered, not required for a session: no provider sets `requireEmailVerification`, an unverified user is signed in, and what needs a verified address checks the column. **Verification completes only in a browser holding a session for that account**: `beforeEmailVerification` refuses a request whose session is not the user's, closing the attack described in [`design-decisions/mb.61-email-verification-and-delivery.md`](../design-decisions/mb.61-email-verification-and-delivery.md), "The token, and who may follow the link". Facebook and Microsoft carry `mapProfileToUser: () => ({ emailVerified: false })`, so `users.emailVerified` true means Google, Discord or our own mail vouched. The `/verify-email` write carries its stamp: `beforeEmailVerification` records the user's id in MB.60's per-request store and `databaseHooks.user.update.before` merges `updatedBy` into the same statement, outside `withAudit` for the reason the create hook is and argued beside it in the record. `src/lib/sign-in.ts` maps `email_not_verified` to a sentence naming the email page. **This is the first email the site writes, so it settles the template library**: React Email (`@react-email/components`, rendered to `send`'s `html` and `text` by `@react-email/render`) is the proposed choice, kept or replaced on what this first template shows, with templates in `src/emails/` rather than `src/components/`, since a mail is not a page component. M7.3 and MB.70 reuse whatever it picks, and the choice is recorded in `claude-docs/` with the rest of this task's docs. **Folded in on request during the task, past the sub-hour ride-along size:** the mail follows the site's design — its palette, checked against the compiled theme mixins, its two fonts self-hosted with Google as the fallback, and Backdrop's photographs pre-blended per theme — dark by default and light under `prefers-color-scheme`, and each template ships a Ladle story, guarded like a component's ([`email.md`](../email.md)).

_Acceptance criteria:_

- Each `emailVerification` value is pinned by test, and `requireLocalEmailVerified` is pinned at its default
- A sign-up with an unverified address creates the row, sends one mail through the transport's test double, and still issues a session, asserted
- Following the link from a session holding that row sets `emailVerified` and stamps `updated_by` with that user's own id, asserted by reading the row; from no session or another user's session it is refused and the row is unchanged
- Facebook and Microsoft profiles arrive unverified whatever the provider reported, and Google and Discord keep their mapping, asserted per provider
- An already-verified row is untouched by a second use of the link, asserted
- `auth.md` gains a "First-party verification" section beside the promotion rules, and CLAUDE.md rule 3's bootstrap sentence names the update hook

**MB.67 — Provisional accounts: expire unverified rows and sweep them at the next callback** · 2h

_Story 58 — As the owner of an address, I want an unverified account that happens to hold it to lapse, so that it cannot block my own verified sign-in for longer than a verification window._

The squat, closed for every address. A row with `emailVerified` false and `updated_at` older than one verification lifetime is expired: a sign-up sets that clock, and a resend touches the row through `withAudit` before mailing, so every send pushes the window forward. A Better Auth `hooks.before` on `/callback/:id` sweeps every expired row before the code exchange, together with its `accounts` and `sessions` rows. It hard-deletes, decided in this task, through the repository's named `deleteProvisionalUsers`, the linked rows going by `ON DELETE CASCADE`, and stamps nothing, since no row survives to carry it. The sweep also requires a provider `accounts` row, so the seeded bootstrap admin is never reached. A resend extends the window only from a session holding the row. A three-hour cap on `created_at`, added in this task on request, sweeps a row whatever it has resent, and carries its own partial index. Why each, from the tombstone that would keep blocking the owner to the squatter resending hourly, is [`design-decisions/mb.61-email-verification-and-delivery.md`](../design-decisions/mb.61-email-verification-and-delivery.md), "Provisional accounts and the sweep". `account_not_linked` is mapped in `src/lib/sign-in.ts` to one generic sentence, the same whatever the cause: sign-in didn't work, and if you signed in before with a different provider, sign in that way and add this one under Account — wording MB.71 decided, since a sentence naming the squat would confirm that the address is taken.

_Acceptance criteria:_

- With a squatting Facebook row older than the window present, a verified Google sign-in with the same address lands in a fresh account, asserted end to end; with the row inside the window, the sign-in is refused with the mapped sentence, so it is the expiry that admits
- A resend touches `updated_at` and keeps the row past what would have been its expiry, asserted
- The swept row's `accounts` and `sessions` rows are gone, asserted, and a verified row of any age is never swept
- The partial index on the sweep predicate lands in this PR; additive, so no acknowledgement sidecar
- `auth.md` and `secrets.md` drop "have the owner sign in before anyone else can sign up with the address"

**MB.68 — Promote the primary admin at first-party verification** · 1h

_Story:_ As the site owner, I want to become the primary keeper by proving I own `ADMIN_BOOTSTRAP_EMAIL`, so that I am not limited to Google or Discord.

One hook on top of MB.66. `afterEmailVerification` on the bootstrap address calls `promotePrimaryAdminAtVerification`, which shares `promotePrimaryAdmin`'s `withAudit` role write, with the user's own session, writing MB.59's `bootstrap` ledger row once MB.58 exists and a stub until then, as MB.60 did. MB.60's sign-in rule stands untouched, on the callback's fresh profile and never the stored column ([`design-decisions/mb.61-email-verification-and-delivery.md`](../design-decisions/mb.61-email-verification-and-delivery.md), "Which of MB.60's restrictions each follow-up lifts"). This is safe only because MB.66 binds verification to a session holding the row, which is why it lands after it and not with it.

_Acceptance criteria:_

- A Microsoft-only steward is promoted on following the verification link from their own session, with the ledger row written once MB.58 exists
- The same link followed from another browser is refused and promotes nobody, asserted, so it is the session binding that guards the promotion
- MB.60's promotion tests stay green unchanged
- `auth.md` and `secrets.md` describe the second promotion event, and MB.60's "squat left open" paragraph is rewritten to the new state

**MB.69 — `admin_invitations` schema** · 1h

_Story:_ As the site owner, I want admin invitations stored the way workspace invitations are, so that a leaked row cannot be redeemed and every one is accounted for.

Table half of story 62, after MB.58 (its acceptance writes a ledger row) and shaped like `workspace_invitations`: `id`, `email`, `tokenHash`, `expiresAt` defaulting to seven days, `acceptedAt`, `acceptedBy`, `revokedAt`, a `note` for why the person is being invited, and the full `...auditColumns` spread. Only the hash is stored; the token is MB.70's. Indexed on the hash, with `CREATE OR REPLACE TRIGGER` for `set_updated_at`. Inert until MB.70 reads it.

**Folded into MB.201 (2026-10-10):** `admin_invitations` was copied into the one two-tier `invitations` table as its site tier, a null workspace and role; its named writes and finder became MB.202's, by tier, and the table is undeclared by MB.202 and dropped by MB.203 ([`design-decisions/mb.201-two-tier-invitations.md`](../design-decisions/mb.201-two-tier-invitations.md)).

_Acceptance criteria:_

- Migration creates the table with the columns above, the partial unique index on `token_hash`, and the `set_updated_at` trigger line, so `updated-at-trigger.test.ts` stays green
- The schema test asserts the columns, the expiry default and the audit spread, and that no column holds a plaintext token
- The repository exposes insert, a finder by hash, and the two stamp updates, and no delete, asserted at the type level
- Additive only, so no acknowledgement sidecar

**MB.70 — Invite an admin by email** · 4h

_Story 62 — As a keeper, I want to invite someone by email to become a keeper, accepted only by an account that has proved it owns that address, so that I can promote someone who has not signed in yet without handing anyone a bearer token._

Bigger than the norm: create, mail, revoke, accept, a page and its rejections. M2.9's option B, on MB.69's table, MB.59's service, MB.63's pause and MB.65's transport. `createAdminInvitation(email, note)` is admin-only, generates the token with `crypto.randomBytes`, stores only its hash, mails the link and returns no URL; it is refused for a non-primary admin while changes are paused. `/invite/[token]`, public in `src/proxy.ts`, is built here with the site-tier branch: it prompts sign-in and then accepts only when the signed-in account's verified email matches the invitation's, case-insensitively; a matching unverified account is pointed at `/account/email`. Accepting is a grant through `setUserRole`'s role write, declared `{ via: 'invitation', note }` with the invitation's note, so the trigger on `users` records the `admin` grant (and a `create_workspace` grant if the flag was off) `via` `invitation` carrying that note; it sets `canCreateWorkspace` and is refused while paused (corrected 2026-10-10 by MB.195; [`design-decisions/mb.194-privilege-ledger-by-trigger.md`](../design-decisions/mb.194-privilege-ledger-by-trigger.md)). Expired, revoked and already-accepted tokens are rejected with distinct messages by the one accept service's checks, built here, and pending invitations are listed and revocable on `/admin/users`. **Amended by MB.202 (2026-10-10)** ([`design-decisions/mb.201-two-tier-invitations.md`](../design-decisions/mb.201-two-tier-invitations.md)): the invitation is the site tier of MB.201's `invitations`. `createAdminInvitation` writes through the repository's `insertInvitation(admin, values)`, the revoke through `revokeInvitation(admin, id)` and the list through `findPendingSiteInvitations(admin)`; the accept is `identity`'s `acceptInvitation(session, token)`, whose site-tier branch grants admin with the invitation's note and lands on `/admin`. There is no `/admin-invite/[token]` and no second accept path. **Amended 2026-10-10, on the owner's call**, since MB.70 runs in Wave 8 and M7.5 and M7.7 in Wave 10 (re-estimated from 3h): this task builds the one accept service and the one route that M7.5's entry describes, with the site-tier branch only, and the three rejections M7.7 named, checked before the tier branch so they hold for both tiers. M7.5 adds the workspace branch to both; M7.7 asserts the checks on the workspace tier. No workspace-tier invitation can exist before M7.3, and until M7.5 lands the service refuses one as an invalid link rather than accepting it.

_Acceptance criteria:_

- Only a keeper can create one; the link reaches the address through the transport's test double and appears in no response or query
- Creation and acceptance are both refused while changes are paused, for every keeper but the primary, and the test asserts the same calls succeed once resumed
- Acceptance requires a verified matching address: the test asserts the same session unverified is pointed at the email page and a different verified address is refused, so it is the match that admits
- Acceptance is recorded as an `admin` grant `via` `invitation`, the invitation's note as `note` and the accepting session as actor, and the same write undeclared is refused by the trigger; it sets `canCreateWorkspace`, stamps `acceptedAt` and `acceptedBy`, and a second use is rejected as already accepted (corrected by MB.195)
- Expired and revoked tokens are rejected, each distinctly, and a pending invitation can be revoked from `/admin/users` and is listed there with its note and expiry
- The one accept service and `/invite/[token]` exist with the site-tier branch. The expired, revoked and already-accepted checks run before the tier branch, report one reason deterministically when several apply, and name no workspace; a workspace-tier token is refused until M7.5 adds its branch (amended 2026-10-10)
- The mutations carry M5.7's Pothos admin scope as well as the service check, and story 62's acceptance test passes
- `auth.md` documents the invitation beside granting and revoking

**MB.71 — Link a second sign-in method from the account page** · 3h

_Story 1 — Sign in with an account I already have, so I can start without setting up a new way to sign in: here a second account I already have, added to the same Sorrel & Salt account so either signs me in._

Minted during MB.66, on the question of what it would take for a keeper who signed up through Discord to sign in through Microsoft ([`design-decisions/mb.71-plan.md`](../design-decisions/mb.71-plan.md)). First-party verification does not help, and cannot: Better Auth's implicit link at sign-in (`oauth2/link-account.mjs`) needs the _provider_ to vouch for the address, and Microsoft is pinned unverified against nOAuth (MB.60), so the row being verified is the wrong side of the equation. What works is an explicit link from a signed-in session, which Better Auth ships as `/link-social`; after it the provider signs in by its account id and its address claim is never consulted again. The link branch does not check `requireLocalEmailVerified`, so an unverified row can link too. The mechanism as built is [`auth/admin-bootstrap.md`](../auth/admin-bootstrap.md), "Linking a second provider".

The one hurdle is that the same pin makes the link branch answer `unable_to_link_account`, so every provider's mapper vouches inside a link flow, read from `better-auth/api`'s `getOAuthState()`, and keeps its own answer everywhere else. The scoping named Microsoft and Facebook alone; Google and Discord were added during the task, on request, so that a Discord account with no verified address can be linked too. `accountLinking.allowDifferentEmails` is turned on, and the row's email is untouched by a link. `trustedProviders`, `requireLocalEmailVerified`, `overrideUserInfoOnSignIn` and `updateUserInfoOnLink` stay as they are, and `validateUserInfo` skips recording the promotion profile on an explicit link, told apart by the state rather than `source.action`. The surface is a protected `/account` page with a `SignInMethods` component: the four providers, each linked or addable, with a remove control shown only when two or more are linked; `allowUnlinkingAll` stays false, pinned, so the last one cannot be removed. Better Auth 1.7's `/unlink-account` takes the `accounts` row's own id rather than the provider id, and wants a session younger than a day, which the page maps to a sentence. On the sign-in page `account_not_linked` gets one generic sentence whatever the provider and the cause, since telling a squat from a never-vouching provider would confirm which addresses are taken. MB.67 landed that sentence in place of the squat-specific one it had planned; this task keeps it, corrects `unable_to_link_account`'s wrong sentence, and moves the link-only codes to `/account`. The `/account` axe scan needed a signed-in browser no spec had had: `tests/e2e/session.ts` writes the rows a sign-in would leave and the signed session cookie.

_Acceptance criteria:_

- Signed in through Discord, linking Microsoft with a profile reporting `email_verified` false creates the `accounts` row on the same user, and a later Microsoft sign-in lands in that user, asserted end to end through `auth.handler` on `tests/support/oauth.ts`
- The same Microsoft callback with no link state over that row is still refused with `account_not_linked`, with the row asserted present and verified beforehand, so it is the pin that refuses and not a missing fixture
- A link started under user A cannot attach to user B, and `/link-social` without a session is refused
- Unlinking removes the row and that provider's sign-in is refused again; the last provider cannot be removed, asserted with the row surviving
- `allowDifferentEmails` on and `allowUnlinkingAll` off are pinned by test beside the options MB.60 pinned, which stay pinned
- `account_not_linked` maps to the one generic sentence and nothing else; `SignInMethods` has a component test with role and label queries, a story, and a Playwright axe scan of `/account`
- `auth.md` gains "Linking a second provider" beside first-party verification, and the MB.61 record and MB.67's entry are corrected

**MB.72 — Scope the mail's light-mode rules beneath the page cell** · 1h

_Story 58 — Verify my email address: here the mail that carries the link, readable in every client._

Minted after MB.66 merged, from a rendered client preview of its verification mail: in every client whose browser or system prefers light (every iPhone and the iPad, iCloud, Yahoo and AOL in Chrome, Zoho, o2.pl, Seznam.cz, Outlook.com's dark mode in Firefox) the light text, link and button rules applied and the page rule did not, leaving dark text on the dark page. MB.66's last commit had moved the page rule to a bare class on a table of the layout's own, and the preview could not show whether that landed, because the failure is the shape of the stylesheet rather than any one selector: eight independent rules on unrelated elements, any one of which a client can drop alone. The fix makes the light rules share fate. One `<td>` the layout renders carries the page colour and the class `ss-page`, and every other light rule is scoped beneath it, so a client that keeps the text rules has by construction kept the page rule too; `Body` takes `ss-body` and its own rule for the surround, which is readable either way. Dark stays the inline default, since flipping the two would move the same hazard to dark-preference clients rather than remove it.

_Acceptance criteria:_

- `ss-page` is on exactly one element, a `<td>` carrying the inline dark page colour, and every selector in the light block is `.ss-page`, `.ss-page .ss-…` or `.ss-body`, pinned by test
- No `ss-` rule exists outside the light block
- The Ladle story shows the beige page under dark text in the light theme and the dark page in the dark theme
- A fresh unspam.email client preview of the rendered mail, linked from the PR, shows the light page in the clients that failed and the dark page unchanged in Gmail, desktop Outlook, Thunderbird and Apple Mail dark
- `email.md` states the shared-fate rule and that a client preview must be checked against the branch's own markup before it is read

**MB.73 — Serve Altair at `/api/graphql` in local development** · 1h

_Story:_ As a developer, I want to explore GraphQL queries by hand as a signed-in user, with nothing to install, so that checking a query means opening a page.

The only credential the API accepts is Better Auth's session cookie, and it is `httpOnly` and `SameSite=Lax`: every desktop client — Postman, Insomnia, Bruno, Altair desktop — needs it pasted from DevTools and pasted again when the seven-day session lapses. A page the app serves same-origin gets it for free, which is what Yoga's GraphiQL already was under `next dev`. This swaps that page for [Altair](https://altairgraphql.dev/): `altair-static` renders the shell, its `<base>` points the assets at jsDelivr pinned to the installed version, so no asset route exists. The route serves it itself rather than through Yoga's `renderGraphiQL`, which never sees the request — the endpoint must be absolute because of that `<base>`, and it is taken from the `Host` header because `next dev --hostname 0.0.0.0` reports its bind address in `request.url`. `cors` stays `false`; the page is same-origin.

Two OAuth-shaped answers were rejected and are recorded so they are not re-tried. A client's own OAuth 2.0 helper _can_ sign in: Better Auth's ID-token branch of `sign-in/social` verifies a provider ID token for Google, Facebook and Microsoft (Discord declares no verification config) and answers with the cookie — but it puts the client secret inside the tool, needs a callback registered on the provider app, and can never be a fixture user. The `bearer` plugin rewrites an `Authorization` header into the same cookie, so it grants nothing a `Cookie:` header does not.

_Acceptance criteria:_

- A browser `GET` (`Accept: text/html`) at `/api/graphql` outside production serves Altair — `AltairGraphQL.init` present, the jsDelivr base pinned to the installed `altair-static` version, the endpoint absolute on the request's `Host` — and serves no IDE at `NODE_ENV=production`; the unit test stubs `NODE_ENV` each way and `tests/e2e/graphql.spec.ts` holds against the production build
- `POST` queries, `GET` queries and `cors: false` are unchanged
- `altair-static` is imported lazily, so production never loads it, and is a `serverExternalPackages` entry so its `readFileSync` of `dist/index.html` survives Turbopack
- M3.1's criterion and `graphql.md`'s IDE section say Altair
- `manual-api-testing.md`: open the endpoint signed in; switching identity; staging through the Altair browser extension, whose host permissions make its requests same-site; any desktop client by pasted cookie; why the clients' OAuth helpers are not the path. Linked from CLAUDE.md's `npm run dev` row and from `graphql.md`
- A `dev:session` script minting fixture-user cookies is named in the doc as a possible follow-up, not built

**MB.74 — Review Better Auth's plugin roster: what lands before launch, what waits** · 2h

_Story:_ As the site owner, I want each of Better Auth's plugins weighed against this site, so that the ones worth having land before launch and the rest are decided once rather than rediscovered.

_Decided:_ [`design-decisions/mb.74-better-auth-plugins.md`](../design-decisions/mb.74-better-auth-plugins.md), with the approved plan beside it as [`design-decisions/mb.74-plan.md`](../design-decisions/mb.74-plan.md). Follow-ups MB.75 through MB.78.

**Scoping task in M2.9's own shape: a decision doc and follow-up tasks, no code.** The site signs in through four OAuth providers and is invite-gated, so most of the roster has nothing to do here (DESIGN.md §14, "Which Better Auth plugins?"). The review read the installed Better Auth rather than its documentation and found three things that were not known: the rate limiter is already on in every deploy and counts per function instance, with a fallback that puts every visitor in one bucket when the client IP cannot be resolved; OAuth tokens sit in `accounts` in plaintext; and two-factor never challenges an OAuth sign-in. Passkeys become the v2 first-party credential in §13, in place of email and password.

_Acceptance criteria:_

- Every plugin exported by the installed version, and the separately packaged passkey, SSO, API-key and OIDC-provider plugins, is placed as adopted before launch, v2, or never, with the reason
- The findings are read from `node_modules/better-auth/dist` and cited by file
- The decisions already taken for `organization` (MB.30) and `admin` (MB.53, M2.9) are restated as unchanged
- DESIGN.md §13 and §14 and `auth.md` say what the record decided
- Ends with written follow-up tasks ready to schedule
- No implementation in this PR

**MB.75 — `rate_limits` schema for Better Auth's rate limiter** · 1h

_Story:_ As the site owner, I want sign-in attempts counted in one place, so that a burst spread across function instances is limited as one burst.

MB.74's rate-limiting decision, table half ([`design-decisions/mb.74-better-auth-plugins.md`](../design-decisions/mb.74-better-auth-plugins.md), "Rate limiting"). Better Auth's `storage: 'database'` expects a `rateLimit` model: `key` unique, `count`, and `lastRequest` as a bigint of milliseconds. It is Better Auth's adapter table, written and pruned by Better Auth alone, so it is shaped like `sessions` rather than like application data: no audit spread, no soft delete and no `set_updated_at` trigger (`auth.md`, "Tables"). Inert until MB.76 turns the storage on.

_Acceptance criteria:_

- Migration creates `rate_limits` with `id`, `key` text unique not null, `count` integer not null and `last_request` bigint not null, in the adapter's pluralised naming
- No audit columns and no `set_updated_at` trigger; `updated-at-trigger.test.ts` stays green unchanged, since the table carries no audit stamps
- The schema test asserts the columns, their types and the unique constraint on `key`
- The Drizzle table is passed to `drizzleAdapter`'s `schema` beside `sessions`, `accounts` and `verifications`
- Additive only, so no acknowledgement sidecar

**MB.76 — Pin Better Auth's rate limiter, OAuth token encryption and session lifetimes** · 2h

_Story:_ As the site owner, I want sign-in limited per visitor across every instance, and the provider tokens we store unreadable without our secret, so that neither depends on a default nobody checked.

MB.74's rate-limiting decision, behaviour half, on MB.75's table. Better Auth enables its limiter whenever `NODE_ENV` is `production`, which every Vercel build is, and by default counts in each instance's memory, which on Fluid Compute limits almost nothing. `rateLimit.storage` becomes `'database'`. The client IP is the other half: Better Auth reads `x-forwarded-for` and trusts it only when it holds one address, and otherwise keys every visitor on that path as one shared bucket, which on `/sign-in/social` is three sign-ins per ten seconds for the whole site. `advanced.ipAddress.ipAddressHeaders` is set explicitly, to the header a real deployed request carries, read from staging's request log before the value is chosen and recorded in `auth.md`. Two riders, each under an hour and named in the PR body: `account.encryptOAuthTokens` is turned on, which needs no migration because Better Auth decrypts only a value that looks encrypted and reads older plaintext rows as they are; and the session lifetimes, which DESIGN.md never set, are pinned at Better Auth's defaults by test.

_Acceptance criteria:_

- `rateLimit.enabled` and `storage: 'database'` are pinned by test
- Past the limit, `/sign-in/social` answers 429 with `X-Retry-After`, through `auth.handler` on `tests/support/oauth.ts`, and the `rate_limits` row for that key is asserted, so it is the database that counted
- Two requests from different client IPs are counted separately, asserted by their two rows; the test also shows that without `ipAddressHeaders` set they would have shared the `no-trusted-ip` bucket, so it is the pin that separates them
- `ipAddressHeaders` is set, and the PR records the header staging's requests actually carry
- `account.encryptOAuthTokens` is on and pinned; a new sign-in stores encrypted tokens, and an `accounts` row written in plaintext beforehand still reads
- `session.expiresIn` (seven days), `updateAge` (one day) and `freshAge` (one day) are pinned in `tests/lib/auth.test.ts`'s "session lifetimes" block, which MB.59's `cookieCache` pin joins
- `auth.md` gains a "Rate limiting" section

**MB.77 — Mark the last-used provider on the sign-in page** · 2h

_Story 1 — Sign in with an account I already have: here the page reminds me which of my accounts I used last time._

MB.74's one sign-in convenience ([`design-decisions/mb.74-better-auth-plugins.md`](../design-decisions/mb.74-better-auth-plugins.md), "Sign-in convenience"). When a sign-in is refused with `account_not_linked`, MB.71's sentence tells the visitor to sign in the way they did before, and the page cannot say which way: the server naming a provider would confirm that the address has an account. Better Auth's `lastLoginMethod` plugin writes a readable cookie holding the provider id whenever a callback sets the session, so the browser remembers its own last sign-in and nothing about the address is revealed. `storeInDatabase` stays off, so no `users` column is added. `lastLoginMethodClient` joins `auth-client.ts`, and `SignInPanel` marks that provider's button as last used.

_Acceptance criteria:_

- The server plugin is registered with `storeInDatabase` unset, pinned by test, and the schema gains no column
- A callback through a provider sets the cookie to that provider's id, and `/sign-in/social` alone does not, asserted through `auth.handler` on `tests/support/oauth.ts`
- `SignInPanel` marks the last-used provider's button in its accessible name, asserted with role and label queries, and marks none without the cookie; its story shows both
- A Playwright axe scan of `/sign-in` with the cookie present
- `auth.md`'s "Plugins" table marks the plugin registered

**MB.79 — Record subscription billing as a v2 feature and the Stripe plugin's fit** · 1h

_Story:_ As the owner, I want to know whether Better Auth's Stripe plugin can carry the subscriptions I mean to charge, so that the requirements and the answer are written down before any of it is scheduled.

Minted on request, from the question of whether the plugin could bill workspace stewards by member count, with free months, workspaces free until a keeper clears them, and a discount for people in several workspaces. The plugin was read from its documentation and source, not installed or run. It carries the Stripe customer, Checkout, the billing portal, webhook verification and per-seat pricing at checkout. Its seat resync hangs off the organization plugin's member hooks, which MB.30 rejected; its trial is per plan and once per customer; it has no exemption and no discount field; and it writes its tables outside `withAudit` and serves browser routes under `/api/auth/subscription/*`. Nothing in v1 changes and no hook is left. The one open question, the plugin or a thin service over the Stripe SDK, is for a test-mode spike in MB.30's shape when the work is scheduled.

_Acceptance criteria:_

- DESIGN.md §1 lists subscription billing as deferred; §13 gains a Subscription billing subsection stating the five requirements, the plugin's fit against each, its structural costs, and what is decided now against what is left to the spike; §14 gains a row; §15 gains a bullet
- CLAUDE.md's out-of-scope list names subscription billing
- `backlog.md` carries the item under V2, and `claude-docs/README.md`'s description of the backlog says so
- MB.74's record and `auth.md`'s plugin table name the Stripe plugin and point here, so the roster MB.74 reviewed is complete
- The diff touches only Markdown

**MB.80 — Re-scope the compendium as public and search-indexable** · 2h

_Story 63 — As a visitor, I want to read the compendium and its entries without signing in, so that the site's reference is useful to people who are not in a coven._

Minted on request, from the question of what it would take. Doc-only: nothing compendium-shaped exists yet, so this is a change to the design and to the acceptance criteria of tasks not yet built, plus MB.81–MB.85 for the slug, the public frame, the search-engine surface and the visitor story. The invite gate itself is untouched. Decided: the public canonical URL is `/compendium/ingredients/[slug]`, with the in-app `/ingredients/[id]` staying signed-in and reaching compendium entries too; a slug from name, form and formal name (name plus form as minted; MB.81 added the formal name when the seed's two _Uncaria_ barks collided on it), stored on every ingredient, following a change to any of the three with the old slug answering a 308 for 180 days from midnight UTC and reserved for that window, a rename into a reserved slug recorded as a single pending claim, and nothing on a schedule; the compendium read takes no session; the three compendium queries drop the `signedIn` scope; the public pages are ISR under the `compendium` tag with a client island for the signed-in affordances; the `anonymous` plugin is declined here and recorded for v2 as try-before-sign-up, beside a v2 path for suggesting a change to an entry ([`design-decisions/mb.80-public-compendium.md`](../design-decisions/mb.80-public-compendium.md), plan in [`design-decisions/mb.80-plan.md`](../design-decisions/mb.80-plan.md)).

_Acceptance criteria:_

- DESIGN.md §1, §5, §7, §9, §10, §13, §14 and §15 amended; §10 gains story 63 and the count reads 51
- CLAUDE.md's invite-gated invariant names the compendium as the public exception, the slug convention says an ingredient slug follows a rename, and the story count reads 51
- M5.2, M5.5, M8.5, M8.6, M8.18 and M8.19 amended in place; MB.81–MB.85 entered, indexed and placed in the wave rows; the MB paragraph names them
- `auth.md`'s route-protection list, the mb.57 record, the mb.74 record's `anonymous` line and `backlog.md`'s V Public item corrected
- The record and the plan sit in `design-decisions/`
- The diff touches only Markdown

**MB.81 — `ingredients.slug`, the pending-slug columns and the `retired_ingredient_slugs` table** · 2h

_Story:_ As an operator, I want every ingredient to carry a URL slug and a record of the slugs it has retired, so that a compendium entry has a permanent public address that survives a relabel.

Table task, landing after M4.8 and before M8.2 under the table-then-behaviour rule. Adds to `ingredients`: `slug` (text, nullable on arrival), `pending_slug` (text, nullable) and `pending_slug_effective_at` (`timestamp`, nullable — without time zone, as every timestamp here, holding UTC; `timestamptz` as minted, corrected while building). Partial unique indexes: `(slug) WHERE workspace_id IS NULL AND deleted_at IS NULL`; `(workspace_id, slug) WHERE deleted_at IS NULL`; the same pair on `pending_slug WHERE pending_slug IS NOT NULL`. Creates `retired_ingredient_slugs`: `id`, `ingredient_id` (FK), `workspace_id` (nullable FK, mirroring the ingredient's scope), `slug`, `retired_at`, `expires_at` generated as the UTC calendar date of `retired_at` plus 180 days at 00:00 UTC, the six-column audit spread and its `set_updated_at` trigger line, and an index on `(slug)`. Backfills `slug` through a script that uses `src/lib/slugify.ts` on name, form and formal name, then `SET NOT NULL` on `slug` alone with a destructive-DDL ack sidecar. If it lands before the compendium holds production rows, the backfill is the seed. **Corrected while building: the slug is the label, the form and the formal name where one is declared.** MB.80 minted it as name plus form, and the `standard` seed's two _Cat's Claw_ barks — _Uncaria tomentosa_ and _U. guianensis_ — collided on the compendium slug index the moment it existed. The formal name is what tells such entries apart everywhere else, so it is in the address too, and the slug index refuses only what `slugify` folds together ([`design-decisions/mb.80-public-compendium.md`](../design-decisions/mb.80-public-compendium.md)).

_Acceptance criteria:_

- Columns, indexes and the table exist with the shapes above, asserted from the catalogue
- `expires_at` is a generated column and reads 00:00 UTC whatever the hour of `retired_at`
- The trigger test and the audit-column test both pass with the new table
- Every seeded ingredient has a slug equal to `slugify` of its name, its form and its formal name where declared, and no two seeded slugs in one tier are alike
- The `NOT NULL` step carries its ack sidecar; nothing else in the migration is destructive
- Nothing reads the new columns yet

**MB.82 — Ingredient slugs: set on create, follow a rename, retire with a 308, hand over once confirmed** · 4h

_Story:_ As a keeper, I want an entry's public address to follow its name and its old address to keep working long enough for search engines to move over, so that a relabel never loses a reader or an index entry.

Lands after M5.2, whose service it extends — and M8.2's, which sets a workspace ingredient's slug on create — and before M5.3 and M5.5, so the admin form and the public route consume a finished rule. The slug is `slugify` of name, form and formal name, set on create and recomputed whenever any of the three changes. A compendium entry's old slug becomes a `retired_ingredient_slugs` row, as the relabelling admin's, with the redirect, expiry and takeover DESIGN.md §5 specifies for that table. The takeover's confirmation is a refusal on `endRedirect`, naming the entry and when its window closes, until the input carries `endRedirect: true`; the retirement stays, so the public route's one read, `resolveCompendiumSlug`, can name the moved entry for the page to link to. A coven ingredient's slug retires nothing (§5).

**Decided while building:** MB.80's reservation and pending claims are dropped ([`design-decisions/mb.82-slug-takeover.md`](../design-decisions/mb.82-slug-takeover.md)). With the formal name in the slug since MB.81, only an entry spelling the old address exactly can want it, and that is most often the correct entry being added — a create the pending claims could not serve, since a create has no current slug to keep while it waits. Building the reservation as written would have doubled the task, for a guarantee the confirmation and the link on the new page mostly recover. The coven tier retires nothing because nothing routes by a coven ingredient's slug. The pending-slug columns and their indexes leave the Drizzle schema here and are dropped by MB.107 once this has deployed, since a column drop is two PRs (CLAUDE.md rule 10). A "new at this address" notice was widened into MB.106's New and Updated markers.

_Acceptance criteria:_

- Create sets the slug; a change to the label, the form or the formal name moves it, and a compendium entry's move records the retirement; an identity collision is refused by the identity index first, and a slug collision the identity index does not catch (two formal names the slug rule folds together) is refused with an explaining error naming the colliding entry
- A retired slug resolves to its ingredient until `expires_at` and not after, tested at either side of midnight UTC, and only while no entry holds it
- A write that would take a slug another entry's redirect runs from is refused on `endRedirect`, naming that entry and when its window closes, until the admin confirms; confirmed, it takes the slug, and the address's read names the entry that moved until the window closes
- Taking back your own retired slug inside the window is accepted at once, without a confirmation
- Lapsed retirements are gone after the next compendium write
- Every write goes through `withAudit`; the retirement's `created_by` is the relabelling admin
- A coven ingredient's slug follows its name under the `(workspace_id, slug)` scope, through the `Membership` proof, and retires nothing
- The pending-slug columns and their two indexes are declared nowhere in the schema; MB.107 drops them from the database

**MB.83 — Public compendium chrome and proxy entries** · 4h

_Story 63 — As a visitor who is not signed in, I want the compendium pages to open without a redirect and to offer me the way in, so that I can read the reference and know how to join._

Lands before M8.18, which composes it; M8.17 is not a prerequisite. `PUBLIC_ROUTES` in `src/proxy.ts` gains `/compendium`, `/compendium/*`, `/robots.txt` and `/sitemap.xml`, and `tests/proxy.test.ts` moves `/compendium` from the lookalike list to the public list and pins the two crawler files as passed through. A public frame for the two compendium pages: the site name, Sign in, and nothing workspace-shaped, in the same minimal shape as `/`. The signed-in affordances — the `AppShell` chrome and the Add to my ingredients slot — are one client island that asks `/api/graphql` `me` after hydration and renders a sign-in link for a null session, so the page itself reads no cookies or headers and stays static. Off production the proxy sets `X-Robots-Tag: noindex` on every response, because `staging.sorrelandsalt.com` is a public URL.

**Amended by the Wave 12 review (2026-10-16):** the public pages are dynamic over the cached reads, the owner's call ([`design-decisions/mb.80-public-compendium.md`](../design-decisions/mb.80-public-compendium.md)). There is no client island and no `me` call. The public frame is a `(public)` route group whose layout reads the session when there is one and renders the signed-in or signed-out chrome on the server, with a skip link, a `<nav>` and `<main id="main">`. The pages themselves stay sessionless and read through `cachedCompendiumRead`. `AppShell` gains a Compendium link for everyone, replacing the "No Compendium link yet" comment in `src/components/AppShell/index.tsx`. `PUBLIC_ROUTES` also gains `/llms.txt`, `/.well-known/*` and the asset paths (favicon, icons, manifest) that M11.16 will fill, so a favicon request never redirects to sign-in; no such file exists yet, so the paths are listed ahead of it. The `X-Robots-Tag` rule stays here. Re-estimated from 2h for the route group and the shell change.

**Owner asks during the build (2026-10-17):** the bar's brand links to `/` for every signed-in observer, the coven link reads Your Covens for more than one coven, the entry page `/` offers Browse the Compendium as a quiet button, the public Sign In takes `.btn--medium`, and `$shell-tablet-width` rises to 56rem so a keeper's bar with the Compendium link fits.

_Acceptance criteria:_

- A signed-out request to `/compendium` and `/compendium/ingredients/x` passes the proxy; `/coven/*` still redirects; `/robots.txt`, `/sitemap.xml`, `/llms.txt` and `/.well-known/*` pass
- The signed-out chrome (the site name and a Sign In link) is in the server-rendered HTML, with no script needed; a signed-in request gets the signed-in chrome from the same layout
- The frame has a skip link, a `<nav>` and `<main id="main">`, asserted
- The Compendium link shows in `AppShell` for every viewer
- Off production every response carries `X-Robots-Tag: noindex`
- axe clean signed out at 375px

**MB.84 — robots, sitemap, page metadata and noindex off production** · 7h

_Story:_ As the owner, I want search engines to find and correctly title every compendium page, and to find nothing on staging, so that the public reference is indexed once at its canonical address.

Lands after M8.19, since both pages must exist to describe. `src/app/robots.ts` allows `/compendium` and `/compendium/*`, disallows everything else and points at the sitemap; under a `VERCEL_ENV` other than `production` it disallows all. `src/app/sitemap.ts` lists `/compendium` and one `/compendium/ingredients/<slug>` per current entry. `generateMetadata` on the list page, the public detail page and the in-app detail page: a title from the name and the site, a description from the entry, and `alternates.canonical` set to the public URL on every route. Filtered list views carry canonical `/compendium` and `noindex`, so category combinations are not a crawl trap. An unknown slug is a real 404; a retired slug inside its window answers `permanentRedirect()` to the current one, and a test pins that the redirect carries `no-store`, no positive `max-age`, no `Expires` and no `Last-Modified` (Next sends `max-age=0` inside `no-store`, which a browser cannot keep).

**Amended by the Wave 12 review (2026-10-16):** four changes. (1) The sitemap needs a read of every current slug, and none is cached today: `src/modules/ingredients/services/compendium.ts` wraps only the page and count reads. This task adds a sessionless one, `cachedCompendiumRead('compendium-slugs', …)` from `src/lib/compendium-cache.ts`, which M12.2's `llms.txt` reuses. (2) `lastModified` comes from MB.106's one definition of "changed", so the sitemap does not report a no-op save. MB.106 therefore lands before this task. (3) The title is built from the name and the site, with no form, because the form is a variant beneath the ingredient (MB.215) and a page is the ingredient. Two entries sharing a label are still told apart by the formal name. (4) There is no Open Graph image: M11.16 (Wave 15) adds it, and until then the page carries no `og:image`. `src/app/robots.ts` is written so that M12.2 can add its two paths (`/llms.txt` and `/.well-known/ai-catalog.json`) without restructuring it. Re-estimated from 3h for the new read.

**Amended by MB.155 (2026-10-17), at the owner's ask:** both entry pages already title themselves `Name (Formal Name)` whenever the entry has a formal name that differs from its name, and the name alone otherwise, through `pageTitleOf` in `src/components/IngredientEntry/page-title.ts`. That meets the criterion that two entries sharing a label are told apart by the formal name. This task adds the site to that title and keeps the helper, rather than building the title again.

**Amended at the owner's call (2026-10-19):** structured data and the home page are folded in; re-estimated from 4h to 7h (2h for the JSON-LD and the Open Graph and Twitter tags, 1h for the home page, its robots rule and its markup). (1) Each public page carries schema.org JSON-LD rendered into the server HTML through one serialiser, `src/lib/json-ld.ts`, which escapes `<`: an entry page is a `DefinedTerm` (name, the formal and folk names as `alternateName`, description, URL, `inDefinedTermSet`) with a `BreadcrumbList` back to the compendium; the list page is a `CollectionPage` whose `mainEntity` is a `DefinedTermSet`. Filtered list views and the in-app detail page carry none. Entry sources are not marked up as citations. This supersedes MB.80's "no structured data beyond WebPage" line. (2) Every page's title takes the template `%s | Sorrel & Salt` from the root layout, and the public pages carry `og:title`, `og:description`, `og:url`, `og:site_name`, `og:type` `website` and a `summary` Twitter card, with no image (M11.16's). (3) The home page `/` becomes crawlable on production so Google can read a site name from it: robots allows it with `/$`, because a bare `/` would match every path (RFC 9309, 2.2.3 ends a pattern at `$`; Google's robots.txt page documents `/$` as matching only the root). The home page carries the site name alone as an absolute, untemplated title, a description, canonical `/`, and `WebSite` JSON-LD (`name`, `url`) shown to a signed-out visitor only, and the sitemap lists it. **Amended 2026-10-31, the owner's call:** the site footer is drawn on `/` for everyone, signed in or out; the page still shows no workspace data. (4) `robots.ts` is read per request (`dynamic = 'force-dynamic'`), so the runtime's `VERCEL_ENV` decides and no build setting matters. (5) Lighthouse is a dev dependency run by hand, since it only means anything against a production-env server (off production the noindex header correctly fails "is crawlable", as on a Vercel preview); the devcontainer has no Chrome and no DevTools port on its remote browser could be reached (a debugging-port launch option sent through the Playwright server was refused from the other container), so the owner runs it from a machine with Chrome.

_Acceptance criteria:_

- `/robots.txt` and `/sitemap.xml` answer 200 with the shapes above; the sitemap carries every current slug and no retired one
- Off production robots disallows all
- The sitemap is served from the cached all-slug read, which takes no session, and its `lastModified` follows MB.106's definition of a change
- Every compendium page carries a title, description and canonical; two entries sharing a label are distinguished in the title by the formal name
- A filtered list view is `noindex` with canonical `/compendium`
- An unknown slug is 404; a retired slug is 308 to the current one, with no browser-cacheable freshness headers
- `npm run lighthouse:seo -- <base-url>` (`scripts/lighthouse-seo.mjs`, run by hand and in no CI job or suite) exits zero on the home page, the compendium list and one entry, signed out, against a `VERCEL_ENV=production` server: every SEO audit that applies passes
- Robots allows `/` alone with `/$`: `/coven/…`, `/admin` and `/account` stay disallowed, asserted by test
- The home page carries an absolute untemplated title, a description, canonical `/` and `WebSite` JSON-LD when signed out, and the sitemap lists `/`
- An entry page carries `DefinedTerm` and `BreadcrumbList` JSON-LD and the list page `CollectionPage`, in the server HTML, with `<` escaped; a filtered list and the in-app page carry none
- Every page title ends with the site name through the root template, and the public pages carry Open Graph and Twitter text tags and no image

**MB.85 — Story 63: a visitor reads the compendium without signing in** · 2h

_Story 63 — As a visitor, I want to read the compendium and its entries without signing in, so that the site's reference is useful to people who are not in a coven._

Lands before the wave's stock tasks (moved 2026-10-19 on the owner's call; it was to close Wave 12), once MB.83, M8.18, M8.19 and MB.84 have landed. Story 63 is a signed-out visitor, and the one stock change to those pages, M9.12's Add to My Ingredients button, is never shown to one. **Amended by the Wave 12 review (2026-10-16):** re-estimated from 1h. MB.83 added a story 63 flow to `tests/e2e/stories/09-public.spec.ts` that stops at the list; this task extends it to follow a card and read an entry, and the spec still walks story 63 only. The story flow for story 63 in `tests/e2e/stories/09-public.spec.ts`; a service test that the compendium read takes no session while a null session is refused on every workspace read, asserting the rows exist before asserting the refusal; the route test that a workspace ingredient's slug at `/compendium/ingredients/` is 404 is M8.19's, asserted once there, so this task cites it and adds no second one: `tests/e2e/compendium-entry.spec.ts`, "a coven's own ingredient has no public page: its slug answers 404 to a visitor"; and the e2e: a signed-out visit to `/compendium` lands on the page rather than `/sign-in?next=`, follows a card to its entry, and both pages are axe clean signed out.

_Acceptance criteria:_

- `npm run test:stories` reports story 63 passing, and it is the only story this spec walks
- The null-session denial test asserts the rows exist before asserting the refusal
- The direct-slug 404 is M8.19's test, which states the row is a workspace entry; this task cites it
- The e2e runs signed out and scans both pages with axe

**MB.86 — Restructure `src/` into domain modules with a guarded boundary** · 5h

_Story: As a developer, I want every table and service to have one owning module with a public surface the tooling enforces, so that a later move to separate services replaces a transport rather than a layout._

Minted on request, from the question of what would make an eventual split a transport change. The answer was that the rules already permit it and the layout forbids it: nothing said which code owned which table, and no unit could be lifted out. So `src/db/schema/` and `src/services/` go, and five modules take their place under `src/modules/` — `identity`, `coven`, `vocabulary`, `ingredients`, `grimoire` — cut along the foreign-key graph and named from the project's own nouns, each owning its tables in `schema/`, its services in `services/`, and its GraphQL registrations and loader factories in `graphql/` and `loaders/`. A module's public surface is its `index.ts` plus its `schema/*.ts` files; `services/`, `graphql/` and `loaders/` are internal. Cross-module imports go through `@/modules/<name>`; the dependency graph is fixed and acyclic; a module never imports presentation. The compendium is a tier inside `ingredients`, not a module, and the `ingredients` table is deliberately not split — the record carries the argument. `src/lib/units.ts` moves to `src/modules/ingredients/schema/units.ts`, since the tables are built from it. Enforcement is the usual two layers: one `no-restricted-imports` pattern group in `.oxlintrc.json` over the deep paths, restated in every override, and `tests/guards/module-boundaries.test.ts`, which resolves alias and relative specifiers alike and pins the public-surface rule, the allowed edges, the module roster, the no-presentation rule and the `TIER_SEAM` allowlist — the named set of repository finders that read the compendium tier, empty today and appended to by each later task that adds one. Tests mirror the move into `tests/modules/<name>/`, the db harness moves to `tests/support/db/`, and M3.9's two guards are re-pointed. Bigger than a sitting, and it says so: the move is mechanical but touches every import of a schema or a service, and the guard is written first and watched to fail on the old layout. Stacked on M3.9's branch, since it adopts M3.9's `server-only` marker and guards. Docs corrected in the same PR: CLAUDE.md rules 1, 2 and 9 and a new Modules convention, DESIGN.md §3's tree, and the moved paths in `db.md`, `graphql.md`, `auth.md`, `workshop.md` and `testing.md`; the summary is `claude-docs/modules.md`. The stale "port from resume-2026" lines in CLAUDE.md and this file's standing rules go in the same pass — nothing in this repo is ported.

_Acceptance criteria:_

- `src/db/schema/` and `src/services/` no longer exist; every table and service sits in one of the five modules, with the ownership the record's table gives
- `npm run db:generate` reports no schema changes and `src/db/migrations/` is untouched in the diff
- `tests/guards/module-boundaries.test.ts` is green, and was shown to fail on a deep import of another module's `services/` — as was `npm run lint` — before the probe was reverted
- `tests/guards/lint-access-boundary.test.ts` and `tests/guards/server-only-services.test.ts` name `src/modules/*/services` and are green
- CLAUDE.md, DESIGN.md §3, `db.md`, `graphql.md`, `auth.md`, `workshop.md` and `testing.md` name no path that no longer exists; `claude-docs/README.md` links `modules.md`
- `design-decisions/mb.86-modular-monolith.md` and `mb.86-plan.md` are present, the plan carrying its execution amendments

**MB.87 — Split `src/db/repository.ts` into a `src/db/repository/` folder** · 2h

_Story: As a developer, I want the repository split into one file per concern, so that adding a finder means reading the file that holds its kind rather than all of them._

Minted on request, once M3.10 had taken `src/db/repository.ts` to 530 lines holding six concerns — the table-shape types, the audited write path, the one select builder and its keyset paging, the generic finders, the spell visibility finders, the two reads that take no proof, and the provisional-account delete — with Wave 8 about to add a finder per service. The file becomes `src/db/repository/`: `index.ts` (named re-exports only, entering the database layer through `users`), `shapes.ts`, `write.ts`, `select.ts`, `finders.ts`, `spells.ts`, `memberships.ts` and `provisional-users.ts`. Callers do not change: `@/db/repository` resolves to the index. **The one design change is privacy**: `selectFrom` was file-private, which the language guaranteed; the finders beside it now import it, so it is folder-private — never re-exported from the index, and a deep import from outside the folder is banned by a `no-restricted-imports` group (restated in every override) and by `tests/guards/module-boundaries.test.ts`, whose resolver sees every spelling. The client importers go from one to three (`write.ts`, `select.ts`, `provisional-users.ts`), each with its own disable comment, rather than one internal re-export of `db` that no lint pattern would name. `tests/db/repository.test.ts` is split to mirror, with the probe tables in `tests/support/db/probe-tables.ts`. Stacked on M3.10's branch, whose three new finders it moves.

_Acceptance criteria:_

- `src/db/repository.ts` no longer exists; `src/db/repository/index.ts` re-exports exactly the surface the soft-delete guard pins, and has no `export *`
- Function bodies are moved, not changed: each finder and writer differs from the old file in location alone
- `tests/guards/soft-delete-finder-guard.test.ts` reads the folder and still asserts one SELECT, inside `selectFrom`, and every finder filtered
- A deep import of `@/db/repository/select` from a service fails `npm run lint` and `tests/guards/module-boundaries.test.ts` — shown before the probe was reverted
- `tests/guards/lint-db-client-boundary.test.ts` pins the six client exemptions
- `tests/db/repository.test.ts` is split into `tests/db/repository/`, every test moved rather than rewritten
- CLAUDE.md, DESIGN.md, `db.md`, `modules.md` and `.oxlintrc.json`'s messages name `src/db/repository/`; `design-decisions/mb.87-plan.md` is present
- `npm run test:coverage` and `npm run build` are green

**MB.88 — One account page: name, email and sign-in methods** · 3h

_Stories 1 and 59, gathered onto one page: the name the site shows, the email it knows me by, and the ways I sign in, all changed in one place. Changing the name has no story of its own._

Minted on request during MB.71, once `/account` held only the sign-in methods and the address lived on a page of its own. `/account` becomes the one account page: a Name section, an Email section and MB.71's Sign-in methods, each under its own heading below the page's "Your account". It carries no link to `/account/email`, and MB.71's "Your email" link comes off. The email page stays for the flows that are not a visit to the account. It is where every unverified sign-in lands and the only page a provisional account can reach. A mailed link lands there and shows its confirmed view, and a link opened from the wrong browser is explained there. Its own link across, offered to a verified account, reads "Your account".

The name changes through GraphQL, as the address does (rule 1): `setName(name: String!): User!`, backed by an identity-module service. It writes the session's own row through `withAudit` and trims the name. A blank or over-long name is refused with a `ValidationError` on `name`, which MB.43 maps to the field. A provisional account is refused, as by every service but `me` and `setEmail`. Better Auth's `/update-user` also writes `name` (and `image`) outside `withAudit`, so it is refused before the endpoint, leaving the name one write path, the audited one. `overrideUserInfoOnSignIn` is already off, so a later sign-in never puts the provider's name back. The Email section is EmailForm's field, mutation, cooldown and field errors, not a second form. EmailForm gains an embedded use without its page heading or its confirmed view, both of which stay on `/account/email`. SignInMethods' heading drops a level.

_Acceptance criteria:_

- `setName` renames the session's own row, stamped with the session's user, and leaves another user's row untouched, asserted present first
- `setName` refuses a blank or over-long name as a field error on `name` and refuses a provisional account; the SDL snapshot and the generated client types are updated
- `/update-user` is refused with the row unchanged; the update hook's `/update-user` test is replaced, or its session fallback removed if nothing else reaches it
- `/account` renders "Your account" with Name, Email and Sign-in methods sections and no link to `/account/email`; an unverified account is still sent to the email page
- The Email section sends a change link through `setEmail` with the email page's cooldown and field errors, and the email page itself behaves as before: sign-up landing, confirmed view, refusals
- The name field is a component with a story, a doc and a role-and-label component test; EmailForm's and SignInMethods' docs and stories cover their use on the account page
- A Playwright axe scan of `/account` with all three sections, on `tests/e2e/session.ts`
- DESIGN.md §7 gains `setName` and §9's `/account` row describes the one page; `auth.md`'s "The email page" and "Linking a second provider" name the account page

**MB.89 — Move task tracking from Asana to GitHub Issues and Projects** · 11h

_Story:_ As someone running this board, I want the tasks, their status and their history on GitHub Issues with a Project board over them, so that custom fields, search, dependencies and rules come back without a paid plan, and a merge closes its task by mechanism rather than by memory.

MB.56 rebuilt the board around Asana's free Personal plan — no custom fields, no search, no rules, no dependencies — so the id and the status lived in the task name and lookup walked the wave cards' notes. GitHub Projects (v2), issue types, sub-issues, issue dependencies and issue search are on every GitHub plan, and `gh` 2.97 in the devcontainer already carries `--parent`, `--add-sub-issue`, `--type` and `--add-blocked-by`. The tracker moves there, one task per issue, and the Asana MCP server goes with it: everything is `gh`.

Decided in the plan ([`design-decisions/mb.89-plan.md`](../design-decisions/mb.89-plan.md)): issues live in the public code repo, on the evidence that the comments carry names and narrative but no values, and that `TASKS.md`, `DESIGN.md`, `secrets.md` and every PR body are already public; the 395 comments are pattern-scanned, and the credential-touching threads read, before any is published. Waves are milestones, one per wave; sub-issues are reserved for genuine parent/child. The task id stays in the title and lookup is one `gh issue list` call with the same exact-segment match, since GitHub search tokenises `M2.1` and `M2.10` alike. The Asana workspace stays alive and archived so the existing PR-body permalinks keep resolving.

Status is a Project single-select and hours a Project number field. Closing is not free: GitHub's `Closes #N` fires only on a PR into the default branch, and feature PRs target `staging`, so `.github/workflows/close-task-on-merge.yml` reads `Closes #N` from a merged PR's body and closes the issue; the Project's built-in workflow then marks it Done. PRs into `main` close natively.

Two prerequisites the owner supplies: a fine-grained PAT owned by the org, with the org's Projects permission at read and write and the repo's Issues, Contents, Pull requests and Workflows permissions — the pre-existing token was refused on `createProjectV2` — and an Asana personal access token for the one-off `scripts/migrate-asana-to-github.mjs`.

_Acceptance criteria:_

- Every Asana leaf task is an issue titled `<ID> — <title>`, with the notes as its body, its wave milestone and an issue type, closed as completed for a done task and as not planned for a retired one; the script's `verify` reports matching counts of issues, closed issues, comments and milestones
- Every migrated comment opens with its original `[YYYY-MM-DD HH:MM UTC]` bracket, and the scan reported zero hits before publication
- The org Project carries `Status` and `Estimate`, its auto-add filter admits only `tracked` issues, and every migrated issue is on it with the status its Asana marker carried
- A PR merged into `staging` closes the issue its body names with `Closes #N`, by Action, and the Project marks it Done
- `start-task`, `create-feature`, `create-hotfix`, `create-pr` and `project-progress` reach the board only through `scripts/task-board.mjs`, and every comment step carries "names, never values"
- CLAUDE.md's Asana section is replaced by a GitHub section; the live docs and `.mcp.json` no longer name Asana; design-decision records and transcripts are left as history
- The Asana project is renamed as archived, not deleted

**MB.91 — Make the planet and zodiac suggestion lists admin-curated vocabularies** · 2h

_Story:_ As a keeper, I want to add a planet or a sign myself, so that a practice the seeded lists left out does not need a deploy.

Documentation and scoping only, in MB.35's shape: the model is recorded before the table task transcribes it. M4.5 settled `planet` and `zodiac` as free text with suggested values and put the suggestions in a TypeScript constant — the shape `form`'s vocabulary had before MB.35, and wrong for the same reason: adding a body is a deploy. The two lists become two tables, `planets` and `zodiac_signs`, shaped like `ingredient_forms` minus the group, and `ingredients.planet` / `ingredients.zodiac` stay `text` — §5's rule that a vocabulary a member writes is text. `nomenclature` and `element` stay enums. Two tables rather than one with a `kind`, by the §14 row that decided it for the groups.

Five differences from the forms precedent are recorded rather than glossed: one tier (no group, so a flat seed helper); tables too small for an EXPLAIN index-scan assertion; §5's new table must sit outside `forms.test.ts`'s slice; `standard` seeds no uncurated planet; and the to-do list's add cannot be one click, since `description` is required. The keeper's to-do list is compendium-tier only; the member's autofill reads the compendium and the current workspace. The scoped plan, with what moving `element` and `nomenclature` too would have cost, is [`design-decisions/mb.91-plan.md`](../design-decisions/mb.91-plan.md).

_Acceptance criteria:_

- DESIGN.md §5: the planet/zodiac paragraph re-points at the two tables; `planets` and `zodiac_signs` paragraphs and one `Vocabulary | Values` table (nineteen bodies, thirteen signs, lower-case, in seed order) inserted after the "`ingredients.form` is `text`" paragraph and before `categories`, so `tests/db/seed/forms.test.ts`'s slice is unchanged — asserted by running that test on the branch
- DESIGN.md §5's admin sentence, §7 (the `compendium` tag covers five reads), §9's route table (`/admin/planets`, `/admin/zodiac-signs`) and §14 rows; CLAUDE.md's curation invariant, rule 6 and commands table
- db.md gains "The astrology vocabularies" and a seed section carrying M4.5's sources; validation.md's `correspondences.ts` row and Sources section move there; modules.md's ownership row and ci.md's seed paragraph updated
- TASKS.md: MB.91–MB.95 entered, indexed and placed in the Wave 8 row; M4.7a, M5.4, M5.6a, M5.7 and M5.10a amended; M4.5's entry gains a forward pointer
- The plan is stored as `claude-docs/design-decisions/mb.91-plan.md`; the Wave 08 milestone description lists the new ids in execution order
- The diff touches only Markdown; `npm run pre-commit` and the vitest job stay green

**MB.92 — `planets` and `zodiac_signs` schema** · 1.5h

_Story:_ As a keeper, I want the planet and zodiac vocabularies to be rows, so that the autofill has something a keeper can edit.

Table task. Two flat tables in `src/modules/vocabulary/schema/astrology.ts`: `id`, `name`, `slug`, `description` NOT NULL with a non-blank CHECK, and the six-column audit spread; a partial unique index on `slug` where not deleted; one multicolumn `gin_trgm_ops` index over `(name, description)` per table, since the suggestion query matches both. No group, colour, order column or workspace scoping. The migration appends two `CREATE OR REPLACE TRIGGER set_updated_at` lines by hand — the first tables since 0016 to carry their own, per CLAUDE.md rule 3.

_Acceptance criteria:_

- Both tables carry exactly `id, name, slug, description` plus the audit spread — asserted from `getTableConfig` and the catalogue
- `slug` unique among live rows on a partial index, freed by soft delete; a blank `description` is a 23514 naming the CHECK
- No `group_id`, colour, ordering column or `workspace_id`; the only foreign keys are the audit stamps
- The `(name, description)` trigram index exists on both, asserted from the catalogue
- `ingredients.planet` and `ingredients.zodiac` stay nullable `text` with no foreign key to either table — asserted from the schema and by the migration-file scan, as for `form`
- `AUDITED_TABLES` gains both names; `tests/db/updated-at-trigger.test.ts` passes
- Nothing reads the tables yet

**MB.93 — Seed the planet and zodiac vocabularies** · 1.5h

_Story:_ As a keeper, I want the nineteen bodies and thirteen signs already curated, so that the autofill offers something before the first uncurated value is typed.

`src/db/seed/astrology.ts` holds `PLANETS` and `ZODIAC_SIGNS` as `{ name, description }` lists in §5's order, Title Case, every slug derived by `slugify`. A flat helper over `insertMissing` replaces the two-tier engine, which assumes a group. `standard` seeds both inside its own transaction. `scripts/db-seed.ts` gains an `astrology` target (`npm run db:seed:astrology`), `migrate.yml`'s reference-seed step a third line, and `deploy.yml`'s seed-changed path list the new files. Deletes `src/modules/ingredients/validation/correspondences.ts`; its tests read the seed literals instead.

_Acceptance criteria:_

- Every value §5's table lists is seeded, in §5's order, and nothing else — parsed from DESIGN.md at test time, the parse itself checked (two vocabularies, 19 and 13)
- Every name is Title Case; every description non-empty and no two the same on a table
- Reseeding adds nothing, resurrects nothing a keeper soft-deleted, and overwrites no description a keeper rewrote
- Rows are stamped by the bootstrap user with the GUC published
- `standard` seeds both vocabularies; every `planet` the seeded compendium sets is curated, case-insensitively
- `migrate.yml` runs the new target beside the other two; `deploy.yml` re-seeds when the new files change
- `validation/correspondences.ts` is gone and nothing imports it

**MB.94 — Scoped suggestion fields for planet and zodiac** · 4h

_Story:_ As a workspace member, I want the planet and zodiac fields to suggest from the vocabulary and from what my workspace already uses, so that I do not write Moon four ways.

Builds the suggestion mechanism M4.7a then adopts, for two text-over-vocabulary columns: curated rows first, matched on name then description, then in-use uncurated values from the compendium and the current workspace only. **Moved ahead of M4.7a while building this task**, since M4.7a had not started and whichever came first had to build the mechanism; hence 4h rather than 1.5h. **Corrected while building: a description matches by `<%`, not `%`.** `%` compares whole strings, so `serpent` scores 0.12 against Ophiuchus's description and `black moon` 0.22 against Lilith's, and the first criterion below could not be met with it. A name or in-use value matches by `%` or `<%`, a description by `<%` alone, under per-transaction `pg_trgm.similarity_threshold` 0.4 and `pg_trgm.word_similarity_threshold` 0.6; `<%` is a trigram operator too, so the rule behind `%` still holds. No group on a suggestion. Two fields, `planetSuggestions` and `zodiacSuggestions`, sharing one `CorrespondenceSuggestion` type, each a `pagedConnection`. The service sits in `vocabulary/services/`; the finder that reads the compendium tier joins `TIER_SEAM`. What counts as uncurated is DESIGN.md §5's case-folded match against live rows. `standard` gains no uncurated planet: the tests write their own against an emptied table, and one in the shared template would reach every workspace's suggestions and MB.95's to-do list. M5.10a renders the two fields.

_Acceptance criteria:_

- Curated first, uncurated second, distinguishable; a name match outranks a description match (`black moon` offers Lilith, `serpent` offers Ophiuchus)
- A value in use only in unrelated workspace X never appears — asserted by direct query, with the precondition that X holds it
- Filtered in SQL; soft-deleted rows excluded; bounded by the M3.6 helper
- The match uses `%` and `<%` with explicit thresholds, asserted by test; no planner assertion, since a two-page table is never index-scanned, and the entry says so
- `Moon` and `moon` on ingredients are one in-use value, and a value equal to a curated name is not offered twice

**MB.95 — Admin planet and zodiac CRUD** · 2h

_Story 18 — As a site keeper, I want to add, edit and soft-delete planets and signs, so that the vocabularies can grow without a deploy._

`/admin/planets` and `/admin/zodiac-signs`, reusing M5.6a's page shape without the group control. `PlanetInput` and `ZodiacSignInput` (name, description; no slug) in `vocabulary/validation/`; create, update and soft-delete mutations per table, admin-gated in the service. A value is curated through the create form, which asks for the required description (DESIGN.md §5). Lands after M5.6a, before M5.7, which gates it.

**Corrected while building, on the owner's calls.** Firing the `compendium` tag is M8.7's, as it is for M5.6's and M5.6a's writes: nothing calls `revalidateTag` until M8.6's caching exists, and M8.7 wants one shared tag constant, so M8.7's entry names these writes. The list keeps M5.6a's name search (`?query=`), since "M5.6a's page shape" now holds MB.178's filter; only the group control goes. The two pages share one list and one form component, `VocabularyValueList` and `VocabularyValueForm`, keyed by the vocabulary.

**The compendium holds curated planets and signs alone (MB.162), and these pages keep it so after the write**, as M5.6a's does for forms (amended by MB.162, [`design-decisions/mb.162-compendium-holds-curated-values.md`](../design-decisions/mb.162-compendium-holds-curated-values.md)). Soft-deleting a planet or sign a live compendium entry's list holds is refused, with an error naming the entries — the first few and how many more — and the keeper edits them first. Renaming one carries the new spelling onto every such entry's list, in the same transaction; a planet or sign is no part of an entry's identity or slug, so the rewrite touches the list alone. Both apply only while the row is the last live spelling of its value. A coven's ingredients never block a delete and are never rewritten; their value moves into the autofill's in-use bucket. MB.163 later moves the rename's rewrite to a background job. The pages carry no to-do list of in-use values outside the vocabulary, as first scoped: under MB.162 the compendium holds none, and a keeper reads no workspace's ingredients.

_Acceptance criteria:_

- Admin can create, edit and soft-delete on both pages; both lists alphabetical by name
- A slug collision is a readable error pathed to `name`
- Soft-deleting a planet or sign a live compendium entry holds is refused, naming the entries, and the row stays live; it passes once no live entry holds it (amended by MB.162)
- Renaming a planet or sign rewrites the entry in every live compendium entry's list holding it, in place and in the same transaction, asserted by row; a soft-deleted entry keeps the old spelling (amended by MB.162)
- A coven's ingredient never blocks a delete and is never rewritten by a rename, asserted by row with the precondition that it holds the value (amended by MB.162)
- Non-admins reach neither page nor any mutation (firing the tag is M8.7's, corrected while building)
- The list narrows by a name search, read literally, and every link keeps it (corrected while building)

**MB.97 — A node Vitest project for the unit files that need no DOM** · 3h

_Story:_ As a developer, I want a test that never touches a DOM to run without booting one, so that the suite's per-file overhead stops growing with every guard that is added.

The `unit` project runs 71 files under jsdom with jest-dom and React Testing Library in its setup files. Nine need a DOM — all `.tsx` — and two `.ts` files need jsdom's `location` (`tests/lib/auth-client.test.ts`, `tests/support/msw/graphql.test.ts`); the other 59 pay for the environment anyway, which Vitest's own diagnostics flag after every run.

**Measured with a mirror config before the change:** the unit project drops from 5.84s to ~3.6s locally, an estimated ~20–28s off the 110s CI step. The measurement, and the alternatives it rules out, are [`design-decisions/mb.96-plan.md`](../design-decisions/mb.96-plan.md), "Part 1 — MB.97: a node project for the unit files that need no DOM" and "Facts the plan rests on".

**The rule: a `.tsx` test gets jsdom; a `.ts` test runs in node unless `dom` names it.** `unit` becomes `environment: 'node'` over `tests/**/*.test.ts`; a new `dom` project takes `tests/**/*.test.tsx` plus the two named `.ts` files under jsdom. `tests/support/setup.ts` splits into `setup-msw.ts`, which both projects run so that no unit test can reach the network, and `setup-dom.ts` for the RTL cleanup and `localStorage` polyfill. The three `// @vitest-environment node` docblocks go. `tests/guards/test-location.test.ts` gains the guard that every test file sits in exactly one project, since a file in none is a file nothing runs and a file in two runs twice unnoticed.

Rides along, under MB.31's sub-hour rule: `tests/guards/codegen-staleness.test.ts`'s redundant fifth `generate()` goes, reusing the `beforeAll` output.

_Acceptance criteria:_

- `npx vitest run --project unit` runs only `.ts` files in node and its `Duration` line has no `environment` share; `--project dom` runs the twelve DOM files
- `npm run test:coverage` is green with the same file and test counts as before and coverage ≥ 80% on all four measures
- A `.test.ts` listed in `dom` but not excluded from `unit`, or a test file matched by neither project, fails `tests/guards/test-location.test.ts`
- `testing.md`, CLAUDE.md's `test:coverage` row and every doc or comment that said "the `unit` (jsdom) project" say which project a file runs in and why

**MB.98 — Gate runs stop when their PR is closed** · 1.5h

_Story:_ As a developer, I want a closed PR to stop spending CI, so that a bulk edit of old PR bodies or a merge mid-run costs nothing.

On 2026-09-27 one bulk edit of PR bodies started 130 `pr-gate.yml` runs for PRs merged days to weeks earlier, since `edited` — in the trigger list so gitflow re-runs when an open PR is retargeted — fires for a closed PR just the same; and four of the last twenty merged PRs had a gate run still in flight at merge that ran to the end ([`design-decisions/mb.96-plan.md`](../design-decisions/mb.96-plan.md), "Blacksmith feasibility (the user's question)"). Free on GitHub's runners, metered on Blacksmith (MB.96), which is why this lands first.

**One mechanism, two paths.** A first step in the `changes` job, which `checks`, `vitest` and `playwright` already `need`, cancels a closed PR's run — a step-level `if:`, so the header's rule against job-level ones is untouched — and `closed` joins the gate's trigger types, so a close cancels the PR's other runs through its concurrency group and then itself, and `build-*` and `gitflow` stop within seconds instead of running out ([`ci/aggregating-workflows.md`](../ci/aggregating-workflows.md) has the shape). Re-scoped during the task from a separate `cancel-gate-on-close.yml` keyed by head branch, which would have cancelled the other PR of a hotfix's pair (the plan's "Part 2 — MB.98: gate runs stop when their PR is closed"). `deploy.yml` is left alone.

**Found on the way, corrected here.** The three `build-*` jobs' `cancel-in-progress: false` never survived the workflow-level `true`, and a cancelled build leaves no tag behind anyway, so the blocks are removed, confirmed with the user, and their comment about a half-written layer is corrected. `deploy`'s non-cancelling group and `migrate`'s lock are right as they are. The audit is the plan's "Facts the plan rests on".

_Acceptance criteria:_

- An `edited` event on a closed PR produces a run that cancels itself in its first job; an `edited` event on an open PR still runs the full gate
- Closing or merging a PR cancels every queued or in-progress `pr-gate.yml` run for that PR, and no other PR's; `deploy.yml` is untouched
- No job in `pr-gate.yml` carries a job-level `if:`
- `ci.md` "Aggregating workflows" describes both paths, the burst that motivated them, and the corrected build-job comment, and records the `deploy` and `migrate` concurrency as right so the audit is not redone

**MB.99 — Docker layer cache to the registry** · 1.5h

_Story:_ As a developer, I want an image build on one PR to warm the next PR's build, so that the layer cache is shared rather than copied per PR until it evicts itself.

The Actions cache is at its 10 GB cap and evicting, mostly with buildkit blobs stored once per PR, since a cache written under a PR's merge ref cannot be restored by any other PR or the base branch; the Next.js build cache and the npm cache are what the duplicates crowd out, and a real build spent 32s more writing layers its image push had already uploaded. The evidence is in [`design-decisions/mb.96-plan.md`](../design-decisions/mb.96-plan.md), "Facts the plan rests on".

**`type=registry`, one `:buildcache` tag per image.** `.github/actions/build-image/action.yml` reads from and writes to `ghcr.io/<repo>/<path>:buildcache` with `mode=max` (the `testing` target needs the `development` stage's layers too; `e2e` is a separate Dockerfile on another base and never shared them, and as its file's first stage it caches only its own layers, as MB.237 corrected), derived beside the image tag; the `cache-scope` input and its two call sites go, since the ref already separates the three images. Each build leaves the previous cache manifest untagged, and a package-version cleanup is a later task. What the registry cache buys is the plan's "Part 3 — MB.99: Docker layer cache to the registry".

**`build-db-image.yml`'s `push` trigger goes too**, confirmed with the user: it existed to seed the branch-scoped Actions cache, which a registry cache leaves nothing to seed, and it had already stopped building.

_Acceptance criteria:_

- `build-image`, `build-e2e-image` and `build-db-image` all read from and write to `ghcr.io/aurora-arctic/sorrel-and-salt/<path>:buildcache`; the `cache-scope` input is gone
- `build-db-image.yml` has no `push` trigger, and no live doc says it seeds a cache
- A build on one PR leaves `[development 6/6] RUN npm ci` CACHED for a later PR that changed only the testing stage
- The cache export step takes seconds rather than tens; `ci.md` "Composite actions" and "Database image" describe the cache, its cost and the 10 GB reason

**MB.96 — Run the vitest job on Blacksmith** · 1h

_Story:_ As a developer, I want the Vitest job to run on a runner with enough cores for the suite and a warm image cache, so that a PR's slowest check takes a minute rather than three.

The job took 2m47s on #517, nearly all of it pulling images and paying per-file overhead on the three workers a 4-vCPU public-repo runner allows, for a suite that runs in 14s locally ([`design-decisions/mb.96-plan.md`](../design-decisions/mb.96-plan.md), "Context"). `blacksmith-8vcpu-ubuntu-2404` gives seven workers and caches job and service images automatically. The job runs inside `container:`, so the host's Ubuntu (Blacksmith has no 26.04 label) is only Docker and the runner agent.

**Only the `vitest` job moves.** Blacksmith's free tier is capped and GitHub's own runners cost nothing on a public repo, so `vitest` alone goes now and `playwright` is the second step, taken after two weeks of the usage page; every other job stays on `ubuntu-26.04`. Lands after MB.98, so a metered runner never sees a closed PR's run. The budget behind the split is the plan's "Blacksmith feasibility (the user's question)".

**Prerequisite outside the repo, met on 2026-09-28:** the Blacksmith GitHub App is installed on the `Aurora-Arctic` organisation. It has to stay installed — a `runs-on` label with no app behind it queues forever rather than failing.

_Acceptance criteria:_

- `vitest.yml` runs on `blacksmith-8vcpu-ubuntu-2404`; every other workflow stays on `ubuntu-26.04`, and `ci.md` says why the split falls where it does
- The "Run vitest" step prints `nproc` and the job log shows 8
- `.actrc` maps the new label so `act` still finds a platform for the job
- `ci.md` carries the runner budget table and the two-week review rule, and records the job time before and after from the second Blacksmith run (the first pays the cold image cache)

**MB.100 — Raw SQL only where a rule or the planner needs it** · 3h

_Story:_ As a developer, I want a `sql\`` fragment in the repository to mean something a Drizzle builder cannot say, so that a reviewer reading one knows it is there for a reason rather than by habit.

M4.8's review found the compendium-tier predicate written as `sql\`${ingredients.workspaceId} is null\``in a fourth finder, copied from three neighbours, where`isNull()`exists. A survey of`src/`found 48`sql\``fragments, every one in`src/db/repository/`— MB.33 holds above it. Three kinds: **31 have no builder** — pg_trgm's`%`, `<%`and`similarity()`, `union all`, `mode() within group`, window functions, `json_agg`, row-value cursor comparisons, casts to a column's own type, and `set_config`with bind parameters — and stay. **5 are plain swaps**:`notSoftDeleted`'s `is null`in`shapes.ts`, and the compendium predicate written three times in `ingredients.ts`, `vocabularies.ts`and`common-names.ts`, which becomes one helper beside `scopedTo`. **4 are correlated `exists (select 1 …)`subqueries** —`findManyInSpell`, `findMembershipsOfUsers`, `findManyOfIngredients`, `deleteProvisionalUsers`— written raw only because`soft-delete-finder-guard.test.ts`allows exactly one`.select(`in the folder — a mechanism that leaves those four the least-checked reads in the repository, though the rule's purpose is right ([`design-decisions/mb.100-plan.md`](../design-decisions/mb.100-plan.md), "Assessment 1"). This task changes the mechanism, not the purpose:`existsIn(table, where)`beside`selectFrom`, on the same `db`, ANDing `notSoftDeleted(table)`itself and returning`SQL`rather than a builder; the guard counts two`.select(`calls, both in`select.ts`, one per named body, and asserts `existsIn`carries the filter;`existsIn`joins`INTERNAL`. `Derived`sources and`union all` arms stay raw and the doc says why.

_Acceptance criteria:_

- `existsIn` exists in `select.ts`, applies `notSoftDeleted` by construction, returns `SQL`, and is in the guard's `INTERNAL` list; the guard asserts exactly two `.select(` calls in the folder, both in `select.ts`, one in each of `selectFrom` and `existsIn`, and that `existsIn`'s body calls `notSoftDeleted(`
- The four raw `exists (select 1 …)` fragments are gone; every direct-id denial test over those finders still passes, and each still fails with `existsIn`'s filter removed (the mutation check is recorded in the PR body)
- No `sql\`… is null\``remains where`isNull()` serves; the compendium-tier predicate has one definition
- Every `sql\`` left in `src/db/repository/`is one a reviewer can justify from`db.md` "Where queries may be built", which gains the list of what has no builder and what a rule requires; a fragment that is not obviously one of those carries a one-clause comment
- `db.md` "Soft-delete filtering" and "Spell visibility", the four finder comments and CLAUDE.md rule 4's text describe the two-builder guard; `tests/db/repository/*` and the ingredient/spell/membership tests are green

**MB.101 — One inserter for an ingredient and its children in tests** · 2h

_Story:_ As a developer, I want a test to seed an ingredient with its folk names and categories in one call, so that the seventeen files that each hand-roll the insert stop drifting from each other.

M4.8's review asked whether test setup should go through `withAudit` rather than the raw `postgres` client. It should not — setup must not depend on the code under test, and the writer refuses states setup needs, a compendium ingredient among them ([`design-decisions/mb.100-plan.md`](../design-decisions/mb.100-plan.md), "Assessment 2") — and this task fixes what the question found instead. What is wrong is the duplication: every ingredient-family service, loader and GraphQL test carries its own `addIngredient` with slightly different columns, and `makeIngredient()` carries `folkNames` and `categories` that nothing inserts. One `insertIngredient(sql, fixture, author)` in `tests/support/db/` writes the row, its folk names and its category links (names resolved to ids through the seeded `categories`), stamps `created_by`/`updated_by` from `author`, and publishes `app.current_user_id` in its transaction the way the seed does, so a v2 history trigger records the author rather than nothing. `testing.md` states the convention: setup rows go through the raw client and the shared inserters; a test whose subject is the write path uses `withAudit`.

_Acceptance criteria:_

- `tests/support/db/insert-ingredient.ts` exports `insertIngredient`, takes an `IngredientFixture` and an author id, writes ingredient + folk names + category links in one transaction with the GUC published, and returns the row's id; its own test — `tests/db/insert-ingredient.test.ts`, under `tests/db/` because the `db` project's glob is `tests/db/` and `tests/modules/` — covers a compendium row, a workspace row, the GUC observed from inside the transaction, and a category name the database does not hold live (a thrown error naming it and nothing written, never a silent skip)
- The ingredient-family fixture tests — `ingredients/services/{common-name-suggestions,duplicates}`, `ingredients/loaders/ingredient-children`, `ingredients/graphql/common-names`, `vocabulary/services/{form-suggestions,suggestions}`, `vocabulary/graphql/{form-suggestions,suggestions}` — seed through it, each keeping at most a one-line adapter from what it states to a fixture; no file under `tests/modules/` outside `schema/` still carries a private fixture insert into `ingredients`. The two `*-plan` tests were on the list when minted and are not fixture tests, found when the task was built: their `generate_series` loads of tens of thousands of rows are the planner's ballast, not fixtures, and stay raw beside the schema tests' inserts
- Schema tests and the existing `tests/db/` files are untouched: their raw inserts are the subject or the mechanism, and the entry says so
- `testing.md` "Fixture factories" states the convention in one paragraph and links the inserter; CLAUDE.md's Testing section gains one line
- Coverage is unchanged or higher; `npm run test:coverage` green

**MB.102 — Board calls that defer to the Project's workflows and fit the rate limit** · 1h

_Story:_ As a developer, I want a board command to make only the calls the Project's own workflows do not already make, and to make them cheaply, so that a status move or an estimate never trips GitHub's rate limit.

Minting MB.100 and MB.101 hit `GraphQL: API rate limit exceeded` twice in one sitting, with 4,896 of the hour's 5,000 points still unspent: the refusal is GitHub's _secondary_ limit on bursts, and every `task-board.mjs` command was a burst. `find` (which every other command calls first) ran `gh issue list --limit 1000` — a GraphQL query carrying each issue's labels — and then `loadProject()` listed all 314 Project items with their field values, page after page, to find one. Meanwhile the Project's built-in workflows already did two of the things the script did by hand. **Auto-add to project** (and **Auto-add sub-issues**) puts every `tracked` issue on the board, so `ensureItem`'s `gh project item-add` was redundant; **Item added to project** sets `Not Started` — verified on #531 and #532 within ten seconds of creation — so no status is ever set by hand before `In Progress`. What the workflows cannot do stays the script's: `In Progress` has no trigger, and `In Review` cannot come from **Pull request linked to issue**, because GitHub links a `Closes #N` only on a pull request into the default branch — #294 and #295, both merged into `staging`, carry no linked PR. `Done` was already the merge's (**Item closed**, after `close-task-on-merge.yml`), verified live on #295.

The change: `listTracked()` reads the issues through REST (`gh api --paginate --slurp repos/…/issues?labels=tracked&state=all`, the core budget, one request per hundred issues, pull requests filtered out and the JSON shape kept); the item, its Status and Estimate, and the Project's field and option ids come from one `issue.projectItems` query (one point) instead of `project view` + `field-list` + `item-list`; `ensureItem` becomes `requireItem`, refusing with a retry message when the auto-add has not run yet rather than adding the item itself. `find` and `comment` make no expensive call; `status` and `estimate` make one small query and one mutation. [`task-tracking.md`](../task-tracking.md) says which status each workflow owns and which the script still sets, and why.

_Acceptance criteria:_

- `task-board.mjs` makes no `gh issue list`, `gh project item-list`, `gh project view`, `gh project field-list` or `gh project item-add` call; the migration script still imports what it needs
- `find`'s and `list`'s JSON shape is unchanged (`number`, `title`, `state`, `stateReason`, `url`, `milestone`, `labels`, plus `status` on `find`), with REST's lower-case `state`/`state_reason` normalised to the GraphQL spellings the skills and `project-progress` read
- `status`/`estimate` on an issue the auto-add has not yet placed refuse with a message naming the workflow and saying to retry, and write nothing
- A unit test covers the REST-to-shape normalisation, the pull-request filter and the exact-prefix match, without calling `gh`
- `task-tracking.md` lists the Project's workflows and which status each owns; CLAUDE.md's Status table says `Not Started` is the Item-added workflow's and is never set by hand; the `find` description no longer says `gh issue list`
- Running `find`, `status`, `estimate` and `comment` back to back on one issue draws no rate-limit refusal

**MB.103 — Reorder the Project's items into execution order** · 3h

_Story:_ As the owner, I want the Project's items to read in execution order, and to stay there as tasks are minted, so that the board is the schedule rather than the order the migration happened to insert.

Minted on finding the Project in TASKS.md heading order — the migration's insertion order — everywhere below the M0 and M1 groupings: M0.1 to M11.16, then MB.5 to MB.89, then MB.1 to MB.4, the MW ids, the retired ids, and everything minted since at the bottom. The board is read in execution order, which is the wave table in the Execution order section, so the order was wrong for every wave still open. Fixing it by hand is 315 `updateProjectV2ItemPosition` mutations behind a `gh project item-list`, which is the burst MB.102 exists to keep off the board.

The fix is a `reorder` subcommand on `scripts/task-board.mjs`, built around the limit three ways: **reads are lean** (no nested connection, and no per-item read), **moves are minimal** (an anchor, the longest increasing subsequence left in place, each other item moved after its predecessor — 44 mutations today rather than 315) and **writes are paced**, a stopped run simply re-run. **Waves with no open task are left where they sit**, which saves 139 moves on the done waves. [`task-tracking.md`](../task-tracking.md)'s "Order" section is the command as built.

The dry run surfaced five places TASKS.md and the board disagreed, fixed here: MB.13 and MB.49 were on the Wave 02 and 05 milestones and in no row; MB.88 was in the Wave 7 row and on the Wave 08 milestone, and moves to the end of Wave 8, where nothing needs it; Wave 13's cell contradicted its own reasoning, which the milestone description already had right; M7.A.1 sits on Wave 15 and was in no row. MB.37 and MB.38 were done tasks with no issue at all and are minted closed. The TASKS.md parser the migration carried moves to `scripts/tasks-md.mjs`, shared by both scripts.

_Acceptance criteria:_

- `node scripts/task-board.mjs reorder` prints the discrepancy report and the move list and writes nothing; `--apply` makes those moves, one paced mutation each, and ends by printing the recomputed plan; `--limit N` caps a run
- The reads are the REST issue list, one milestones page and an items listing with no nested connection; nothing calls `gh project item-list`
- A wave whose milestone has no open issue is left where it sits; the anchor never moves; no move omits `afterId`
- `readTasksMd` lives in `scripts/tasks-md.mjs`, imported by the migration script and the board script, with its `.d.mts`
- Waves 08 to 15 read in the wave table's order on the Project, and the run's cost is recorded in the PR body
- The wave rows agree with the board: MB.13, MB.49 and M7.A.1 in their rows, MB.88 at the end of Wave 8, Wave 13's cell matching its prose; the Wave 07 and 08 milestone descriptions follow
- MB.37 and MB.38 are on the board, closed as completed, on Wave 03
- Tests cover the parser and the planner, including a replay of the moves that proves the plan; `task-tracking.md` and CLAUDE.md describe the command; `npm run test:coverage` is green

**MB.104 — Rank the compendium search by word similarity, with the score on each edge** · 7h

_Story 21 — As a workspace member, I want the closest match first when I search, so that a typo or a prefix finds what I meant without scrolling._

M8.5's `compendium(query:)` matches by word similarity at 0.5 but pages the matches alphabetically, because the keyset helper sorts on one stored column and a score is computed per query. This task teaches the helper a list of sort parts and pages a search by `(score DESC, name ASC, id ASC)`, keeping rule 8 whole — never a capped top-N, which would leave matches past the cap unreachable and give a search a different shape from a browse, and never pg_trgm's `<<->` nearest-neighbour order, which needs GiST, orders by one text where the score is the best of three, and cannot resume after a cursor. Each edge of `QueryCompendiumConnection` carries `score: Float`, null on an unranked list. A query shorter than two characters is treated as absent by the service; the finder stays callable with one.

It is sized past one sitting because the mechanism and its one adopter land together. The cursor's key becomes an array, `{k: [...], i}`, which reaches every list — `readSuggestionPage`'s hand-rolled `tier:fold` key becomes a two-part key and drops its regex. `pagedConnection` gains edge fields, and `resolvePage` copies what an entry carries beside `cursor` and `node` onto its edge. The score is negated so one ascending row comparison serves, as `real`, whose shortest-exact text round-trips through the cursor unchanged (`1 - score` would promote to `double precision`). It is computed inside the search's `UNION ALL` arms, where the GIN recheck already runs `word_similarity`, and joined back as `max(score) … group by id` — a plain column that the order and the page bound both read, rather than a `greatest(…)` with a correlated folk-name subquery, which a page bound would evaluate against every compendium row. An `EXPLAIN ANALYZE` test over ~20,000 rows shows the ranked plan, pages one and two, still starting from the expression indexes. M8.14 declares its `(lower(name), canonical_key, id)` parts on the same mechanism rather than building one.

_Acceptance criteria:_

- A search pages best match first, `(score DESC, name ASC, id ASC)` — ties on score by name then id — and a walk across a tie neither loses nor repeats a row, forwards or backwards
- `edges { score }` is the row's word similarity on a search and `null` without one; the SDL snapshot and `src/gql/` are regenerated
- A one-character query is no filter and no ranking, asserted at the service (the finder sees `query: undefined`) and through the query
- The keyset helper takes a list of sort parts, each a column or an expression with its cast type, all ascending; a cursor whose key has the wrong number of parts is `InvalidCursor`; single-column callers are unchanged in behaviour; `tests/db/pagination.test.ts` walks a compound, computed key with a tie
- The ranked query, on its first page and after a cursor, starts from `ingredients_unaccent_trgm` and `ingredient_folk_names_unaccent_trgm` under `enable_seqscan = off` over ~20,000 rows with no `SubPlan`, and the test prints the ranked and unranked timings
- `claude-docs/graphql.md` ("Pagination", the compendium section), `claude-docs/db.md` ("Keyset pages", "The compendium read") and DESIGN.md §7 and §14 describe the compound key and the score

**MB.105 — Page numbers on the compendium connection** · 4h

_Story 14 — As a workspace member, I want a browsable compendium page, so that I can find shared entries and add them to my ingredients._

M8.18's pager can offer Next and Previous and nothing more: the compendium connection carries `edges` and `pageInfo`, the whole Relay set, and no count, so neither how many pages there are nor which one this is can be shown. This task adds both, as `totalCount: Int!` and `countBefore: Int` on `QueryCompendiumConnection` — the rows the list holds under its filter, and how many of them come before this page's first edge, 0 on the first page and null on an empty one — and the client derives "Page X of Y": the page is `floor(countBefore / size) + 1`, the count `max(1, ceil(totalCount / size))`, and Last asks for `last: totalCount % size || size`, since `last: 25` would end on a page that starts mid-page and read one page early. The position is counted from a key and never used to seek, so DESIGN.md §7's "never an offset" stands; a row inserted ahead mid-walk shifts a label, not a page. No numbered jump links: a cursor per page would rank every match on every request and tie the pager to one page size. The position is named as the count it is rather than `startIndex`, which Google's JSON style guide and OpenSearch count from 1, so a client has no base to guess.

`pagedConnection` gains an optional `count`, emitted as the two fields through the Relay plugin's connection options, beside MB.104's edge fields. Both fields share one memoised call per connection, so selecting both runs one query and selecting neither runs none — M8.10's typeahead dropdown, the first page of the same search, selects neither. The count is one statement, `count(*)` beside `count(*) filter (where <row> < <first edge's key>)`, built by a count mode on `selectFrom` over the page's own `where` and search join, with no order or limit and no new `.select(`; the keyset is built once for the page and the count, so the two cannot drift. On a search it runs under the page's word-similarity threshold, 0.5 — read at the server's 0.6 it would count fewer rows than the pages hold. It is priced as `pageInfo` is, at the page size.

_Acceptance criteria:_

- `totalCount` equals the rows collected by walking every page — unfiltered, by category, by form, and on a search whose query is word-similar between 0.5 and 0.6 — and excludes soft-deleted and workspace rows
- `countBefore` is `(n − 1) × size` on page n, walked forwards and backwards across a score tie, and null on an empty page
- Selecting neither field runs no count; selecting both runs one
- A signed-out query reads both fields
- The SDL snapshot and `src/gql/` are regenerated; `claude-docs/graphql.md` ("Pagination", the compendium section), `claude-docs/db.md` ("Keyset pages", "The compendium read") and DESIGN.md §7 describe the two fields and the client's formula

**MB.106 — Mark compendium entries New or Updated for 30 days** · 4h

_Story:_ As a reader of the compendium, I want to see which entries are new and which have changed lately, so that a return visit shows me what moved since I last looked.

A compendium entry reads **New** for 30 days after it is created and **Updated** for 30 days after its last change, New winning while both hold. Compendium entries only: a coven's ingredients are its members' own, and they made the changes themselves. Both markers are computed at read time from the entry's stamps, so there is no column and nothing runs on a schedule. They show on M8.14's card in M8.18's list and on M8.19's entry page, public and in-app.

Two things the task settles, because the stamps as they stand do not say "changed". `updateCompendiumEntry` replaces the whole row, and M1.18's trigger stamps `updated_at` on every `UPDATE`, so a save that changes nothing would read as an update. And an entry's folk names and categories are child rows, whose changes do not move the entry's own `updated_at`. Raised while scoping MB.82, whose "new at this address" notice this replaces with a marker every new entry carries.

**Amended by the Wave 12 review (2026-10-16):** the two settled points now have one mechanism, and the task moves before MB.84 so the sitemap's `lastModified` shares its definition of a change. (1) A new expand-only migration redefines `set_updated_at()` from `0016_updated-at-trigger.sql` with `CREATE OR REPLACE FUNCTION`, so that it leaves `updated_at` alone when `NEW IS DISTINCT FROM OLD` is false (an `UPDATE` that changed nothing). It drops nothing, so it needs no acknowledgement file. (2) The ingredient service touches the parent row after any child-list replace, so a change to folk names, categories, variants or references moves the parent's own `updated_at`. The child lists are replaced by `writeChildren` in `src/modules/ingredients/services/ingredient-rows.ts`, and the touch goes there. New is read from `created_at` and Updated from `updated_at`. The "up to an hour late" caveat goes: the pages are dynamic over cached reads, and the cache is tagged and refreshed on every keeper edit. One cost is accepted and named: a seeded database has every entry created at seed time, so it reads New for 30 days after a seed. Re-estimated from 3h for the migration and the touch.

_Acceptance criteria:_

- An entry created within the last 30 days reads New, and one changed within them reads Updated; New wins when both hold, and neither shows after 30 days, tested at either side of the boundary
- A save that changes nothing leaves `updated_at`, and so the entry's marker, as it was; tested against the trigger's function directly as well as through the service
- A change to an entry's folk names, categories, variants or references marks it Updated, tested through `writeChildren`
- A freshly seeded database reads every entry New, asserted and named as accepted
- The markers show on the compendium list's cards and on the entry page, public and in-app, as text a screen reader announces rather than colour alone
- A coven's ingredients carry no marker

**MB.107 — Drop the pending-slug columns MB.82 stopped declaring** · 1h

_Story:_ As an operator, I want a column dropped only after the code that declared it has left every deploy, so that a migration never breaks the reads of the version still serving.

MB.82 replaced the slug reservation's pending claims with a taker ending the redirect ([`design-decisions/mb.82-slug-takeover.md`](../design-decisions/mb.82-slug-takeover.md)), and took `pending_slug`, `pending_slug_effective_at` and their two partial unique indexes out of the Drizzle schema. That was the first half of the drop, and this task is the second: the migration `drizzle-kit generate` now produces, with its acknowledgement sidecar. It lands once MB.82 has deployed to staging, since a drop that met a deploy still declaring the columns would break that deploy's ingredient reads (`.claude/rules/database.md`, rule 10). Production has never had them — its release predates MB.81 — so the release carrying both ships the add and the drop together. Until this lands, a `db:generate` run on any branch emits the drop; the destructive-DDL check refuses it without a sidecar, and it belongs here rather than to the branch that ran the command.

_Acceptance criteria:_

- The migration drops the two pending-slug indexes and the two columns, and nothing else
- An acknowledgement sidecar beside it says why the drop is safe, and `npm run check:destructive-ddl` passes
- The catalogue tests expect only the five unique indexes the schema declares, and no pending column
- `db:generate` reports no change afterwards

**MB.108 — Move type declarations into type-only files** · 8h

_Story:_ As a developer, I want a code file to hold behaviour and its types to sit in a type-only file beside it, so that I read what a file does without scrolling past the shapes it passes around.

Raised by the owner: 126 `type` and `interface` declarations in 61 files of `src/` and `scripts/` sat inline, and nothing said where a type belongs. This moves every one that can move into a `types.ts` beside the code that uses it, and lands the guard that keeps them there. Larger than the usual sitting because it is a sweep with its guard, and a sweep that attaches to code lands as a mechanism plus a guard rather than piecemeal. `tests/` follows in MB.109.

Three kinds stay in their code file. The first is a type derived from a value declared in the same file, such as the Zod schema and type pairs, `Loaders` and `WorkspacePermission`. The second is the branded proofs `Membership` and `SiteAdmin`, beside the function that mints each. The third is the repository's two `typeof db` types, since the client import is pinned to three files. Where a types file sits follows from who imports it, because the guards that walk imports follow `import type` too. `src/lib/types.ts` imports nothing, since a validation schema reaches it. A module's types sit at the module root, named through its index. A validation file's helper types go in `validation/types.ts` ([`design-decisions/mb.108-types-in-type-files.md`](../design-decisions/mb.108-types-in-type-files.md)).

_Acceptance criteria:_

- `tests/guards/types-in-type-files.test.ts` fails a column-0 `type` or `interface` in any `src/` or `scripts/` file that is not type-only, unless it reads a same-file value through `typeof`, carries a same-file `unique symbol` key, or is on its pinned list. It proves itself on both proofs and a Zod pair, and fails a pinned entry that no longer exists.
- The guard passes over `src/` and `scripts/`, with the exemptions `Membership`, `SiteAdmin`, the value-derived types, `Executor` and `Transaction`, and no others.
- `src/db/repository/shapes.ts` is `types.ts` and `predicates.ts`, and the index re-exports its types in one `export type` line without changing its value exports.
- Each module's index names the moved types it exported before, so no module's surface shrinks. `@/modules/*/types` is in the lint deep-import group in every override, and `lint-access-boundary.test.ts` probes it.
- `IngredientRow` and the seed's `SeedUser` are declared once each.
- The scripts Node runs directly import their types as `import type … from './types.ts'`, and still run.
- `claude-docs/modules.md` has "Where types live"; CLAUDE.md's Conventions name the rule; `db.md`'s repository file table lists the folder as it is.

**MB.109 — Move the tests' type declarations into type-only files** · 5h

_Story:_ As a developer, I want the tests to follow the same rule as the code, so that a test file reads as its cases and a shape two tests share is declared once.

MB.108's guard covers `src/` and `scripts/`. This widens it to `tests/` and moves the tests' own declarations, about 130 in 23 directories, into a `types.ts` per directory. The shared harness in `tests/support/` goes first, because the rest import it. The repeats collapse as they move: `Diagnostic` four times in the guards, `Logged` four times, `Step`, `Job` and `Workflow` across the workflow guards, and `Row` three times. The names reused for different shapes, `Node`, `Connection` and `UserRow` among them, are renamed for what each holds. A type declared inside a function or a `describe` block stays with it, and so does one derived from a table the test declares itself.

_Acceptance criteria:_

- The guard's roots include `tests`, and it passes.
- Every duplicate shape in `tests/` is declared once, and a test's type that duplicates a `src/` type imports that one instead, such as `ProviderId` and `SpellVisibility`.
- The guard's own interfaces live in `tests/guards/types.ts`.
- `npm run test:coverage` and `npm run test:stories` pass.

**MB.110 — Make spell layers soft-deletable** · 3h

_Story:_ As a workspace member, I want an ingredient I take out of a spell to be recoverable, so that editing a spell never loses part of it.

A table task, minted by M5.3. `spell_ingredients` is one of MB.34's three hard-deleted join tables; a spell is a recipe that keeps what went into its jar, so a layer leaves it only when a user removes it, and then softly. The table takes the full `...auditColumns`, gaining `deleted_at` and `deleted_by`; `ingredient_categories` and `spell_categories` stay hard-deleted, so "the three join tables" becomes two in CLAUDE.md rules 3 and 4, DESIGN.md §5, db.md's "Hard delete on the three join tables", `tests/support/db/table-metadata.ts` and `audit-columns.test.ts`. A removed layer must not hold its slot, so the `(spell_id, layer_order)` primary key gives way to a surrogate `id`, with `(spell_id, layer_order)` a partial unique index over live rows, and the two existing partial indexes gain `deleted_at IS NULL`. That is destructive DDL — a primary key and two indexes dropped, a `NOT NULL` column added — so the migration carries an `.ack.md` sidecar, and the task decides whether the index swap needs MB.107's two-PR split. It lands while the table is still empty in production and before Wave 13 writes a layer. M5.3's spell finders read the layer through `existsIn`, which filters a removed layer as soon as the column exists, so they need no change.

_Acceptance criteria:_

- `spell_ingredients` carries all six audit columns, and a catalogue test asserts every unique index on it is partial on `deleted_at IS NULL`
- A removed layer vanishes from `findManyInSpell` and from M5.3's two spell finders
- A removed layer's `layer_order`, ingredient and custom name can be reused in the same spell
- Soft-deleting an ingredient never touches a layer
- The destructive-DDL check passes with the sidecar, and the demo seed and spell fixtures still write

**MB.111 — Carry the return path through the verification link** · 2h

_Story:_ As a new member, I want the link that confirms my address to take me on to the page I was headed for, so that confirming it does not drop me somewhere else.

Minted during M5.4. `requireSession()` sends an unverified account to `/account/email?next=<its own path>`, and the confirmed view's Continue goes to that `next` — but no mailed link carries it. The `sendVerificationEmail` hook in `src/lib/auth.ts` rewrites every link's `callbackURL` to `VERIFIED_LANDING` (`/account/email?verified`), and `src/lib/email-verification.ts` sends the resend and change links to the same fixed landing, so the page the link opens has no `next` and Continue falls back to `/coven`. A new account sent to verify on its way to `/admin` ends at the landing instead.

The landing becomes `/account/email?verified&next=<path>`, the path through `safeReturnPath` when the link is built as well as when the page reads it. The hook builds it from the link's own `callbackURL`: a sign-up's is where the sign-in was going, and a resend's is the landing the email page asked for. The email page hands its `next` to the resend and change links through an optional `next` argument on `setEmail`, passed to the sender, with the SDL snapshot and codegen regenerated. A refused link already keeps the rest of its landing's query, so an expired or wrong-account link keeps `next` beside its `?error=`. The confirmed view stays (MB.54): the link lands on it, and Continue goes on. The signed-out path, `SIGN_IN_TO_VERIFY_PATH`, carries nothing from the link by design and is unchanged.

_Acceptance criteria:_

- The sign-up, resend and change links each land on the confirmed view carrying the `next` the account was sent with, and Continue goes there
- A `next` that leaves the site is dropped when the link is built, and that link lands as it does today
- A refused link keeps `next` beside its `?error=`
- With no `next`, every link lands exactly as today
- `auth.md`'s "The email page" and `components/email-form.md` describe the landing

**MB.112 — Give each Playwright worker its own server and database** · 2h

_Story:_ As a developer, I want the e2e suite to run in parallel without one spec file resetting another's database, so that it stays fast as the UI specs arrive and never fails for a reason that is not in the code.

Minted during M5.4. CLAUDE.md says Playwright re-clones its database before every spec file as Vitest does, but Vitest gives each worker its own database and Playwright has one, `sorrel_e2e`, which every server reads. A file's reseed drops it `WITH (FORCE)`, cutting the connections of whatever another worker is running, and two files starting together race the same `CREATE DATABASE` — the collision M5.4's `admin.spec.ts` hit beside `account.spec.ts`. M5.4 set `workers: 1` to keep the rule true; this task makes it true in parallel.

Each worker slot gets its own server and database, as each Vitest pool slot gets a database. Playwright's `parallelIndex`, `TEST_PARALLEL_INDEX` inside the worker, is unique among running workers and kept across a worker's restart. The first `webServer` entry still builds; each further slot runs `npm run start` over that build on the next port, reading `sorrel_e2e_<index>`. The configured-providers server moves off 8002 to a port and a database of its own, which no spec reseeds. `global-setup.ts` clones every slot's database from the one seeded template before any test runs — after the servers start, which Playwright does first. `recreateE2eDatabase()` and `signInAs()` read the slot themselves, so no spec changes, and a fixture points the default project's `baseURL` at its slot's server. The worker count becomes a config value with an env override, since the servers are declared up front, and a slot with no server fails loudly rather than reaching another worker's.

**Decided while building:** a server per slot, declared in `playwright.config.ts`, over the two alternatives [`design-decisions/mb.112-server-per-worker.md`](../design-decisions/mb.112-server-per-worker.md) records — a server each worker starts from a worker-scoped fixture, which reboots a server after every failed test, since Playwright replaces the worker and its fixtures die with it, and can orphan one on the port the slot's next worker needs; and one server choosing its database per request by a header the browser sends, which puts a test-only, request-controlled database switch into `src/db/connection.ts` and hands one slot's cached compendium to every slot. Swapping `DATABASE_URL` in the worker, as Vitest does, would move only the reseed and `signInAs()`: the app runs in `next start`, which read it once at boot. The worker count is `E2E_WORKERS`, defaulting to half the CPUs as Playwright's own default does, and capped at 99. The configured-providers server takes 8100, fixed above every slot's port with the cap keeping it there, so that no slot reaches it or, under a local `reuseExistingServer`, silently attaches to it; it reads `sorrel_e2e_providers`. `global-setup.ts` runs after the servers start, not before as `testing.md` had it — Playwright's runner orders the `webServer` entries ahead of the global setups — which is enough only because postgres.js connects on its first query and the readiness poll reads no database. Riding in the same PR as a sub-hour fix: `experimental.isrFlushToDisk` off under `NEXT_ISR_FLUSH_TO_DISK=false`, which every e2e server sets, since the servers share the one `.next-e2e` build and a data cache flushed to it would hand one slot's cached compendium to another slot's server ([`testing.md`](../testing.md), "E2E — Playwright").

_Acceptance criteria:_

- `workers` is above one, and each worker's reseed, `signInAs` and page requests reach only its own database and server
- Two db-touching spec files starting together on different workers both pass, where on the one shared database they collided
- A retried test runs on the same slot, server and database
- Asking for more workers than there are servers fails with a message naming the limit
- The configured-providers spec runs against its own server and database
- CLAUDE.md's "Playwright does the same" and testing.md's E2E section describe one server and database per worker, and the ports named in `testing.md`, `DESIGN.md` and `components/sign-in-panel.md` are corrected

**MB.113 — Land an admin on the admin area after a sign-in with no return path** · 2h

_Story:_ As a site keeper, I want signing in to take me to the admin area when I was not headed anywhere else, so that curating starts where I work.

Minted during M5.4, on the owner's request. With no `next`, the sign-in page falls back to `POST_SIGN_IN_LANDING`, `/coven`, for everyone. A verified admin who signs in with no return path lands on `/admin` instead. A return path still wins, an explicit `/coven` included, so the sign-in has to carry whether one was asked for rather than the callback guessing it from the landing path. The callback's after-hook in `src/lib/auth.ts` already sends an unverified account to the email page and promotes the primary keeper, so it is where the landing is chosen, by the role after any promotion at this very sign-in. An unverified admin goes to the email page first, as every unverified account does, and the page's Continue follows the same rule. DESIGN.md §9's `/coven` row and `auth.md`'s "Route protection" record it.

**Decided while building:** the sign-in carries it as Better Auth's `additionalData`, a `NO_RETURN_PATH` flag the after-hook reads back with `getOAuthState()` — the one channel from the browser's `signIn.social` to the callback, and the one the link flow already reads `link` through. It is client-supplied, and harmless so: it only chooses between two landings the account may open anyway. `safeReturnPath` loses its `/coven` fallback and answers `undefined` for a missing or unsafe `next`, since which landing applies is the role's, known only once the callback has run: so `signInPath` with none is a bare `/sign-in`, the email page with none is a bare `/account/email`, and `verifiedLanding` carries an explicit `/coven` rather than dropping it. `postSignInLanding(role)` is the one rule, used by the after-hook and by the email page's Continue, which reads the role when it renders, after a followed link has promoted the primary keeper. `socialSignInTarget(next)` builds `SignInPanel`'s call and the tests' OAuth harness alike, so a harness sign-in with no destination is the panel's. On the owner's request while building, `/`'s signed-in Continue follows the same rule: `src/app/page.tsx` hands `Welcome` the `postSignInLanding` of the session's role, so a keeper's front door leads to `/admin` too.

_Acceptance criteria:_

- A verified admin who signs in with no `next` lands on `/admin`
- With a `next`, `/coven` included, a keeper lands on it
- A non-keeper with no `next` lands on `/coven`, as today
- The primary keeper promoted at this sign-in lands on `/admin`
- An unverified admin is sent to the email page first, and its Continue, with no `next`, goes to `/admin`
- DESIGN.md §9 and `auth.md` describe the keeper's landing

**MB.114 — Design review: foundations** · 3h

_Story:_ As the site's owner, I want the palette, type, spacing and shared primitives settled first, so that each section review designs its pages rather than re-deciding a button.

Minted during M5.4, the first of the design reviews and the one the rest build on. Since M0 the standing rule has been that the design will change and nothing is styled beyond the tokens and mixins; MB.114 through MB.124 are where it changes, one section at a time, each once the section is built. This one reviews what every section shares: the palette and its two themes, the type scale, spacing, which has no scale yet, the reading measure, focus rings, and the `_primitives.scss` class layer — buttons, panels, chips, badges and modals. It adds the one primitive every section needs and none has, form fields, and lands before the admin pages are built, so they are built on it. The direction it settles is written into `styling.md`, where each section review reads it, and it is reviewed in the workshop, in both themes and at phone width, with the owner signing off before anything is built.

_Acceptance criteria:_

- The owner signs off the palette, type scale, spacing and primitives, in both themes and at phone width, recorded as a comment on this issue
- `styling.md` records the direction the section reviews design to, including the spacing scale if one is adopted
- Form fields — text, select, textarea, checkbox and their error state — exist as a primitive, and `EmailForm` uses it
- The workshop has a foundations page showing the palette, type scale, spacing and every primitive in both themes
- Every token still clears 4.5:1 in both themes, and the existing pages' e2e specs, axe scans and stories pass

**MB.115 — Design review: the admin area** · 30h

_Story:_ As a site keeper, I want the admin area to look finished and read clearly, so that curating the compendium is quick and hard to get wrong.

Minted during M5.4. Reviews the admin area once its last page lands: M5.4's layout and `AdminNav`, including the current-page marker it leaves to the design; `IngredientForm` in editable mode (M5.9, M5.10, M5.10a) inside M5.5's compendium page; the category, form, planet and zodiac pages (M5.6, M5.6a, MB.95); the group pages and their colour pickers (M5.6b); the user list (MB.52) with its impersonation, approval, grant and pause controls (MB.53, M5.8, MB.59, MB.63); the impersonation banner (MB.53), whose tucked-away motion, full width, 3px rule and small Stop button the owner already set; and admin invitations (MB.70). **The user list gets a design of its own, not only tokens on a table** (amended during MB.53, re-estimated from 3h): the owner found it too basic as built. At phone width it currently scrolls sideways inside its frame with the last columns, Impersonate among them, out of sight. **The phone design is reviewed as a design of its own** (amended during MB.53, on the owner's word), not only checked for not breaking: phone layouts are proposed and signed off separately from desktop, on a touch screen at 375px and at 412px, the width the owner tests at, including the impersonation banner's touch layout (in the page's flow at the very top, with everything else offset by the top inset, `styling.md`). The admin layout is wider than the reading measure for its tables. `IngredientForm` is reviewed again in the Add Ingredient dialog and in the admin add and edit modals, not with the public compendium, which shows no form (corrected at MB.120's sign-off). MB.169 left one call here, on the owner's word: a picked form's description opens in a tooltip while the Form box has focus, so the keyboard reaches it without a tab stop of its own, and the bubble then covers the Form label above the box. Whether it stays on focus, moves, or closes at the first keystroke is this review's to settle; hover-only is not an option, since the keyboard would then never reach it (WCAG 2.1.1).

A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built — in the workshop and the running app, in both themes, at desktop and at phone width (375px) — proposes the design as workshop stories and screenshots, and builds what the owner signs off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

The review also reads the section's pages and components for repeated frontend code — the same modal or form shell, list or table scaffold, page-level plumbing or Sass partial written out per page — and either folds the shared piece into the review when it is sub-hour or mints it. The backend had its own pass on 2026-10-10 (MB.206 to MB.214); this is the frontend's. Known already: `CategoryForm` and `IngredientFormValueForm` are duplicated components (MB.189 kept their nine identically titled tests as one `it.each` so the next copy is a row); the hex regex is written in `GroupForm` and `ChipColorField` once more each after `lib/contrast.ts` exports it (MB.209); and the admin list pages carry their filter, cursor and "Page X of Y" plumbing per page.

_Left by MB.116:_ The shared row of links and the notice component are already in the admin area: `AdminNav`'s list is a `ul.link-row`, and every admin page and form shows its notices through `Notice`. Two warnings in the user list stay hand-written, since `Notice`'s `warn` kind is an alert and they must not be read out twice. The admin forms already read a failed request through `readGraphqlFailure` and its fallback sentence, `GENERIC_FAILURE`, so this review reads their sentences for the copy, not their plumbing. The four forms that place several field errors at once (`GroupForm`, `GroupedValueForm`, `VocabularyValueForm` and `IngredientForm`) keep a small reader of their own that falls back to the shared one. `.admin-layout`'s raw `2rem 1rem` padding, `1.5rem` gap and `64rem` width are this review's to put on the scale or a token. A shared `TextField` is the candidate once `IngredientForm`'s react-hook-form `TextField` and `FieldShell` (`IngredientForm/fields.tsx`) are compared with the plain-state forms. The user list's Google and Microsoft circle edges changed in MB.116, to clear 3:1 on the light page. `scripts/review-screenshots.mjs` takes this review's phone screenshots, at 375px and 412px in both themes.

**Amended during MB.115 (2026-10-11, the owner's call):** three changes to the admin compendium list. First, the compendium search ranks a match by the field it hit: each field's word similarity is multiplied by that field's weight — the label 1.0, the formal name 0.9, a folk name 0.8, a variant's form 0.6 and a variant's description 0.2 — and the best result is the entry's rank. Before, every matched field counted the same, so a search for _Storax_ brought up _Sweet Gum_ as high as Storax itself, because Sweet Gum's folk name _American Storax_ and its resin's description carry the word; weighted, Storax comes first. Second, the list gains a Form filter between Name and Classification: a type-ahead over the curated forms, on the curated lists' Group filter's pattern, over the `compendium` query's existing `form` argument, so the address carries the form's text (`?form=Oil`). Third, the Formal Name column moves before Classification, so the identity column sits beside the label it belongs to (MB.215). The approved plan is [`mb.115-search-plan.md`](../design-decisions/mb.115-search-plan.md).

**Amended during MB.115 (2026-10-12, the owner's call):** the admin lists' filter rows apply on change. The owner found the rows awkward, and the workshop measured why: a Filter submit disabled until something changed, so the primary button stood dashed nearly all the time; Filter and Clear stretched to the fields' reach when they wrapped; only some fields took the full line on a phone; and a switch waiting on a submit, against the guidance that a toggle takes effect at once. Now a select, a switch or a type-ahead (on a pick, its clear or leaving the box) opens the filtered list the moment it changes, softly from the first page, with the tabs' loading state; the search box carries its own magnifier submit, named Search, so Enter and a press before hydration both work; Clear is a plain link at the row's end, drawn only while a filter is applied; the changed field gets its focus back once the list arrives; the search box grows to fill the line, choice fields share one width, every field takes the full line under 28rem, and the row runs edge to edge with the table beneath it. Four earlier calls are replaced: Filter offered only when something changed (MB.53), Clear disabled rather than hidden, Filter and Clear half each on their own line, and the user, invitation and privilege lists filtering by a full page load, safe to drop because every page under `/admin` runs the guard itself. The approved plan is [`mb.115-filter-plan.md`](../design-decisions/mb.115-filter-plan.md).

**Amended during MB.115 (2026-10-11 and 2026-10-12, the owner's calls; re-estimated from 4h):** the review folded in all the frontend clean-up it found rather than minting it, and the owner redesigned the area after signing it off, so it grew to 16h, and a DRY audit of the finished branch (2026-10-12) added about 14h more, making 30h. The admin pages now share link tabs, each tab with its own address and one loading state: Categories, Forms and Deities each hold their list and its groups; Astrology holds Planets and Zodiac Signs; People holds Users, Invitations (moved to `/admin/invitations`) and Privilege Changes; the nav and the admin index fall into two sections. Users and Invitations show "Page X of Y" as the other lists do, and the pager keeps to one line at every width. Every admin form asks before throwing away unsaved changes, and a form's questions (discard, delete, move and delete) appear on a card over the form rather than in its flow. Each edit dialog says what it edits: an eyebrow ("Edit Ingredient") over the entry's saved name, with an ingredient's formal name or a deity's tradition after it, and a dialog opens with the focus on its first field. The ingredient form's sections, and an open variant's, fold, each with a one-line summary while closed and Open All / Close All in the modal's header; a new entry opens with every section open, an edit with every one closed. Substitute chips tell a linked ingredient from typed text, and a variant's substitutes link forms only ([`mb.115-variant-substitutes-name-a-form.md`](../design-decisions/mb.115-variant-substitutes-name-a-form.md)). A reference-work entry is cited `under "Headword"`, as Chicago's 18th edition writes it, in place of "s.v.". The approved plan is [`mb.115-plan.md`](../design-decisions/mb.115-plan.md), which ends with the DRY audit. The audit folded the repetition it found into this task, with no lint guard (the owner's call), and named the shared pieces that replaced it: the Sass mixins (`list-reset`, `truncate`, `visually-hidden`, `button-reset`, `busy-faded`, `tip-above`, `disclosure-chevron`, `icon-button-remove`, `arrived`, the `data-table--roomy` and `--nowrap` modifiers) and the `$opacity-disabled`, `$fill-quiet` and `$hairline` tokens; `StackTable` and `GroupChip`; `ConfirmQuestion`, `FormActions`, `ReasonField`, `SearchField` and `FilterSelectField`; `placeServerIssues`, `noMatchText`, `capitalise`, `oneOf`, `useHydrated` and `ListDialog`; `tabbedLayout` and the edit-place helper; and the test and story helpers. Raw `z-index` layers are left for MB.124.

_Acceptance criteria:_

- The owner signs off the section's design, in both themes and at phone width, recorded as a comment on this issue
- No page in the section scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- Every page in the section is axe clean with visible keyboard focus, and its e2e specs and stories pass
- Each component's doc updates its Styling section, and its stories show the reviewed design
- `AdminNav` marks the current page, with `aria-current` as well as visually
- The picked form's tooltip on the Form box's focus is settled, the keyboard still reaching it (MB.169)
- Admin lists and tables read at desktop width and stay usable at phone width
- The phone design is signed off on its own, as screenshots on a touch screen at 375px and 412px, every admin page and the impersonation banner among them (amended during MB.53)
- The user list is designed, not a bare table: at phone width every user's facts and controls are reachable without a hidden sideways scroll (amended during MB.53)
- A destructive admin action looks destructive, and its confirmation says what will happen
- No component or Sass partial in the section is a copy of another; a shared piece is one component, named in the PR body

**MB.116 — Design review: the sign-in and account pages** · 8h

_Story:_ As a member, I want signing in and managing my account to feel like one finished site, so that trusting it with my sign-in is easy.

Minted during M5.4. Reviews the pages around signing in once MB.88 rebuilds `/account`: the public entry page `/` (MB.57), the sign-in page and its provider buttons with the last-used mark (M2.6, MB.77), `/account` with the name, the address and the sign-in methods (MB.88, MB.71), `/account/email` (MB.54) and the not-authorized page (M5.4). **MB.117, the review of the sign-in methods, is merged into this task** (the owner's call, 2026-10-10): the methods are on `/account`, so the two were one page reviewed twice. MB.117's three criteria are this task's, below, and MB.117 is retired. **Re-estimated from 2h to 8h**: MB.117's 1h, and the shared pieces, stylelint, the adoptions across the frontend and the copy review that the review turned up. The plan is [`design-decisions/mb.116-plan.md`](../design-decisions/mb.116-plan.md).

A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built — in the workshop and the running app, in both themes, at desktop and at phone width (375px) — proposes the design as workshop stories and screenshots, and builds what the owner signs off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

The review also reads the section's pages and components for repeated frontend code — the same modal or form shell, list or table scaffold, page-level plumbing or Sass partial written out per page — and either folds the shared piece into the review when it is sub-hour or mints it. The backend had its own pass on 2026-10-10 (MB.206 to MB.214); this is the frontend's. Known already: the provider buttons' brand-coloured and greyed states, the client twins of `sign-in.ts`'s error-message lookups, and `SignInMethods`' per-provider row — linked, addable or unavailable — as one row component.

What the review builds beyond the section's own pages, each named in the PR body:

- **Shared pieces for every later review.** The centred full-height frame of a page with no AppShell, `.page-frame`, with `--narrow` for a form page and `__section` and `__rule` for its titled sections; a row of links that is not a bulleted list, `.link-row`; a provider's mark on its brand's circle, `.provider-mark`, and the `ProviderMark` component; the providers' brand colours as one map in `_variables.scss`, read through `brand-color()`; the `Notice` component, which pairs each notice's look with the role that gets it read out, and its `quiet` option, a status rather than an alert for a warning on the page from the start; `readGraphqlFailure` and its one fallback sentence, `GENERIC_FAILURE`, and `readGraphqlIssues`, which reads every field error of a refusal at once for a form that places each under its field; `scripts/review-screenshots.mjs`, which takes a review's phone screenshots in both themes; and an e2e check that a page does not scroll sideways at 375px.
- **Stylelint**, run by `npm run lint`, refusing a raw hue anywhere but `_variables.scss`. Group colours are data on their rows and never reach a stylesheet, so it cannot conflict with them.
- **Ride-alongs outside the section**: `InvitationAcceptance` takes the page frame; `UserList` takes the brand map and the shared provider mark, its Google and Microsoft circles' edges darkened to clear 3:1 on the light page; `AdminNav`'s list becomes a `.link-row`; and every hand-written notice and every copy of the failure reader across the frontend, the admin pages and forms among them, takes `Notice` and `readGraphqlFailure`, or `readGraphqlIssues` where a form places several field errors at once.
- **The plain-writing rule**: a `CLAUDE.md` line, its long form in `.claude/rules/writing.md`, and a row in `claude-docs/agent-skills.md`.
- **The copy review**: every sentence the section shows, proposed against one register in the sign-off comment and applied as agreed. Second person and plain words; one sentence for what happened and one for what to do; "Please try again." only where trying again can help; "sign-in method" and "address" throughout; title case for every label, button and heading.

On the section's own pages, one behaviour fix rides with the design: **the account page pre-empts a stale session**. Better Auth refuses to remove a sign-in method on a session older than its freshness window, so the page withholds Remove on such a session and offers Sign In Again, rather than letting the request fail. The decisions taken at sign-off, and the owner's calls on the applied design in the running app (the only method's Remove greyed with its reason as its description, the sign-in card filling the narrow column as one centred column with more room inside, a quiet Continue to Account button inside the email card, each sign-in method's button small and one word with the provider in its accessible name, and a page-frame child made `border-box` after the new 375px width check caught the account panels overflowing), are recorded at the end of the plan.

_Acceptance criteria:_

- The owner signs off the section's design, in both themes and at phone width, recorded as a comment on this issue
- No page in the section scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- Every page in the section is axe clean with visible keyboard focus, and its e2e specs and stories pass
- Each component's doc updates its Styling section, and its stories show the reviewed design
- The provider buttons keep their brand-coloured and greyed states distinct in both themes
- `/`, `/sign-in` and the not-authorized page read as one site with the signed-in pages
- Linked, addable and unavailable providers are told apart without colour alone (from MB.117)
- The last remaining method reads as the one that cannot be removed, and says why (from MB.117)
- A failed link's error sits beside the provider it concerns (from MB.117)
- Stylelint refuses a raw hue outside `_variables.scss`, as part of `npm run lint`
- Every hand-written notice that carries a role, and every copy of the failure reader and its fallback sentence, uses `Notice`, `readGraphqlFailure` and `GENERIC_FAILURE`, and a form that places several field errors at once reads them with `readGraphqlIssues`
- The section's copy is reviewed against one register, proposed in the sign-off comment and applied as agreed
- No component or Sass partial in the section is a copy of another; a shared piece is one component, named in the PR body

**MB.117 — [RETIRED] Design review: sign-in methods** · **RETIRED 2026-10-10, merged into MB.116**

> **Merged into MB.116, not done on its own.** The owner's call (2026-10-10):
> the sign-in methods are on `/account`, which MB.116 reviews, so the two were
> one page reviewed twice. The ID is kept, as every retired one is. Its three
> criteria below are MB.116's now, and its issue is closed as not planned.

_Story:_ As a member, I want to see at a glance how I can sign in, and add or remove a method safely, so that I never lock myself out by accident.

Minted during M5.4, a review of its own at the owner's request, after the sign-in and account pages (MB.116): `SignInMethods` on `/account` (MB.71, moved there by MB.88) — each provider linked or addable, Add greyed for a provider that is not configured, Remove only while another method is left, and the error a failed link comes back with.

A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built — in the workshop and the running app, in both themes, at desktop and at phone width (375px) — proposes the design as workshop stories and screenshots, and builds what the owner signs off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

The review also reads the section's pages and components for repeated frontend code — the same modal or form shell, list or table scaffold, page-level plumbing or Sass partial written out per page — and either folds the shared piece into the review when it is sub-hour or mints it. The backend had its own pass on 2026-10-10 (MB.206 to MB.214); this is the frontend's. Known already: `SignInMethods`' per-provider row — linked, addable or unavailable — as one row component.

_Acceptance criteria (retired — moved to MB.116):_

- The owner signs off the section's design, in both themes and at phone width, recorded as a comment on this issue
- No page in the section scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- Every page in the section is axe clean with visible keyboard focus, and its e2e specs and stories pass
- Each component's doc updates its Styling section, and its stories show the reviewed design
- Linked, addable and unavailable providers are told apart without colour alone
- The last remaining method reads as the one that cannot be removed, and says why
- A failed link's error sits beside the provider it concerns
- No component or Sass partial in the section is a copy of another; a shared piece is one component, named in the PR body

**MB.118 — Design review: the site's mail** · 6h

_Story:_ As a new member or an invitee, I want the site's mail to look like the site and read well in my mail client, so that I trust the link in it.

Minted during M5.4. Reviews the mail the site sends, once the last of it exists: the verification and change-of-address mail (MB.66, `verify-email.tsx`), the coven invitation (M7.3) and the admin invitation (MB.70). Mail has its own constraints — inline styles, a client's own dark mode, images blocked by default, MB.72's light-mode rules — so it is reviewed as mail, in Mailpit and in the major clients, not as a page, and built within the palette and type MB.114 settles. Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

_Left by MB.116:_ The providers' brand colours are one map in `_variables.scss`, `$brand-palettes`, read through `brand-color()`: the one place their hexes are written, if a mail ever shows a provider mark. MB.116's copy register holds for mail too: second person and plain words, one sentence for what happened and one for what to do, "Please try again." only where trying again can help, and title case for every label and heading (`styling.md`, "Designing a section").

_Left by the Wave 10 review (2026-10-12):_ Three of the criteria below already hold on staging, so the review asserts them and builds nothing: every mail has a plain-text part (`renderParts` in `src/emails/parts/layout.tsx` renders both the HTML and the plain text), the link is readable as text under the button (`claude-docs/email.md`, "Templates"), and `email.md` has a "Design" section recording the design rules. What `email.md` lacks is a line about the phone-width check, so the review adds the rule that each mail is checked at 375px. The coven invitation mail does not exist until M7.3, which the wave orders before this task.

_Amended 2026-10-12 by the review itself, on the owner's call:_ the estimate rises from 2h to 6h because every sub-hour defect the review found lands here rather than minted, and the branch sits on M7.3's (#915) so the coven mail is in the tree. The plan and its sources are [`design-decisions/mb.118-plan.md`](../design-decisions/mb.118-plan.md). What the review measured: the mail palette equals the site's tokens to the channel; every token pairing clears 4.5:1 in both themes (light link and button 4.65:1 the lowest), pinned by `tests/emails/theme.test.ts`; in the light theme the salt photograph ran under the closing lines, where the muted ink fell to 2.14:1 and the written-out link to 1.66:1, which no opacity fixes, so the salt now sits beneath the text block; the button was 43px tall, now 47px; and a document with no viewport meta lays out at 980px on a phone. A client pass found desktop Outlook (the Word engine) falling back to Times New Roman, because the body font sat only on the outer cell and Word ignores a stack whose first face is an uninstalled `@font-face`, and dropping the side padding, which sat on tables; both fixed in `src/emails/parts/layout.tsx` with a 600px ghost table and pixel line heights. The plain-text part no longer opens with the wordmark's address. `tests/emails/parts/layout.test.tsx` asserts, once per template with a guard over `src/emails/`, that the text part says everything the HTML does and that the address is readable as text and first among the text part's links. `email.md` records the 375px rule, the overlap rule, the Outlook rules and the copy guidance. Waiting for the owner's sign-off, as copy: each subject without its full stop and with the important words first, a preview line per mail that adds to the subject, the two closing sentences without their negative contractions (GOV.UK style guide), and an expired-link sentence in the verification mail. Three things the sources want that the data does not yet carry are left to mint, not built: the reader's name in the verification mail, the inviter's name in both invitations, and transparent ornaments should Gmail on iOS prove to invert the dark mail. **Signed off 2026-10-12** from the review page: all three designs approved; subjects, preview lines, the closing sentences and the expired-link sentence accepted as drafted; and, on the owner's call over this entry's "behaviour does not change", the inviter's name built here rather than minted (`InvitationSender` takes the inviter). The reader's name was built into the verification mail the same way and taken out again on the owner's second call: that mail goes to an address the account has not proved, and a mistyped one would hand a stranger the name of whoever typed it. The client preview, Gmail on iOS and the Outlook.com button are not yet checked; transparent ornaments stay to mint only if that look finds the inversion.

_Acceptance criteria:_

- The owner signs off each mail's design, in a light and a dark client and in a phone-width client (375px), recorded as a comment on this issue (phone width amended during MB.53, on the owner's word)
- Each mail reads correctly in Gmail, Outlook and Apple Mail, light and dark, and with images blocked
- Each mail carries a plain-text part that says everything its HTML does (already holds, asserted by the review)
- The link is the obvious action, and its address is also readable as text (already holds, asserted by the review)
- Text contrast holds at 4.5:1 in the mail's light and dark renderings
- `email.md` records the design rules the mail follows (already holds, asserted by the review)
- `email.md` records the 375px rule

**MB.119 — Design review: the coven and invitations** · 10h

_Story:_ As a coven member, I want the coven's pages to feel like one place I belong to, so that finding members and inviting someone is obvious.

Minted during M5.4. Reviews the coven section once invitations land: creating a coven (M6.7) and its form (M9.16), `WorkspaceSwitcher` (M6.9), the coven layout's chrome (M6.10), the coven's index page and section nav (M9.15), `MemberList` and the members page with its steward controls (M6.12, M6.13), deleting, leaving and the last steward's guided exit (M6.14 to M6.16), `InviteDialog` (M7.4), the acceptance page (M7.5) and the post-sign-in landing (M2.8). The switcher is reviewed here as a component; where it sits in the app's nav is MB.7's.

A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built — in the workshop and the running app, in both themes, at desktop and at phone width (375px) — proposes the design as workshop stories and screenshots, and builds what the owner signs off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

_Left by MB.116:_ `.page-frame--narrow` is already the invitation acceptance page's frame (`/invite/[token]`), a page with no AppShell (`styling.md`, "The page frame"). The create-workspace page, `/coven/new` (M9.16), takes it too: the owner asked for it centred like the email page (2026-10-12), so its form sits on a `.panel` in `.page-frame--narrow` inside the AppShell (MB.7). Every notice in the section shows through `Notice` (`components/notice.md`).

_Left by MB.115:_ The coven's lists and forms build on what the admin section shares rather than drawing their own: `Field` for every field and `FormActions` for a form's buttons (`components/field.md`), `BusyButton` for a button whose request is in flight, `PageHeader` and `FilterForm` for a list page's head, with `FilterSelectField` for a filter's choice, a native select until the page's script loads, then the forms' own dropdown, or a type-ahead for a long list, `StackTable` for its rows, a table that turns each row into a card on a narrow screen (`components/data-table.md`), and `Pager` with `listHref` for its pages. A question asked before a step that cannot be undone is `ConfirmQuestion`, drawn over the form (`components/modal.md`). M7.6's pending invitations page and count as the admin Invitations tab does (`src/app/(shell)/admin/(people)/invitations/`), the owner's call during MB.115.

_Left by the Wave 10 review (2026-10-12):_ The scope above grows by these. M7.6's pending invitations list, its count, its revoke control and the Invite button it mounts (the review moved mounting `InviteDialog` into M7.6). The components `CovenNav` (`src/components/CovenNav/`), `CreateWorkspaceForm`, `InvitationAcceptance` (the acceptance page's component), `ContextRow`, and `ActionFailure` in `WorkspaceActions/action-failure.tsx`, which has neither a doc under `claude-docs/components/` nor a story, and gains both here. The members page (`src/app/(shell)/coven/[slug]/members/page.tsx`) uses none of MB.115's shared list pieces, so it adopts `PageHeader` and `Pager` here, not in M7.6. The docs `member-list.md`, `delete-workspace-button.md` and `leave-workspace-button.md` have no Styling section yet, so each gains one rather than updating it. The section's copy mixes two nouns: `WorkspaceSwitcher` says "Coven", "Create Coven" and "Select Coven" while the buttons say "Leave Workspace" and "Delete Workspace". The review settles one user-facing noun with the owner and makes all the copy use it. The acceptance page also has to read correctly for an invitation into a deleted coven, which M7.5 refuses at page load.

_Scoped 2026-10-13, build not yet started:_ The plan is [`design-decisions/mb.119-plan.md`](../design-decisions/mb.119-plan.md), with the audit of the section as built (nineteen findings across consistency, accessibility and repeated code, and three from M10.32's branch) and the four-lane build it proposes. The owner decided three things at planning: the word a person reads for a workspace is **coven** everywhere on screen, so the Leave and Delete buttons change and `DESIGN.md` §5's vocabulary line gains the screens; every sub-hour fix and every adoption of a shared piece lands in this task, which is why the estimate rises from 3h to 10h; and the review takes in M10.32's `ReceivedInvitations` list on the landing, so the review's second wave starts once M10.32's PR is open and its branch sits on that head. The first wave, the foundations and the shared pieces, has no file in common with M10.32 and can start off staging at any time. The entry's earlier line that the members page adopts `PageHeader` and `Pager` is out of date: both are already there, through `TabbedPage` and M7.6; what remains is the hand-written cursor reading and pager links, which the plan converges on `readPageCursors` and `pagerHrefs`.

_Acceptance criteria:_

- The owner signs off the section's design, in both themes and at phone width, recorded as a comment on this issue
- No page in the section scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- Every page in the section is axe clean with visible keyboard focus, and its e2e specs and stories pass
- Each component's doc adds or updates its Styling section, and its stories show the reviewed design
- The section's user-facing copy uses one noun for a workspace, settled with the owner
- `ActionFailure` has a doc and a story
- Steward-only controls read as such, and an observer's page shows no control it cannot use
- The acceptance page reads correctly signed in, signed out, and for an expired or used link, or an invitation into a deleted coven

**MB.120 — Design review: the public compendium and shared ingredient components** · 10h

_Story:_ As a visitor, I want the public compendium to look finished and read well on any device, so that it earns trust as a reference.

Minted during M5.4. Reviews the public compendium and the ingredient components the rest of the site shares, once MB.106's markers land: the public frame's landmarks, which are the skip link, `<nav>` and `<main id="main">` (MB.83); `IngredientSearch` with its chips, OR toggle and filters (M8.10 to M8.13); `IngredientCard` (M8.14); `SafetyNote` and the toxic mark (M8.13a); the compendium page and its pager (M8.18, MB.105); the entry page (M8.19); the Add Ingredient dialog (M8.16); and the New and Updated markers (MB.106). M9.12's dialog, M8.17's edit flow, the local-or-compendium chip and the stock badges (M9.7, M9.8) belong to MB.121, which reviews them on the coven page.

**Amended by the Wave 12 review (2026-10-16):** the scope above replaces the earlier list, which named M8.15 (retired into M8.19) and a signed-in island that no longer exists. The compendium is the site's public, indexable face (MB.80), so it is reviewed signed out as well as signed in.

A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built — in the workshop and the running app, in both themes, at desktop and at phone width (375px) — proposes the design as workshop stories and screenshots, and builds what the owner signs off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

_Left by MB.116:_ `IngredientForm`'s notices already show through `Notice`, and its failed saves fall back to `readGraphqlFailure`. The one left hand-written is the duplicate-name warning in `IngredientForm/duplicates.tsx`, a `div` that turns from warning to error in place, which is this review's to settle. A shared `TextField`, lifted from `IngredientForm/fields.tsx`, is settled with MB.115.

_Left by MB.115:_ The shared field is `Field` (`components/field.md`): `TextField`, `SelectField`, `SwitchField` and `SearchField` on one shell, and `IngredientForm` uses them. `SuggestField`, `MultiSelectField` and `ListField` still live in `IngredientForm/fields.tsx`, on that shell; whether they move is this review's call. The `duplicates.tsx` warning stays as MB.116 left it. The qualifier's tooltip in `Combobox` sits above the field, aligned to its right, and closes at the first keystroke and when the list opens (the owner's call at MB.115); it holds wherever `FormField` renders. The edit dialogs' head is MB.115's: an eyebrow saying what the dialog does, the entry's name as the title, and its formal name after it, italic only for a botanical, fungal or zoological entry (`components/modal.md`).

_Acceptance criteria:_

- The owner signs off the section's design, in both themes and at phone width, recorded as a comment on this issue
- No page in the section scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- Every page in the section is axe clean with visible keyboard focus, and its e2e specs and stories pass
- Each component's doc updates its Styling section, and its stories show the reviewed design
- The compendium and entry pages read the same signed out and signed in, apart from the chrome the layout renders for a session
- A safety note stands out from the rest of an entry without relying on colour alone
- The card grid holds its layout from phone width to a wide screen

**MB.121 — Design review: the workspace ingredients page** · 6h

_Story:_ As a coven member, I want the ingredients page to make stock easy to scan and edit, so that keeping it current is quick.

Minted during M5.4. Reviews the coven's one ingredients page (M9.6) once its flows land — editing a jar from its row (M9.9), last-edited-by on its rows (M6.18, moved here from MB.119 when it moved to Wave 12 on 2026-10-12), deletion with confirmation (M9.10), the empty state (M9.11) and the add-from-compendium flow (M9.12) — over the search and cards MB.120 has reviewed.

**Amended by the Wave 12 review (2026-10-16):** the page is a card per ingredient with a jar line per held form (`IngredientCard`, M8.14), not a table, so the list is no longer a `StackTable`. The scope gains the in-stock and low-stock filters and the stock badges (M9.7, M9.8), `StockFields` (M9.9), the edit flow for a local (M8.17), M9.12's add dialog, the Edit control (M12.5), the folk-name control (M12.1), M12.7's icons on the jar lines, and the coven home's Contents. Re-estimated from 2h.

A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built — in the workshop and the running app, in both themes, at desktop and at phone width (375px) — proposes the design as workshop stories and screenshots, and builds what the owner signs off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

**Amended by M12.29 (2026-10-21):** the scope gains the entry page's Stock section (`JarShelf`, M12.29): the shelf, its Low and Out jars and their tips, the Edit Stock button and the empty "No stock recorded." state. M12.29 put the section in a `.panel` box as an interim trial, and this review removes it: the Stock section is the only boxed section on the entry page, and the jar's shine is drawn in the card colour, so it fades on a card-coloured panel. Drop `panel` from the wrapper in `IngredientEntry/stock-section.tsx`, and set the section apart, if it still needs it, in a way the entry page's other sections can share. The review also checks the section for repetition (DRY: one shared helper or mixin where the shelf, the stock badge and the Edit Stock dialog repeat a style, a string or a piece of markup), for UX (pressing a jar, the amount tip, and editing with no stock), and for accessibility (names and descriptions of the jar and amount buttons, keyboard order, focus, and colour that is never the only cue).

**Amended by M12.53 (2026-10-23):** M12.53 merged each component's data-only stories into one `States` story, but eight components still have a story named `Default`: `FormIcon`, `MenuButton`, `Spinner`, `SearchSentence`, `IngredientForm`, `FilterForm`, `CardDensitySwitch` and `JarLines`. This review merges each one into a `States` story, sorted first, the same way M12.53 did for the rest (`claude-docs/workshop.md`). A component whose only story has nothing to merge with keeps `Default`.

_Left by MB.115:_ A list builds on the admin section's pieces rather than its own: `IngredientCard` for its rows (corrected by the Wave 12 review; the admin lists use `StackTable`, a table that turns each row into a card on a narrow screen, `components/data-table.md`), `FilterForm` and `Pager` for narrowing and paging it, with `FilterSelectField` for a filter's choice, a native select until the page's script loads, then the forms' own dropdown, or a type-ahead for a long list, and `BusyButton` for a button whose request is in flight.

_Acceptance criteria:_

- The owner signs off the section's design, in both themes and at phone width, recorded as a comment on this issue
- No page in the section scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- Every page in the section is axe clean with visible keyboard focus, and its e2e specs and stories pass
- Accessibility: the workspace ingredients page, `IngredientCard`, `StockFields`, the stock dialogs and the entry page's Stock section (`JarShelf`) pass an axe check in Playwright (`@axe-core/playwright`) in both themes. Each page also gets a keyboard-only and a screen-reader pass against WCAG 2.2 AA, and every failure found is fixed or filed as a task
- UX, with research: the review is backed by published UX guidance for jar lines, stock badges, filters and the Edit Stock dialog (for example Nielsen Norman Group, the GOV.UK Design System, the WAI-ARIA Authoring Practices and Baymard). Each change it makes or rejects names its source, in Chicago form. Wikipedia is acceptable; academic or practitioner sources are preferred
- Storybook and /design-sync: a separate agent, not the one doing the design review, updates every Storybook story that the review's changes affect, covering new states, changed props and removed variants (the stories follow the `States`-first convention). That same separate agent then runs `/design-sync`, so the Claude Design project matches, and every changed story grades `match` or `close`
- `FormIcon`, `MenuButton`, `Spinner`, `SearchSentence`, `IngredientForm`, `FilterForm`, `CardDensitySwitch` and `JarLines` each have a `States` story sorted first, and none of them has a `Default` story unless it has nothing to merge
- Each component's doc updates its Styling section, and its stories show the reviewed design
- A jar being edited reads differently from one at rest, and an unsaved change shows
- The empty state says what to do next
- The entry page's Stock section has no `.panel` box, and the review records what sets it apart instead, if anything
- The section repeats no style, string or markup that a shared helper or mixin already holds, and the review lists what it merged
- Each jar and amount button has a name and description a screen reader can tell apart, the shelf works by keyboard alone, and Low and Out are never shown by colour alone

**MB.122 — ~~Design review: the navigation~~** · **RETIRED 2026-10-12, folded into MB.7**

> **Retired without being done as its own task.** The ID is kept because task IDs
> are immutable. The review and the build are one piece of work once the design is
> chosen before the build, and the design was chosen from a rendered mock-up on
> 2026-10-12 (the owner's call). MB.7 now carries the review's scope, its "Left by
> MB.116" and "Left by MB.115" notes and its acceptance criteria. The design
> chosen, its options and its reasons are in
> [`design-decisions/mb.7-navigation.md`](../design-decisions/mb.7-navigation.md).
> MB.7 keeps its own 2h. The two entries added up to 4h, and no new figure
> has been invented for the merged task; the owner sets it.

See **MB.7**.

**MB.123 — Design review: the grimoire** · 11h

_Story:_ As a coven member, I want building and reading a spell to feel crafted, so that the grimoire is a pleasure to use.

Minted during M5.4. Reviews the grimoire once its print layout lands: the grimoire list (M10.11), `SpellBuilder` with its fields, visibility control, intent categories, steps and reordering (M10.12 to M10.16), the intent-versus-derived comparison panel (M10.17), the safety and out-of-stock warnings (M10.18, M10.19), draft and complete (M10.20), and the recipe view (MB.6) with its print layout (M10.22), the one print style on the site.

**Amended 2026-10-16 by the spell steps and workings plan** ([`design-decisions/m13.1-plan.md`](../design-decisions/m13.1-plan.md)): the review also covers the step editor (M13.3), the Record a Working dialog with its deduction preview (M13.7), and the recipe page's Workings section (M13.8). M13.9 follows it.

The review list also covers: `SpellCard` and the card list's empty states (M10.11), the `Skeleton` shapes for the list and the recipe page, the focus ring (M12.45), click feedback (M12.31), the tooltip triage (M12.43, a tooltip only for a rule or format trap) and the recipe page's Duplicate control (M13.20). After a step is added, removed or reordered, focus placement and the `aria-live` message are asserted in the story spec, since axe does not check them.

A section review designs what the section's building tasks left at the tokens and mixins. It looks at every page and component in the section as built — in the workshop and the running app, in both themes, at desktop and at phone width (375px) — proposes the design as workshop stories and screenshots, and builds what the owner signs off, within the tokens, mixins and primitives MB.114 settles: a value that is not there becomes a token, never a raw hue or size (`styling.md`). Behaviour does not change; a defect found on the way is fixed if it is sub-hour and minted if not.

_Left by MB.115:_ The grimoire list builds on the admin section's pieces rather than its own. It was first scoped as a `StackTable` (the default export of `src/components/DataTable/index.tsx`, not a component of its own; `components/data-table.md`) for its rows, but M10.11 now builds it as cards in the `CovenCards` pattern (`SpellCard`), so this review covers the card list, not a table. It still uses `FilterForm` and `Pager` for narrowing and paging it, with `FilterSelectField` (`src/components/Field/filter-select-field.tsx`) for a filter's choice, a native select until the page's script loads, then the forms' own dropdown, or a type-ahead for a long list, and `BusyButton` for a button whose request is in flight. A question asked before a step that cannot be undone, such as deleting a spell, is `ConfirmQuestion`, drawn over the form (`components/modal.md`).

_Acceptance criteria:_

- The owner signs off the section's design, in both themes and at phone width, recorded as a comment on this issue. The owner signs off per decision on a private sign-off page, and the decisions are recorded in [`design-decisions/mb.123-design-review-the-grimoire.md`](../design-decisions/mb.123-design-review-the-grimoire.md)
- No page in the section scrolls sideways at 375px, and its body copy keeps to the reading measure
- Contrast holds at 4.5:1 in both themes, and no raw hue or size is added outside `_variables.scss`
- Every page in the section is axe clean with visible keyboard focus, and its e2e specs and stories pass
- Accessibility: the grimoire list, `SpellCard`, `SpellBuilder` with its step editor, the Record a Working dialog and the recipe page pass an axe check in Playwright (`@axe-core/playwright`) in both themes. Each page also gets a keyboard-only and a screen-reader pass against WCAG 2.2 AA, and every failure found is fixed or filed as a task
- UX, with research: the review is backed by published UX guidance for step reordering, the comparison panel, the warnings and the deduction preview (for example Nielsen Norman Group, the GOV.UK Design System, the WAI-ARIA Authoring Practices and Baymard). Each change it makes or rejects names its source, in Chicago form. Wikipedia is acceptable; academic or practitioner sources are preferred
- Storybook and /design-sync: a separate agent, not the one doing the design review, updated every Storybook story that the review's changes affect, covering new states, changed props and removed variants (the stories follow the `States`-first convention), and the workshop build and check pass (`workshop:build`, `workshop:check`, 390 of 390 story loads clean). The owner runs `/design-sync` at the end, so the Claude Design project matches, and every changed story grades `match` or `close`
- Each component's doc updates its Styling section, and its stories show the reviewed design
- The recipe view's print layout is reviewed on paper or as a PDF as well as on screen
- Reordering steps reads clearly by keyboard as well as by pointer
- The deduction preview reads plainly, and a shortfall or a step not deducted is told apart without colour alone
- The comparison panel reads without relying on colour alone

**Amended 2026-10-30 by the review itself** ([`design-decisions/mb.123-design-review-the-grimoire.md`](../design-decisions/mb.123-design-review-the-grimoire.md), plan in [`design-decisions/mb.123-plan.md`](../design-decisions/mb.123-plan.md)): the review changed three rules. The destructive-controls rule in `.claude/rules/components.md` (Delete and Remove live in the edit dialog; a row's Remove or Revoke is drawn plain; red also marks the two high-risk controls, Impersonate and Pause Keeper Changes). The page-head rule in `claude-docs/styling.md`, guarded by `tests/guards/page-heads.test.ts`. The stylelint token rules in `.stylelintrc.json`. It also added a non-blocking knip leg to CI. The estimate is now 11h. That figure is the wall-clock time of the agent run (a floor), not an estimate of human hours.

**MB.125 — Categories on the ingredient writes** · 2h

_Story 30 — As a workspace member, I want the categories I pick saved with the ingredient, so that searching by category finds it._

Minted during M5.9, on the owner's question of whether ingredients get categories. They do — `ingredient_categories` (M4.4), `Ingredient.categories` through M4.8's loader, and the seed tags the compendium — but nothing writes them: M8.8's inputs take no `categoryIds`, and M8.11, which cited story 30, builds its chips as a search filter. This task is the write half; MB.126 is the picker. `categoryIds` joins both Zod variants and every ingredient input — the workspace create and update and the compendium create and update — and DESIGN.md §7's sketch. The service replaces the ingredient's set inside the `withAudit` transaction that writes the ingredient: a pair kept keeps its stamps, a pair dropped is hard-deleted (MB.34), and a pair added is stamped from the session. On update the field is required, as every field of `IngredientUpdateInput` is (M8.8), and `[]` clears it.

_Acceptance criteria:_

- Creating an ingredient with `categoryIds` writes one `ingredient_categories` row per id, stamped from the session, in the ingredient's own transaction — a failed category write leaves no ingredient behind
- Updating replaces the set: a kept pair's `created_by` and `created_at` are unchanged, a dropped pair leaves no row, and an added pair is stamped by the editor
- An id naming no live category, unknown or soft-deleted, is a `VALIDATION` field error at `['categoryIds', i]`; a repeated id is written once
- The returned `Ingredient`'s `categories` are the ones just written
- An observer is refused, as for any workspace write; a compendium entry's categories are written only under the `SiteAdmin` proof
- DESIGN.md §7's sketch and claude-docs/graphql.md name the new field

**MB.126 — Grouped category picker in IngredientForm** · 3h

_Story 30 — As a workspace member, I want to pick categories from grouped chips, so that I can tag an ingredient without scrolling through 63 of them._

Minted during M5.9. Follows MB.36, whose row colours the chips wear, and MB.125, which writes what they pick. It reads the public `categories` query, each live category with its group, paged like every list (rule 8): one page of the hard maximum holds every category there is. M5.6 built the query, on the owner's call ([`design-decisions/m5.6-admin-categories.md`](../design-decisions/m5.6-admin-categories.md)); caching it under the `compendium` tag, as rule 6 allows, is M8.6's. `CategoryPicker` is a component of its own, since M8.11 reuses it as its filter: toggle chips grouped by category group, the groups alphabetical by name and each collapsible, a picked chip filled. `IngredientForm` gains it as a `categoryIds` field after the lists. A `fieldErrors` entry at `['categoryIds', i]` renders on the picker's one error element, naming the chip, as a list entry's does (claude-docs/components/ingredient-form.md).

_Acceptance criteria:_

- Every live category appears under its group, the groups alphabetical, and a group added after the seed appears without a code change
- Each chip wears its group's stored colour for the active theme through MB.36's mixin; a picked chip is distinguishable visually and to assistive technology (`aria-pressed`)
- Groups collapse, and the picker is usable at a 375px viewport
- The form sends the picked ids as `categoryIds`, and `[]` when none is picked
- A server field error at `['categoryIds', i]` renders through `FieldError`, on the picker's error element
- `CategoryPicker` ships a story and a component doc

**Amended while building, the owner's call: the picker is the deities field's box, not a wall of chips** ([`design-decisions/mb.126-categories-on-the-combobox.md`](../design-decisions/mb.126-categories-on-the-combobox.md)). The grouped, collapsible chips were built and reviewed, and the owner asked for the same controls and chip styling as the deities list instead, with the colours kept: `CategoryPicker` is one `Combobox`, its rows the live categories not yet picked, narrowed by the text and listed under their groups' headings, both alphabetical, and each pick a `ComboboxEntry` inside the control in its group's colour through `chipColors`, with its x, Backspace and a Clear. Nothing typed is a category, so there is no Add and no typed row. The second and third criteria read accordingly: a picked category is a coloured entry inside the box, not a pressed chip, and the groups head the list rather than collapse. The Combobox gained a `heading` on its options and a `colors` pair on its entry for it, and its entry's tooltip runs as wide as its words, past the chip and the control, shifted to stay on screen. On the same review, the `categories` query orders by group name then category name, so the admin list does too, and an entry's tooltip reads the name with its group in brackets, then the description. DESIGN.md §6 and §14 follow; M8.11's filter is the same box, and its "each group collapses" criterion is for M8.11 to settle.

**MB.127 — Make deities an admin-curated vocabulary** · 2.5h

_Story:_ As a keeper, I want the deities the autofill offers to be a list I curate, so that a practice's gods are spelled one way and a missing one needs no deploy.

Documentation and scoping only, in MB.91's shape: the model is recorded before the table task transcribes it. Minted during M5.9, on the owner's decision that the deities field searches a curated list, as planet and zodiac do, rather than only the values already in use. `deities` becomes a flat table shaped like `planets` — `name`, `slug`, `description` and the audit spread — and `ingredients.deities` stays `text[]`, by §5's rule that a vocabulary a member writes is text. Two differences from MB.91 are recorded rather than glossed: the ingredient column is an array, so the in-use scan unnests it; and the seeded compendium names no deity at all, so the starting list is the owner's to supply. This task also settles whether `description` is required, as it is for a planet, given a seed of many deities across pantheons.

_Acceptance criteria:_

- DESIGN.md §5 re-points `deities[]` at the vocabulary; its admin sentence, §7 (the `compendium` tag covers six reads), §9's route table (`/admin/deities`) and §14 rows follow, as do CLAUDE.md's curation invariant and rule 6
- The owner's starting list is recorded with its source, for MB.129 to seed
- db.md and modules.md name the table and the module that owns it

**Widened while building, the owner's call: deities are grouped by tradition.** The model is two-tier, `ingredient_forms` and `ingredient_form_groups` in shape rather than `planets`'s flat one: `deity_traditions` (`id`, `name`, `slug`, `description`, + audit) and `deities` with a NOT NULL `tradition_id`, one tradition per deity, each suggestion labelled with its tradition as a form's is with its group. **`description` is required on both**, NOT NULL with a non-blank CHECK: the seed's size argues for it, since the description carries the tradition and the other spellings a reader types, which is how one curated spelling is found by the rest. **The list lives in [`db/deity-vocabulary-seed.md`](../db/deity-vocabulary-seed.md), not DESIGN.md §5**: thirty-five traditions and 216 deities, the owner having asked for 100 to 200, each with its description, so MB.129 transcribes rather than writes them. The model is [`db/deity-vocabulary.md`](../db/deity-vocabulary.md). MB.128, MB.129, MB.130, MB.131 and MB.132 are amended to the two tiers below. **The list's sources were gathered under the rule minted here** (CLAUDE.md, "What the compendium says, it sources"; MB.151 to MB.156): the seed doc's Sources section cites, in Chicago bibliography form, the correspondence references the deities were chosen from, one to three reference works per tradition beside the Wikipedia lists the spellings were first checked against — academic where one exists, Wikipedia a valid source where none does, the owner's call — and a citation beside each deity whose filing or spelling was a judgement call, every link fetched before it was cited, so that MB.156 can write them as rows. **The list was regrouped and widened on the owner's review**: a tradition is a people or a religion, never a region, so Celtic, Mesopotamian and Levantine, Norse and Germanic, Chinese, Mesoamerican, Andean and Folk and modern pagan split into seventeen (DESIGN.md §14), and five African traditions — Akan, Igbo, Fon and Ewe, Kongo and Zulu — were added from their own scholarship, 28 rows, which is how twenty traditions and 188 deities became thirty-five and 216. Twenty-one rows were reworded to what their sources carry, and the seed doc says which and why.

**MB.128 — `deities` schema** · 1.5h

_Story:_ As a keeper, I want the deity vocabulary to be rows, so that the autofill has something a keeper can edit.

Table task, as MB.92, in `ingredient-forms.ts`'s two-tier shape (MB.127): `src/modules/vocabulary/schema/deities.ts` gains `deity_traditions` — `id`, `name`, `slug`, `description` — and `deities` — `id`, `name`, `slug`, `description`, `tradition_id` NOT NULL referencing `deity_traditions` — each with the six-column audit spread, a NOT NULL `description` with a non-blank CHECK, and a partial unique index on `slug` where not deleted; one `gin_trgm_ops` index on `deities` over `(name, description)`, since the suggestion query matches both. The migration appends two `CREATE OR REPLACE TRIGGER set_updated_at` lines, per CLAUDE.md rule 3.

_Acceptance criteria:_

- Both tables carry exactly their columns plus the audit spread — asserted from `getTableConfig` and the catalogue
- `slug` is unique among live rows on a partial index on each, freed by soft delete; a blank `description` on either is a 23514 naming the CHECK
- `deities.tradition_id` is NOT NULL and references `deity_traditions`; it and the audit stamps are the only foreign keys
- The `(name, description)` trigram index exists on `deities`, asserted from the catalogue
- `ingredients.deities` stays a nullable `text[]` with no foreign key to either table
- `AUDITED_TABLES` gains both names; `tests/db/updated-at-trigger.test.ts` passes
- Nothing reads the table yet

**MB.129 — Seed the deity vocabulary** · 2h

_Story:_ As a keeper, I want a starting list of deities already curated, so that the autofill offers something before the first one is typed.

As M4.3a's form seed rather than MB.93's flat one, since MB.127 groups deities by tradition: `src/db/seed/deities.ts` holds `DEITY_TRADITIONS` and `DEITIES` (`{ name, tradition, description }`), transcribed from the two tables in `claude-docs/db/deity-vocabulary-seed.md`, written through `seedTwoTierVocabulary`, with every slug derived by `slugify`. Names are copied as written, not title-cased: `Manannan mac Lir`. `standard` seeds it inside its own transaction. `scripts/db-seed.ts` gains a `deities` target, `migrate.yml`'s reference-seed step a line, and `deploy.yml`'s seed-changed paths the new file.

_Acceptance criteria:_

- Every tradition and deity MB.127 records is seeded, in its order, under its tradition and with its description, and nothing else — parsed from the doc at test time, the parse itself checked (thirty-five traditions, 216 deities)
- Names and descriptions are pairwise distinct within each table, and every description is non-empty
- Reseeding adds nothing, resurrects nothing a keeper soft-deleted, and overwrites no description a keeper rewrote
- Rows are stamped by the bootstrap user with the GUC published
- `migrate.yml` runs the new target beside the others; `deploy.yml` re-seeds when the new file changes

**MB.130 — Scoped suggestion field for deities** · 2.5h

_Story:_ As a workspace member, I want the deities field to suggest from the vocabulary and from what my workspace already uses, so that I do not write Hecate three ways.

Adopts MB.94's `findVocabularySuggestions`, pairing `deities` with `ingredients.deities`. The column is an array, so the in-use scan unnests it before it trims and lower-cases, adopting the scan MB.136 built for the planet and zodiac lists. `deitySuggestions(workspaceId, query)` is a `pagedConnection` carrying each curated row's tradition, as `formSuggestions` carries a form's group, so it pairs the deity tables the way forms pair theirs, and is `FormSuggestion`'s shape rather than `CorrespondenceSuggestion`'s: curated rows first, matched on name then description, then in-use uncurated values from the compendium and the current workspace only. A deity is curated only while its tradition is live too, as a form is (MB.127).

_Acceptance criteria:_

- Curated first, uncurated second, distinguishable; a name match outranks a description match
- A curated suggestion names its tradition; a deity whose tradition is soft-deleted is offered as uncurated, with no tradition
- A value in use only in unrelated workspace X never appears — asserted by direct query, with the precondition that X holds it
- `Hecate` and `hecate` in two ingredients' arrays are one in-use value, and a value equal to a curated name is not offered twice
- Filtered in SQL; soft-deleted rows excluded; bounded by the M3.6 helper; the match uses `%` and `<%` with explicit thresholds, as MB.94's does

**MB.131 — Deity, planet, zodiac and substitute lookups in IngredientForm** · 3h

_Story 16 — As a workspace member, I want the deity, planet, zodiac and substitute fields to suggest from what already exists, so that I pick an entry rather than typing a fourth spelling of it, and a substitute I pick leads to its ingredient._

Minted during M5.9, and widened in the same review once planet and zodiac became lists and a substitute could link an ingredient. Follows M5.10a, whose `Combobox` it reuses, MB.130, and MB.136 and MB.140, which make those changes. The Deities, Planets, Zodiac signs and Substitute ingredients boxes are already that combobox, since M5.10a puts it on every list field (amended during MB.136); this task gives each its source: deities over `deitySuggestions`, planets and signs over MB.94's `planetSuggestions` and `zodiacSuggestions`, each with curated values distinguished from in-use ones; substitutes over MB.138's `ingredientSuggestions`, the compendium and this coven. A compendium entry's form reads `compendium(query)` instead, since its substitutes may link only the compendium; that form is M5.5's, and so is the wiring (amended during MB.131, when `IngredientForm` still wrote a coven's ingredient alone). Picking a deity, planet or sign adds its text as an entry. Picking an ingredient adds a linked substitute, its pill reading as that ingredient. Free text is still added by Add or Enter, and a typed substitute stays text. Text left in a box, neither picked nor added, still stops the save, as M5.9's boxes do. Colour keeps no suggestions, the owner's call, and folk names keep M5.10a's. The planet and zodiac lookups moved here from M5.10a once they became lists.

_Acceptance criteria:_

- Typing in any of the four boxes suggests, debounced; picking adds an entry and empties the box
- A deity, planet or sign suggestion shows whether it is curated, and a curated deity its tradition, "Hecate (Greek)", as a form shows its group; a substitute suggestion shows the ingredient's formal name and whether it is the compendium's or this coven's
- Picking an ingredient saves a link, and a substitute typed without picking saves as text, without a warning
- Arrow keys move through the suggestions, Enter picks one, Escape closes them, and Enter with none open adds the typed text

**MB.132 — Admin deity CRUD** · 2.5h

_Story 18 — As a site keeper, I want to add, edit and soft-delete deities, so that the vocabulary can grow without a deploy._

`/admin/deities` and `/admin/deity-traditions`, reusing MB.95's page shape and M5.6b's for the groups, since MB.127 groups deities by tradition. `DeityInput` (with its tradition) and `DeityTraditionInput` in `vocabulary/validation/`; create, update and soft-delete mutations on both, admin-gated in the service and firing the `compendium` cache tag. The deities page lists each deity under its tradition; a deity is curated through the create form, which asks for a description and a tradition. Lands after MB.95, before M5.7, which gates it.

**The compendium holds curated deities alone (MB.162), and these pages keep it so after the write**, as MB.95's do (amended by MB.162, [`design-decisions/mb.162-compendium-holds-curated-values.md`](../design-decisions/mb.162-compendium-holds-curated-values.md)). Soft-deleting a deity a live compendium entry picks is refused, with an error naming the entries — the first few and how many more — and so is soft-deleting a tradition while a deity under it is so picked, since a deity is curated only while its tradition is live; the keeper edits the entries first. Renaming a deity carries the new spelling onto the name of every such entry's `ingredient_deities` row, in the same transaction; renaming a tradition touches no ingredient. **Both follow the pick** (amended by MB.167, [`design-decisions/mb.167-read-and-write-the-pick.md`](../design-decisions/mb.167-read-and-write-the-pick.md)): a compendium entry's deities are picks, `ingredient_deities.deity_id`, so an entry is held by the one deity it picked, and Greek Hecate's delete is not refused by an entry that picked Roman. The reads find the rows by `deity_id`, and this task adds the index on it they want, since MB.165 built none. A coven's ingredients never block a delete and are never rewritten. MB.163 later moves the rename's rewrite to a background job. What else soft-deleting a tradition does to its deities is still decided here, as M5.6b decides it for form groups. The deities page carries no to-do list of in-use values outside the vocabulary, as first scoped: under MB.162 the compendium holds none, and a keeper reads no workspace's ingredients.

**Corrected while building, on the owner's calls** ([`design-decisions/mb.132-admin-deities.md`](../design-decisions/mb.132-admin-deities.md)). **Deleting a tradition moves its live deities to another live tradition the admin picks**, M5.6b's two steps for form groups, rather than being refused while a deity under it is picked: the deities stay curated, so no entry's pick is orphaned. **A deity's slug is its name and its tradition's**, `deitySlug`, as M5.6a made a form's its name and its group's, so a Greek and a Roman Hecate both fit: the seed re-derives its slugs, and a tradition's rename and delete re-slug its deities, refused on `name` or `moveTo` where one would collide. This amends MB.162 for traditions, as M5.6b amended it for form groups. **The rename's rewrite is a twenty-third writer method, `carryDeityRename`**, since `vocabulary` may not name `ingredient_deities`. **`CategoryForm` and `IngredientFormValueForm` fold into one `GroupedValueForm`, and `CategoryList` and `IngredientFormValueList` into one `GroupedValueList`**, each keyed by a `kind`, before the deity kind is added, rather than a third copy of each: in this PR, by the owner's call, though it is a refactor beside the task. Firing the `compendium` tag is M8.7's, as MB.95 corrected for its writes, and M8.7's entry names these. **Every group page numbers its pages**, the traditions' running to two: `GroupList` takes a `position`, each group service a count over a generic `findPageCount`, and one `resolveNumberedPage` replaces the eight copies of each admin page's read-then-count.

_Acceptance criteria:_

- Admin can create, edit and soft-delete deities and traditions; each list is alphabetical by name, deities within their tradition
- A slug collision is a readable error pathed to `name`; a deity's slug carries its tradition, so two traditions may each hold a deity of one name (corrected while building)
- Soft-deleting a deity while a live compendium entry picks it is refused, naming the entries, and the row stays live; it passes once no live entry holds it (amended by MB.162). Soft-deleting a tradition first moves its live deities to the live tradition the admin picks, and is never refused for an entry's pick (corrected while building)
- Renaming a deity rewrites the name of every live compendium entry's row picking it, in place and in the same transaction, asserted by row; a soft-deleted entry keeps the old spelling (amended by MB.162, on the pick by MB.167)
- A coven's ingredient never blocks a delete and is never rewritten by a rename, asserted by row with the precondition that it picked the deity (amended by MB.162 and MB.167)
- Non-admins reach neither the page nor any mutation (firing the tag is M8.7's, corrected while building)
- The category, form and deity pages share one form and one list component, each by its `kind` (corrected while building)
- Every group page, the traditions' included, says which page of how many (corrected while building)

**MB.133 — Long list entries in IngredientForm** · 1h

_Story:_ As a workspace member, I want a long folk name, deity or substitute ingredient to stay inside the form, so that one long entry does not push the page sideways or bury the others.

Minted during M5.9, on the owner's review. An entry in one of M5.9's list fields is a pill, `.ingredient-form__entry`, sized to its text, and nothing bounds it: the shared schema sets no length on a list entry, and the pill is an `inline-flex` whose text keeps its minimum content width. So an unbroken string wider than the column — a binomial run together, a pasted address — should run past the form's edge and scroll the page sideways, and a long entry in words should wrap inside a pill whose rounded ends were drawn for one line. That is read from the styles rather than yet seen, and the task confirms it first. It settles how a long entry is drawn: wrapped inside the pill, with its ends eased so a two-line pill still reads as one, or truncated with an ellipsis. Either way the whole text stays reachable: the entry's × already names its full value, and a truncated entry shows all of it somewhere a sighted user can read it. Whether a list entry also takes a length cap in the shared schema, and at what length, is decided here with the owner, since a cap binds the service as well as the form.

_Acceptance criteria:_

- An entry of any length stays inside the form's column, and nothing scrolls sideways at 320px, with an entry of 80 unbroken characters and one of 80 characters in words, in each of the three lists
- The entry's whole text stays readable, and its × is still named by the full value
- A one-line entry looks as it does now
- If a length cap is added, it is in the shared schema, its message lands on the list's error element, and the service refuses the same length
- Checked by hand in the workshop at 320px in both themes until M5.5's page holds the form for a Playwright spec to assert it; the component doc's Styling section records the rule

**MB.134 — Make planet, zodiac sign and colour lists** · 1.5h

_Story:_ As a workspace member, I want an ingredient to carry more than one planet, sign or colour, so that a herb ruled by both Venus and the Moon is recorded as it is practised.

Documentation and scoping only, in MB.91's shape: the model is recorded before the table task transcribes it. Minted during M5.9, on the owner's decision. DESIGN.md §5 gives `planet`, `zodiac` and `color` one text value each; they become text arrays beside `deities[]`, and stay free text: the planet and zodiac vocabularies suggest and nothing refuses, and colour has no vocabulary and no suggestions at all, the owner's call. Folk names keep M5.10a's suggestions; colour is the one list without any. This task settles the new column and field names; the GraphQL change, the single fields on `Ingredient` and both inputs replaced by lists with no deprecation window, since nothing outside the app reads the API; the sequence rule 10 requires, MB.135 adding and filling the lists, MB.136 switching every reader and writer and ceasing to declare the old columns, and MB.137 dropping them once a release carrying MB.136 has reached production; and the in-use scan MB.94 built for a single column, which must unnest an array, as MB.130 needs for deities too. MB.136 lands first by the order, so it builds that scan and MB.130 adopts it. M5.10a's planet and zodiac fields move to MB.131 as list lookups.

_Acceptance criteria:_

- DESIGN.md §5's column list and correspondence rows and §7's sketch carry the three lists; §14's form-library row names every list field
- The column and field names, and whether a list keeps the order entered, are recorded
- db.md and validation.md say how the three lists are validated, as `deities` already is

**MB.135 — List columns for planet, zodiac sign and colour** · 1h

_Story:_ As a developer, I want the list columns in place before any code reads them, so that the switch to lists is a code change against columns that already exist.

Table task, the expand half of rule 10. `ingredients` gains three nullable `text[]` columns, named as MB.134 records, and the migration fills each from its single column where one is set. The single columns stay declared and written until MB.136. Nothing reads the new ones yet.

_Acceptance criteria:_

- The three columns exist as nullable `text[]`, asserted from the catalogue
- Every row with a value in a single column carries it as a one-entry list, and no row without one gains a list, asserted against the seeded template
- The migration only adds, so the destructive-DDL check passes with no sidecar
- The single columns are unchanged

**MB.136 — Read and write planet, zodiac sign and colour as lists** · 3h

_Story:_ As a workspace member, I want to add several planets, signs and colours to an ingredient, so that it records every correspondence I work with.

Switches every reader and writer to MB.135's columns. The shared Zod schema takes each as a list of free text, blank entries dropped as for `deities`; the workspace and compendium services write them; GraphQL's `Ingredient` and both inputs carry the lists; the planet and zodiac suggestion fields' in-use scan unnests a list, the mechanism MB.130 then adopts for deities; the seed and the test fixtures write lists. `IngredientForm`'s Planet, Zodiac sign and Colour become M5.9's list fields in the same PR, since the form's types follow the schema; their lookups are MB.131's. The Drizzle schema stops declaring the single columns, rule 10's first half of a drop, and the migration fills the lists again for any row the live deploy wrote to a single column after MB.135.

_Acceptance criteria:_

- A save carries several planets, signs and colours, and an edit replaces each list whole
- Each list keeps the order entered, drops blank entries, and treats an empty list as absent
- `planetSuggestions` and `zodiacSuggestions` count a value in use once however many lists hold it, still scoped to the compendium and this coven — a value only another coven holds never appears, asserted with the precondition that it holds it
- The seed and fixtures write lists, and the SDL snapshot moves
- Nothing declares or reads the single columns, which still exist
- The form's three fields are list fields with their info tips, covered by its tests

**MB.137 — Drop the single planet, zodiac and colour columns** · 1h

_Story:_ As a developer, I want the retired single columns gone, so that nothing can write a value the app no longer reads.

The contract half of rule 10, a task of its own. Once a release carrying MB.136 has reached production, the migration drops `planet`, `zodiac` and `color`, with its `.ack.md` sidecar. Production is the gate rather than staging because v0.4.0 still declares the singles, and a release carrying MB.136 and this drop together would drop them under it. Scoped first with a last fill from the singles, and dropped on the owner's decision: MB.136's deploy writes the lists, so a single that disagrees with its list may be either's newer write, and a fill would overwrite a member's edit to recover a write from a deploy-length window (claude-docs/db/identity-model.md, "The ingredient identity model").

_Acceptance criteria:_

- The three columns are gone, and the lists hold every value they held
- The migration carries its acknowledgement sidecar, and the destructive-DDL check passes with it
- Lands only after a release carrying MB.136 has reached production

**MB.138 — Let a substitute link an existing ingredient** · 3h

_Story:_ As a workspace member, I want to pick an existing ingredient as a substitute or type one that is not entered, so that a substitute I have recorded leads to its own page.

Scoping, and the picker's search. Minted during M5.9, on the owner's decision: `ingredients.substitutes text[]` becomes a child table, one row per substitute, each either a link to an ingredient or a free-text name, the shape MB.40 gave a spell's layers, `CHECK (num_nonnulls(substitute_id, name) = 1)`. This task settles which ingredients a substitute may link: a compendium entry only another compendium entry, since the compendium is public and a coven's entries are not, and a coven's ingredient either tier, its own coven's included. It settles what a link does when its ingredient is deleted, kept and shown by its last name or turned to text; whether a row takes the full audit spread, as content like a folk name, or the stamp columns and a hard delete, as a link (MB.34); whether the list keeps its order; the GraphQL shape, a `Substitute` carrying `name` and a nullable `ingredient`, resolved through a DataLoader (rule 9); and which search the form's picker reads for ingredients to link, since `commonNameSuggestions` returns names rather than ids. The expand, switch and drop follow as MB.139 to MB.141. **Widened while it was built, on the owner's call:** no existing query fits the picker — `possibleDuplicates` compares whole names and never completes a prefix, and `workspaceIngredients` lists only what a coven holds, in wave 11 — so this task also builds the one it names, `ingredientSuggestions`, ahead of MB.131. **Decided** ([`design-decisions/mb.138-substitute-links.md`](../design-decisions/mb.138-substitute-links.md)): a compendium entry links only the compendium, a coven's ingredient either tier; a link to a deleted ingredient is kept and shown by its last name, the owner's choice, through a third named finder in M5.3's shape; the full audit spread, soft-deleted; alphabetical by the name each shows, and each substitute once, both the owner's calls, so nothing stores an order; `Substitute { name, ingredient }`.

**Amended by MB.215 (2026-10-11):** the substitute picker ranks a matching form first, then its form group, then the rest, and links a variant when the linked ingredient has them, as MB.217 to MB.221 build it ([`design-decisions/mb.215-ingredient-variants.md`](../design-decisions/mb.215-ingredient-variants.md)).

_Acceptance criteria:_

- DESIGN.md §5 gains the table and drops `substitutes[]` from the column list, §7's sketch gains `Substitute`, and §9's detail page links a linked substitute
- The tier rule, the deletion rule, the audit shape and the order rule are each recorded with its reason
- The picker's search is named, scoped to the compendium and the current coven
- `ingredientSuggestions` answers a reader of the coven with the live ingredients of the compendium and that coven, matched as `compendium` matches, best first, and never another coven's, asserted with the precondition that another coven holds a match

**MB.139 — `ingredient_substitutes` table, filled from the list** · 1.5h

_Story:_ As a developer, I want the substitutes table in place and filled before any code reads it, so that the switch to links is a code change against rows that already exist.

Table task, in MB.138's shape: the table, its CHECKs, an index on the parent over live rows, the two partial unique indexes that hold one link per ingredient and one name per ingredient case-insensitively, and the full audit spread MB.138 chose, so its own `set_updated_at` trigger line. **Amended by MB.138:** no index on the linked ingredient, since under its deletion rule nothing reads from a linked ingredient back to its linkers. The migration copies each `substitutes` entry across as a name. `ingredients.substitutes` stays declared and written until MB.140. Nothing reads the table yet.

_Acceptance criteria:_

- The shape is asserted from the catalogue, and a row that is both a link and a name, or neither, or that links its own ingredient, is a 23514 naming its CHECK
- Every existing entry is a name row, and a list repeating an entry, in any case, is copied once, in the spelling it first holds, so the unique index never refuses the fill
- A second live link to the same ingredient, or a second live name folding alike, is a 23505 naming its index, and a soft-deleted row reserves neither
- `AUDITED_TABLES` and `tests/db/updated-at-trigger.test.ts` agree with the full audit spread MB.138 chose
- Nothing reads the table yet

**MB.140 — Read and write substitutes as links or text** · 3h

_Story:_ As a workspace member, I want a substitute I pick to stay linked to its ingredient, so that the detail page can lead me to it.

Switches substitutes to MB.139's table. The shared schema takes each entry as a name or an ingredient id, and refuses a repeat — the same id twice, or the same name in any case — at the repeat's position, as it refuses a repeated folk name; the services write them in the ingredient's own `withAudit` transaction, bringing the live rows to the list sent as folk names are replaced, so a save that changes nothing writes nothing, and refuse a link the tier rule forbids, as a field error pathed to the entry; GraphQL's `Ingredient.substitutes` returns MB.138's `Substitute`, through a loader whose finder reaches a linked ingredient deleted or not — MB.138's third named `…IncludingSoftDeleted` finder, added to `tests/guards/soft-delete-finder-guard.test.ts`'s pinned hatches and held to skipping the linked ingredient's filter alone; the seed and fixtures follow; the Drizzle schema stops declaring `ingredients.substitutes`. `IngredientForm`'s substitute entries carry a link or a name in the same PR, a linked entry's pill reading as its ingredient's label with its formal name. Picking a link in the form is MB.131's.

_Acceptance criteria:_

- A save carries linked and typed substitutes together, read back alphabetically by the name each shows
- A repeated link or name is a field error pathed to the repeat, never the index's 23505
- A compendium entry cannot link a coven's ingredient, and a coven's cannot link another coven's — refused by direct id, with the precondition that the id exists
- A page of ingredients resolves its linked substitutes in one query, through a DataLoader
- MB.138's deletion rule holds, asserted by soft-deleting a linked ingredient: the substitute reads as its last name with no `ingredient`, survives a save of its parent, and a new link to the deleted ingredient is refused
- Nothing declares or reads `ingredients.substitutes`, which still exists

**MB.141 — Drop `ingredients.substitutes`** · 1h

_Story:_ As a developer, I want the retired substitutes column gone, so that nothing can write a substitute the app no longer reads.

The contract half of rule 10, a task of its own. Once MB.140 has deployed, the migration copies anything written to the column since MB.139 across as names, then drops it, with its `.ack.md` sidecar.

_Acceptance criteria:_

- The column is gone, and the table holds every substitute it held
- The migration carries its acknowledgement sidecar, and the destructive-DDL check passes with it
- Lands only after MB.140 has deployed to staging

**MB.142 — Cut the per-turn context: plugin, reporters, stale MCP** · 1h

_Story:_ As a developer, I want a session to start from the context this repo needs and no more, so that every turn of every task stops paying for a plugin it never uses and a test table it never reads.

Minted on the owner's request to cut the tokens a task costs, the first of six ([design-decisions/mb.142-plan.md](../design-decisions/mb.142-plan.md)). Measured: `CLAUDE.md` is 63 KB, and the Vercel plugin's 49 skills, ~250 tool names and session hook are another ~10k tokens, on every turn, for a repo whose deploys are CI-only (M0.26); `npm run test:coverage` prints ~200 coverage rows and one line per test file, several times a task. The plugin is disabled at project scope, the stale `asana` MCP entry goes with the board that left it, and the reporters are quiet under Claude Code only: `CLAUDECODE=1` is set in its shell and nowhere else, so the host and CI see what they see today.

_Acceptance criteria:_

- `.claude/settings.json` disables `vercel@claude-plugins-official` for this repo, and a fresh session lists none of its skills or tools
- `.claude/settings.local.json` names no `asana` server
- Under `CLAUDECODE=1`, Vitest reports with `dot`, coverage with `text-summary`, and a passing test's console output is dropped (`silent: 'passed-only'`); without it all three are as before, and CI's run is unchanged
- The plan is stored as `design-decisions/mb.142-plan.md`, and testing.md says where the per-file coverage numbers are read when the table is not printed

**MB.143 — Split TASKS.md by milestone and wave** · 3h

_Story:_ As a developer, I want a task's entry and its wave's reasoning to be readable without the 800 KB around them, so that starting a task costs a page rather than a book.

The first move ([design-decisions/mb.142-plan.md](../design-decisions/mb.142-plan.md)), verbatim: each `## M0 …`, `## MB …` and `## MW …` section becomes `claude-docs/tasks/<milestone>.md`, and the execution-order table's reasoning column becomes `claude-docs/waves/wave-NN.md`, the table keeping its id cells and a link. `TASKS.md` keeps the preamble, the deferrals and the table, and indexes the rest. `scripts/tasks-md.mjs` reads the files in a declared sequence and concatenates them, since a range like `M3.3 → M3.10` is the headings between its ends in file order; `tally.mjs` reads the same list. `start-task` reads the task's entry by its heading and its wave file, not "the milestone".

_Acceptance criteria:_

- `claude-docs/tasks/` holds one file per milestone section and `claude-docs/waves/` one per wave, each moved without a rewrite, and `TASKS.md` is under 40 KB
- `tasks-md.mjs` exports the file sequence, `loadTasksMd` and `tally.mjs` read through it, and a test fails on a file in `claude-docs/tasks/` the sequence does not name
- `node scripts/task-board.mjs reorder` prints no moves, and `tally.mjs` prints the figures it printed before the split
- `start-task`, CLAUDE.md's "Minting a task", task-tracking.md's "Order" and README.md name the new paths

**Decided while building.** The sections keep their `## ` headings and the wave files gain a `# Wave NN — name` line; the one edit the move needed was a `../` on each of the 94 links relative to `claude-docs/`, since the files sit one directory down. `tally.mjs` skips a file the ref lacks: `origin/main` and every ref before the split hold the whole breakdown in `TASKS.md`, so the figures are the same there as here, and a bad ref still fails on the `rev-parse` it runs first.

**MB.144 — Slim CLAUDE.md into path-scoped rules** · 3h

_Story:_ As a developer, I want the rules for the area I am editing in front of me and the rest out of the way, so that a turn on a component does not carry the database's rules, or the reverse.

`CLAUDE.md` goes from 63 KB to about 18: the vocabulary, a ten-row command table, the ten architecture rules cut to their binding sentences and keeping their numbers (tests cite `CLAUDE.md rule 4` by number), the domain invariants, the testing bullets every test obeys, the conventions, out of scope, the skills table and a ten-line task-tracking summary. The long forms go to `.claude/rules/<area>.md` with a `paths:` frontmatter, which Claude Code loads only when a matching file is read or edited — `database`, `graphql`, `components`, `testing`, `task-tracking` — and the long command table to `claude-docs/commands.md`. The redundancy that is CLAUDE.md's own goes in the same pass: TASKS.md's eleven standing rules become one line citing it, `create-pr` loses its stale notes and restatements, and `create-feature` and `create-hotfix` become wrappers over one shared reference. A precedence line says `DESIGN.md` wins over `CLAUDE.md`, which wins over a rule file.

_Acceptance criteria:_

- `CLAUDE.md` is at most 20 KB, and every `CLAUDE.md rule N` a test cites still names the same rule
- Each `.claude/rules/*.md` carries a `paths:` list, and a fresh session that opens a file under `src/db/` has the database rule in context while one that opens `src/components/` does not
- TASKS.md's "Standing rules" is one line, and `create-feature` and `create-hotfix` share one reference file
- `tests/guards/doc-citation.test.ts` passes, and every citation in a rule file resolves

**Decided while building.** A fresh `claude -p` session settled what loads a rule file — the Read tool opening a file its globs match, and never a shell read ([`agent-skills.md`](../agent-skills.md), "Rule files", has the probe). `CLAUDE.md` therefore names every rule file and says to open the one for the area being edited, and `tests/guards/claude-rules.test.ts` checks each glob with picomatch, the matcher Vitest uses, rather than asking Claude Code. That guard also holds `CLAUDE.md` to 20,000 bytes and pins each numbered rule to the clauses code cites it for. `doc-citation.test.ts` now reads `CLAUDE.md` and every markdown file under `.claude/`. TASKS.md's standing rules were all in `CLAUDE.md` bar one, that the OAuth handshake at `/api/auth/*` carries no application data, and code cites rule 1 for it, so rule 1 took it. The comment rule and the doc-correction rule bind every area, so their long forms went to README.md's "Comments in code" and "Correcting a doc" rather than to a rule file. The Skills table keeps its rows and triggers with shorter descriptions, since a session already lists each skill's own. The shared branch steps are `create-feature/reference-branch.md`, so that every directory under `.claude/skills/` is a skill. `create-release` and `create-main-sync` lose the same stale `gitflow` hedge `create-pr` did, one sentence each.

**MB.145 — Split db.md by section** · 4h

_Story:_ As a developer, I want one section of the database summary to cost one section, so that reading how keyset pages work does not mean reading 236 KB.

Verbatim: each of the 37 `## ` sections moves to `claude-docs/db/<slug>.md`, and `db.md` becomes the index, keeping every `## ` heading with one sentence and a link. The doc-citation guard resolves a `db.md, "Section"` cite by heading prefix in the cited file, so the 105 section citations and 159 plain citations in code keep resolving and no code file changes. Intra-doc `#anchor` links move to the new files.

**Widened while building, on the owner's decision.** The five subsections large enough to read alone — "Fuzzy matching", "Ingredient slugs", "The member's autofill", "The finder convention" and "What a `sql` fragment is for" — move to files of their own, each leaving a one-line pointer where it stood. Every section citation in code and in the other summaries then names the file its section lives in rather than `db.md`, and the guard fails one that names a split summary's index, so the index is for reading and not a hop every citation pays. The move's fallout is corrected in the same PR: a mention of a section that now sits in another file, "above", "below" or by name, becomes a link to that file, and the client-import exemption count, "four" in three sections and three comments since MB.87 split the repository, becomes six.

_Acceptance criteria:_

- `claude-docs/db/` holds one file per section and per carved subsection, moved without a rewrite bar links, and `db.md` lists every one under its original heading
- `tests/guards/doc-citation.test.ts` fails a section cited through a split summary's index, reads a citation whose section starts the next comment line, and passes
- No `db.md#` link remains in `claude-docs/`, no "above" or "below" in `claude-docs/db/` points into another file, and a section named in another file is a link
- README.md names the layout and the citation rule

**Decided while building.** The index keeps every `### ` heading too, each linked to where it lives: the guard matches a cited section against a heading at any level of the cited file, and 35 of the 103 section citations named a subsection. That puts the index at 15 KB rather than the plan's 6. The sections keep their `## ` headings, as MB.143's did; a carved subsection's `### ` becomes its file's `## `, and each file is named for its heading, shortened and without the task id. Nine citations put the quoted section on the next comment line, which the guard's pattern did not read, so they had never been checked; it reads them now, and all nine resolved. Five citations named `db.md` alone but meant one section — `check-destructive-ddl.ts`'s message among them, naming a "Migrations section" no heading carries — and point at that section's file; `.claude/rules/database.md`'s means the whole summary and keeps the index. Comment lines the longer paths pushed past 100 columns were rewrapped to their paragraph's width. A mention that names a section in another file without "above" or "below" still read correctly, but no longer resolved by searching the file it sits in, so on the owner's decision it became a link too. On the owner's request the split and the repoint are kept, as `scripts/split-doc.mjs` and `scripts/repoint-doc-citations.mjs`, for MB.146: the repoint reads citations through `scripts/doc-citations.mjs`, which the guard now imports too, so the rewrite reaches exactly what the guard reads, and anchors come from `github-slugger`, GitHub's own algorithm, rather than a hand-kept pattern. Found along the way and fixed here, as a sub-hour fix: `src/db/repository/index.ts` still imported `users` first against a `users` ↔ `audit.ts` cycle MB.86 had removed. The import goes, with the comments and records that argued for it; the test that entering through the repository builds `users` with its audit columns stays, and a cycle put back makes it throw.

**MB.146 — Split auth.md, ci.md, testing.md and graphql.md by section** · 3h

_Story:_ As a developer, I want the next four largest summaries to cost a section each, so that the auth doc's 35 KB bootstrap section is read only by the task that needs it.

MB.145's move for the next four, 47 sections into `claude-docs/auth/`, `ci/`, `testing/` and `graphql/`, each original file becoming its index. Nothing is condensed here: `auth.md`'s "Admin bootstrap and the self-created user" moves as is, and MB.147 shortens it. As in MB.145, and with its `scripts/split-doc.mjs` and `scripts/repoint-doc-citations.mjs`, every section citation in code and in the other summaries then names the file its section lives in, since the guard fails one named through an index — 138 on one line alone, by the count taken during MB.145 — and a mention of a section that now sits in another file, "above", "below" or by name, becomes a link to it.

_Acceptance criteria:_

- The four directories hold one file per section, moved without a rewrite, and each index lists every one under its original heading
- `tests/guards/doc-citation.test.ts` passes, no section citation in code or another summary names one of the four indexes, and no intra-doc anchor link is left dangling
- No "above" or "below" in the four directories points into another file, and a section named in another file is a link

**Decided while building.** Each file is named for its heading, shortened as MB.145's were, and no subsection is carved out, since nothing here is condensed. The repoint reached 148 section citations in code rather than 138: `CLAUDE.md`'s cite of "The email page" closes its code span before the comma, a form `scripts/doc-citations.mjs` did not read, so the guard had never checked it; it reads it now, with a test. Four comments that named one of the four summaries alone but meant one section point at that section's file, as do 23 such mentions in other summaries, and those meaning the whole summary keep the index: the two rule files, DESIGN.md's CI inventory, and `db/migrations-and-scripts.md`'s pointer to both test harnesses. The other summaries' 38 section citations name the file too, which mends `components/email-form.md`'s link to `auth.md`, written as if from the directory above; decision records, task entries and transcripts keep theirs, as in MB.145. In `auth/tests.md`, "the wiring above" meant the whole summary and reads "the auth wiring". Paragraphs a link lengthened were rewrapped at 80 where they were already wrapped there, never inside a code span, which prettier outdents.

**MB.147 — One home per fact across the docs** · 3h

_Story:_ As a developer, I want each fact stated once and cited elsewhere, so that a correction is one edit and a read is one page.

Measured before the pass: 6,537 eight-word runs occur in two or more of the 82 live docs and skills. The largest pairs are TASKS entries restating the design-decision plans and DESIGN.md's sections, db.md restating §5's data model, and the wave reasoning kept three times — the table column, the milestone preambles and each GitHub milestone description. The rule, added to README.md beside "a summary must stand on its own": a summary stands on its own for the current shape and cites for the argument. A binding rule lives in CLAUDE.md or its rule file, a subsystem's shape in its summary, a contested choice's argument in its decision record, a task's scope in its entry, and ordering reasoning in its wave file; every other mention becomes a clause and a citation. The pass goes pair by pair, largest first, and stops under about 60 shared runs. The measuring script is kept as `scripts/doc-overlap.mjs`, a report rather than a guard, since a threshold would penalise the legitimate mentions.

_Acceptance criteria:_

- README.md carries the rule and the table of homes
- The GitHub milestone description carries the id list and a link to the wave file, and the task-tracking rule's "Board layout" (`.claude/rules/task-tracking.md`) says so
- `scripts/doc-overlap.mjs` runs from a clean checkout, and the PR body records its count before and after
- `tests/guards` pass

**Decided while building.** The count was retaken on this branch, since MB.143 to MB.146 had split the corpus after the plan measured it: 7,536 runs across 209 live docs (`CLAUDE.md`, `.claude/` and `claude-docs/`, less `archive/` and `transcripts/`) before, 3,937 across 210 after. The table of homes gains a row the plan's lacked, DESIGN.md for specified behaviour and the data model, so a summary restating §5 is the copy. Four pairs stay at or above 60, each for a reason: DESIGN.md ↔ `tasks/mb.md` (130) is mostly entries' `_Story:_` lines quoting §10, kept as each entry's story; `design-decisions/mb.24-rls-role-split.md` (72) shares MB.24 to MB.26, which MB.29 marked as history left as written; `CLAUDE.md` ↔ DESIGN.md (60) is the domain invariants, binding reminders of §5 and §8; and `design-decisions/mb.80-plan.md` (60) is the approved scope MB.81 to MB.85 were cut from. Each wave's milestone description held reasoning its wave file lacked, so the wave files absorbed it first and the description keeps the row's ids and a link; Waves 02, 03 and 05's descriptions had drifted from their rows and take the row's. `create-main-sync` and `create-release` share their merged-PR lookup and notes in `create-release/reference-shared.md`, as `create-feature` and `create-hotfix` share `reference-branch.md`. Stale facts met on the way were corrected rather than cited: DESIGN.md §5's hard-deleted join tables (two since MB.110) and its keeper grant (MB.68 promotes too), MB.37's claim that PR #73 carried an acknowledgement, the MB.61 record's sentence for a squatted address, and `auth/admin-bootstrap.md`'s change link and field count.

**MB.150 — Combobox's × buttons move as a button does** · 0.5h

_Story:_ As a workspace member, I want the × that removes a list entry to answer the keyboard as it answers the pointer, and as every other button does, so that I can see which entry Tab has reached before I press it.

Minted during M5.10, on the owner's review. `.btn` fades its fill, edge, ink and shadow through `theme-transition`, and draws its hover state on `:focus-visible` as well as `:hover`, so the keyboard sees what the pointer sees. Combobox's × buttons do neither: the chip's remove (`.combobox__entry-remove`) and the clear (`.combobox__indicator`) snap to their hover state, and focus draws only the ring. Both take the button's transition and its focus state, with reduced motion dropping the transition. The chevron shares `.combobox__indicator` and takes the same, since an indicator that moves unlike the clear beside it reads as a different kind of control.

_Acceptance criteria:_

- The chip's × and the clear × fade into and out of their hover state on `theme-transition`, as `.btn` does
- Each draws its hover state on `:focus-visible` as well as `:hover`, with the focus ring
- `prefers-reduced-motion: reduce` drops the transition
- `claude-docs/components/combobox.md`'s Styling section says so
- Checked by hand in the workshop in both themes, by pointer and by Tab

**MB.151 — Record the references model** · 2h

_Story 64 — As a reader of the compendium, I want to see where an entry's information came from, so that I can judge a claim and read further._

Documentation and scoping only, in MB.138's shape: the model is recorded before the table task transcribes it. Minted during MB.127, on the owner's request that every compendium entry carry a references section, and that references be one table any sourced row links rather than a child of `ingredients` (DESIGN.md §5, "References"). The owner's decisions are already made and recorded there — Chicago bibliography form; two tiers, as ingredients are, with MB.138's tier rule on what a row may link; optional on an entry, with a keeper to-do filter; the vocabulary seeds' sources written as rows — and this task settles what they leave open, each with its reason in [`design-decisions/mb.151-references.md`](../design-decisions/mb.151-references.md): the `references` columns Chicago needs and no more — a `kind` (book, chapter, article, web page, other) deciding which render, the authors as Chicago prints them with the first inverted, title, the containing work (the book of a chapter, the journal of an article, the site of a page), edition, volume and issue, place, publisher, date, pages, `url` and the accessed date for a page, and whether a free `note` is one of them; how a link reaches any sourced row — one `reference_links` table carrying a nullable foreign key per sourced table under `CHECK (num_nonnulls(…) = 1)`, the shape MB.40 and MB.138 use, or a join table per entity, and what a new sourced table costs under each; what a link carries, a locator — a page, a section — and nothing else; uniqueness, one link per reference per row, and whether two rows may be the same book; order, alphabetical by the rendered entry as a bibliography is, so nothing stores one; which module owns the tables, since the links reach rows of `ingredients` and `vocabulary` — a sixth module, or `ingredients` with the vocabulary links reaching it through `@/modules/ingredients`; what soft-deleting a reference does to its links, and a reference whose every link is gone; the GraphQL shape, a `Reference` carrying its fields and a server-rendered `citation: String!` in Chicago form, so one renderer serves the page, the admin's list and the seed's test, and the title's italics as plain text or marked; and which writers exist in v1 — the ingredient form and the seed, with the admin vocabulary pages gaining no field, since MB.156 writes theirs and nothing else does.

**Decided while scoping.** The column list above could not render the deity doc's own citations, which MB.156 requires: of its 334 lines, 79 are `s.v.` reference-work entries, 89 carry a last-modified date, 48 were read through an online host and 29 name a translator or an editor. So `entry` replaced `other` among the kinds, and `contributors`, `series`, `host` and `modified` joined the columns, each counted in the record; `book` and `chapter` stay two kinds, the owner's call, so a chapter saved without its book is refused rather than rendered as a book. The record is [`design-decisions/mb.151-references.md`](../design-decisions/mb.151-references.md) and the plan [`design-decisions/mb.151-plan.md`](../design-decisions/mb.151-plan.md).

_Acceptance criteria:_

- DESIGN.md §5 gains both tables with their columns, CHECKs and indexes, the tier rule and the link rule; §7's sketch gains `Reference` and `Ingredient.references`; §9's detail row and §14 follow
- The column set, the link mechanism, the locator, the uniqueness and order rules, the owning module, the delete rule and the renderer's home are each recorded with their reason and the alternative they beat
- The Chicago rendering is specified per `kind` with one example each, taken from the deity doc's Sources section, so the seed's test and the page's test render the same entries
- db.md and modules.md name the tables and the module that owns them

**MB.152 — `references` and `reference_links` tables** · 1.5h

_Story:_ As a developer, I want the references tables in place before any code reads them, so that the first reference is written against rows that already exist.

Table task, in MB.139's shape: the two tables as MB.151 specifies them (DESIGN.md §5; [`design-decisions/mb.151-references.md`](../design-decisions/mb.151-references.md)), in `src/modules/ingredients/schema/`, each with the six-column audit spread and its own `set_updated_at` trigger line. `references`: `workspace_id` nullable, held as `ingredients` holds its tier; the `reference_kind` enum (`book`, `chapter`, `article`, `entry`, `web_page`); `title` not null; `authors`, `container`, `contributors`, `edition`, `volume`, `issue`, `series`, `place`, `publisher`, `published`, `pages`, `host`, `url` and `note` nullable text, each non-blank when set; `modified` and `accessed` nullable `date`s; the four CHECKs that make the renderer total — `url` absolute http(s), `accessed` only with a `url`, a `container` on a chapter, article or entry, and a `url` and `accessed` on a web page; and no unique index. `reference_links`: `reference_id` not null; `ingredient_id`, `deity_id`, `deity_tradition_id`, `planet_id` and `zodiac_sign_id`, each a nullable foreign key, under `CHECK (num_nonnulls(…) = 1)`; `locator` nullable and non-blank; and one partial unique index per sourced column, `(<row>_id, reference_id)` over live rows of that column, which also serves the read by row, so no plain parent index is built and none leads on `reference_id`. Nothing reads the tables yet.

_Acceptance criteria:_

- Both tables carry exactly MB.151's columns plus the audit spread — asserted from `getTableConfig` and the catalogue
- A blank text, a non-http(s) `url`, an `accessed` without a `url`, a chapter, article or entry without a `container`, and a web page without a `url` or an `accessed` are each a 23514 naming its CHECK
- A link naming two rows, or none, is a 23514 naming its CHECK; a second live link of one reference to one row is a 23505 naming its index, per sourced column, and a soft-deleted link reserves nothing
- Each link index leads on its sourced id, and no index leads on `reference_id` — asserted from the catalogue
- `AUDITED_TABLES` gains both names; `tests/db/updated-at-trigger.test.ts` passes
- `tests/guards/pagination.test.ts` and the soft-delete guard see nothing new to fail
- Nothing reads the tables yet

**MB.153 — Read and write references on an ingredient** · 2.5h

_Story 64 — As a reader of the compendium, I want to see where an entry's information came from, so that I can judge a claim and read further._

The behaviour half, on MB.152's tables. The shared Zod schema takes an ingredient's references as a list of existing reference ids with an optional locator each, and a new reference as its Chicago fields, validated per `kind` — a page needs a `url` and an accessed date, a book a title and a date — with `url` an absolute http(s) address. The services, in the module MB.151 names: a reference is created and edited under `withAudit` in its tier, a keeper's in the compendium and a member's in the coven of the proof; an ingredient's links are written in the ingredient's own transaction, brought to the list sent as folk names are, so a save that changes nothing writes nothing; and a link the tier rule forbids is refused as a field error pathed to the entry, asserted by direct id. A compendium reference is written only under the `SiteAdmin` proof and a coven's only under its `Membership`, whoever links it; revalidating the `compendium` tag on a compendium-tier write is M8.7's, with every other keeper mutation (amended in the build, the owner's call: nothing calls `revalidateTag` yet, and it throws outside a request). GraphQL: `Ingredient.references: [ReferenceLink!]!` through a loader over a finder of its own, `findReferencesOfIngredients`, which joins each link's reference in one statement (amended in the build: `findManyOfIngredients` reads the links alone), each `ReferenceLink { reference, locator }` and each `Reference` with its fields and the server-rendered `citation`, plain text, alphabetical by it — the key less a leading quotation mark and an initial _A_, _An_ or _The_, compared case- and accent-insensitively, sorted in the service since the citation exists only in TypeScript; `referenceSuggestions(workspaceId, query)` for the form's picker, matching `authors`, `title` and `container` in SQL as the compendium search matches names (rule 7 filters in SQL, so not the rendered citation, which this entry first said; amended in MB.151), scoped to the compendium and the current coven, never another; `createReference` and `updateReference`, and no `deleteReference`; graphql-scalars' `LocalDate` for `modified` and `accessed`; and a `withoutReferences` argument on `compendium` for the keeper's to-do list, which M5.5 adopts. Every finder here that reads the compendium tier joins `TIER_SEAM`. The Chicago renderer is one pure function, `renderCitation` in `src/lib/citation.ts`, returning `{ text, italic }` parts under MB.151's italics rule — the kind's defaults, and `_…_` marks in `title`, `container` and `note` read by CommonMark's intraword rule, `url` never parsed — tested per `kind` against MB.151's examples, the parts joined with `_` around the italic ones so the test compares strings, plus an invented article with a volume; the seed's test (MB.156) renders through it.

_Acceptance criteria:_

- A save carries existing references with locators and new ones together, read back alphabetical by citation, through one query for a page of ingredients
- A compendium entry cannot link a coven's reference, and a coven's ingredient cannot link another coven's — refused by direct id, with the precondition that the reference exists
- `referenceSuggestions` never offers another coven's reference, asserted with the precondition that coven X holds a match
- A member cannot edit a compendium reference their ingredient links, refused by direct id, with the precondition that the link exists
- A field error on a new reference is pathed to the field that failed, per `kind`, never a bare constraint name
- `compendium(withoutReferences: true)` lists exactly the live compendium entries with no live link
- Each `kind` renders to its MB.151 example, italics and all, from one function

**MB.154 — IngredientForm — References field** · 9h

_Story 64 — As a reader of the compendium, I want to see where an entry's information came from, so that I can judge a claim and read further._

Adopts MB.153 in the form. A References list field on M5.10a's `Combobox`, in the shape the substitute field takes: typing searches `referenceSuggestions`, debounced, each suggestion its rendered citation and whether it is the compendium's or this coven's; picking one adds it as a row beneath the box reading the citation — the plain `citation`, as MB.151 gave a chip, the italics left to MB.155 — with an optional locator beside it; and an "Add a reference" row, where the substitute field has "use what you typed", and a New Reference button where a list has Add, open a citation sub-form inline beneath the field — `kind` first, then the fields that kind needs, validated inline through the one error element — whose save adds the new reference to the list without leaving the ingredient form. **Amended in its scoping, the owner's calls** ([`design-decisions/mb.154-plan.md`](../design-decisions/mb.154-plan.md)): the references are full-width rows beneath the box rather than chips inside it, so a citation reads whole, as a bibliography does; the sub-form is an inline panel rather than a dialog, since M8.16 puts the form in a modal; and the estimate went from 2h to 5h. **Widened in the build, the owner's calls:** every form control and button stands at one height, `$control-height`; a Locator carries an info tip, and a source cited at several places is one row whose locator names them all, "pp. 12–19, 40; chap. 3", rather than a repeated pick, which would have dropped the five one-link-per-source indexes; and the reference fields are tidied and checked in the shared schema, so the server stores and refuses what the form shows — spacing, a title's wrapping quotes, a range's en dash, an address's missing scheme and an edition's form, and a date with no year, a page that is not a number, an address with no named host and a day not yet come refused beside their fields ([`db/references.md`](../db/references.md), "Formatting and checks") — which took the estimate to 8h; and every suggestion list spans its field and stays on the screen, on Floating UI (DESIGN.md §14), which took it to 9h. Lands after MB.153 and before M5.5, whose compendium page is the first to write the field; a coven's form writes it the same way.

_Acceptance criteria:_

- Typing suggests, debounced; picking adds a row reading the citation; the row's × removes it and Backspace in an empty box takes the last, as every list field does
- The sub-form shows only the fields its `kind` needs, marks the required ones, and a server field error lands beside the field it names through `FieldError`
- A reference added through the sub-form is in the list sent, by id, and the form sends no citation text of its own
- Keyboard operable end to end, announced as the other list fields are, axe clean, usable at 375px
- Each reference field is tidied as it is left and stored the same, whoever sends it, and the schema's checks land beside their fields; every source the seed writes passes them unchanged
- A Locator's tip says what a locator is and that several places go in one
- The field's story and `claude-docs/components/ingredient-form.md` cover it

**MB.155 — References section on the ingredient page** · 4h

_Story 64 — As a reader of the compendium, I want to see where an entry's information came from, so that I can judge a claim and read further._

A References section on M8.19's page, on both its routes: beneath the substitutes, above the slot v2's notes take, a bibliography list of the entry's references in Chicago form, each with its locator where one was given and its `url` a link that opens the source, `rel="noopener"`. The page renders the parts `renderCitation` returns rather than the plain `citation`, each italic part in `<cite>` (MB.151). An entry with none shows a deliberate empty state — "No sources recorded" — rather than nothing, so the gap is as visible to a reader as it is on the keeper's to-do list. The public route serves it from the same page, dynamic over the cached reads under the `compendium` tag, so a reference a keeper edits refreshes it through `revalidateTag`. Story 64's acceptance test is written here: the flow in `tests/e2e/stories/02-compendium.spec.ts`, tagged `@story-64`.

**Amended by the Wave 12 review (2026-10-16):** the one renderer is `renderCitation` in `src/lib/citation.ts`, and the order is not this task's to build.

**Amended by MB.215 (2026-10-11):** a form's own references are listed in its section of the page, beneath the ingredient's, in the same Chicago form ([`design-decisions/mb.215-ingredient-variants.md`](../design-decisions/mb.215-ingredient-variants.md)).

**Amended by the owner (2026-10-17), after a first build:** the references move out of the side column and out of each form into one section of their own at the very bottom of the centre column, beneath the forms and above the notes slot, in Chicago's notes-and-bibliography form rather than a bibliography alone. Each section the entry's references support (the ingredient's details, and each form with references of its own) ends with its superscript note numbers on a line of their own beneath a small References label, each number a link to its note (the label the owner's addition, 2026-10-17; a label rather than a heading, so the page keeps one References heading). The References section holds **Notes**, numbered in order of first appearance down the page, one per link (a reference and its locator in one section), each in Chicago short form from `renderShortCitation` (`src/lib/short-citation.ts`) with its locator, a link back to the number it answers and a link on to its full entry; and beneath them the **Bibliography**, every reference once, alphabetical, in full form from `renderCitation`, each entry linking back to the notes that cite it. A number marks a section rather than a sentence, because a reference links an ingredient or a variant, not a claim. The jump menu gains References beside Details and Forms. DESIGN.md §5 and the routes table are corrected in this PR, recorded in `design-decisions/mb.155-notes-and-bibliography.md`. Re-estimated from 1.5h.

_Acceptance criteria:_

- One References section at the bottom of the centre column on `/compendium/ingredients/[slug]` and `/coven/[slug]/ingredients/[id]` alike, beneath the forms and above the notes slot; no references remain in the side column or inside a form's section
- Each section with references ends with its superscript note numbers beneath a small References label, each linking to its note, and each note links back to its number
- Notes are numbered in page order, one per link, in Chicago short form through `renderShortCitation`, each with its locator where one was given
- Each note links to its reference's entry in the Bibliography, and each Bibliography entry links back to every note citing it
- The Bibliography lists each reference once, in full Chicago form through `renderCitation`, alphabetical (the loader's `byCitation` order, asserted), italic parts in `<cite>` and a `url` a link to the source, `rel="noopener"`
- An entry with no references shows a deliberate empty state in the section
- The jump menu lists References
- DESIGN.md §5 and the routes table corrected, with the decision recorded
- axe clean; the `@story-64` flow in `02-compendium.spec.ts` walks a number to its note, the note to its entry and back, and passes

**MB.156 — Seed the curated vocabularies' sources** · 6h

_Story:_ As a keeper, I want the curated vocabularies to carry the sources they were drawn from, so that the first sourced row is not the first compendium entry a keeper writes.

The backfill, the owner's call: every curated vocabulary whose seed doc records sources — the planet and zodiac vocabularies ([`db/astrology-vocabulary-seed.md`](../db/astrology-vocabulary-seed.md)) and the deity vocabulary with its traditions ([`db/deity-vocabulary-seed.md`](../db/deity-vocabulary-seed.md)) — has them written as compendium-tier `references` rows, linked to the rows each supports: a tradition's sources to the tradition and to every deity under it, a per-deity citation to its deity alone, a planet source to the bodies it covers. The categories and the forms are the project's own design and cite nothing. The astrology doc's sources are recast in Chicago form first, as the deity doc's were in MB.127, and the deity doc is normalised to the one shape MB.151's renderer prints ([`db/references.md`](../db/references.md), "What the seed doc needs"): its comma-form `Wikipedia, s.v. "…," last modified …` lines in period form, the locators embedded in a citation (Grimm's "Vol. 1, chap. 13", Tacitus's "Chap. 40") moved onto the links, "Revised" as "Last modified", and "Originally published in …" and an unparenthesised "Existence confirmed at …" as notes, so the seed parses one shape; the reference-data seed (`src/db/seed/`) gains a `sources` target run after the vocabularies it links, keyed by the rendered citation it inserted, stamped by the bootstrap admin, in `migrate.yml`'s step and `deploy.yml`'s paths. Lands after MB.152's tables and MB.129's deities. **Keyed on `seed_key`, after MB.172** (amended by MB.171, the owner's call): each reference it inserts records its citation as `seed_key`, so a reference a keeper later edits is still recognised and never twinned; a live compendium reference with no key whose citation matches is linked rather than duplicated, and written to never; link targets are found by their `seed_key`, so a renamed deity keeps its sources. The deity doc's per-deity citations become nested bullets, one full citation each with an optional ` · locator`, and a back-reference repeats the citation it names; the five sources that chose which deities to list are rows with no links (both the owner's calls). Re-estimated from 2h for the normalisation, about 250 citations, and the astrology doc's research.

_Acceptance criteria:_

- Every source the two docs record is a reference row, rendered through MB.153's function to the doc's own text, parsed from the docs at test time with the parse itself checked
- Every curated deity, tradition, planet and sign the docs source carries its links, and a per-deity citation links its deity alone — asserted by row
- Reseeding adds nothing, resurrects nothing soft-deleted, and overwrites or twins no reference a keeper edited
- Rows are stamped by the bootstrap user with the GUC published
- `migrate.yml` runs the target after the vocabularies it links; `deploy.yml` re-seeds when either doc or the seed file changes

**MB.157 — Make element a list** · 1h

_Story:_ As a workspace member, I want an ingredient to carry more than one element, so that a herb worked with both fire and air is recorded as it is practised.

Documentation and scoping only, in MB.134's shape: the model is recorded before the table task transcribes it. Minted during MB.131, on the owner's decision. DESIGN.md §5 gives `element` one value of a closed enum; it becomes a list of that enum, still closed — earth, air, fire, water, spirit — so nothing is typed and nothing outside the five is written. This task settles the column's name and type, an array of `ingredient_element` beside the free-text lists, and whether a list keeps the order chosen and refuses a repeat; the GraphQL change, the single field on `Ingredient` and both inputs replaced by a list with no deprecation window, since nothing outside the app reads the API; `updateIngredient`'s "every field but element non-null" rule, which the list ends; `IngredientSearch`'s element filter (§9), which matches any element a list holds; and the sequence rule 10 requires, MB.158 adding and filling the list, MB.159 switching every reader and writer and ceasing to declare the old column, and MB.160 dropping it once MB.159 has deployed. The form's field becomes a list on MB.131's select-only box, its chosen elements chips inside the control as every list's are, its list offering the elements not yet chosen.

**Decided while building:** the column and field are `elements`, a nullable `ingredient_element[]`; the list keeps the order chosen and refuses a repeat at its position, since the form never offers a chosen element twice; an empty list is null. The filter is §9's `IngredientSearch`, not §13, which is v2. It is built by M8.13, which runs after MB.159, so MB.159 no longer claims it and M8.13 adds the containment match.

_Acceptance criteria:_

- DESIGN.md §5's column list, the `element` values line and correspondence row, §7's sketch and `updateIngredient` comment, §9's filter and §14's form-library row carry the list
- The column and field names, the array type, and whether the list keeps the order chosen and refuses a repeat, are recorded
- db.md and validation.md say how the list is validated

**MB.158 — List column for element** · 1h

_Story:_ As a developer, I want the element list column in place before any code reads it, so that the switch to a list is a code change against a column that already exists.

Table task, the expand half of rule 10. `ingredients` gains a nullable array of `ingredient_element`, named as MB.157 records, and the migration fills it from `element` where one is set. The single column stays declared and written until MB.159. Nothing reads the new one yet.

_Acceptance criteria:_

- The column exists as a nullable `ingredient_element[]`, asserted from the catalogue
- Every row with an element carries it as a one-entry list, and no row without one gains a list, asserted against the seeded template
- The migration only adds, so the destructive-DDL check passes with no sidecar
- The single column is unchanged

**MB.159 — Read and write element as a list** · 3h

_Story:_ As a workspace member, I want to choose several elements for an ingredient, so that it records every element I work it with.

Switches every reader and writer to MB.158's column. The shared Zod schema takes a list of the five values; the workspace and compendium services write it; GraphQL's `Ingredient` and both inputs carry the list, and `IngredientUpdateInput` has no nullable field left; the seed and the test fixtures write lists. `IngredientForm`'s Element becomes a multi-select in the same PR, since the form's types follow the schema: the list fields' control, its chosen elements as chips inside it, each with its ×, and a clear and a chevron on its right, on MB.131's select-only box, nothing typed and no Add, its list offering the elements not yet chosen. The Drizzle schema stops declaring the single column, rule 10's first half of a drop, and the migration fills the list again for any row the live deploy wrote to `element` after MB.158.

_Acceptance criteria:_

- A save carries several elements, and an edit replaces the list whole
- The list keeps the order chosen, refuses a repeat and a value outside the five, and treats an empty list as absent
- Every field of the update input is non-null, and `elements: []` clears the list
- The seed and fixtures write lists, and the SDL snapshot moves
- Nothing declares or reads the single column, which still exists
- The form's Element is a select-only multi-select with chips, keyboard-operable — the arrows move, Enter or Space chooses, Escape closes, Backspace in it removes the last — covered by its tests

**MB.160 — Drop the single element column** · 0.5h

_Story:_ As a developer, I want the retired single column gone, so that nothing can write a value the app no longer reads.

The contract half of rule 10, a task of its own. Once MB.159 has deployed, the migration drops `element`, with its `.ack.md` sidecar, and fills nothing. MB.159's refill copied everything written before it ran. After MB.159 promotes, members edit the list and nothing rewrites the single, so a row where the two disagree is either a write the old deploy made during MB.159's rollout or a list edited since, and nothing in the row says which. Copying the single in would bring back elements members had removed, so the drop gives up those minutes of writes instead, the owner's call during this task. `db:generate` would also emit MB.141's pending drop, so the migration is `generate --custom`, its snapshot the last one less `element` (claude-docs/db/identity-model.md, "The ingredient identity model").

_Acceptance criteria:_

- The column is gone, its `ingredient_element` type stays, and the migration writes no list
- The migration carries its acknowledgement sidecar, and the destructive-DDL check passes with it
- Lands only after MB.159 has deployed to staging

**MB.161 — Let an unknown classification carry a formal name** · 2.5h

_Story:_ As a workspace member, I want to record a formal name before I know which classification it belongs to, so that the entry carries the name and the classification can be settled later.

Minted during MB.131, on the owner's call; the decision and what was weighed are [`design-decisions/mb.161-plan.md`](../design-decisions/mb.161-plan.md), and DESIGN.md §5, `validation.md`, `db/identity-model.md` and `components/ingredient-form.md` were corrected in the same pass, so this task is the build alone. The kind↔name rule goes from a biconditional to three cases: `none` takes no formal name, the five named kinds each take one, `unknown` takes either. A migration replaces `ingredients_nomenclature_declares_canonical_name` with `nomenclature = 'unknown' OR (nomenclature = 'none') = (canonical_name IS NULL)`, under its `.ack.md` sidecar, since the `DROP CONSTRAINT` only widens. `NAMELESS_KINDS` splits into the kind that forbids a name and the one where it is optional; `crossFieldRules` refuses the two remaining cases with the messages it has; `LocalIngredientInput` reads a formal name with no kind as `unknown` rather than asking for one. `IngredientForm` shuts and empties the formal name under None alone, leaves it open and optional under Unknown, marks it required only under a named kind, and no longer marks the classification required when a formal name is typed. The SDL's `canonicalName` comment follows, through `codegen`, and every code comment citing the biconditional is corrected.

_Acceptance criteria:_

- `none` with a formal name is refused by Zod and by the CHECK, and each named kind without one by both
- `unknown` saves with a formal name and without one, through Zod and the CHECK
- A workspace entry with a formal name and no classification saves as `unknown`; one with neither saves as `none`
- The compendium input still refuses a missing classification
- The form keeps the formal name open and optional under Unknown, shut and emptied under None, required under a named kind, and a typed formal name marks no classification required — asserted by role and label
- The migration carries its acknowledgement sidecar, and the destructive-DDL check passes with it
- The SDL snapshot moves

**MB.162 — Hold compendium entries to the curated vocabularies** · 2.5h

_Story:_ As a site keeper, I want a compendium entry's form, planets, zodiac signs and deities chosen only from the curated lists, so that the shared reference spells each one one way, and a value it lacks is added to the list rather than typed.

Minted during MB.131, on the owner's decision. DESIGN.md §5 makes every curated vocabulary an autofill, so an uncurated value stays writable everywhere; this task narrows that for the compendium tier alone. A compendium entry's `form`, `planets`, `zodiacSigns` and `deities` must each name a live curated row — a form under a live group, a deity under a live tradition — and the compendium services refuse anything else as a `ValidationError` on the field, matched case-folded and trimmed as the suggestions fold, and stored in the curated row's own spelling. A coven's ingredients keep free text. Folk names and colours have no curated list and stay free text, and a compendium substitute already links only the compendium. Nothing is lost by the rule, since the keeper who writes the compendium also curates the lists: a value missing from one is added there first. It is what makes MB.131's headings true — "From Compendium" for a curated value and "From Coven" for one only in use — since no compendium entry then holds an uncurated value. The `standard` seed's uncurated compendium form, `rhizome`, moves to a coven entry, and the tests that read it as the compendium's follow. The task also settles what soft-deleting or renaming a curated row that a compendium entry uses does, and amends M5.6a, MB.95, MB.132 and M5.6b, which delete and rename them, to match. The owner settled it in this task's scoping ([`design-decisions/mb.162-compendium-holds-curated-values.md`](../design-decisions/mb.162-compendium-holds-curated-values.md)): a delete is refused while a live compendium entry holds the row, or a row under the group or tradition deleted, naming the entries, over removing the value from them with it; a rename carries the new spelling onto them in the same transaction, over refusing it, and MB.163 moves that rewrite to a background job. A coven's rows neither block nor are rewritten, and the curation to-do lists of compendium values outside the vocabularies, which could no longer hold anything, are dropped from the three admin pages. M5.5's admin form makes the four boxes choose-only (amended here).

_Acceptance criteria:_

- DESIGN.md §5, `identity-model.md` and `validation.md` say a compendium entry holds only live curated values in the four fields, recorded in a `design-decisions/` record
- A compendium create or update naming an uncurated or soft-deleted value in any of the four is refused beside that field, asserted per field, with the precondition that the same value saves on a coven's ingredient
- A value matching a curated row but for case and spacing is stored in the row's spelling
- No seed scenario writes a compendium entry with an uncurated value in the four fields, asserted from the seeded template; `rhizome` stays seeded, on a coven entry
- What soft-deleting or renaming a curated row in use by a compendium entry does is decided and recorded, and the vocabulary admin tasks amended

**MB.164 — Show what a picked substitute is** · 2h

_Story:_ As a workspace member, I want a substitute I have picked to tell me its form and whose entry it is, so that I can see I linked the ingredient I meant.

Minted with MB.165 to MB.169 on the owner's request that a picked form, deity and substitute show enough to tell the right one is selected ([`design-decisions/mb.165-plan.md`](../design-decisions/mb.165-plan.md)). This one stands alone, since a substitute already saves its link. A linked substitute's pill reads "Mockwort (Fixtura vulgaris)" and keeps reading so, the owner's call, but what the lookup's row said of it — whose entry it is — is gone once it is picked, and so is what the row never said, its form, which with the formal name is the ingredient's identity (§5): two Mockworts in different forms read alike. `ComboboxEntry` takes an optional `detail`, shown with the entry's text in its tooltip, which then opens on hover and on its ×'s focus whether the text is cut off or not, and describes the × so a screen reader hears it. The substitutes' lookup asks for each ingredient's form and description as well, and a linked entry's detail is its form, "Compendium entry" or "This coven’s entry", and its description. A typed substitute has none and keeps today's tooltip, shown only when cut off. Nothing the form sends changes.

_Acceptance criteria:_

- A linked substitute's pill reads as before, and its tooltip names its form, its tier and its description, opening on hover and on its ×'s focus though the text fits
- The ×'s accessible description carries the detail, and the list's error still describes it when the error names that entry
- A typed substitute carries no detail, and its tooltip opens only when its text is cut off
- Escape closes the tooltip, and the axe pass over the form stays clean
- The mutation's input is unchanged

**MB.165 — Record the picked form and deities beside their text** · 2.5h

_Story:_ As a developer, I want a place to record which curated form and deity a member picked, so that two same-named rows — Wax under _Animal_ and under _Substance_, Greek and Roman Hecate — stay told apart after a save.

Table task, minted with MB.164 on the owner's decision ([`design-decisions/mb.165-plan.md`](../design-decisions/mb.165-plan.md)). DESIGN.md §5 keeps `ingredients.form` and `ingredients.deities` text, so that a member can write a value before anyone curates it, and lets two live vocabulary rows share a name, so the autofill's "Wax (Animal)" and "Wax (Substance)" save alike. The text stays, and stays identity; a link beside it records which curated row a pick named, and only a pick: typed text is never resolved into one. `ingredients.form_id`, nullable, a foreign key to `ingredient_forms`, with `CHECK (form_id IS NULL OR form IS NOT NULL)`. `ingredient_deities`, a child table in `ingredient_substitutes`' shape, since a link cannot live in a `text[]`: `ingredient_id`, a nullable `deity_id` to `deities`, and `name`, not null and not blank — the label, held on a linked row as well, so a link whose deity is soft-deleted reads as its name with no new soft-delete exception — a `position`, one live link per ingredient and deity, one live unlinked name per ingredient case-folded, so Greek and Roman Hecate may sit on one ingredient, and the full audit spread, so its own `set_updated_at` line. **The list keeps the order entered**, the owner's call in this task, unlike substitutes (MB.138): deities are a correspondence beside planets, zodiac signs and colours, which keep theirs (MB.134), and one list re-sorting itself after a save would be the odd one out in the form. Hence `position`, unique among an ingredient's live rows by `ingredient_deities_position_unique`, which leads on `ingredient_id` and so serves as the parent's index, read in order, as `spell_ingredients_spell_id_layer_order_unique` does a jar's; no plain parent index is built. The reorder control the order then wants is MB.170, minted here. After MB.141, whose drop has merged by then, so the migration is `db:generate`'s own. Nothing reads or writes either yet. The decision is recorded in `design-decisions/mb.165-record-the-picked-vocabulary-row.md`, and DESIGN.md §5 corrected: "a vocabulary a member writes is text" gains its link beside the text, and the gap §5 records for two same-named forms closes for a pick. Two entries with one formal name, one picked as each Wax, still share a `canonicalKey`, which stays on the text.

_Acceptance criteria:_

- DESIGN.md §5 and `identity-model.md` say a member-written vocabulary is text with an optional link to the curated row picked, recorded in the design-decision record with the order rule
- The shapes are asserted from the catalogue; a `form_id` without a `form`, and a blank deity name, are each a 23514 naming its CHECK
- A second live link to one deity, or a second live unlinked name folding alike, is a 23505 naming its index; links to two same-named deities are not, and a soft-deleted row reserves neither
- A second live row at one ingredient's position is a 23505 naming `ingredient_deities_position_unique`, while the same position on another ingredient, or beside a soft-deleted row, is not
- `ingredients.form` and the deity names stay text, the vocabulary schema tests asserting no foreign key on the text amended rather than removed
- `AUDITED_TABLES` and `tests/db/updated-at-trigger.test.ts` agree with the full audit spread
- Nothing reads or writes the column or the table yet

**MB.166 — Fill `ingredient_deities` from the list** · 1h

_Story:_ As a developer, I want every deity an ingredient holds copied into MB.165's table before any code reads it, so that the switch to links is a code change against rows that already exist.

After MB.165. The migration, `generate --custom`, copies each `ingredients.deities` entry across as an unlinked name — never linked, since typed text is never resolved into a link behind a member's back, and the text cannot say which of two same-named deities it meant. Each entry is trimmed, and a blank or null one skipped; each row takes its `position` from the array's order, since the list keeps the order entered (MB.165). An entry repeated, case-folded, is copied once, at its first position and in the spelling it first holds, and the positions are renumbered so they stay dense, so neither unique index refuses the fill. `ingredients.deities` stays declared and written until MB.167.

_Acceptance criteria:_

- Every existing entry is an unlinked name row, asserted row by row from a list holding a repeat
- Each ingredient's rows read back in the array's order, their positions dense, from a list holding a blank entry and a repeat in another case
- No filled row is linked
- `ingredients.deities` is still declared and written

**MB.167 — Read and write the picked form and deities** · 6.5h

_Story:_ As a workspace member, I want the form and deities I pick saved as the ones I picked, so that the ingredient says Greek Hecate and not either Hecate.

After MB.166, and after MB.162, whose compendium rule it moves. Switches to MB.165's link and table. The shared schema takes a `formId` beside `form`, and each deity as a deity id or a name, refusing a repeated link, or an unlinked name repeated case-folded, pathed to its position as substitutes do, so neither unique index is what a member sees; planets, zodiac signs and colours refuse a repeat at its position too, case-folded and trimmed, as folk names do; the services write a link only when it names a live curated row — anything else is a field error — write the text in that row's spelling, and bring the live deity rows to the list sent, in the order sent, in the ingredient's own `withAudit` transaction — a row still listed keeps its row and takes its new `position`, moving the live rows through a scratch offset as a spell's layers do, since `ingredient_deities_position_unique` is checked per row (MB.165); the deities are read in `position` order; GraphQL's inputs take `formId` and `deities: [IngredientDeityInput!]`, `Ingredient` gains `formChoice`, the curated form picked, null when none was or it or its group is soft-deleted, and its `deities` become `[IngredientDeity!]!`, each `{ name, deity: Deity }` with the deity's tradition, both through DataLoaders — named after the table rather than `DeityInput`, which MB.132 keeps, the owner's call in this task's scoping; `formSuggestions` and `deitySuggestions` return a curated row's `id`, null for a value only in use, and the deities in use are read from the table. **MB.162's compendium rule moves onto the links:** a compendium entry's form and deities must each carry a link to a live curated row rather than match one by spelling, and MB.162's delete and rename rules for those two follow the link; planets and signs keep the spelling match. The seed and fixtures follow, the Drizzle schema stops declaring `ingredients.deities`, and `IngredientForm` keeps sending a valid input, its deities as names and no `formId` — showing a pick is MB.169's. Settled in scoping ([`design-decisions/mb.167-read-and-write-the-pick.md`](../design-decisions/mb.167-read-and-write-the-pick.md)): a `formId` beside text that is not its row's name is refused at `form` rather than overwritten; a deity pick held when its deity is retired is kept, as MB.138 keeps a substitute's link, on a coven's ingredient, and a save sending back its name keeps the row; a compendium entry re-picks. MB.162's delete and rename rules are unbuilt, so following the link is an amendment to M5.6a, M5.6b and MB.132, which also take the reverse indexes MB.165 left to this task.

_Acceptance criteria:_

- A save carries a linked form, and linked and typed deities together, and reads them back; Greek and Roman Hecate saved together read back as two
- Deities read back in the order sent, and a save reordering them keeps each row and writes the new order, with no tombstone and no 23505
- A deity linked twice, or an unlinked name repeated but for case, is refused beside the second; a typed name equal to a linked deity's is not
- A `formId` or deity id naming no live curated row is a field error pathed to it, never a 23503
- A planet, zodiac sign or colour listed twice, but for case and spacing, is refused beside the second, on either tier
- A linked value's text is written in the curated row's spelling
- Soft-deleting a linked form or deity leaves the ingredient's text, read back with no link
- A compendium entry's form or deity without a link is refused beside the field, with the precondition that the same value saves on a coven's ingredient, and M5.6a, M5.6b and MB.132, which build MB.162's delete and rename rules, are amended so those rules follow the links (amended in scoping: the rules are unbuilt)
- A page of ingredients resolves its form choices and its deities in one query each, through DataLoaders
- A curated suggestion carries its row's id, and a value only in use none
- Nothing declares or reads `ingredients.deities`, which still exists, and the SDL snapshot moves

**MB.168 — Drop `ingredients.deities`** · 1h

_Story:_ As a developer, I want the retired deities column gone, so that nothing can write a deity the app no longer reads.

The contract half of rule 10, a task of its own. Once MB.167 has deployed to staging, the migration copies anything written to the column since MB.166 across as unlinked names, placed after the entries the ingredient already holds in the array's order, then drops it, with its `.ack.md` sidecar. Staging is the gate rather than production, the owner's call: production is not live yet, so no release there has members writing under a deploy that still declares the column, which is what made production MB.137's gate.

_Acceptance criteria:_

- The column is gone, and the table holds every deity it held
- The migration carries its acknowledgement sidecar, and the destructive-DDL check passes with it
- Lands only after MB.167 has deployed to staging

**MB.169 — Show what a picked form and deity are** · 3h

_Story:_ As a workspace member, I want the form and deities I pick to show which ones they are, so that I can tell Greek Hecate from Roman, and Wax under _Animal_ from Wax under _Substance_.

After MB.167, on MB.164's tooltip. A picked deity's pill reads "Hecate (Greek)", its tradition beside it as the lookup's row has it, and its tooltip carries its description; a typed one reads as its name. The form box keeps the picked value as its editable text, "Wax", with its group, "Animal", muted at its right before the clear and the chevron, its tooltip the form's description and the box's accessible description; editing the text away from the value drops the link and the group, the owner's call. The form sends `formId` and each deity's id or name, the ids read from `formSuggestions`' and `deitySuggestions`' `id`, and MB.167's `IngredientDeityInput` taking either; a read shows a pick through `Ingredient.formChoice` and `IngredientDeity.deity`, each with its group or tradition (MB.167). The combobox takes the group as a prop, styled with the tokens alone.

_Acceptance criteria:_

- Picking Greek and then Roman Hecate adds two pills, "Hecate (Greek)" and "Hecate (Roman)", and sends two deity ids
- A typed deity reads as its name and sends a name
- Picking a form shows its group in the box and sends its id; editing the text drops both, and a typed `rhizome` sends no id
- The group's tooltip opens on hover and focus and closes on Escape, and the group is in the box's accessible description
- Asserted by role and label, and the axe pass over the form stays clean

**MB.170 — Reorder the ordered list fields** · 3h

_Story:_ As a workspace member, I want to move an entry within an ingredient's deities, planets, zodiac signs or colours, so that the order recorded is the one I mean rather than the one I happened to type.

Minted during MB.165, on the owner's call ([`design-decisions/mb.165-record-the-picked-vocabulary-row.md`](../design-decisions/mb.165-record-the-picked-vocabulary-row.md)). Deities, planets, zodiac signs and colours keep the order entered (DESIGN.md §5; MB.134, MB.165), and an order the member cannot change once typed is of little use: a ruler remembered after a lesser body goes first only by removing and retyping everything ahead of it. Each of the four list fields in `IngredientForm` gains a reorder control on its chips, operable by keyboard alone as well as by pointer, each move announced to assistive technology, and the list the form sends follows it, so a save stores the new order — the three arrays as sent, the deities as `position` through MB.167's replace. Folk names and substitutes read alphabetically, so they get none. The mechanism is the task's to choose, a standard package preferred over a bespoke one, recorded in `combobox.md`; M10.16's layer reorder may adopt it. Also the owner's call: when a list field's chips wrap onto more than one line they sit too close, with too little room above the group, so the vertical spacing in `src/components/Combobox/index.scss` — `.combobox__control`'s padding and gap, and `.combobox__entries`' gap — is opened up. Both are styled with the tokens and the existing primitives alone, so no design review is needed; a control that needs styling past them takes the owner's sign-off within this task (`.claude/rules/components.md`). After MB.169, which changes the same chips, and so after MB.167, whose replace stores the deities' order.

_Acceptance criteria:_

- Deities, planets, zodiac signs and colours each reorder by keyboard alone and by pointer; folk names and substitutes offer no reorder
- Each move is announced to assistive technology, and focus stays with the moved entry
- The input the form sends carries the new order, and a saved reorder reads back in it, deities included
- Chips wrapped onto several lines have room between the rows and above the group, on the tokens' spacing
- Asserted by role and label in the component tests, and the axe pass over the form in Playwright stays clean
- `combobox.md` and `ingredient-form.md` describe the control and the spacing

**MB.171 — `seed_key` on the seeded tables** · 1.5h

_Story:_ As a keeper, I want a row I renamed or edited to stay the one I edited, so that the next deploy's seed does not bring back the original beside it.

Table task, minted during MB.156 on the owner's call ([`design-decisions/mb.171-seed-keys.md`](../design-decisions/mb.171-seed-keys.md)). The reference-data seeds recognise their own rows by what a keeper can change: the vocabularies by slug, which follows the name, and MB.156's sources by the rendered citation. Once M5.6, M5.6a, M5.6b, MB.95 and MB.132 let a keeper rename a row, and MB.153 lets one edit a reference, the next deploy that touches a seed file reinserts the original as a twin. Every table `migrate.yml` seeds — `category_groups`, `categories`, `ingredient_form_groups`, `ingredient_forms`, `planets`, `zodiac_signs`, `deity_traditions`, `deities` and `references` — gains a nullable `seed_key text`, the identity the seed gave the row when it wrote it and never changed after, under a partial unique index `(seed_key) WHERE seed_key IS NOT NULL AND deleted_at IS NULL`. A row a keeper or a member writes holds null. No input, service or GraphQL field names it. The migration backfills each vocabulary row the bootstrap user created with its slug, exact because no rename writer has shipped; `references` holds no seeded row yet. The scenarios key by fixed id on fresh databases and `reference_links` by two ids, so neither is covered. Nothing reads the column yet: MB.172 keys the vocabulary seeds on it and MB.156 the sources seed.

_Acceptance criteria:_

- The nine tables carry `seed_key`, nullable, and refuse a second live row with one key while admitting one beside a soft-deleted row — asserted per table
- The migration's backfill, replayed against rows written beforehand, keys each bootstrap-created vocabulary row by its slug and leaves another user's row null
- The migration is additive and the destructive-DDL check passes without a sidecar
- DESIGN.md §5 names the column on each table and §14 records the decision; `db/seed-module.md` describes it

**MB.172 — The vocabulary seeds key on `seed_key`** · 2h

_Story:_ As a keeper, I want the vocabulary seeds to leave my renamed and retired rows alone, so that a deploy never undoes an edit.

Behaviour task, after MB.171, minted with it ([`design-decisions/mb.171-seed-keys.md`](../design-decisions/mb.171-seed-keys.md)). `seedFlatVocabulary` and `seedTwoTierVocabulary` take a row as present when its `seed_key` matches, live or soft-deleted, or when a live row holds its slug, so a renamed or retired seeded row is never reinserted and a row a keeper created under a seed name does not trip `*_slug_unique`; each row they insert carries `seed_key`, its slug at insert. An item's group is found by the group's `seed_key` rather than its current name, so a renamed group no longer throws the seed. Every vocabulary seed — categories, forms, planets and zodiac signs, deities and traditions — runs through the two helpers, so all take it at once. A row seeded after MB.171's deploy and before this one's carries no key, so a migration refills each bootstrap-created row still unkeyed with its slug, as MB.136's refill did for the lists (`0031_refill-ingredient-lists`).

_Acceptance criteria:_

- A seeded deity and tradition renamed and re-slugged in SQL, as the admin pages will, are left unchanged by a reseed, which adds nothing — with the precondition asserted that each row's slug no longer equals its key
- A soft-deleted seeded planet is not resurrected, and a live row a keeper created under a seed name blocks that insert without an error
- Items under a renamed group still seed into it
- Every inserted row carries its key, and a second run writes nothing
- The refill, replayed against rows written beforehand, keys an unkeyed bootstrap-created row and leaves a keyed one and another user's alone
- The vocabulary seed docs and `db/seed-module.md` say "by seed key" where they said "by slug"

**MB.173 — Refuse a migration older than its base's newest** · 2h

_Story:_ As a developer, I want CI to refuse a migration older than one already on its base branch, so that staging never skips a migration without saying so.

Minted during MB.168 on the owner's call. Drizzle's migrator reads the newest `created_at` in `drizzle.__drizzle_migrations` and applies only the journal entries whose `when` is later; it compares no name or hash (`migrate` in `drizzle-orm/pg-core/dialect.js`). Each entry's `when` is stamped when its author runs `generate`, so with several migration branches in flight one can reach staging older than a migration already applied there: `migrate.yml` passes, the migration never runs, and the deploy then meets a schema it expects and does not have. The tests cannot see it, since a test database starts empty and every migration runs. On 2026-10-06 MB.171's 0045, MB.69's 0046, MB.172's 0047 and MB.168's 0048 were in flight together; regenerating 0046 to put it after 0045 left it newer than 0047 and 0048, so merging in number order would have skipped both. A check beside the destructive-DDL scan reads the branch's journal against its Gitflow base's, resolving the base as `check:destructive-ddl` does: each entry the branch adds must follow every base entry in the journal and carry a later `when` than every one of them, and `when` must rise through the journal. A refusal names the entry and says to regenerate it on the current base. A run is only as current as the base it read, so a branch whose base moves after it passed is checked again on its next push, not before.

_Acceptance criteria:_

- An entry the branch adds whose `when` is no later than the base's newest is refused, by name, asserted against fixture journals
- An entry the branch adds ahead of a base entry in the journal is refused
- A journal whose `when` does not rise in order is refused, and the journal on `staging` passes
- It runs as `npm run check:migration-order` and as a `checks.yml` leg, and `db/migrations-and-scripts.md` describes it with the regenerate step

**MB.174 — Stop the list fields offering or adding a repeat** · 3h

_Story:_ As a workspace member, I want a list field to refuse a repeat as I type, so that I learn of it at the box rather than at save.

Minted during MB.154 on the owner's call. The shared schema refuses a repeat only at save, beside the entry that repeats it: a folk name repeated, or repeating the name; a planet, zodiac sign or colour repeated but for case and spacing (MB.167); a deity or substitute linked twice, or the same name typed twice (MB.138, MB.167). Nothing in the form prevents one while a member types, picks or presses Add. The Element multi-select offers only what is not yet chosen, and MB.154's References search leaves out a source already listed; every other list field — Folk Names, Planets, Zodiac Signs, Colours, Deities, Substitute Ingredients — follows them, matching on the schema's keys: text, trimmed and case-folded, for folk names, planets, signs and colours; a curated deity by its id, so Greek and Roman Hecate both stay pickable; a linked substitute by its ingredient id; and a typed deity or substitute by its text, among the typed entries alone. A typed name equal to a linked entry's is not a repeat, the owner's call, as it is not at save. Add and Enter on text repeating a listed entry add nothing and say why in the list's one error element, where the save-time refusal already reads, the owner's call over an announcement alone; and the "Use what you typed" row is not offered for such text. The schema stays the backstop for an API caller. After MB.154, whose `ListField` and lookups it changes, and before M5.5, whose compendium page wraps the form.

_Acceptance criteria:_

- A lookup never offers a listed entry: planets, signs and folk names by trimmed, case-folded text, folk names also leaving out the name; deities by curated id, so Greek Hecate listed still offers Roman; substitutes by ingredient id
- Add and Enter on text repeating a listed entry add nothing, and the list's error element says why; a typed deity or substitute whose text matches a linked one's name is added
- "Use what you typed" is not offered for text repeating a listed entry
- Colours, which has no lookup, refuses a repeat at Add and Enter the same way
- The schema's save-time refusals and their tests are unchanged
- Keyboard operable, announced as the other list fields are, axe clean, usable at 375px, and asserted by role and label
- `claude-docs/components/ingredient-form.md` describes it under its list fields, lookups and testing, and `combobox.md` too if the combobox gains an option

**MB.176 — ~~Bug reports~~** · **RETIRED 2026-10-31, not done**

> **Folded into M15.1, not done on its own.** The owner's call (2026-10-31): one table and one form serve bug reports and support requests. What survives is recorded in [`design-decisions/m15.1-support-form.md`](../design-decisions/m15.1-support-form.md), "MB.176 folded in". The ID is kept, and its issue is closed as not planned.

_Story:_ As a signed-in user, I want to report a bug from the page I hit it on and follow what happens to it, so that a problem reaches someone who can fix it and I can see when it has been.

Minted during MB.154 on the owner's request. **v1, in Wave 15 ahead of M11.8, the owner's call:** testers should be able to report from the first deploy, so it lands before launch rather than after it. The shape was decided at minting so the build is transcription: reports are rows in the app, not issues filed straight onto the public repo, so a report can hold what its reporter would not post publicly and a keeper decides what reaches GitHub. A `bug_reports` table (`id`, `title`, `description` as plain text, `path` — the page it was filed from, with the segment after `/coven/` redacted because workspace existence is private — `status` of `open`, `triaged`, `fixed` or `closed`, `issueUrl` nullable, + audit; soft-deleted; no workspace id), written only through `withAudit`, the reporter being `created_by`. Any signed-in, verified account files one, an account in no workspace and an observer included, because a report is the account's, not workspace content; a reporter reads only their own reports, through a finder that ANDs `created_by` itself, with each one's status and issue link, and a direct-id read of another's report is refused. A site keeper lists every report under `assertSiteAdmin` through the M3.6 cursor helper and sets its status; **Create Issue** opens GitHub's new-issue page on `Aurora-Arctic/Sorrel-and-Salt` prefilled through `?title=&body=` — no token and no API call, and the keeper edits it before posting, because the repo is public. The prefill carries the title, description, redacted path and report id, never the reporter's name or address; the admin pastes the issue's URL back onto the report, validated as an issue on that repo. A "Report a Bug" link in `AppShell` and on M11.10's 500 page opens the form; `/account/bug-reports` is the reporter's list and `/admin/bug-reports` the triage page. No email goes out on a status change: the status is in the app. Two CLAUDE.md lines move for it, each an architecture decision to record rather than route around: "Admins curate the compendium … and nothing else" gains the triage of bug reports, which hold only what a reporter chose to write, and "Observers write nothing" is made explicit as workspace content. It takes story 65, which MB.175 named before anything in DESIGN.md held it; MB.175 is post-launch and takes the next free number when it runs. Whether a sixth module `feedback` owns the table, or `identity` does, is decided then (claude-docs/modules.md, "Adding a module"). This task is the scoping record and the minting: the build follows as four PRs, one per task — the table, the services and GraphQL, the report form with its entry points and the reporter's list, the admin triage page with Create Issue — under the table-then-behaviour rule.

_Acceptance criteria:_

- The model is recorded in DESIGN.md §5, §7, §9 and §10, and in a `design-decisions/mb.176-bug-reports.md` weighing rows in the app against filing GitHub issues directly, with the two invariants it moves
- CLAUDE.md's two lines are amended in the same PR, and story 65 is named with its acceptance file, the v1 count reading 53 (1–34, 47–65) in CLAUDE.md and DESIGN.md
- The four build tasks are minted with estimates, placed after this one in Wave 15 and ahead of M11.8, and each names its prerequisite
- M11.10's entry gains the 500 page's report link, and its issue is synced
- Nothing is built in this task

**MB.177 — Every admin holds `canCreateWorkspace`** · 2h

_Story:_ As a site keeper, I want my account to say I may create a coven, so that the user list and M6.7's gate read one rule rather than two.

Minted on the owner's call that every keeper can create a coven. DESIGN.md §5 already let a keeper create "regardless of the flag", and M6.7 was to gate on the flag or the admin role, but no keeper row held the flag: the primary keeper's promotion (MB.60, MB.68) wrote `role` alone, fixture E was seeded without it, and no migration had set it, so every keeper read "No" on MB.52's `/admin/users` and sat in M5.8's awaiting filter. The rule becomes an invariant rather than a second prong. A CHECK on `users` refuses a keeper without the flag; its migration first sets the flag on every keeper row, soft-deleted included, since the CHECK binds them all, stamped as that keeper as MB.58's backfill was; the promotion writes both columns in its one audited update; and E is seeded with it. M6.7's gate then reads the flag alone, and M5.8 refuses to revoke a keeper's flag with an explaining error rather than a constraint violation ([`design-decisions/mb.177-admins-hold-workspace-creation.md`](../design-decisions/mb.177-admins-hold-workspace-creation.md)). After MB.53, and before M5.8, the next task to write the flag.

_Acceptance criteria:_

- A CHECK on `users` refuses a row with `role = 'admin'` and `can_create_workspace = false`, asserted by insert and by update, with the preconditions shown: the same row is accepted with the flag, and a user without it
- The migration sets the flag on every existing keeper, soft-deleted included, stamped as that keeper, before it adds the constraint
- A primary-admin promotion, at sign-in or at verification, sets both columns in one audited write
- Fixture E is seeded with the flag, and `/admin/users?awaiting` lists no keeper
- DESIGN.md, CLAUDE.md, M6.7, M5.8, MB.59 and the M2.9 record say the flag is what lets anyone create, and that every keeper holds it

**MB.178 — Search and filter the admin categories list** · 1.5h

_Story:_ As a site keeper, I want to find a category by part of its name or by its group, so that I can edit one without paging through the whole vocabulary.

Minted while M5.6 was built, on the owner's call. `/admin/categories` pages some sixty seeded categories twenty-five at a time, with no way to narrow them. The shape is MB.52's user list: a GET form to the page itself, so a filtered page is an address. `?query=` matches a case-insensitive substring of the name through `ilike`, its wildcards escaped by one repository helper that the user list's `userArms` moves onto. `?group=` names a category group by slug, as `?edit=` names a category, resolved against the groups the page already reads for its modal; an unknown slug is ignored, as a hand-edited cursor gets the first page. Both narrow in SQL, in the page's finder and its count alike, and the pager, each Edit, Add Category and the modal's way back keep the filter. The public `categories` query takes `query` and `groupId` too, so the page and GraphQL still end at the same service, as `users(query:)` does. The group picker is a native `<select>`, not `ComboboxSelect`, so the form submits before hydration as the user list's does. Lands straight after M5.6, whose page it extends.

_Acceptance criteria:_

- `?query=` narrows the list to the categories whose name contains it, case-insensitively, with `%` and `_` matched literally; a blank query is no query
- `?group=<slug>` narrows the list to that group's categories, alone or with the query; an unknown slug lists every category
- The count behind the pager reads the same filter as the page
- The pager, each Edit, Add Category and closing the modal keep the filter, and a save returns to the filtered page
- `categories(query:, groupId:)` filters its edges and `totalCount`; a `groupId` that is not a uuid returns an empty page, not an error
- Filter is offered only when the form differs from the page's filter, and a filtered list with no rows says no category matches
- The user list's wildcard escaping reads the shared helper, its tests unchanged

**MB.179 — Keep the test suite inside Postgres's connection limit** · 2h

_Story:_ As a developer, I want the test suite to pass whenever the code does, so that a red run means a broken change and not a crowded database.

Minted during M5.5, on the owner's call. A `db`-project run can fail tests that pass alone. During M5.5 the OAuth sign-in tests in `tests/db/email-change.test.ts`, `tests/db/email-verification.test.ts` and `tests/modules/identity/services/provisional-accounts.test.ts` failed together, the sign-in start answering 500, and passed one file at a time, on a clean `staging` checkout as on the branch. The cause is Postgres's 100 connections running out — `remaining connection slots are reserved for roles with the SUPERUSER attribute`, under the sign-in's insert into `verifications`. Each worker opens the harness's client (`tests/support/db/database.ts`) and the app's (`src/db/connection.ts`, postgres.js's default pool of 10), and whatever else holds connections at the same moment — another session's run, an e2e server left idle on `sorrel_e2e_*` — takes the rest, so which test fails depends on the room left. Measure what a run holds per worker, then bound it under the limit with room for the e2e servers and one more run: a pool size for tests, a worker cap, a higher `max_connections` in the local Postgres, or a mix, whichever costs least. CI runs one suite alone and has not shown it; the local devcontainer runs several sessions at once.

_Acceptance criteria:_

- The peak connections a full `npm run test:coverage` holds is measured and recorded, per worker and in all
- A full run holds no more than half of `max_connections`, asserted by a guard that reads the configured pool size and worker count, so a change that raises either fails it
- The three files above pass together, ten runs in a row, beside an e2e server holding its connections
- `claude-docs/testing.md` says how many connections a run takes and why the limit holds

**MB.180 — Test-layer ownership, and a per-file time budget in the PR comment** · 1.5h

_Story:_ As a developer, I want every kind of assertion to have one named owning layer and the CI comment to show which test files are over budget, so that a consolidation is reviewed against a rule and a slow file is seen in the run that lands it.

Minted on the owner's report that CI was slowing as the suite grew, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). The Vitest job's cases went from some 2,200 to 3,400 in a week (204 to 257 files on `staging`, 1–7 October), and the latest green run held 248 files, 4,570 tests and 215 s of summed worker time inside 114 s of wall on seven workers. Three explorations found the same rule asserted at several layers — 75 of 119 ingredients GraphQL tests re-run a service, repository or validation test; seed scenarios re-seeded per test when the clone already holds `standard`; the identity integration files re-importing `@/lib/auth` per test; the guards spawning `git ls-files` ten times and oxlint four — and nothing says which layer an assertion belongs to, so each later task would otherwise argue its deletions from scratch. This is the sweep-task rule's mechanism and guard, landing before the sweeps that adopt it. A new `claude-docs/testing/layer-ownership.md` tables assertion kind against owning layer: zod rules in `tests/modules/*/validation/`; service rules, every refusal direct-id with its precondition, in `tests/modules/*/services/`; the transport's half in `tests/modules/*/graphql/` — one refusal per error code per field with its precondition, SDL-level refusals, auth-scope refusals, loader cache clearing, one read per page, edge fields, and any mode no service test reaches; the repository's mechanism, the `Membership` proof ANDing `workspace_id`, once per finder family in `tests/db/repository/`; a table's own columns, constraints and exact audit set in its module schema test, cross-table invariants once by catalogue sweep in `tests/db/`; a component behaviour in the smallest component that has it, a page test holding search params → service call, the guard and NotFound; seed content in `tests/db/seeded-template.test.ts`, seed-shape invariants once in `tests/db/seed/index.test.ts`; one filesystem scan shared by the guards. It is linked from `claude-docs/testing.md` and by one line in `.claude/rules/testing.md`, CLAUDE.md staying under its size guard. The GraphQL doctrine change — `claude-docs/graphql/schema.md`'s "each refusal is asserted as the browser receives it" (`:528-530, 567, 610`) becoming "one refusal per error code per field, with its precondition; the service owns the rules", with its two backstops, a signed-out sweep over Query and Mutation alike and the six class-asserting resolver files moving onto the Yoga harness — is recorded in `design-decisions/mb.180-graphql-transport-half.md`, which `schema.md` points to until MB.185 and MB.186 rewrite its per-field sentences.

The budget is the guard. `.github/scripts/summarize-vitest.mjs` appends a "Slowest files" block — the ten slowest from each file's `endTime - startTime`, and every file over 10 s marked over budget with a pointer to the ownership doc — to the details the job summary and PR comment already carry, with a unit test under `tests/scripts/` feeding it fixture JSON that holds an over-budget file. The block warns in the PR comment and never fails the job, the owner's decision: a file's time is a signal for review, not a gate a slow runner could trip. `claude-docs/ci/reusable-checks.md` describes the block in the same PR, and the plan itself is copied to `design-decisions/mb.180-plan.md`.

_Acceptance criteria:_

- The PR comment and job summary of this PR's own CI run list the slowest files, with the two IngredientForm files marked over budget
- The block warns and never fails the job
- `layer-ownership.md` names a steward for every assertion kind the ten tasks cite
- The decision record states the doctrine change and both backstops
- Nothing under `tests/` changes but `tests/scripts/`
- Coverage threshold holds

**MB.181 — `IngredientForm`'s list field and closed sets tested as components** · 5h

_Story:_ As a developer, I want a list field's behaviour, and each lookup's, tested on its own component, so that the form's test file answers only what needs the form and the suite's wall clock is not one file.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). `tests/components/IngredientForm/index.test.tsx` is 82.7 s of the run's 215 s of summed worker time — 38 %, in one file of 258 tests — and, being one worker's job, its wall-clock critical path: no worker count brings the run under some 83 s while it exists. Some 240 of its tests go through `renderForm` (`index:132`), which mounts nine MSW handlers, the 25-field form and a categories fetch per render, to assert behaviours that owe nothing to the form: `describe.each(LISTS)` at `:1245` runs nineteen cases over six lists, 'moving an entry' (`:1524`) three over four, 'a repeat at the $legend box' (`:1622`) three over six, and the chips, Backspace, Enter, handle, move and 'a long entry' tests repeat what `Combobox/index.test.tsx` already proves (`:118, 650, 548, 563, 1010, 1042, 1057, 1223, 855, 870`), as the Element and Classification closed-set repeats do (`index:1062, 1136, 1151, 1179, 1194, 2885`). A new `tests/components/IngredientForm/list-field.test.tsx` renders `ListField` alone, in `renderGivenList`'s shape (`index:266`): the list-independent behaviours once per variant `ListField` actually branches on — plain, ordered, folk-name, pick-only — and the few list-specific ones (hint text, the sent shape for deities and substitutes, order kept) per list on the small harness. What Combobox owns is deleted with its owner named; `index:1206` moves into Combobox's file, being the only keyboard test of `ComboboxSelect`. The eight debounce "asks once the typing settles" tests (`:1717, 2002, 2018, 2410`) become one "the form wires the hook", `tests/lib/debounce.test.tsx` owning the timing; the fourteen error-placement tests become five — field, list entry, nested reference, server `fieldErrors`, cleared on edit; the categories tests that are `CategoryPicker`'s (`:812, 848, 923, 826`) go to it. The form's file keeps what needs the form: the save payload, the lookups wired, kind↔name coupling, mode, error placement. Built, that left the form's file at 83 tests and 40 s locally with coverage on, every test that mounts the 25-field form costing some 0.5 s in CI however little it does, so the owner extended the task: the duplicate warning moves onto `NameField` with `useDuplicateWarning` in `duplicates.test.tsx`, the Form box onto `FormField` and the list boxes onto `LookupListField` in `lookups.test.tsx`, each in the smallest harness that has the behaviour, as `list-field.test.tsx` holds `ListField`; their MSW answers move to `tests/support/msw/ingredient-lookups.ts`. The form's file keeps one wiring test per lookup — the box asks with this coven, the pick is sent — and of the warning only what the form does with it: the focus on Create Anyway, Save busy while it checks, an error elsewhere first. A profile showed role queries with a name to be some 40 % of what is left, since each names every element of the role, so the form's file finds its controls by label and its saves within their row. `tests/support/sortable.ts:78`'s 60 ms real waits stay, 0.7 s in all, since fake timers would couple to the dnd sensor. The estimate was index 258 → some 110 tests and ≤ 12 s; built, it is index 258 → 55 tests, 82.7 s → some 15–20 s in CI (6 s locally without coverage, 15–24 s with it beside the rest of `tests/components`), `list-field` 49, `lookups` 24 and `duplicates` 10 tests, each under 10 s. The 10 s budget is not met here: what is left mounts the whole form, and needs to, and v8 coverage multiplies a dom test's time by two to three, which MB.191's coverage provider takes on. `claude-docs/components/ingredient-form.md` and `combobox.md` are corrected in the same PR to describe the files as they then are. At 3h it exceeds the 1–2h norm, and stays one PR because the halves — the new files and the deletions — edit the same `describe` blocks, so splitting it would land a file half-moved; it splits only if review asks.

_Acceptance criteria:_

- Every behaviour independent of which list it is renders `ListField` alone
- The duplicate warning, the Form box and the list boxes are tested on `NameField`, `FormField` and `LookupListField`; the form's file keeps one wiring test per lookup
- Every deleted test names its owner in the PR table; `index:1206` is in Combobox's file
- `index.test.tsx` is under 20 s in the CI slowest-files block, from 107.5 s, and each new file under the 10 s budget
- Per-file coverage of `src/components/IngredientForm/**` and `src/components/Combobox/**` not below the previous run
- The two component docs describe the files as they now are

_Not met, and why:_ `index.test.tsx` ran 13.2 s, 29.8 s and 24.9 s in three istanbul CI runs (median 24.9 s, from 82.7 s at the baseline). It stands over the budget by the owner's decision, its remaining tests being the ones that need the whole form ([`layer-ownership.md`](../testing/layer-ownership.md), "The file budget").

**MB.182 — The reference panel and compendium mode on their own harness** · 1.5h

_Story:_ As a developer, I want the reference panel tested on the panel alone and the compendium-mode file to hold only what is about the mode, so that no dom file renders the whole form for what a part of it answers.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). `tests/components/IngredientForm/references.test.tsx` is 16.4 s for 39 tests, the second-largest file in the run after MB.181's, and `compendium.test.tsx` renders the whole form for its 22. A new `tests/components/IngredientForm/reference-panel.test.tsx` renders `ReferencePanel` (`src/components/IngredientForm/reference-panel.tsx:256`) alone for the panel's own behaviours, and `references.test.tsx` renders `ReferencesField` alone, on the form's resolver as `lookups.test.tsx` renders a list's box, for the search, the rows and the panel opened from the list, saved and listed; it mounts the whole form only for the payload sent and cleared by Save & Add Another, and a server error routed to a row. Deleted with owners: `formats %s` × 4 (`:767`) → `tests/modules/ingredients/validation/reference-format.test.ts`, the panel's applying them kept as one test; `:620, 637, 783` → `validation/reference.test.ts:102, 117, 267`, the panel's half — beside the field, focused, nothing sent — kept in one; `:293`'s debounce → MB.181's stewards, its coven kept; `:475` (`[]` for none) → `index.test.tsx`'s whole input. Kept, their named stewards not asserting them: `:486` (error placement), since `fieldNameOf`'s references branch and the row's own error are no list entry's, and `:514`, Save & Add Another, merged into the whole-form payload test, since `index:403` picks no reference. `compendium.test.tsx` keeps only what is about the mode — choose-only boxes, required marks, `workspaceId: null` lookups, and the entry edited, saved over and deleted — 21 → 11, by deleting what `list-field.test.tsx` and CategoryPicker own, merging, and rendering the Form box and a pick-only list alone on `compendiumResolver`. The to-do filter is `CompendiumList`'s, not in either file. The estimate: references 39 → some 20 tests and 16.4 → some 5 s, compendium −2 s, the largest dom file afterwards Combobox's at 5 s. Its own task rather than MB.181's tail because it edits different files for a different component, and MB.181 is already over the norm. `claude-docs/components/ingredient-form.md` is corrected in the same PR.

_Acceptance criteria:_

- Every behaviour of the panel alone renders `ReferencePanel` alone, and `compendium.test.tsx` holds only what is about the mode
- Every deleted test names its owner in the PR table
- Per-file coverage of `src/components/IngredientForm/**` not below the previous run
- No dom file over 8 s in the slowest-files block

_Not met, and why:_ on #737's CI run `references.test.tsx` took 5.8 s and `compendium.test.tsx` 7.0 s, from 27.4 s and 16.5 s on #732, and the new `reference-panel.test.tsx` under 3 s; the one dom file over 8 s is MB.181's `index.test.tsx`, at 24.9 s over the median of three runs, which stands over the budget by the owner's decision ([`layer-ownership.md`](../testing/layer-ownership.md), "The file budget"). The criterion is left as written and recorded as unmet.

**MB.183 — Seeds: one reseed per file, the shared shape once** · 2h

_Story:_ As a developer, I want each seed's content asserted once against the template and the seed-shape invariants asserted once over every seed, so that the seed tests read what the clone already holds instead of rebuilding it per test.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). `tests/db/seed/` is nine files, 199 tests and 21 s of summed worker time, the largest area after the two IngredientForm files, and runs the five vocabulary seeds, some 278 references and the compendium some 130 times, when the clone every test gets already holds `standard` (`tests/support/db-setup.ts:9-11`). `tests/db/seeded-template.test.ts` becomes the owner of the standard seed's content — `where-tests-live.md` already calls it the baseline — and `standard.test.ts` loses the rows it repeats (`:95/120/152/213-225/276/231/252/359` ↔ the template's `:55-93`), keeping what is about running `seedStandard` — idempotency and the re-run (`:398-467`), stamping (`:142`), routing (`:471`), the acting-user probe (`:388`) — under its `beforeEach` truncate (`:83`), some 29 seed calls → 8. `demo.test.ts` seeds once in `beforeAll` for its some 12 read-only tests (`:101-284`), the layer-integrity re-runs (`:313-402`) keeping their own; `sources.test.ts` seeds once instead of ten times. The copied shape — publishes the bootstrap user as `app.current_user_id` × 8, stamps every row × 6, idempotent × 8, does not resurrect what a keeper deleted × all — joins `index.test.ts:190-210`'s `it.each(SEED_ENTRIES)`, with its precondition that the table is empty before the run; the per-seed files keep their data-vs-doc parsing, admin-edit (`seed_key`) and slug re-derive (`forms:320-366`) tests. Vocabulary counts are asserted once, in the template, not in `standard:213` and each file's "starts from two empty tables" as well. The estimate: 199 → some 130 tests, 21 → some 6 s. `claude-docs/db/category-seed.md`, `astrology-vocabulary-seed.md`, `deity-vocabulary-seed.md` and `demo-scenario.md` where they name a per-seed test, `claude-docs/testing/db-harness.md` and `where-tests-live.md` are corrected in the same PR.

_Acceptance criteria:_

- Each seed-shape invariant asserted in `index.test.ts` over every `SEED_ENTRIES` row and in no per-seed file
- A read-only seed test reads the template or one `beforeAll` seed; a test that writes truncates first
- No seed file holds a row `seeded-template` asserts
- `tests/db/seed/` sums under 7 s on CI
- The seed docs name the tests that exist

**MB.184 — Guards share one scan; plan tests share one seed** · 1.5h

_Story:_ As a developer, I want the guards to read one file listing and one lint run and the plan tests to seed once, so that the fixed cost of a scan is paid per run rather than per file.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). The 36 guard files sum 5.6 s, `codegen-staleness` alone 3.0 s, and the two EXPLAIN-plan files under `tests/modules/ingredients/services/` 7.9 s: the guards spawn `git ls-files` ten times and oxlint four, `codegen-staleness` runs `generate()` five times on the same input, and the plan tests seed their decoys per test. A new `tests/support/unit-global-setup.ts`, the unit project's `globalSetup` in `vitest.config.mts`, runs `git ls-files --cached --others --exclude-standard` once and `provide`s the list — `seeded-template.test.ts`'s `inject` is the precedent — and the guards at `no-server-actions:17`, `module-boundaries:110`, `slug-rule:35`, `types-in-type-files:40`, `chip-colour-source:26`, `route-handlers:18`, `pagination:51`, `test-location:27`, `lint-db-client-boundary:232` and `lint-loader-boundary:101` inject it; the same setup runs oxlint once over the probe files with the shared config, and `lint-access-boundary:254`, `lint-db-client-boundary:170`, `lint-loader-boundary:64` and `lint-service-session-boundary:88` read their rule's diagnostics from its JSON. Each guard still asserts first that it found what it scans. `codegen-staleness` generates once in `beforeAll` for the same-input runs (`:45, :104, :116, :125`), `:76` alone being the staleness check. Guard-against-guard overlaps get an owner: `pulled-env-assertion:284-320` keeps and `vercel-pull-git-branch:60-100` drops, `ci-secret-environments:33-80` keeps and `database-probe:133-213` drops, `soft-delete-finder-guard:231` keeps and `tests/db/repository/index.test.ts:8` drops. The plan tests `common-names-plan`, `duplicates-plan` and `compendium-search-query` seed in `beforeAll` with their row counts unchanged, load-bearing per `claude-docs/db/fuzzy-matching.md` and `member-autofill.md`; `compendium-search-query:199`, asserting only `ms > 0`, goes; `ingredients-trigram:153/159/194` and `ingredients-unaccent:168/176/184`, hand-written predicates, go in favour of the plan tests on the real service SQL, their 2,000-decoy `beforeEach` becoming `beforeAll`, the negative controls at `trigram:170/181` staying. The plan's estimate was guards 5.6 → some 3 s, codegen 3.0 → some 1.2 s and plans 10.9 → some 5 s. Measured locally, the guards' CPU fell 14.6 → 13.1 s, `codegen-staleness` 370 → 70 ms and the trigram and unaccent files 700 → 190 ms, while the plan files stayed at some 10 s: their two largest each held one EXPLAIN test over an 80,000- and a 40,000-row seed already run once, and the row counts are the task's to keep, so that saving was never there to take. `where-tests-live.md`'s guards section, and `claude-docs/db/fuzzy-matching.md` if it names the benchmark, are corrected in the same PR.

_Acceptance criteria:_

- One `git ls-files` and one oxlint per full run, asserted by a test on the setup's provided values; each guard still fails on an empty scan
- Plan tests' row counts byte-identical
- No benchmark asserting only `ms > 0` remains
- Deleted-test table names each owner

**MB.185 — The ingredients GraphQL files hold the transport's half** · 2.5h

_Story:_ As a developer, I want the ingredients GraphQL tests to assert what the transport adds — the error code, the SDL, the loaders, the page — and not the service's rules again, so that a rule is proved once, where it is enforced.

Minted with MB.180, under the doctrine change its record states ([`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md); `design-decisions/mb.180-graphql-transport-half.md`). Of the ingredients GraphQL files' 119 tests, some 75 re-run a service, repository or validation test, against the files' own headers (`workspace-ingredients.test.ts:24-25`), and five of the files assert an error's class through bare `graphql()` and `originalError instanceof`, not the code the browser receives. A shared harness, `tests/support/graphql/run.ts` — Yoga with the route's `maskedErrors`, asserting `extensions.code` — is what `ingredient`, `duplicates`, `common-names`, `ingredient-suggestions` and `compendium` move onto. Kept, per the ownership table: SDL refusals (`WI:219, 401, 415, 473, 490`; `CE:216, 270, 285`), loader cache clearing (`WI:569, 649`; `CE:318`; `references:129, 249`), one read per page (`compendium:249, 296, 331, 398`), edge fields (`duplicates:96, 110`), compendium-only `workspaceId: null` (`duplicates:279, 296`; `common-names:106, 131`, which have no service twin until MB.187 adds it), one non-keeper refusal per admin mutation in `compendium-entries`, since `authScopes: { admin: true }` is a separate gate, and one refusal per error code per field with its precondition. Deleted with owners: the service mirrors (`WI:275/516/708` → `SVC-WI:154/491/669`; `WI:537/549/729/736` → `SVC-WI:356/502/681/698`; `ingredient:101/111/122` → `services/compendium:235/241/251`; `duplicates:124/132/162/227/243/255`; `common-names:80`; `ingredient-suggestions:84/98`; `references:100/165/338/216/274/387`; `CE:377/495`), the repository search re-runs (`compendium:146/161/176/194/204/216` → `tests/db/repository/ingredients.test.ts`), the validation re-runs (`references:112`, `WI:455, 503` → `validation/*.test.ts`), the pagination default (`duplicates:197` → `tests/graphql/pagination.test.ts:85`) and the per-field signed-out tests (`common-names:72`, `duplicates:233`), which the sweep owns. The first backstop lands here: `tests/db/graphql-query-scopes.test.ts:91-98`'s null session at every Query field gains a sibling loop over `schema.getMutationType()` and, for every workspace-taking Query field, the null-workspace variant, `PROBES` classified for each. The estimate: 119 → some 50 tests, some 6 s summed. `claude-docs/graphql/schema.md:528-530, 567, 610` are rewritten to the doctrine in the same PR.

_Acceptance criteria:_

- Every kept refusal asserts `extensions.code` through the shared harness with the precondition that would have let it succeed; no test asserts `originalError instanceof`
- For every mutation one test per error code the SDL can return
- Every Query and Mutation field is probed signed-out, and every workspace-taking Query field with a null workspace, by the sweep, which asserts its field list non-empty and equal to the schema's
- The loader, SDL, page and mode tests listed stay
- `schema.md` says what the GraphQL file holds

**MB.186 — The vocabulary, identity and coven GraphQL files, the same way** · 1.5h

_Story:_ As a developer, I want the vocabulary, identity and coven GraphQL tests held to the same half as the ingredients', so that one doctrine governs every module's transport tests.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). The same rule and MB.185's harness over `tests/modules/vocabulary/graphql/*.test.ts` — `astrology`, `categories`, `category-groups`, `deity-suggestions`, `form-suggestions`, `ingredient-form-groups`, `ingredient-form-values` and `suggestions` — `tests/modules/identity/graphql/{me,set-email,users,user-private-fields}.test.ts` and `tests/modules/coven/services/two-transports.test.ts`, the coven module's one GraphQL file, which re-run service tests and probe sign-out per field as the ingredients files did. The plan put them at some 3–4 s of summed worker time; measured, they summed some 2.3 s before and after (117 → 127 tests, the error-code refusals added costing what the deletions saved), so the task buys the doctrine holding in every module, not time. Known pairs: `users.test.ts:112` → `identity/services/user-list.test.ts:163`; `me.test.ts:73` → the sweep, which `route.test.ts:181` checks too; `vocabulary suggestions:100`, `deity-suggestions:107` and `form-suggestions:113` → the sweep; `services/form-suggestions.test.ts:213`, a soft-delete one-off, stays for MB.187's READS row. The harness's `run` takes a fourth argument replacing part of the context — loaders a test spies on or shares between operations, or a recording sender — and `runnerOn(schema)` builds it over `two-transports`' scratch schema. Each admin write keeps one `FORBIDDEN` to a coven's steward, as `compendium-entries` does, and a write missing a code it can return gains the test. Its own task rather than MB.185's tail because the pairs are found file by file, and MB.185 already carries the harness and the backstop. `schema.md`'s per-field sections for these modules are amended in the same PR.

_Acceptance criteria:_

- Every kept refusal asserts `extensions.code` through the shared harness with the precondition that would have let it succeed; no test asserts `originalError instanceof`
- For every mutation one test per error code the SDL can return
- Every deleted test names its owner in the PR table, the sweep included
- The loader, SDL, page and mode tests stay
- `schema.md`'s per-field sections say what each of these GraphQL files holds

**MB.187 — Services own the rules; repositories own the mechanism** · 2h

_Story:_ As a developer, I want a service's rule proved in its service test and the repository's `Membership` mechanism proved once per finder family, so that the two authorization layers are each tested as what they are and neither re-proves the other.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). The repository tests and the service tests refuse the same rows twice, and in places a third time: `tests/db/repository/vocabularies.test.ts:94-121` (the mechanism) ↔ `vocabulary/services/ingredient-form-values:165-193` (the rule), both staying, the service rows losing only their SQL-shape assertions; `slugs.test.ts:173-250` owns the rename's cases and `ingredient-form-values:533-650` keeps one "a rename follows the rule", `slugs:75-148` ↔ `compendium-entries:873-909` likewise; `repository/ingredients:462-599` ↔ `services/compendium:143-270`, the service keeping every refusal and the repository the proof-ANDs-workspace mechanism once; `finders:264-320` ↔ `tests/db/workspace-isolation:117-198` ↔ `workspace-ingredients:339-365, 502, 681`, the service tests staying whole, `finders` keeping one per finder family, and `workspace-isolation.test.ts` staying as Story 19's per-entity sweep — `tests/acceptance/README.md` names it — with `:179`, the same Forbidden for a real and a fake id, unique to it, its stale header (`:18-24, :56, :106`) rewritten and its `attemptIngredientUpdate` helper (`:105`) replaced by the real `updateWorkspaceIngredient`; `repository/spells:135-166` ↔ `spell-visibility:99-214`, the same split. E's no-admin-bypass is proved once per service and in the Story 19 sweep, not in some eight places. No service authorization test is deleted: the direct-id, precondition-asserting rule in CLAUDE.md is the constraint, and repeats come out only below it, at the repository, and above it, at GraphQL. The soft-delete one-offs `services/compendium:265`, `workspace-ingredients:373`, `duplicates:112` and `common-name-suggestions:139` join the documented READS tables (`workspace-ingredients:804`, `compendium-entries:468`), `suggestIngredients` added to the table so `ingredient-suggestions:82` goes; a service test for compendium-only mode (`workspaceId: null`) is added as the twin MB.185 lacked. Validation re-run through services — `references:106` (eight rows → one), `ingredient-substitutes:153`, `ingredient-deities:255` — keeps one "the service parses its input and no constraint name leaks" row each. `two-transports.test.ts:13-16`'s header is corrected, production fields now reading a workspace. The plan's estimate was some 40 tests fewer and some 4 s summed; measured side by side under the same load, the 21 touched files went 561 → 552 tests and 13.4 → 13.9 s, the fourteen READS rows added costing about what the deletions saved, so the task bought no time, only the split it names. `claude-docs/db/workspace-ingredients.md`, `compendium-writes.md` (the READS tables) and `tests/acceptance/README.md` are corrected in the same PR. As built, where the code corrected the plan: the soft-delete one-offs folded into the `READS` tables are seven, `vocabulary/services/suggestions`'s planet case and `deity-suggestions`'s beside the four named and `form-suggestions`'s, and the two tables now list every exported reader of an ingredient, `substitutesOf`, `deitiesOf`, `referencesOf` and the planet, sign and deity suggestions added beside `suggestIngredients`; the compendium-only twin is two tests, in `duplicates` and `common-name-suggestions`, the two services that take a null workspace; E's per-entity refusals in `workspace-isolation` became one `it.each` holding E's refusal of each entity to a stranger's, and no service file's E refusal went, the `Forbidden` count per service file being the criterion; `ingredient-form-values`' rename block lost only the case `write.carryFormRename` and `findCompendiumPage`'s `formId` own, keeping the slug rule, the no-op rename, the coven's pick (an M6.6 refusal) and the refusals; `repository/spells` lost only the deleted-spell case, keeping one test for each half of `readableSpells`; and `workspace-isolation` seeds through the shared inserters (MB.101) rather than `withAudit`.

_Acceptance criteria:_

- Every service authorization test is direct-id and asserts its precondition; none deleted — the count of `Forbidden` expectations per service file is not lower
- Each READS table lists every exported reader of its service, `suggestIngredients` included, and no per-reader soft-delete one-off remains
- Repository tests prove the `Membership` mechanism once per finder family and no service rule
- `workspace-isolation` and `two-transports` headers describe the files as they are

**MB.188 — Catalogue sweeps once, and the auth module imported once per file** · 2h

_Story:_ As a developer, I want each cross-table invariant proved once by a catalogue sweep and `@/lib/auth` imported once per file whose env does not change, so that the top-level `db` tests pay for each proof and each import once.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). The 23 top-level `tests/db/*.test.ts` files sum 17.3 s for 365 tests. `tests/db/audit-columns.test.ts` holds 112 of them, half `getTableConfig` per-table presence checks that the module schema tests already subsume with exact `[...OWN, ...AUDIT_COLUMNS]` sets — 15 audited and 2 stamped: `admin-invitations:41`, `workspace-invitations:39`, `spells:36`, `spell-ingredients:61`, `reference-links:51`, `references:60`, `inventory-items:62`, `ingredient-folk-names:23`, `ingredient-substitutes:45`, `ingredient-deities:45`, `ingredients-schema:51`, `astrology:39`, `deities-schema:25/65`, `ingredient-categories:24`, `spell-categories:29`; its `information_schema` half stays, being the only check that catches a spread deleted from a schema file, since `tableFacts` in `tests/support/db/table-metadata.ts` reads the code side. `updated-at-trigger:119/127` go to `audit-columns:112/147/190/215`. The per-table "second live row refused / slot freed by soft delete" pairs (`astrology:168/179`, `categories-schema:191/202, 296/305`, `ingredient-forms-schema:242/253, 335/344`, `deities-schema:288/299, 375/384`) become one catalogue sweep over every partial unique index, in `seed-keys.test.ts:98-136`'s shape, under the sweep-over-database-objects rule. The identity integration files re-import `@/lib/auth` per test under `vi.resetModules()`: a new `tests/support/auth-module.ts` exports `importAuth(env)`, called once in `beforeAll` per constant-env file — `tests/db/{account-linking:57, email-change:62, email-verification:54, sign-in-landing:56, last-login-method:55, oauth-token-encryption:49, impersonation:31}` and `identity/services/admin-role:240` — with `provisional-accounts` and acceptance `08-email-and-admin`, which follow the same pattern. No file needs a per-test import: `src/lib/auth.ts` reads `ADMIN_BOOTSTRAP_EMAIL` per request, not at import, so a file whose address varies stubs it per test. `tests/lib/auth.test.ts` drops the config pins with a behavioural twin (`:507` → `oauth-token-encryption:86`; `:465, 469` → `rate-limiting:69-117`; `:531` → `last-login-method:80`; `:364/368/342` → `account-linking:140/254/180`; `:417/389` → `email-verification:255/108/144`; `:81` duplicating `:417`) and keeps `:14, 274, 457, 491, 537` and the session lifetimes; `tests/lib/impersonation.test.ts:117` → `tests/db/impersonation:92`. Cross-file owners: `email-change:262` → `identity/services/email.test.ts:156`; `:288` → `provisional-accounts:307`; `:221/423` → `provisional-accounts:174/131`; `email-verification:316-409` → `admin-role:348-400`; `sign-in-landing:118/150` → `admin-role:247/276`; `impersonation:145` → `repository/write.test.ts:185`; `test-database-isolation:19/26` → `seeded-template:39/45`. `tests/lib/sign-in.test.ts`'s second `describe('signInPath')` (`:241`) merges into `:65`, and `account-email.test.ts:59` imports the unsafe-path strings. A pin or test whose twin proves only part of it stays: the trusted-provider linking pin, the one-hour link and the placeholder mapping in `auth.test.ts`; email-change's resend throttle and its 401; and email-verification's two promotion-wiring tests, the only ones that reach the promotion through `auth.ts` rather than the service. The partial-unique-index sweep keys its row builders by index rather than table, since one table's indexes can sit on opposite sides of a predicate, and asserts the keys equal the catalogue's set. The `users` and `workspace_members` schema tests gain the exact column set the rest already assert. The estimate: audit-columns 112 → some 45, eight pair tests → one sweep, the `tests/db` top level 17 → some 10 s, some 9 s summed. `claude-docs/testing/db-harness.md:86` is corrected — module schema tests assert the exact full set, not "own columns only" — with `claude-docs/db/audit-columns.md` and the `claude-docs/auth/*.md` that name a pin or file, in the same PR.

_Acceptance criteria:_

- `audit-columns.test.ts` reads the catalogue for every audited table and asserts `UNAUDITED_TABLES` carry none of the ids; it reads `getTableConfig` nowhere
- One test proves, for every partial unique index in the catalogue, that a second live row is refused and the slot freed by soft delete, the index set asserted non-empty first
- `@/lib/auth` is imported once per file, the env stated in its `beforeAll`
- Each dropped pin's twin is named in the PR table
- `db-harness.md` says what module schema tests assert

**MB.189 — Config moves, the admin pages' half, and the closing measurement** · 1.5h

_Story:_ As a developer, I want the database-free files out of the `db` project, the admin page tests holding the page's half, and the suite's time measured against the plan's baseline, so that the consolidation closes on a number.

Minted with MB.180, in the scoping recorded in [`design-decisions/mb.180-plan.md`](../design-decisions/mb.180-plan.md). Sixteen files in the `db` project pay for the database clone and never query it: the eight `tests/modules/**/validation/**` files and eight pure ones — `tests/db/audit.test.ts`, `bootstrap.test.ts`, `repository/index.test.ts` (which survived MB.184), `coven/schema/workspaces-schema.test.ts`, `coven/services/access-control.test.ts`, `identity/services/{site-admin,workshop-access}.test.ts`, `ingredients/schema/units.test.ts` — so `vitest.config.mts`'s `db` project excludes them as `DB_FREE` and `unit`'s `NOT_UNIT` narrows to match: to the files `db` runs, listed by a `globSync` at config load, since Vitest's `exclude` takes no negation and the two trees could not be excluded with `DB_FREE` carved back out. `tests/guards/test-location.test.ts` already holds each file to one project. `EmailForm`'s two real 1 s waits (`:145, :245`) become `vi.useFakeTimers({ shouldAdvanceTime: true })`, as the IngredientForm files already do beside MSW, −2 s, and the `resendDelaySeconds` prop that existed only to shorten the wait goes with them; `setup-dom.ts` clears `localStorage` after each test, a latent coupling since `vitest-setup.test.tsx:40` passes only by its predecessor's `clear()`. The admin page tests keep the page's half — search params → service call, the guard, NotFound against any other error. Read against the component tests, most of the forms and categories page tests hold work only the page does — the hrefs it builds under the filter and cursor, the position it counts, the group names it joins onto the rows — and stay: what moves is what the components' tests already assert, each modal's starting fields and the list's empty message, the two empty-filter tests becoming the count's from no row; categories gains the NotFound-against-other test forms had, so forms holds 18 and categories 17. The groups pages (M5.6b) shed the same modal-start assertions. `CategoryForm` and `IngredientFormValueForm` are duplicated components, so their nine identically titled tests stay, and share one `it.each` table in `tests/support/` so the next copy is a row, not a file. Last of the ten because its measurement is the whole consolidation's: the PR body closes with the slowest-files block, the summed worker time and the wall from the job summary, against the plan's baseline of 215 s summed and 114 s of wall with one file at 82.7 s, and its target of some 130 s summed, no file over 10 s and a wall of 35–45 s. `claude-docs/testing/where-tests-live.md` (which files the `db` project excludes and why) and the two admin page docs are corrected in the same PR.

_Acceptance criteria:_

- No `db`-project file runs without a database query, asserted by a guard that greps each `db` file for the harness client or a service import
- No file over 10 s in CI's slowest-files block
- Summed worker time under 140 s and vitest wall under 45 s, recorded in the PR body
- The page docs name what each page test keeps

_Not met, and why:_ the median of three istanbul CI runs (#735, #737, #739) is 73.5 s of wall and 187.6 s summed, with two files over 10 s, against 114.2 s and 215.4 s at the baseline, read the same way from the job log. The two files over the budget stand by the owner's decision ([`layer-ownership.md`](../testing/layer-ownership.md), "The file budget"). The rest of the gap is the free runners' variance, one tree having run 64 s and 110 s, and the suite's growth from 248 files to 282 meanwhile. The criteria are left as written and recorded as unmet, on the owner's call, rather than restated to the result.

**MB.190 — ~~Release and main-sync PRs skip the gate's checks~~** · **RETIRED 2026-10-09, not done**

> **Retired without being done.** ID kept. The owner's report was of checks
> running on the push to `staging` and `main`, and no push runs one; what ran
> beside the deploy was the release PR's gate, which the owner wants. A
> promotion PR keeps the full gate, so nothing in CI changes.
>
> **What it measured first**, kept because it holds for any filtered-off leg:
> a skipped `checks` leg still pulls its image in `Initialize containers` —
> the flag is read in the first step, after the job's `container:` starts — so
> a leg can skip its suite but not the pull, and its image build cannot be
> skipped with it ([`aggregating-workflows.md`](../ci/aggregating-workflows.md)
> already prices that pull).

_Story (retired):_ As a developer, I want a PR that only promotes commits already gated on their own PRs to skip the checks those PRs ran, so that cutting a release or syncing `main` does not pay for a second full CI run beside the deploy.

Minted on the owner's report that the checks were running alongside the staging and production deploys, and on their call that this buys nothing: the checks run before merge, will be required, and will run again in the merge queue M7.A.1 turns on. No push to `staging` or `main` runs a check — `deploy.yml` is the only workflow either starts — but the release PR cut from the same commit does: Release 0.6.0's PR Gate ran Vitest, Playwright and every `checks.yml` leg on `2aa34fe` a minute after staging's deploy of it began, over commits each of which had passed the gate on its own feature PR. A `main-sync/*` PR into `staging` does the same with commits gated on their hotfix PR into `main`. The combination a merge makes is the merge queue's to test, not the promotion's.

`pr-gate.yml`'s `changes` job decides it. A PR is a promotion when its head is `release/*` into `main` and every commit on it is already on `staging` (`git merge-base --is-ancestor` against the fetched `origin/staging`), or its head is `main-sync/*` into `staging` and every commit on it is already on `main`. A promotion sets every leg's run flag false, so each completes under its own name without running its suite, as the workflow header's no-job-level-`if:` rule requires of a check that will be required; `checks.yml`'s format and audit legs, unfiltered today, gain the flag the path-filtered legs already carry. `gitflow` runs as before, since it is what holds a promotion to its branch pair. A release branch holding a commit `staging` does not — a hotfix merged into it, or a direct push, which the Release Branches ruleset allows — is not a promotion and runs the full gate, as does every `hotfix/*` PR, whose commits nothing has gated yet. Whether the image builds can be skipped with the legs depends on whether a skipped container leg still pulls its image, which the task measures rather than assumes. `deploy.yml` is untouched, and `claude-docs/ci/aggregating-workflows.md` states the rule in the same PR.

_Acceptance criteria (retired — not to be met):_

- A release PR whose head is on `staging`, and a main-sync PR whose head is on `main`, run `gitflow` and complete every other gate check under its own name without running its suite
- A release PR carrying a commit not on `staging`, and a `hotfix/*` PR, run the full gate
- All three shown by `act` or a real PR, and recorded in the PR body
- `aggregating-workflows.md` states which PRs are promotions and why they skip

**MB.191 — The coverage provider chosen by measurement, istanbul against v8** · 1.5h

_Story:_ As a developer, I want the coverage run instrumented by whichever provider this suite runs fastest under, so that measuring coverage does not cost more than the tests it measures.

Minted during MB.181 on the owner's call. MB.181's profiling found v8 coverage roughly triples a dom file's time — `tests/components/IngredientForm/index.test.tsx` ran 12.3 s without coverage and some 40 s with it, locally — and CI's slowest-files block (MB.180) times the run with coverage on, so the file budget is spent on instrumentation as much as on tests. `@vitest/coverage-v8` collects V8's coverage of everything a worker executes, jsdom and React's development build included, and remaps it onto `src/`; `@vitest/coverage-istanbul` instruments only the files `coverage.include` names, at transform time, and leaves the rest running as it would without coverage. Which is faster here is a measurement, not a known answer: istanbul's instrumented code runs slower per line of `src/`, where v8's cost is in collecting and remapping. So the task measures first — summed worker time, vitest wall and the slowest-files block under each provider, on CI's runner — and adopts istanbul only if the run is faster and the 80 % threshold holds, with `.reports/coverage/coverage-summary.json` still in the shape `.github/scripts/lib/coverage-table.mjs` and `summarize-vitest.mjs` read; otherwise it records why v8 stays. The two providers count branches differently, so the per-file figures later tasks compare against are re-baselined in the same PR. It precedes MB.189, whose closing measurement is the consolidation's and is taken under the provider that stays. The doc naming the coverage configuration is corrected in the same PR.

_Acceptance criteria:_

- Summed worker time, vitest wall and the slowest-files block under v8 and under istanbul, from CI, recorded in the PR body
- The faster provider is the one `vitest.config.mts` names, and `npm run test:coverage` holds the 80 % threshold under it
- This PR's own CI comment carries the coverage table and the slowest-files block
- The decision and its measurement are recorded in `claude-docs/design-decisions/mb.191-coverage-provider.md`, whichever provider stays

_Measured, and why the first criterion's CI pair is recorded here:_ the decision was taken on three alternating pairs of local full runs, istanbul 32 % off the wall and 21 % off the summed time, and #733's body left its CI column blank. CI's pair, read the same way from the Vitest job logs afterwards: #732 under v8 ran 87.7 s of wall and 261.6 s summed, #733 under istanbul on the same tree 87.6 s and 239.7 s, and per file `IngredientForm/index.test.tsx` 29.4 → 22.9 s, `references.test.tsx` 27.4 → 22.6 s, `compendium.test.tsx` 16.5 → 11.5 s. On CI's runner the wall did not move and the summed time fell 8 %: the saving is the dom project's, and the free runners' variance (one tree ran 64 s and 110 s) is larger than it.

**MB.192 — A reseed of `standard` puts a deleted deity pick back at the end of its list** · 1h

_Story:_ As a developer, I want the local database to reseed cleanly after I have removed a compendium deity pick through the app, so that compose's `db-init` does not fail on every start until a `db:reset`.

Minted in MB.183's close-out on the owner's call, and placed after MB.132, the admin surface that reads and writes these picks. MB.183 made a reseed of `standard` put back a soft-deleted compendium deity pick, as a reset of the local fixtures (`restoreDeletedDeityPicks`, on for `standard` and off for `demo`), and `insertMissingDeities` in `src/db/seed/standard.ts` inserts the missing pick at its seed index, keyed over the live rows. But `replaceDeities` (`src/modules/ingredients/services/ingredient-rows.ts`) soft-deletes a dropped pick and renumbers the kept ones to contiguous positions, so a pick removed from the middle of a list leaves its position held by the pick below it; the reseed's insert then fails `ingredient_deities_position_unique`, and with it the whole scenario, on every compose `db-init` until a `db:reset`. Removing the last pick is fine, which is the case MB.183's test covers; [`db/standard-scenario.md`](../db/standard-scenario.md), "A reseed of standard puts a deity pick back; demo does not", records it as a known limitation. The fix: a restored pick takes the first position above every live pick of its ingredient — the end of the list as the admin left it — rather than its seed index. That keeps the seed's shape, "a second run adds nothing and moves nothing" (`tests/db/seed/index.test.ts`), since no live row moves; resetting the list to the seed's order instead would reorder what a keeper ordered, which a seed that adds what is missing has never promised. `demo` passes `false` and is untouched; staging and production run no scenario seed. The regression test sits in `tests/db/seed/standard.test.ts` beside MB.183's "puts back a compendium deity pick a keeper has since deleted", under the block that truncates first: it removes a middle pick through the service, asserts the precondition that the pick below took its position, reseeds, and reads the pick live at the end. The doc's limitation paragraph becomes the behaviour, in the same PR.

_Acceptance criteria:_

- Removing a deity pick from the middle of a compendium entry's list through the service and reseeding `standard` succeeds, the pick live again at the end of its list, with the precondition that the pick below had taken its position asserted first
- The seed-shape sweep holds: a second run adds nothing and moves nothing, and the `demo` row still keeps the deletion
- `db/standard-scenario.md` describes the placement, and its known-limitation paragraph is gone

**MB.193 — The workspace creation ledger (schema)** · 1.5h

_Story:_ As a site keeper, I want every change to who may create a coven recorded where a later edit cannot overwrite it, so that "who approved this person, and who revoked them" still has an answer after their row has changed again.

_Superseded 2026-10-10: folded into MB.194's `user_privilege_changes`, which copied its rows and which a trigger on `users` fills (MB.195); MB.196 and MB.197 retire the table ([`design-decisions/mb.194-privilege-ledger-by-trigger.md`](../design-decisions/mb.194-privilege-ledger-by-trigger.md))._

M5.8's table half, minted while building M5.8 on the owner's calls: a keeper may revoke the flag as well as grant it, and each change is recorded in a ledger ([`design-decisions/m5.8-revoking-workspace-creation.md`](../design-decisions/m5.8-revoking-workspace-creation.md)). `users.updated_by` is overwritten by the next update to the row — a verified email change, a role grant, Better Auth's own writes — so an approval's provenance would last only until then, the gap M2.9's record left to M5.8. The ledger is MB.58's shape for a second privilege. It is not the v2 edit history.

`workspace_creation_changes`: `id`, `userId` → `users.id`, `change` (`grant` | `revoke` | `invitation` | `admin`, a pgEnum because the set is closed), plus the full `...auditColumns` spread like every non-join table. `created_by` is the actor and `created_at` is when. `grant` and `revoke` are a keeper's act on `/admin/users` (M5.8); `invitation` is accepting a workspace invitation, which sets the flag (M7.5); `admin` is being made admin while the flag was off, since a grant sets it in the same write (MB.177, MB.59). Nothing in v1 updates or deletes a row: the writer refuses the table every update and delete, as `NotAppendOnly` does MB.58's. **No backfill**: who set a flag held before the ledger is not known, and a row stamped by guess would be a false record, so a holder with no row predates the ledger.

_Acceptance criteria:_

- Migration creates the table, its enum and its `CREATE OR REPLACE TRIGGER` line for `set_updated_at`, so `updated-at-trigger.test.ts` stays green without an edit
- The migration only adds, so the destructive-DDL check passes with no sidecar
- The schema test asserts the columns, the enum values and the foreign key
- The repository offers an insert and a read for the table and nothing that updates or deletes it, asserted at the type level
- No row exists after migration, asserted against the seeded template

**MB.194 — `user_privilege_changes`, the one privilege ledger (schema)** · 2h

_Story:_ As a site keeper, I want every change to a user's privileges kept in one ledger the database will not let anyone rewrite, so that a third privilege is not a third table and a record of misuse cannot be edited away.

Minted after M5.8 on the owner's call, to stop privilege ledgers multiplying ([`design-decisions/mb.194-plan.md`](../design-decisions/mb.194-plan.md)). MB.58's `admin_role_changes` and MB.193's `workspace_creation_changes` share one shape, one row per change to a column on `users`, and a third privilege would have been a third table, migration, schema test and doc entry. This is the expand step: one table both fold into, append-only by a trigger rather than by the writer's types, holding a copy of both. MB.195 makes `users` fill it; MB.196 and MB.197 retire the two it replaces. It is not §13's edit history: it records two columns of one table, as a privilege's account.

`user_privilege_changes`: `id`, `userId` → `users.id`, `privilege` (`admin` | `create_workspace`), `change` (`grant` | `revoke`), `via` (`bootstrap` | `admin` | `invitation` | `manual`), `note` (nullable text), plus the full `...auditColumns` spread. `created_by` is the actor and `created_at` when. Each enum is a pgEnum because each set is closed; a future flag on `users` is a value in `user_privilege`, not a table. The migration also creates `forbid_rewrite()`, a trigger function that raises on any update or delete, attached `BEFORE UPDATE OR DELETE`, so append-only holds against `psql` and the seed as well as the repository. It copies both old ledgers with their ids and stamps, so MB.197's final sweep can skip what is already there: `admin_role_changes`' `bootstrap`, `grant` and `revoke` become `admin` rows with that change and `via` `bootstrap`, `admin` and `admin`; `workspace_creation_changes`' `grant` and `revoke` become `create_workspace` rows `via` `admin`, its `invitation` a grant `via` `invitation`, and its `admin` a grant `via` `admin`.

_Acceptance criteria:_

- The migration creates the table, its three enums, `forbid_rewrite()` and its trigger, and the `set_updated_at` line, so `updated-at-trigger.test.ts` stays green without an edit
- The migration only adds, so the destructive-DDL check passes with no sidecar
- The schema test asserts the columns, the enum values, the foreign key and that no index is declared
- An update and a delete through the raw client are each refused by `forbid_rewrite()`, and an insert succeeds, so it is the trigger that refuses
- A catalogue-introspection test lists the append-only tables and asserts each carries `forbid_rewrite`, failing a table added to the list without it
- The copy, re-run against a row of each old table and each `change`, lands each with its id, stamps and mapped privilege, change and route
- No row exists after migration on a fresh database, asserted against the seeded template
- `design-decisions/mb.194-privilege-ledger-by-trigger.md` records the model, why a trigger, why the route is declared, and what was rejected; DESIGN.md §5 and `modules.md` carry the table, and §5's two old entries say they are superseded

**MB.195 — Privilege changes record themselves, with their route** · 3h

_Story:_ As a site keeper, I want every change to who is a keeper or who may create a coven recorded by the database, with how it came about and an optional reason, so that no code path, script or `psql` session can change a privilege without leaving a row.

MB.194's behaviour half. A trigger on `users`, `record_privilege_change()`, `AFTER INSERT OR UPDATE`, with a `WHEN` clause on `role` and `can_create_workspace`, writes one `user_privilege_changes` row for each watched column that changed. It is attached as two triggers over the one function, `record_privilege_change_on_insert` and `record_privilege_change_on_update`, since an insert trigger's `WHEN` may not name `OLD` (as built). `created_by` is `app.current_user_id`, or the row's own `updated_by` where no transaction published one. `via` and `note` come from two new transaction-local settings, `app.privilege_route` and `app.privilege_note`, which `withAudit(session, fn, { via, note })` publishes in the one `set_config` statement it already runs. **A change that declares no route is refused**, so a service that forgets it fails its own test, and a `psql` fix must say `manual` first. Better Auth's own writes never touch either column, so the `WHEN` clause keeps them off this path.

Every writer that changes a privilege declares its route in the same PR, since the trigger refuses those that do not: M5.8's approval and revoke (`admin`), dropping its own insert into `workspace_creation_changes`; the primary keeper's promotion at sign-in and at verification (`bootstrap`); and the `standard` seed's fixture E, inserted with both settings so the trigger writes its two `bootstrap` rows stamped as E, replacing `insertMissingAdminBootstrap`. A–D are inserted holding the creation flag too, so the seed declares `bootstrap` around their insert as well, and the trigger gives each a `create_workspace` grant stamped as the seed's own user (as built). MB.59, M7.5 and MB.70 are corrected here to declare a route and write no ledger row of their own, MB.59's confirmation gaining an optional reason that becomes `note`, and MB.59 hands story 61 to MB.199 and MB.200.

_Acceptance criteria:_

- Granting and revoking the flag through M5.8's service writes one row each, `via` `admin`, stamped with the acting keeper; the same write with no route declared is refused, so it is the trigger that records
- Making a user admin who lacks the flag writes two rows at one instant, one per privilege, both `via` the declared route
- A refused grant or revoke writes no row, because no column changed
- A `psql`-style update without `app.privilege_route` is refused with a message saying a route must be declared, and with it set to `manual` writes a `manual` row stamped with the row's `updated_by`
- The primary keeper's promotion writes `bootstrap` rows; a reseed of `standard` gives fixture E its two `bootstrap` rows stamped as E and adds none on a second run
- Better Auth's sign-in and profile writes to `users` write no row
- `app.privilege_route` and `app.privilege_note` are transaction-local, so the next transaction on a pooled connection sees neither, asserted as `app.current_user_id` is
- The catalogue test asserts `users` carries `record_privilege_change`
- `db/write-path.md` documents the two settings, `auth/admin-bootstrap.md` the `manual` route for a `psql` fix, and MB.59, M7.5, MB.70, MB.63, MB.58 and MB.193's entries are corrected and synced

**MB.196 — Nothing declares the two old privilege ledgers** · 1.5h

_Story:_ As a developer, I want the code to stop naming the two privilege ledgers MB.194 replaced, so that a later migration can drop them without breaking the deploy that reads them.

The contract step's first half (`db/expand-contract.md`; CLAUDE.md rule 10). After MB.195, nothing writes `admin_role_changes` or `workspace_creation_changes`; this removes their schema files, their schema tests, their rows in `table-metadata.ts`, and `NotAppendOnly` from the writer's signatures, which leaves it marking no table. **`db:generate` is not run here**: it would emit the drops, which are MB.197's.

_Acceptance criteria:_

- No file under `src/` names either table, nor any test file but the catalogue lists in `tests/support/db/table-metadata.ts` and MB.194's copy test, which go with the drop (MB.197), asserted by a search in the PR body (amended 2026-10-10: the catalogue sweeps read the tables while the database holds them)
- `NotAppendOnly` is gone from `src/db/repository/types.ts` and every signature that carried it
- No migration is added, and the destructive-DDL check passes with no sidecar
- DESIGN.md §5 and §14, `modules.md`, `db/standard-scenario.md` and `db/migrations-and-scripts.md` name only `user_privilege_changes`, and the M2.9 and M5.8 records carry a dated pointer to MB.194

**MB.197 — Drop `admin_role_changes` and `workspace_creation_changes`** · 1h

_Story:_ As a developer, I want the two retired privilege ledgers dropped once no deploy reads them, so that the schema holds one ledger and not three.

The contract step's second half. **It is not gated on a production release: production was not live, on the owner's call, 2026-10-10.** Production's deploy declares `admin_role_changes`, and a release runs every pending migration before it promotes (`db/expand-contract.md`, MB.137's worked case), so the release carrying MB.196 carries this drop too and that deploy's ledger reads fail for its rollout, which costs nothing while no member uses production, as MB.168 argued (amended 2026-10-10: the entry first waited for a release carrying MB.196 to reach production). `db:generate` emits the two drops and their enums; MB.194's copy, prepended with `ON CONFLICT (id) DO NOTHING`, sweeps any row the pre-switch deploy wrote during the rollout. The last names in the tests go with the tables: both come out of `AUDITED_TABLES` in `tests/support/db/table-metadata.ts`, where MB.196 left them for the catalogue sweeps, and MB.194's copy test in `user-privilege-changes-schema.test.ts` becomes this migration's sweep test.

_Acceptance criteria:_

- The migration sweeps both tables into `user_privilege_changes`, then drops both tables and both enums
- A row written to either old table after MB.194's copy lands in the new one with its id, asserted by re-running the sweep against such a row
- Both tables leave `AUDITED_TABLES`, MB.194's copy test is replaced by that sweep test, and afterwards no file under `src/` or `tests/` but the migrations and that sweep test, which restores the tables in its clone to write the rows it sweeps, names either table (amended 2026-10-10: the sweep test was not excepted)
- `src/db/migrations/<tag>.ack.md` acknowledges the destructive DDL with its reason, and the destructive-DDL check passes with it
- The PR body says the drop is not gated on a production release, production not being live, on the owner's call (amended 2026-10-10: it first named the release that carried MB.196 to production)

**MB.198 — One table mark replaces the state-ledger markers** · 2h

_Story:_ As a developer, I want a table written only through named calls to say so once, in its schema file, so that a new such table does not add a marker to every generic writer method and an unrelated table sharing a column name is not refused by accident.

Minted with MB.194 ([`design-decisions/mb.194-plan.md`](../design-decisions/mb.194-plan.md)). `NotPauseLedger` (`{ endedAt?: never }`) and `NotInvitation` (`{ tokenHash?: never }`) each key a refusal on a column that happens to be unique to one table, and each was added to six signatures in `src/db/repository/types.ts`. They become one mark, `NamedWrites = { readonly $writes: 'named' }`, applied in the schema file by a one-line cast helper, `namedWrites(table)`, in a new runtime file `src/db/table-marks.ts`, with every generic writer method, unscoped, proof-scoped and compendium-tier, taking `Generic = { $writes?: never }`. `$writes` is a phantom key beside Drizzle's `$inferSelect`, so no column can collide with it and drizzle-kit sees the same object. The pause and admin-invitation tables take the mark. Their named writes move beside their finders, into `admin-roles.ts` and `admin-invitations.ts`, spread into the writer by `writerFor`, so a later named table touches its own repository file rather than `write.ts`. A sweep over code, so it lands as a mechanism and its guard, before MB.63 and MB.70 build on the named writes.

_Acceptance criteria:_

- `NotPauseLedger` and `NotInvitation` are gone, and the two tables are refused by every generic writer method through the mark alone
- Two probe tables, one unscoped and one with a nullable `workspaceId`, carry the mark; `write.test.ts` asserts with `@ts-expect-error` that every generic method refuses each, so typecheck fails if one stops
- The writer still offers exactly twenty-three methods, and the named writes' existing tests pass unchanged from their new files
- `db/write-path.md` gains a "Table marks" section; `db/finder-convention.md`, `db/repository-files.md`, `db/invitations.md` and the MB.62 record name the mark instead of the markers

**MB.199 — Read the privilege ledger** · 2h

_Story 61 — As a keeper, I want to see every change to who is a keeper and who may create a coven, with who made it, how, when and why, so that misuse comes to light._

The read under MB.200's page. `listPrivilegeChanges(session, { userId, privilege }, page)` in `src/modules/identity/services/privilege-changes.ts`, under `assertSiteAdmin`, newest first by `(created_at, id)` through `findPage` (rule 8), each filter optional. GraphQL `privilegeChanges(userId, privilege, first, after)` as `t.pagedConnection`, with enum types for privilege, change and route, the nullable note, and the subject and actor resolved through the per-request user loader (rule 9). It carries M5.7's Pothos admin scope beside the service check. An index on `(user_id, created_at desc)` is added here if the keyset read's plan wants one.

_Acceptance criteria:_

- A keeper reads every change, newest first, and each filter narrows it; a page boundary neither repeats nor drops a row
- A non-keeper is refused with `Forbidden` at the service and at the schema independently; the test asserts fixture E reads the same rows, so it is the role that refuses
- Subject and actor resolve in one batched query per page, asserted by query count
- `npm run codegen` output and the SDL snapshot are committed, and `tests/guards/pagination.test.ts` stays green

**MB.200 — The privilege ledger page** · 3h

_Story 61 — As a keeper, I want to see every change to who is a keeper and who may create a coven, with who made it, how, when and why, so that misuse comes to light._

`/admin/privilege-changes`, one page over MB.199's read: one ledger, filtered by part of the subject's name or email (`?query=`, which MB.199's read takes from this task on, matched as the user list matches) and by privilege (`?privilege=`, a dropdown), not a page per privilege and not a feed merged with the pause or invitations, which stay where they are acted on. A server component calling the service through `cache()`, numbered through `src/lib/pagination.ts`'s helper as every admin page is (MB.132), with a `PrivilegeLedger` component (its directory, story and doc) listing when, subject, privilege, change, route, actor and the note where there is one. `AdminNav` gains it after Users, and each `UserList` row gains a permissions history icon before the name, opening the page searched for that user's address (the owner's calls in review, over a `?user=` filter and a History column).

_Acceptance criteria:_

- A keeper sees every change, newest first, paged, and the filters narrow it; each row names the subject and actor, linking to their `/admin/users` row, and shows the note only where one was given
- The page states plainly when there is nothing to show, overall and for a filter
- A user row's permissions history icon opens the page searched for that user's address
- A signed-in non-keeper gets the styled not-authorised page, as every `/admin` page does
- The Playwright spec covers the page, the filters and the link, with `@axe-core/playwright` clean, run against the e2e container
- Component tests use role and label queries only, and story 61's acceptance test passes

**MB.201 — `invitations`, one two-tier table (schema)** · 2h

_Story:_ As a developer, I want workspace and admin invitations in one table, so that the token, the expiry, the accept and the revoke are built once rather than twice.

Minted with MB.194 on the owner's call ([`design-decisions/mb.194-plan.md`](../design-decisions/mb.194-plan.md), "The invitations"). M7.1's `workspace_invitations` and MB.69's `admin_invitations` have the same nine columns, and nothing writes or reads either yet, while M7.2 to M7.7 and MB.70 are about to build a token path, an accept, a revoke, a pending list and an acceptance page on each. One table in `ingredients`' two-tier shape: `workspaceId` and `role` nullable and paired by a CHECK, so a null workspace is a site-tier invitation, which grants admin, as a null workspace is a compendium entry. M2.9's objections to reusing the workspace table, that it was scoped and its CHECK refused admin, are both answered by the nullable pair. Born with MB.198's mark, since the table authorises a membership or a grant.

`invitations`, in `src/modules/coven/schema/invitations.ts`: `id`, `workspaceId` (nullable → `workspaces.id`), `email`, `role` (nullable `workspace_role`), `tokenHash`, `expiresAt` (default seven days), `acceptedAt`, `acceptedBy`, `revokedAt`, `note` (nullable), plus `...auditColumns`. CHECK `invitations_tier`: `(workspace_id is null) = (role is null)`. CHECK `invitations_role_invitable`: `role is null or role in ('viewer', 'member')`, the allowed set as today. The unique index on `token_hash` is partial, as both tables' are. The migration copies both tables with their ids and stamps.

_Acceptance criteria:_

- The migration creates the table, its CHECKs, its index and its `set_updated_at` line, and only adds, so the destructive-DDL check passes with no sidecar
- A workspace without a role, and a role without a workspace, are each refused; `owner` is refused; a null pair is accepted
- The only column whose name mentions a token is the hash, asserted as a property of the table
- The copy lands a row of each old table with its id, stamps, tier and note
- The table carries MB.198's mark, so every generic writer method refuses it
- `design-decisions/mb.201-two-tier-invitations.md` records the model, why now, and the three things a reader must know: what a null workspace means, why the table is `coven`'s, and that policy stays in two services while the mechanics exist once; DESIGN.md §5 and `modules.md` carry it

**MB.202 — Invitations are written and read by tier** · 2.5h

_Story:_ As a developer, I want one set of named invitation writes and finders, each scoped by the proof it is handed, so that the workspace and admin invitation tasks build on the same mechanics.

MB.201's code half. MB.69's `insertAdminInvitation`, `acceptAdminInvitation`, `revokeAdminInvitation` and `findAdminInvitationByToken` become `insertInvitation`, `acceptInvitation`, `revokeInvitation` and `findInvitationByToken`, in `src/db/repository/invitations.ts`, each overloaded on the proof: a `Membership` fills the workspace from the proof and requires a role, a `SiteAdmin` writes the null pair, and each revoke reaches only its own tier. `findPendingInvitationsInWorkspace(membership)` and `findPendingSiteInvitations(admin)` are added for M7.6's and MB.70's pending lists. The two old schema files go, and **`db:generate` is not run here**. M7.1 to M7.7, MB.69 and MB.70 are corrected to build on the one table, one accept service and one `/invite/[token]` route that branches by tier.

_Acceptance criteria:_

- A steward's invitation carries its workspace and role, a keeper's the null pair, and the token's hash is the only one stored
- A workspace revoke cannot reach a site-tier row by id, nor a site revoke a workspace row, each asserted by direct id against a row the other tier can revoke
- Accepting matches only a pending row whose address the session holds verified, on either tier, and a second accept matches nothing
- The writer still offers exactly twenty-three methods
- No file under `src/` names either old table, and no migration is added
- `db/invitations.md` describes one table; DESIGN.md §5, §7 and §14, `modules.md` and the MB.61 and M2.9 records are corrected; M7.1 to M7.7, MB.69 and MB.70's entries are corrected and synced

**MB.203 — Drop `workspace_invitations` and `admin_invitations`** · 1h

_Story:_ As a developer, I want the two retired invitation tables dropped once no deploy reads them, so that the schema holds one.

As MB.197, for MB.202's tables. **It is not gated on a production release: production was not live, on the owner's call, 2026-10-10**, so the release carrying MB.202 may carry this drop too, and production's deploy, which declares both tables, loses its reads of them for that rollout only (amended 2026-10-10: the entry first waited for a release carrying MB.202 to reach production). `db:generate` emits the drops, and no enum: `workspace_role` stays, held by `workspace_members` and `invitations`; MB.201's copy, prepended with `ON CONFLICT (id) DO NOTHING`, sweeps any row written during the rollout. It may share a release with MB.197, as its own PR. The last names in the tests go with the tables: both come out of `AUDITED_TABLES` in `tests/support/db/table-metadata.ts` and out of the partial-index sweep, where MB.202 left them for the catalogue sweeps, and MB.201's copy test becomes this migration's sweep test.

_Acceptance criteria:_

- The migration sweeps both tables into `invitations`, then drops both
- A row written to either old table after MB.201's copy lands in `invitations` with its id, asserted by re-running the sweep against such a row
- Both tables leave `AUDITED_TABLES` and the partial-index sweep, MB.201's copy test is replaced by that sweep test, and afterwards no file under `src/` or `tests/` but the migrations and that sweep test, which restores the tables in its clone to write the rows it sweeps, names either table (amended 2026-10-10: the sweep test was not excepted)
- `src/db/migrations/<tag>.ack.md` acknowledges the destructive DDL with its reason, and the destructive-DDL check passes with it
- The PR body says the drop is not gated on a production release, production not being live, on the owner's call (amended 2026-10-10: it first named the release that carried MB.202 to production)

**MB.204 — The provisional-account sweep skips an account holding a privilege change** · 1h

_Story:_ As the site owner, I want the sweep of lapsed unverified accounts to keep running when a keeper has vouched for one of them, so that one approved account cannot stop every other one being cleaned up.

Minted after MB.195 on the owner's call. `deleteProvisionalUsers` hard-deletes every lapsed unverified account holding a provider in one statement (MB.67; `auth/admin-bootstrap.md`, "Provisional accounts"). A keeper may approve an unverified account for coven creation (M5.8) or make it a keeper (MB.59), and either writes a `user_privilege_changes` row that references the account with a plain foreign key, as both earlier ledgers did. If that account never verifies, the sweep's delete violates the key and fails, and no lapsed account is removed on that run or any later one. The fix is the owner's: the sweep skips any account holding a ledger row, since a keeper has vouched for it; the history stays, and MB.205 and MB.59 warn the admin before they vouch. Letting the rows go with the user was rejected: it erases what the ledger keeps, and `forbid_rewrite` refuses the delete and the update either way.

_Acceptance criteria:_

- A lapsed unverified account holding a provider and a ledger row is kept by the sweep, and a lapsed one beside it without a row is deleted in the same run; the test asserts the first would be deleted were its row absent, so it is the row that keeps it
- The sweep never fails on the ledger's foreign key, asserted with such an account present
- An account kept this way is otherwise unchanged: its sessions, accounts and ledger rows remain
- `auth/admin-bootstrap.md`, "Provisional accounts", and `db/provisional-account-delete.md` say an account a keeper has vouched for is not swept, and why

**MB.205 — Warn before approving an unverified account for coven creation** · 1h

_Story:_ As a site keeper, I want to be told when the account I am about to approve has not verified its email, so that I vouch for it knowing nobody has proved who holds the address, and knowing it will not lapse.

Minted with MB.204 on the owner's call. M5.8's Approve on `/admin/users` opens a confirmation naming the user. When the row's email is unverified, that confirmation also says so, in plain words: the address has not been proved, and approving keeps the account rather than letting it lapse (MB.204). The keeper may still approve; it is a warning, not a refusal, since M2.9 leaves confirming who someone is to the admin. Revoke carries no warning. MB.59's grant gets the same warning in its own confirmation.

_Acceptance criteria:_

- Approving a user whose email is unverified shows the warning in the confirmation, and approving a verified user does not; both still approve on confirm
- The warning is read with the confirmation by assistive technology, asserted by role and label queries, and the component's story shows the unverified case
- The Playwright admin spec covers approving an unverified user through the warning, with `@axe-core/playwright` clean, run against the e2e container
- `components/user-list.md` describes the warning

**MB.276 — An Admin's Compendium Edit Saves Whatever the Autosave Timing** · 4h

_Story:_ As a site keeper editing a compendium entry, I want the Save Ingredient button to reflect what is unsaved whatever the autosave timing, so that the edit flow behaves the same on a slow machine as on a fast one and story 18 passes first time.

The ingredient form saves on a pause (`src/components/IngredientForm`, the autosave that creates at the first named save and updates on a pause). In `tests/e2e/stories/07-admin.spec.ts` (around line 398) story 18 fills Name, Description, adds the Oil form and its Safety Notes, then waits for Save Ingredient to be enabled. On a slow runner the pause-save lands first, so nothing is left to save, Save stays disabled, and the story times out at 60 s. Either the form must keep Save meaningful after an autosave, if the design says so, or the story must prove the flow in a way the autosave timing cannot break; the task decides which and states why.

Found on 2026-10-30 on the PR gate's stories job: flaky (failed, then passed on retry) on PR #1344; failed both attempts on PR #1358's run; passes locally on the same branch. A wrong result, seen sometimes, as a site keeper, under Admin & Compendium. Steps to reproduce:

1. Run the story suite on CI's runner (the PR gate's stories job)
2. Story 18 signs in as a site keeper and opens `/admin/compendium`
3. It adds the entry "Aaa Testwort", then opens its Edit Ingredient dialog and presses Open All
4. It fills Name, Description, adds the Oil form and fills its Safety Notes, taking longer than the autosave pause on a slow runner (assumed)
5. It waits for Save Ingredient to be enabled

Actual: Save Ingredient stays disabled for 60 s and the story times out; on a fast run it passes, so the story is flaky. Expected: Save Ingredient is enabled while the form holds unsaved changes, and the story passes first time on every runner.

_Chosen (story 18 and story 30):_ the form keeps its behaviour: once an autosave has filed the edits there is nothing left to save, so Save Ingredient is disabled, and that is correct. The stories change instead: each holds the form's own save request with `page.route` (`holdSaves` in `tests/e2e/stories/ingredient-dialogs.ts`) until after the click on Save, so the autosave cannot land first on any runner. The story changes landed on `staging` through #1383, as `52cd4902c` (story 30's accessibility scan), `be54fd8d9` (story 18's) and `0e7017f57` (the hold). A longer wait would only move the race, and changing the form would make Save enabled over nothing.

_Also in scope:_

- The dialog heading and address after a save the form makes by itself. The heading came from the page's data, which only Save and the create updated, so an autosave that renamed an entry left the old name in the heading. The form now calls a new `onAutosaved(row)` after an autosave that updates an existing ingredient. The admin compendium dialog replaces its address with the saved slug and fetches the page again; the coven entry dialog only fetches again.
- The Playwright report and trace upload on a test that failed and then passed on retry. The upload ran only when the run failed, so a flaky pass left no trace to read. The summarisers now write a `flaky` output and the upload step runs on it.

_Acceptance criteria:_

- The form's behaviour is unchanged: Save Ingredient is disabled once a save the form made by itself has filed every edit. The fault was in stories 30 and 18, and their proof is those stories holding back the save request until after the click on Save. No component test is added for unchanged behaviour
- Story 18 passes first time on CI's runner in two consecutive PR-gate runs, with no retry
- The chosen behaviour is stated in `claude-docs/components/ingredient-form.md` ("Autosave") and, if the form changes, in that doc's form save rules
- No other story's timing is changed to make it pass
- After an autosave renames an existing ingredient, the dialog heading shows the saved name and the admin compendium dialog's address names the saved slug, and what was typed after the autosave is kept: a component test under `tests/app/(shell)/admin/compendium/` that failed before the fix
- A run where a test failed and then passed on retry uploads the Playwright report and traces, and a clean run still does not

**MB.277 — The Unused Code Check Finds Nothing Left to Clear** · 4h

_Story:_ As a developer, I want `npm run lint:unused` (knip, the tool that finds unused code) to pass on a clean checkout, so that the non-blocking `checks / unused` comment on a pull request only ever reports what that pull request introduced.

Knip's first run on CI reported its config could not load `drizzle.config.ts` and `playwright.config.ts` (both throw when `DATABASE_URL` is unset, and the `unused` job sets none), which also made four files look unused. It also reported an unused development dependency, one unlisted dependency, three environment names in `.github/workflows/deploy.yml` read as imports, unused exports and unused exported types, mostly re-exports from the module barrels and `src/db/repository/index.ts`.

Found on 2026-10-30 on the `checks / unused` job of PR #1365, which exited 2; it is on `staging` too. A wrong result, every time, under Admin & Compendium (tooling). Steps to reproduce:

1. Check out `staging` with no `DATABASE_URL` set, as the CI job has none
2. Run `npm run lint:unused`

Actual: exit code 2 with config-load errors and findings. Expected: exit code 0 with no findings.

_Acceptance criteria:_

- `npm run lint:unused` exits 0 on a checkout with no `DATABASE_URL` set, and on the same checkout with one
- Each genuinely unused file, export, type and dependency is removed, after a search for dynamic and string references; each false positive is recorded in `knip.json` with a narrow entry and a reason, and no blanket ignore is added
- The tests for what changed pass, and `npm run typecheck` and `npm run lint` are clean
- `claude-docs/commands.md` names the false positives `knip.json` skips and drops the sentence saying the repo still has findings

**MB.278 — The Gitflow Check Reads Pull Request Values Safely** · 1h

_Story:_ As a maintainer, I want the Gitflow check to receive a pull request's branch names and author as environment variables, so that the text of a branch name can never be run as part of the check's shell script.

`.github/workflows/gitflow.yml` writes `github.event.pull_request.head.ref`, `.base.ref` and `.user.login` straight into the text of a `run:` script, so the shell sees whatever those values contain. `.github/workflows/close-task-on-merge.yml` already passes its values through the step's `env:` and reads them as quoted shell variables; this task does the same here and sweeps `.github/workflows/` for any other `${{ github.event.* }}` written inside a `run:` script.

Found on 2026-10-30 in a security review of the repository. A wrong design, always, under Admin & Compendium (tooling). Steps to reproduce: not applicable; this is a code-reading finding.

Actual: the check's script is built from pull request text. Expected: the script is fixed text, and the values arrive as data.

_Acceptance criteria:_

- A regression test under `tests/guards/` that fails before the fix: it reads every file in `.github/workflows/` and fails when a `run:` script contains `${{ github.event.`
- `gitflow.yml` passes the three values through the step's `env:` and reads them as quoted shell variables
- Any other `run:` script found by the sweep gets the same change, and the pull request body lists each one
- The Gitflow check still passes a valid pull request and still refuses an invalid one, with the same messages

**MB.279 — Pages Carry Security Headers** · 3h

_Story:_ As a visitor, I want the site to tell my browser which scripts may run, who may frame it and that it must be reached over HTTPS, so that the browser blocks a whole class of mistakes before they reach me.

The site sends none of these headers outside the workshop, which keeps its own. This task adds a Content Security Policy (a list of the places a page may load scripts, styles and images from), `frame-ancestors` (which refuses framing by another site), HTTP Strict Transport Security (HSTS: tells the browser to use HTTPS only), `X-Content-Type-Options` and `Referrer-Policy`. Whether Vercel already sends HSTS for the production domain is unconfirmed; the task checks the live response first and sets the header only where it is missing.

Found on 2026-10-30 in a security review of the repository. A wrong result, always, under Public Facing. Steps to reproduce: not applicable; this is a finding from reading the configuration.

Actual: pages carry none of these headers. Expected: every page outside the workshop carries them, and nothing the site needs is blocked by them.

_Acceptance criteria:_

- A regression test that fails before the fix: the header configuration in `next.config` (or the proxy) returns each of the five headers for an application path, and none of them for the workshop
- The policy is checked in a browser: a Playwright spec loads the home page, `/compendium` and a signed-in page, and records no policy violation in the console
- The policy names its sources explicitly, with no blanket `*` and no `unsafe-eval`; each `unsafe-inline` that remains is explained in a comment beside it
- The task states whether the production response already carried HSTS, and the header is added only if it did not
- `claude-docs/` records the policy and how to relax it for a new third-party source

**MB.280 — Invitation Mail Is Limited per Sender** · 3h

_Story:_ As the site's operator, I want each person's invitation mail limited over time, so that a coven steward cannot send unlimited mail through the site's mail provider.

Coven invitations and their resends each send one mail from the site's address through the mail provider (MB.65). Nothing limits how many one sender may cause, so a single account can use up the provider's allowance or harm the sender reputation of the site's domain. The limit counts per sending account, covers both new invitations and resends, and answers with an explaining error that says when the sender may try again.

Found on 2026-10-30 in a security review of the repository. A wrong result, always, under Coven & Grimoire, as a coven steward. Steps to reproduce: not applicable; this is a finding from reading the invitation service.

Actual: there is no limit. Expected: a sender who passes the limit is refused until the window passes, and other senders are unaffected.

_Acceptance criteria:_

- A regression test that fails before the fix: a sender who has sent the limit's number of invitations in the window is refused the next, whether a new invitation or a resend, and the refusal names when to try again
- The same test shows the guard is what refuses: a sender under the limit succeeds, and a second sender is not affected by the first sender's count
- The count is kept in the database, so it holds across server instances, and the limit and window are named constants in one place
- A refused attempt sends no mail and creates no invitation row
- `claude-docs/` states the limit and its window beside the invitation rules

**MB.281 — An Unverified Account Reaches No Workspace Data Through the API** · 3h

_Story:_ As a coven steward, I want an account whose email address is unverified to be refused every workspace operation on the API as well as on the pages, so that the rule that such an account reaches only `/account/email` and the public pages cannot be sidestepped by calling `/api/graphql` directly.

`CLAUDE.md` ("An address changes only at verification") says an unverified account reaches `/account/email` and the public pages and nothing else. `requireSession()` enforces that for pages, but the GraphQL endpoint builds its session without that check, so the rule holds on one of the two access paths only.

Found on 2026-10-30 in a security review of the repository. A wrong result, always, under Sign-in & Account. Steps to reproduce: not applicable; this is a finding from reading the two session paths.

Actual: the pages refuse an unverified account and the API does not. Expected: both refuse it, with the same explaining error, and the operations an unverified account legitimately needs (changing its email address, reading its own account) still work (`me`, `setEmail` and sign-out at least).

_Acceptance criteria:_

- A regression test that fails before the fix: a session whose email is unverified is refused a workspace-scoped query and a workspace-scoped mutation by direct id, while the same user with a verified address succeeds on the same ids (the precondition that the access could have succeeded)
- The refusal is made in one place that every workspace-scoped operation passes through, not copied per resolver
- An unverified session can still call the operations behind `/account/email`
- A Playwright spec shows an unverified account signed in on the email page and unable to read a coven it belongs to
- `claude-docs/auth/admin-bootstrap.md` ("The email page") states that the rule covers the API

**MB.282 — The GraphQL Endpoint Refuses Cross-Site Requests** · 3h

_Story:_ As a signed-in user, I want `/api/graphql` to accept a request only when it plainly came from this site's own pages, so that another website cannot cause my browser to change my data using my session.

The session cookie is `SameSite=Lax`, which already stops most cross-site sends, but it is one line of defence and depends on the browser. This task adds a second one at the endpoint, chosen to fit GraphQL Yoga (the GraphQL server library): refuse mutations that do not arrive as `application/json`, and additionally require either a custom request header the site's own client sends or a matching `Origin` header. The task states which it chose and why, and checks that Altair (the in-browser query tool at `/api/graphql` in development) and the generated client still work (`me`, `setEmail` and sign-out at least).

Found on 2026-10-30 in a security review of the repository. A wrong result, always, under Sign-in & Account. Steps to reproduce: not applicable; this is a finding from reading the endpoint's configuration.

Actual: the endpoint relies on the cookie's `SameSite` attribute alone. Expected: a request that does not meet the second check is refused before any resolver runs.

_Acceptance criteria:_

- A regression test that fails before the fix: a mutation sent with a form content type, and one sent without the required header or `Origin`, are each refused with no resolver run and no row written, while the same mutation sent as the site's client sends it succeeds
- Queries made by server components and by the generated client are unaffected, shown by the existing tests passing
- Altair still works in development
- `claude-docs/` records the choice, the alternatives and the reason in `claude-docs/design-decisions/`

**MB.283 — An Email Change Needs a Recent Sign-in and Tells the Old Address** · 4h

_Story:_ As an account holder, I want changing my email address to need a recent sign-in, and the old address to be told when a change is requested, so that a session left open on a borrowed device cannot quietly move my account to another address.

`setEmail` mails the new address a verification link and swaps the address when the link is followed (`claude-docs/auth/admin-bootstrap.md`). It does not ask whether the session is recent, and it does not tell the current address. This task refuses the change when the session was created longer ago than a stated window (Better Auth's `freshAge` setting is the likely tool) with an explaining error that sends the person to sign in again, and mails the current address when a change is requested and again when it completes.

Found on 2026-10-30 in a security review of the repository. A wrong result, always, under Sign-in & Account. Steps to reproduce: not applicable; this is a finding from reading `setEmail`.

Actual: an old session can request a change and the old address hears nothing. Expected: an old session is refused, and the old address is mailed on request and on completion.

_Acceptance criteria:_

- A regression test that fails before the fix: `setEmail` on a session older than the window is refused with an explaining error, and the same call on a fresh session succeeds (the precondition that the change could have gone through)
- A request mails the current address once, naming the time and the new address's domain only, and the mail contains no link that completes or cancels the change by itself
- Completion mails the old address once
- The window is a named constant, stated in `claude-docs/auth/admin-bootstrap.md`, and the account page's email section tells the person to sign in again when the error is returned
- The mail follows the mail design rules in `claude-docs/`

**MB.284 — Changing an Email Address Answers the Same Whether or Not It Is Taken** · 2h

_Story:_ As an account holder, I want `setEmail` to give the same answer for any new address, so that the form cannot be used to learn which addresses already belong to an account.

Today `setEmail` answers differently when the requested address already belongs to a verified account. This task makes the visible answer identical in both cases ("If that address can be used, a link is on its way"), and does the real difference silently: a free address gets the verification mail, and an address that is held by a verified account gets nothing, or a short mail to that address's owner saying a change to it was attempted (the task chooses and states which). The time taken to answer should not differ noticeably either.

Found on 2026-10-30 in a security review of the repository. A wrong result, always, under Sign-in & Account. Steps to reproduce: not applicable; this is a finding from reading `setEmail`.

Actual: the answers differ. Expected: they match.

_Acceptance criteria:_

- A regression test that fails before the fix: `setEmail` with an address that is held by a verified account and with a free address return the same result shape and message
- The same test shows the difference is real: the free address received the verification mail and the held one did not
- No mail is sent to the held address's owner containing a link
- `claude-docs/auth/admin-bootstrap.md` states that the two cases answer alike

**MB.285 — Compendium Entries Stay Pending After the Citation Wording Changed** · 4h

_Story:_ As a curator, I want each Wikipedia source in the compendium stored once, under the key the seed builds today, so that the deploy's seed run reports only real changes and no entry cites the same source twice.

The compendium seed finds an existing source by its `seed_key`: the source's citation rendered as text by `citationText` (`src/lib/citation.ts`). Commit 2aa282b51 changed a Wikipedia citation's wording from `Wikipedia, s.v. "X."` to `Wikipedia, under "X."`, and no migration rewrote the stored keys. Since then every seed run fails to find a source stored under the old wording and treats it as missing. On staging, 25 approved entry files that nobody marked for update (`seedUpdate`) show `differs: references` and are reported as pending on every run. Wherever an entry was marked for update, and wherever the vocabulary sources seed (`src/db/seed/sources.ts`) ran, a second "under" copy of the source was inserted beside the old one. That leaves old `s.v.` rows with no links, sources whose links are split across both rows (Asafoetida, Beryl), and deities whose sources (Agwu Nsi, for example) have two linked rows, so each such deity cites the same source twice. The commit is on `main`, so production very likely holds the same rows.

The fix is a forward data migration over compendium `references` rows (those with no workspace) whose `seed_key` holds the old wording. Where no live row already has the new key, it rewrites the key in place. Where one does (a twin), it moves the old row's live links to the twin, soft-deletes (marks deleted rather than removes) any link that would then be a duplicate, and soft-deletes the old row.

Found on 2026-10-30, in the staging Deploy workflow's seed output and with read-only queries on staging; wrong result, every run. Steps to reproduce:

1. Push any change to `staging`.
2. The Deploy workflow's `migrate` job runs the reference seed.
3. Read the seed's output.

Actual: 25 entries are reported as pending with `differs: references` on every run.
Expected: an unchanged entry file is skipped.

_Acceptance criteria:_

- Regression tests in `tests/db/`, written first and failing before the fix, cover the three cases the migration handles for a compendium source whose `seed_key` has the old wording: with no twin, the key is rewritten in place and the row keeps its id and links; with a twin and no links on the old row, the old row is soft-deleted; with links on both rows, the old row's links move to the twin, a link that would duplicate one already there is soft-deleted, and the old row is soft-deleted.
- After the migration, the seed decides `skip`, not `pending`, for an approved, unmarked entry whose only difference was the old wording.
- No live compendium source has `, s.v. ` in its `seed_key`, and the partial unique index on `seed_key` holds.
- Links from `needs-review` entries follow the source they point to.
- Workspace references are not touched.
- Docs: `claude-docs/db/references.md` says that a change to the citation wording needs a migration that rewrites the stored keys.

**MB.286 — Seven Cosmetic Faults in Loading, Spell Preview and Quick Look** · 7h

_Story:_ As a coven member, I want each screen to show only what belongs to it, in full, so that a loading page, the spell preview pane and Quick Look never show stale or clipped things.

Seven cosmetic faults, reported together:

- A. Clicking an ingredient card leaves the card's green pending dot (`LinkHint`, `src/components/LinkHint/`) pulsing over the ingredients loading skeleton.
- B. In the spell preview pane on a phone, the Screen Awake eye's tip opens under the camera cutout.
- C. The Quick Look eye in the spell page's In the Cupboard panel is too small to read or press easily.
- D. After a switch from the demo coven to another coven, the demo warning stays on screen while the other coven loads.
- E. The loading skeleton for the spells page (the Grimoire) does not match the page it stands in for.
- F. The loading skeleton for a single spell's page, and the Grimoire skeleton's filter row, do not match the pages they stand in for.
- G. On the list pages (the Grimoire and the Ingredients list at least), the loading skeleton's filter row sits lower than the loaded page's.

Found on 2026-10-31 on staging; cosmetic, every time. Steps to reproduce:

A. Phantom dot

1. Sign in as a coven member.
2. Open the coven's Ingredients list.
3. Click an ingredient card.

Actual: the card's green pending dot shows, pulsing, over the loading skeleton.
Expected: the dot goes with the card; the skeleton shows alone.

B. Eye tip under the cutout

1. On a phone with a camera cutout, open a spell and press Preview.
2. Touch the Screen Awake eye (assumed: the pane is full screen).

Actual: the tip opens under the camera cutout.
Expected: the tip shows in full, clear of the cutout.

C. Quick Look eye too small

1. Open a spell's page in a coven that holds stock.
2. Look at the Quick Look eye on a line of the In the Cupboard panel.

Actual: the eye is drawn smaller than the Quick Look eye elsewhere.
Expected: the eye is the Quick Look eye's usual size, and the panel's lines stay aligned.

D. Demo warning while switching

1. Sign in with seats in the demo coven and another coven.
2. Open the demo coven.
3. Switch to the other coven with the coven switcher.

Actual: the demo warning stays on screen while the other coven loads.
Expected: the warning goes as soon as the switch starts.

E. Grimoire skeleton

1. Open a coven's Grimoire from another section of the coven.
2. Watch the skeleton while the page loads, and again on switching from Spells to Drafts.

Actual: the skeleton draws the Ingredients cards placeholder: each card is about 204px tall with an ingredient card's bars, where a loaded spell card is about 157px.
Expected: the skeleton has the loaded page's shape.

F. Spell page skeleton and the Compact switch

1. Open a spell from the Grimoire list.
2. Watch the skeleton while the spell's page loads.
3. Open the Grimoire from another section and look at the skeleton's filter row.

Actual: the spell page shows the generic page skeleton, three plain blocks (assumed: found from the code, not yet seen in a browser). The Grimoire skeleton's filter row has no Compact switch.
Expected: the spell page skeleton has the loaded page's shape: the back link, the title row, the Workings menu and both columns. The filter row has the Compact switch's place.

G. Filter row lower in the skeleton

1. Open a coven's Grimoire, or its Ingredients list, from another section of the coven.
2. Compare the skeleton's filter row with the loaded page's.

Actual: the skeleton's filter row sits lower than the loaded row: about 24px lower at 1280px wide and about 80px lower at 375px on the Grimoire, measured in Playwright.
Expected: the skeleton's filter row sits where the loaded row does.

_Acceptance criteria:_

- Each of the seven has a regression test that fails before its fix and passes after.
- A: while a page is held under the loading skeleton, the pending dot is not visible.
- B: on a phone viewport, the Screen Awake tip's box lies inside the visible area, clear of the safe-area insets.
- C: the Quick Look eye in the In the Cupboard panel renders at the Quick Look eye's usual size, set from the tokens, at desktop and phone widths.
- D: once a switch away from the demo coven starts, the demo warning is not shown; a switch into the demo coven shows no stale state from the coven left behind.
- E: the skeleton shown while the Grimoire loads has the loaded page's shape: its placeholder cards match the real cards' size and the grid's columns, at desktop and phone widths.
- F: the skeleton shown while a spell's page loads has the loaded page's regions in their places, and the Grimoire skeleton's filter row holds a Compact switch placeholder, at desktop and phone widths.
- G: on every list page whose skeleton draws a filter row, the row sits where the loaded page's row does, at desktop and phone widths.
- Docs: `claude-docs/components/link-hint.md`, `claude-docs/components/spell-preview.md` and the Quick Look and demo coven docs describe the behaviour after the fix.

**MB.287 — A Production Deploy Rerun Fails at the Neon Snapshot** · 2h

_Story:_ As the owner deploying a release, I want a rerun of a production deploy to get past the snapshot step, so that I can retry a deploy without the snapshot blocking it.

Before migrating production, `.github/workflows/migrate.yml` ("Snapshot production before migrating") branches Neon's `main` branch as `snapshot-<short sha>`. Rerunning a deploy runs the same commit, so the step tries to create a branch that the first attempt already made. Neon refuses, and because the call uses `curl -sf`, the step exits with code 22 and the log never shows Neon's error message. The migration and the deploy are then skipped.

Found on 2026-11-02, on run 41414386584 (the push to `main` for release 0.11.0, commit 1566b6d). Steps to reproduce:

1. Merge a release PR into `main` (PR #1473).
2. The Deploy workflow runs. Attempt 1 passes, and its snapshot step creates `snapshot-1566b6d`.
3. Rerun the same Deploy run.

Actual: attempts 2, 3 and 4 fail at the snapshot step with exit code 22, the log has no Neon error message, and the deploy job is skipped.
Expected: the rerun keeps `snapshot-1566b6d`, then migrates and deploys. Any Neon call that is refused logs Neon's error message.

_Acceptance criteria:_

- A regression test runs the snapshot step's script from `migrate.yml` against a stub `curl` whose branch list already holds `snapshot-<short sha>`. It fails before the fix and passes after it.
- When `snapshot-<short sha>` already exists, the step exits 0, creates no branch, and the job summary says the snapshot was kept.
- When no snapshot branch exists, the step creates `snapshot-<short sha>` from `main`, as it does today.
- When a Neon call is refused, the step fails and the log carries Neon's response body.
- `claude-docs/ci/neon-snapshots.md` describes what a rerun does.

**MB.288 — Bug Bash 2026-11-02: Ingredient Edits, the Formal Name Eyebrow and the Terms Screens** · 6.5h

_Story:_ As a curator, coven steward or site keeper, I want ingredient edits to save, the entry page to stay clean, and the terms screens to show their state, so that I can trust what I change and see what users agreed to.

Six items found in one bug bash, kept in one task at the owner's request. A: in the edit form (`src/components/IngredientForm/`), changing an entry's classification to None blocks the save. B: the curator's Visible switch (`src/components/IngredientEntry/shown-toggle.tsx`) saves one change but loses a second change made straight after it. C: the formal name eyebrow (`src/components/IngredientEntry/formal-name.tsx`) prints "None" for an entry classified None with no formal name, where it should draw nothing. D: the admin user table and user modal do not show which terms version a user agreed to most recently; this is new display work, not a fault. E: the Agree button on the terms page (`src/components/TermsAgreement/index.tsx`) shows no loading state while its save runs. F: the entry page's Back link, from an entry opened in the admin compendium list (`/admin/compendium`), goes to the public compendium (`/compendium`) instead of back to the admin list (`src/components/IngredientEntry/back-link.tsx`, which takes the previous list from `window.navigation` through `listReturnHref` in `back-href.ts`, and the callers that pass `href`/`also` for a compendium entry).

F was found on 2026-11-03, locally, signed in as a site keeper. The rest were found on 2026-11-02 on a local dev server, every time, signed in as a site keeper and as a coven steward. Steps to reproduce:

- A. Open an entry's edit form, change Classification to None, press Save. Actual: the save does not go through. Expected: the entry saves with classification None.
- B. As a curator or keeper, open an entry's details, turn Visible off, then straight away back on (order assumed), and reload. Actual: the off saved and the on did not. Expected: the last position saves, however quickly it was changed.
- C. Open an ingredient page classified None with no formal name. Actual: the eyebrow reads "None" with its label and tip. Expected: no eyebrow.
- D. As a site keeper, open Admin › People, look at the table, then open a user's modal. Actual: neither shows a terms version. Expected: both show the latest version the user agreed to.
- E. As an account that has not agreed to the current terms, press Agree. Actual: no spinner. Expected: the standard loading spinner, and a second press is refused.
- F. Sign in as a site keeper, open `/admin/compendium`, open an entry from the list and press the Back link. Actual: it goes to `/compendium`. Expected: it goes back to `/admin/compendium`, with its filters.

A was not reproduced on 2026-11-03. The owner had seen it on the Unknown Beeswax, a hidden compendium entry with a picked Wax form, and it no longer happens. A separate agent could not reproduce it in component, service or browser tests either.

_Acceptance criteria:_

- B, C, E and F each start with a regression test that fails before its fix.
- A: saving an entry with classification None succeeds, and the entry reads back as None. A was not reproduced (see below), so there is no fix and no test that fails first; acceptance tests prove that a reclassification to None saves, from the admin list, from the entry page pencil and in a coven.
- B: two quick changes to the Visible switch leave the entry in the second position after a reload.
- C: an entry classified None with no formal name draws no formal name list, label or tip on the entry page or in the details modal head.
- D: the admin user table and the user modal show the latest terms version each user agreed to, and show that a user who never agreed has not; the read goes through the admin service behind `assertSiteAdmin`.
- E: while the agreement save runs, the Agree button shows the standard spinner, and a second press sends no second request.
- F: from the admin compendium, the entry's Back link returns to `/admin/compendium` with its query. From the public compendium, and with no history, it still returns to `/compendium`.
- `claude-docs/components/ingredient-entry.md`, "Structure", no longer says the formal name is never blank.

**MB.289 — Crawlers Hit Blocked Links and Index Few Compendium Pages** · 6.5h

_Story:_ As someone looking for a compendium entry through a search engine, I want every public page in the sitemap to be crawlable and indexable, so that I can find the entry from a search.

Found on 2026-11-03 on production, on every scan. Bing Webmaster Tools' Site Scan reports `ERROR : Blocked by robots.txt` on `/account/terms` and `/?support=`, and finds 174 pages; Google indexes 74; the sitemap lists 529 public URLs. The causes:

- The Support link (`src/components/SupportLink/`) adds `?support=` to the current page's address, so every page links to a copy of itself. On the home page that copy is `/?support=`, which `robots.txt` blocks, because `Allow: /$` matches `/` and nothing after it.
- The published Terms of Use document links to the acceptance page, `/account/terms`. `robots.txt` blocks it, and a signed-out visitor is redirected from it to sign-in, which is marked noindex.
- The compendium list is split into pages of 24 entries. The pages after the first (`/compendium?after=…`) name `/compendium` as their canonical address (the address a search engine should treat as the page's real one), so crawlers treat them as copies of page 1. Each `/compendium?entry=…` link, which opens an entry in a dialog, also names `/compendium` as its canonical, not the entry's own page.
- The proxy (`src/proxy.ts`) marks `?after=` and `?before=` pages `noindex, follow`, so a search engine may index none of the list's later pages.
- `robots.txt` blocks `/_next/`, so Google renders pages without their CSS, JavaScript and images, and `/opengraph-image`, the home page's share image.
- Each site document has a page per published version, such as `/terms/versions/1`. These pages carry the generic site title and no canonical, so the current version's page is an unmarked copy of `/terms`. No page links to them while a document has one version; once it has two, the document page lists them.

Steps to reproduce:

1. Open Bing Webmaster Tools for the production site.
2. Run a Site Scan of the production site.
3. Open the scan's errors.
4. Open Google Search Console's Pages report for the same site.

Actual: Site Scan reports `ERROR : Blocked by robots.txt` on `/account/terms` and `/?support=`, and finds 174 pages. Google indexes 74 pages. The sitemap lists 529 URLs, all public.
Expected: Site Scan reports no robots.txt errors, because no public page links to a URL that `robots.txt` blocks. Every URL in the sitemap can be crawled and indexed (assumed): each page of the compendium list names itself as canonical, and the sitemap lists no noindex page.

_Acceptance criteria:_

- A regression test fails before the fix and passes after it, for each cause above.
- Every Support link carries `rel="nofollow"`.
- Each `/compendium?after=…` page names its own address, cursor included, as its canonical.
- Each `/compendium?entry=…` address names the entry's page, `/compendium/ingredients/<slug>`, as its canonical.
- A link from a site document to `/account/terms` carries `rel="nofollow"`, so a crawler does not fetch it.
- `/account/terms` is marked `noindex, nofollow`. `robots.txt` keeps blocking `/account`, and a signed-in account still gets the acceptance page exactly as it does today.
- `robots.txt` allows `/_next/`, which holds only the site's build files, and `/opengraph-image`.
- Each document version page has its own title naming the document and version number. The current version's page names the document page (for example `/terms`) as its canonical; an older version's page names itself.
- `/compendium?after=…` and `?before=…` responses carry no noindex header, and `?entry=` and `?support=` still do.
- The comments in `src/app/robots.ts` and `src/app/sitemap.ts` describe the new allowed paths and the sitemap's contents, and `claude-docs/components/support-link.md` names the `nofollow`.

**MB.290 — Renaming or Deleting a Celestial Body or Zodiac Sign Misses Compendium Variants** · 3h

_Story:_ As a site keeper, I want renaming a celestial body or zodiac sign to update every compendium variant that holds it, and deleting one to be refused while a variant holds it, so that a compendium entry never holds a value missing from the curated lists and still saves afterwards.

Since MB.215 each compendium variant carries its own `celestial_bodies` and `zodiac_signs` lists, and the compendium save checks them against the curated rows (`src/modules/ingredients/services/compendium.ts`, `curatedSpellings`), as DESIGN.md §5's MB.162 rule requires ("and each variant's"). Two paths read the ingredient's own lists only. `carryAstrologyRename` (`src/db/repository/write.ts`) rewrites the ingredient's lists and not its variants', so a variant keeps the old spelling. The delete check behind `deleteAstrologyValue` (`refuseWhileHeld` in `src/modules/vocabulary/services/held-entries.ts`, reaching `listArm` in `src/db/repository/ingredients.ts`) reads the ingredient's lists only, where `elementArm` beside it also checks live variants, so a celestial body or sign that only a variant holds can be deleted. Either way a variant ends up holding a value no curated row has, and the entry's next save is refused. No decision record leaves variants out on purpose.

Found on 2026-11-03 by reading the code during MB.163's review, not seen on any environment; it happens on every rename or delete of a value a variant holds. Signed in as a site keeper, Admin & Compendium. Steps to reproduce:

1. Sign in as a site keeper.
2. Open a compendium entry for editing, give one of its variants a celestial body, for example Mars, that the entry's own list does not hold, and save.
3. Open the Celestial Bodies admin page and rename Mars, for example to Mars Planet, and save.
4. Reopen the compendium entry for editing.
5. Press Save without changing anything.

Actual: the variant's Celestial Bodies list still reads Mars, and Save is refused on that variant. Expected: the variant reads Mars Planet, and Save succeeds. The same happens for a zodiac sign. Deleting Mars in step 3 instead of renaming it is not refused, where it should be.

_Acceptance criteria:_

- A regression test fails before the fix: after a celestial body rename and after a zodiac sign rename, a live compendium variant holding the old spelling holds the new one, asserted by row.
- A regression test fails before the fix: deleting a celestial body or zodiac sign that only a live compendium variant holds is refused, naming the entry.
- The rename keeps every other value in the variant's list, in its order.
- A coven's variants are never rewritten and never block a delete, asserted by row.
- A deleted variant, or a variant of a deleted entry, neither blocks a delete nor is rewritten.
- DESIGN.md §5's MB.162 paragraph says the rewrite and the delete check both cover the variants' lists.
- The compendium's Celestial Body and Zodiac Sign filters, and their facet counts, match an entry whose live variant holds the value, as the Element filter does; a deleted variant's value does not match, asserted by a test that fails before the change.
```
